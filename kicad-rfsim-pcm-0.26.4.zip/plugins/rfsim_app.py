"""RF Sim – the program window started by the single "RF Sim" toolbar button.

One window with four pages, like a KiCad tool:
  Setup      read the PCB selection, create the simulation setups, model preview
  Simulate   choose setups, start/stop, progress (run k of n, remaining time, energy decay), log
  Results    antenna reports, tuning viewers and "how this was solved", shown inside the window;
             "Apply to board" in the tuning viewer writes the values to the footprints
  Settings   solver settings per setup (automatic or custom) with defaults and meaning; openEMS path

The window uses wxPython (the toolkit KiCad itself is built with). Pressing the
toolbar button again brings an open window to the front instead of starting a
second one.
"""
from __future__ import annotations

import hashlib
import json
import os
import socket
import sys
import threading
import time
import traceback
from pathlib import Path

import wx
import wx.lib.newevent

try:
    import wx.html2 as webview
except Exception:  # pragma: no cover - wx without webview
    webview = None
import wx.propgrid as wxpg

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import rfsim_common as common  # noqa: E402
import rfsim_core as core  # noqa: E402

APP_NAME = "RF Sim"
PAD = 6  # KiCad dialogs use small, even spacing


# ---------------------------------------------------------------------------
# one window per board: a second start for the same board brings its window to the front,
# a start from another KiCad instance or for another board opens its own window
# ---------------------------------------------------------------------------
def _port_file(board) -> Path:
    try:
        key = str(Path(board.get_project().path) / board.name)
    except Exception:  # noqa: BLE001
        key = str(getattr(board, "name", "board"))
    h = hashlib.sha1(os.path.normcase(os.path.abspath(key)).encode("utf-8")).hexdigest()[:12]
    return common.APP_DIR / f"app-{h}.port"


def _ask_running_instance(port_file: Path) -> bool:
    try:
        port = int(port_file.read_text())
        with socket.create_connection(("127.0.0.1", port), timeout=0.5) as s:
            s.sendall(b"raise")
            return s.recv(2) == b"ok"
    except Exception:
        return False


def _serve_raise(frame: wx.Frame, port_file: Path):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(2)
    common.APP_DIR.mkdir(parents=True, exist_ok=True)
    port_file.write_text(str(srv.getsockname()[1]))
    frame._port_file = port_file

    def loop():
        while True:
            try:
                c, _ = srv.accept()
                with c:
                    if c.recv(16) == b"raise":
                        c.sendall(b"ok")
                        wx.CallAfter(frame.bring_to_front)
            except Exception:
                return
    threading.Thread(target=loop, daemon=True).start()
    return srv


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def _fmt_s(s) -> str:
    if s is None:
        return "estimating ..."
    s = float(s)
    if s < 90:
        return f"{s:.0f} s"
    if s < 5400:
        return f"{s / 60:.0f} min"
    return f"{s / 3600:.1f} h"


def _box(parent, label: str, orient=wx.VERTICAL):
    sb = wx.StaticBoxSizer(orient, parent, label)
    return sb, sb.GetStaticBox()


def _wrap(text: str, cols: int) -> str:
    """Line-wrap ``text`` at ``cols`` characters, breaking long words (paths) too: a label with a line
    that cannot wrap gets so wide that it pushes the neighbouring panels out of the window."""
    import textwrap
    out = []
    for line in text.splitlines() or [""]:
        ind = len(line) - len(line.lstrip(" "))
        out += textwrap.wrap(line, cols, subsequent_indent=" " * ind, break_long_words=True,
                             break_on_hyphens=False) or [""]
    return "\n".join(out)


def _keep_scroll(win):
    """A scrolled column: refit its scroll range when the window is resized (small windows keep all
    buttons reachable)."""
    def fit():
        if win:
            win.Layout()
            win.FitInside()
    win.Bind(wx.EVT_SIZE, lambda e: (e.Skip(), wx.CallAfter(fit)))


def _hint(parent, text: str) -> wx.StaticText:
    t = wx.StaticText(parent, label=text)
    t.SetForegroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT))
    return t


def _warn_colour():
    return wx.Colour(196, 82, 27)


def _icon_bundle() -> wx.IconBundle:
    ib = wx.IconBundle()
    for n in ("rfsim-24.png", "rfsim-48.png"):
        p = HERE / "icons" / n
        if p.exists():
            ib.AddIcon(wx.Icon(str(p), wx.BITMAP_TYPE_PNG))
    return ib


class ImagePanel(wx.Panel):
    """Shows a picture scaled to the panel (keeps the aspect ratio)."""

    def __init__(self, parent):
        super().__init__(parent, style=wx.FULL_REPAINT_ON_RESIZE)
        self.SetBackgroundStyle(wx.BG_STYLE_PAINT)
        self._img: wx.Image | None = None
        self.Bind(wx.EVT_PAINT, self._paint)

    def set_file(self, path: Path | None):
        self._img = None
        if path and Path(path).exists():
            im = wx.Image(str(path))
            self._img = im if im.IsOk() else None
        self.Refresh()

    def _paint(self, _e):
        dc = wx.AutoBufferedPaintDC(self)
        dc.SetBackground(wx.Brush(self.GetBackgroundColour()))
        dc.Clear()
        if self._img is None:
            return
        w, h = self.GetClientSize()
        iw, ih = self._img.GetWidth(), self._img.GetHeight()
        s = min(w / iw, h / ih, 3.0)
        if s <= 0:
            return
        bw, bh = max(1, int(iw * s)), max(1, int(ih * s))
        dc.DrawBitmap(wx.Bitmap(self._img.Scale(bw, bh, wx.IMAGE_QUALITY_HIGH)), (w - bw) // 2, (h - bh) // 2)


class Worker:
    """Runs a function in a thread; results come back on the GUI thread."""

    def __init__(self, frame):
        self.frame = frame
        self.busy = False

    def run(self, fn, done=None, fail=None):
        if self.busy:
            wx.Bell()
            return False
        self.busy = True
        self.frame.set_busy(True)

        def body():
            try:
                r = fn()
            except Exception as e:  # noqa: BLE001
                tb = traceback.format_exc()
                wx.CallAfter(self._end, fail, e, tb)
                return
            wx.CallAfter(self._end, done, r, None)
        threading.Thread(target=body, daemon=True).start()
        return True

    def _end(self, cb, value, tb):
        self.busy = False
        self.frame.set_busy(False)
        if tb is not None:
            if cb:
                cb(value, tb)
            else:
                self.frame.show_error(value, tb)
        elif cb:
            cb(value)


# ---------------------------------------------------------------------------
# Setup page
# ---------------------------------------------------------------------------
class BandRow:
    """Operating band: preset choice + editable MHz ranges (one definition for all setups of a board)."""

    def __init__(self, parent, sizer, cols=58, inline=False, extra=None, on_change=None):
        self._changed = on_change
        from kicad_rfsim.bands import OPERATING
        self._ops = OPERATING
        self.cols = cols
        row = wx.BoxSizer(wx.HORIZONTAL)
        row.Add(wx.StaticText(parent, label="Band:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.choice = wx.Choice(parent, choices=[lab for lab, _r in OPERATING] + ["Custom (enter MHz)"])
        self.choice.SetMinSize((120, -1))
        self.choice.SetToolTip("Operating band: sets the frequencies of all setups of this board")
        row.Add(self.choice, 1 if not inline else 0, wx.EXPAND)
        row2 = row if inline else wx.BoxSizer(wx.HORIZONTAL)
        row2.Add(wx.StaticText(parent, label="MHz:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT | wx.LEFT,
                 PAD if inline else 0)
        self.text = wx.TextCtrl(parent, size=(220, -1) if inline else wx.DefaultSize)
        self.text.SetToolTip("Ranges in MHz, e.g. 2400-2483.5 or 863-870, 2400-2483.5 (dual band)")
        row2.Add(self.text, 0 if inline else 1, wx.EXPAND)
        if extra is not None:
            row2.AddStretchSpacer()
            row2.Add(extra, 0, wx.LEFT, PAD)
        sizer.Add(row, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, PAD)
        if not inline:
            sizer.Add(row2, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, PAD)
        self.hint = _hint(parent, "")
        sizer.Add(self.hint, 0, wx.LEFT | wx.RIGHT | wx.TOP, PAD)
        self.choice.Bind(wx.EVT_CHOICE, self._on_choice)
        self.text.Bind(wx.EVT_TEXT, self._on_text)
        self._why = ""

    def set(self, ranges, why: str = ""):
        from kicad_rfsim.bands import format_ranges
        self._why = why
        self.text.ChangeValue(format_ranges(ranges) if ranges else "")
        self._on_text(None)

    def ranges(self):
        from kicad_rfsim.bands import parse_ranges
        return parse_ranges(self.text.GetValue())

    def _on_choice(self, _e):
        from kicad_rfsim.bands import format_ranges
        i = self.choice.GetSelection()
        if 0 <= i < len(self._ops):
            self.text.ChangeValue(format_ranges(self._ops[i][1]))
        self._why = ""
        self._on_text(None)

    def _on_text(self, _e):
        from kicad_rfsim.bands import label_of
        try:
            r = self.ranges()
        except ValueError as ex:
            self.choice.SetSelection(wx.NOT_FOUND)
            empty = not self.text.GetValue().strip()
            self.hint.SetLabel(_wrap("Choose a band or enter MHz ranges, e.g. 2400-2483.5" if empty else str(ex),
                                     self.cols))
            return
        if self._changed:
            self._changed()
        lab = label_of(r)
        labs = [l for l, _r in self._ops]
        self.choice.SetSelection(labs.index(lab) if lab in labs else len(labs))
        self.hint.SetLabel(_wrap(core.band_summary(r), self.cols))


class SetupPage(wx.Panel):
    ANT_MODES = ["Detect automatically", "Define antenna", "No antenna (RF chain only)",
                 "Antenna board (own KiCad project, soldered in)"]
    GROUND_MODES = ["auto", "below", "side"]
    LEFT_W = 400  # px, width of the left column

    def __init__(self, parent, app: "RfSimFrame"):
        super().__init__(parent)
        self.app = app
        main = wx.BoxSizer(wx.HORIZONTAL)

        # left column: fixed width, scrolls when tall - long texts (paths, reasons) never push the model view off
        self.lpanel = lp = wx.ScrolledWindow(self, style=wx.VSCROLL)
        lp.SetScrollRate(0, 12)
        left = wx.BoxSizer(wx.VERTICAL)
        sb, box = _box(lp, "Selection in the PCB editor")
        sb.Add(_hint(box, "Select the matching parts (e.g. Z1, Z2, Z3) and the antenna."), 0, wx.ALL, PAD)
        self.sel = wx.ListCtrl(box, style=wx.LC_REPORT | wx.LC_SINGLE_SEL, size=(-1, 120))
        self.sel.InsertColumn(0, "Selected", width=150)
        self.sel.InsertColumn(1, "Kind", width=120)
        sb.Add(self.sel, 1, wx.EXPAND | wx.LEFT | wx.RIGHT, PAD)
        self.b_read = wx.Button(box, label="Read Selection")
        sb.Add(self.b_read, 0, wx.ALL, PAD)
        left.Add(sb, 0, wx.EXPAND | wx.BOTTOM, PAD)

        sa, abox = _box(lp, "Antenna")
        self.ant_mode = wx.Choice(abox, choices=self.ANT_MODES)
        self.ant_mode.SetSelection(0)
        sa.Add(self.ant_mode, 0, wx.EXPAND | wx.ALL, PAD)
        self.ant_found = wx.StaticText(abox, label="")
        sa.Add(self.ant_found, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        grid = wx.FlexGridSizer(3, 2, PAD, PAD)
        grid.AddGrowableCol(1)
        self.ant_net = wx.Choice(abox)
        self.ant_feed = wx.Choice(abox)
        self.ant_gnd = wx.Choice(abox, choices=["automatic", "ground plane below the pad", "ground beside the pad"])
        self.ant_gnd.SetSelection(0)
        for lab, w in (("Antenna net:", self.ant_net), ("Feed pad:", self.ant_feed), ("Feed to ground:", self.ant_gnd)):
            t = wx.StaticText(abox, label=lab)
            grid.Add(t, 0, wx.ALIGN_CENTER_VERTICAL)
            grid.Add(w, 1, wx.EXPAND)
        self.user_grid = grid
        sa.Add(grid, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        bg = wx.FlexGridSizer(4, 2, PAD, PAD)
        bg.AddGrowableCol(1)
        self.ab_fp = wx.Choice(abox)
        self.ab_file = wx.FilePickerCtrl(abox, message="Antenna board (.kicad_pcb)", wildcard="KiCad board|*.kicad_pcb",
                                         style=wx.FLP_OPEN | wx.FLP_FILE_MUST_EXIST | wx.FLP_USE_TEXTCTRL)
        self.ab_in = wx.Choice(abox)
        self.ab_feed = wx.Choice(abox)
        for lab, w, tip in (("Footprint:", self.ab_fp, "footprint whose 3D model is the antenna board"),
                            ("Antenna board:", self.ab_file, "the antenna's own .kicad_pcb (exact copper and stackup)"),
                            ("Input pad (antenna):", self.ab_in, "pad of the antenna board soldered to the feed - "
                                                                 "joined directly to the feed pad of this board"),
                            ("Feed pad (this board):", self.ab_feed, "pad of this board where the RF chain ends")):
            t = wx.StaticText(abox, label=lab)
            t.SetToolTip(tip)
            w.SetToolTip(tip)
            bg.Add(t, 0, wx.ALIGN_CENTER_VERTICAL)
            bg.Add(w, 1, wx.EXPAND)
        self.board_grid = bg
        sa.Add(bg, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        self.ab_hint = _hint(abox, "Position from the footprint's 3D model, checked against its STEP.\n"
                                   "Check / correct it on the Casing & 3D page.")
        sa.Add(self.ab_hint, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        self.ant_trace = wx.CheckBox(abox, label="Feed on the selected antenna trace")
        self.ant_trace.SetToolTip("Feed on the selected trace where it leaves the last matching pad. "
                                  "Without it the feed is a port at the feed pad.")
        sa.Add(self.ant_trace, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        orow = wx.BoxSizer(wx.HORIZONTAL)
        orow.Add(wx.StaticText(abox, label="Offset along the trace:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.ant_off = wx.SpinCtrlDouble(abox, min=0.0, max=20.0, inc=0.1, size=(80, -1))
        self.ant_off.SetDigits(2)
        self.ant_off.SetToolTip("Move the feed this far (mm) from the pad towards the antenna")
        orow.Add(self.ant_off, 0, wx.RIGHT, PAD)
        orow.Add(wx.StaticText(abox, label="mm"), 0, wx.ALIGN_CENTER_VERTICAL)
        sa.Add(orow, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        self.band = BandRow(abox, sa, on_change=lambda: wx.CallAfter(self._fit_left))
        self.b_create = wx.Button(abox, label="Create Setup from Selection")
        self.b_create.SetDefault()
        sa.Add(self.b_create, 0, wx.ALL, PAD)
        left.Add(sa, 0, wx.EXPAND | wx.BOTTOM, PAD)

        sb2, box2 = _box(lp, "Simulation setups")
        self.cfgs = wx.ListCtrl(box2, style=wx.LC_REPORT | wx.LC_SINGLE_SEL)
        for i, (t, w) in enumerate((("Setup", 115), ("Details", 175), ("Last result", 70))):
            self.cfgs.InsertColumn(i, t, width=w)
        sb2.Add(self.cfgs, 1, wx.EXPAND | wx.ALL, PAD)
        self.b_mesh = wx.Button(box2, label="Inspect Mesh")
        self.b_mesh.SetToolTip("Show the model on its mesh as the next run builds it (no simulation)")
        sb2.Add(self.b_mesh, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        left.Add(sb2, 1, wx.EXPAND)
        self.cfgs.SetMinSize((-1, 110))
        lp.SetSizer(left)
        lp.SetMinSize((self.LEFT_W, -1))
        lp.SetMaxSize((self.LEFT_W, -1))
        _keep_scroll(lp)  # texts change length too: _fit_left after those changes
        main.Add(lp, 0, wx.EXPAND | wx.ALL, PAD)

        sb3, box3 = _box(self, "Model")
        srow = wx.BoxSizer(wx.HORIZONTAL)
        srow.Add(wx.StaticText(box3, label="Show:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.show = wx.Choice(box3, choices=["RF chain (ports)", "Antenna (copper, ground beneath, feed)"])
        self.show.SetSelection(0)
        srow.Add(self.show, 0, wx.RIGHT, PAD * 3)
        self.b_kicad = wx.Button(box3, label="Show in KiCad")
        self.b_kicad.SetToolTip("Select the shown ports / antenna parts in the PCB editor (replaces the selection)")
        srow.Add(self.b_kicad, 0)
        sb3.Add(srow, 0, wx.ALL, PAD)
        prow = wx.BoxSizer(wx.HORIZONTAL)
        self.port_lbl_in = wx.StaticText(box3, label="Input port:")
        self.p_in = wx.Choice(box3, size=(110, -1))
        self.port_lbl_out = wx.StaticText(box3, label="Output port:")
        self.p_out = wx.Choice(box3, size=(110, -1))
        self.b_ports = wx.Button(box3, label="Apply Ports")
        for w, fl in ((self.port_lbl_in, wx.RIGHT), (self.p_in, wx.RIGHT), (self.port_lbl_out, wx.RIGHT | wx.LEFT),
                      (self.p_out, wx.RIGHT), (self.b_ports, wx.LEFT)):
            prow.Add(w, 0, wx.ALIGN_CENTER_VERTICAL | fl, PAD)
        self.port_row = prow
        sb3.Add(prow, 0, wx.LEFT | wx.RIGHT, PAD)
        self.port_why = _hint(box3, "")
        sb3.Add(self.port_why, 0, wx.ALL, PAD)
        self.warn = wx.StaticText(box3, label="")
        self.warn.SetForegroundColour(_warn_colour())
        sb3.Add(self.warn, 0, wx.LEFT | wx.RIGHT | wx.EXPAND, PAD)
        self.img = ImagePanel(box3)
        sb3.Add(self.img, 1, wx.EXPAND | wx.ALL, PAD)
        self.desc = wx.TextCtrl(box3, style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_DONTWRAP, size=(-1, 170))
        self.desc.SetFont(wx.Font(wx.FontInfo(9).Family(wx.FONTFAMILY_TELETYPE)))
        sb3.Add(self.desc, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        main.Add(sb3, 1, wx.EXPAND | wx.TOP | wx.RIGHT | wx.BOTTOM, PAD)
        self.SetSizer(main)

        self.sections: list = []
        self._ports = None
        self._opts = {"candidates": [], "nets": [], "pads": {}, "previous": None}
        self.b_read.Bind(wx.EVT_BUTTON, lambda e: self.read_selection())
        self.b_create.Bind(wx.EVT_BUTTON, lambda e: self.create())
        self.cfgs.Bind(wx.EVT_LIST_ITEM_SELECTED, self.on_cfg)
        self.b_mesh.Bind(wx.EVT_BUTTON, lambda e: self.inspect_mesh())
        self.ant_mode.Bind(wx.EVT_CHOICE, lambda e: self.on_ant_mode())
        self.ant_net.Bind(wx.EVT_CHOICE, lambda e: self.fill_pads())
        self.ab_fp.Bind(wx.EVT_CHOICE, lambda e: self.fill_board())
        self.ab_file.Bind(wx.EVT_FILEPICKER_CHANGED, lambda e: self.fill_board_pads())
        self.show.Bind(wx.EVT_CHOICE, lambda e: self.show_picture())
        self.b_ports.Bind(wx.EVT_BUTTON, lambda e: self.apply_ports())
        self.b_kicad.Bind(wx.EVT_BUTTON, lambda e: self.show_in_kicad())
        self.on_ant_mode()

    # -- selection and antenna choices
    def read_selection(self):
        try:
            refs, nets = core.read_selection(self.app.board())
        except Exception as e:  # noqa: BLE001
            self.app.show_error(e, traceback.format_exc())
            return
        self.sel.DeleteAllItems()
        for r in refs:
            self.sel.Append([r, "footprint"])
        for n in nets:
            self.sel.Append([n, "net"])
        if not refs and not nets:
            self.sel.Append(["(nothing selected)", ""])
            return
        self.ant_found.SetLabel("looking for antennas ...")
        self.app.worker.run(lambda: core.antenna_options(self.app.board(), self.app.proj()), self.got_options,
                            lambda e, tb: self.ant_found.SetLabel(f"antenna search failed: {e}"))

    def _fit_left(self):
        if self.lpanel:
            self.lpanel.Layout()
            self.lpanel.FitInside()

    def got_options(self, opts):
        wx.CallAfter(self._fit_left)
        self._opts = opts
        if opts.get("band") or not self.band.text.GetValue().strip():
            self.band.set(opts.get("band"), opts.get("band_reason", ""))
        acc = [c for c in opts["candidates"] if c["accepted"]]
        rej = [c for c in opts["candidates"] if not c["accepted"]]
        lines = [f"Found: {c['nets'][0]}, feed {c['feed']}\n  {c['reason']}" for c in acc[:2]]
        lines += [f"Not used: {c['nets'][0]}\n  {c['reason']}" for c in rej[:2]]
        self.ant_found.SetLabel(_wrap("\n".join(lines) if lines else "No antenna found on the RF nets of the selection.", 58))
        self.ant_net.Set(opts["nets"])
        pick = (opts["previous"] or {}).get("net") or (acc[0]["nets"][0] if acc else None)
        if pick in opts["nets"]:
            self.ant_net.SetStringSelection(pick)
        elif opts["nets"]:
            self.ant_net.SetSelection(0)
        self.fill_pads()
        self._fps = opts.get("model_fps", [])
        self.ab_fp.Set([d["ref"] for d in self._fps])
        ft = opts.get("feed_trace")
        self.ant_trace.SetValue(bool(ft))
        if ft:
            self.ant_off.SetValue(float(ft.get("offset", 0.0)))
        prev = opts["previous"] or {}
        if prev.get("mode") == "board":  # the antenna board chosen last time
            self.ant_mode.SetSelection(3)
            if prev["footprint"] in [d["ref"] for d in self._fps]:
                self.ab_fp.SetStringSelection(prev["footprint"])
            self.fill_board(prev)
        elif prev:  # the user defined the antenna last time: keep that
            self.ant_mode.SetSelection(1)
            if prev.get("feed"):
                self.ant_feed.SetStringSelection(prev["feed"])
            self.ant_gnd.SetSelection(self.GROUND_MODES.index(prev.get("ground_mode", "auto")))
            if self._fps:
                self.ab_fp.SetSelection(0)
                self.fill_board()
        else:
            if self._fps:
                self.ab_fp.SetSelection(0)
                self.fill_board()
            missing = [c for c in opts["candidates"] if c.get("kind") == "board_missing"]
            if missing and not acc:  # a soldered-in board without its .kicad_pcb: offer to choose it
                self.ant_mode.SetSelection(3)
                if missing[0]["footprint"] in [d["ref"] for d in self._fps]:
                    self.ab_fp.SetStringSelection(missing[0]["footprint"])
                    self.fill_board()
        self.on_ant_mode()
        self.GetSizer().Layout()
        self.lpanel.FitInside()

    def fill_pads(self):
        net = self.ant_net.GetStringSelection()
        pads = self._opts["pads"].get(net, [])
        self.ant_feed.Set(pads)
        acc = [c for c in self._opts["candidates"] if c["accepted"] and c["nets"][0] == net]
        if acc and acc[0]["feed"] in pads:
            self.ant_feed.SetStringSelection(acc[0]["feed"])
        elif pads:
            self.ant_feed.SetSelection(0)

    def fill_board(self, prev: dict | None = None):
        """Antenna board mode: file and pads of the chosen footprint."""
        i = self.ab_fp.GetSelection()
        d = self._fps[i] if 0 <= i < len(getattr(self, "_fps", [])) else None
        if d is None:
            return
        self.ab_feed.Set(d["pads"])
        if prev and prev.get("feed") in d["pads"]:
            self.ab_feed.SetStringSelection(prev["feed"])
        elif d["pads"]:
            self.ab_feed.SetSelection(0)
        f = (prev or {}).get("board") or d["board"]
        self.ab_file.SetPath(f or "")
        self.fill_board_pads((prev or {}).get("input_pad"))

    def fill_board_pads(self, want: str | None = None):
        path = self.ab_file.GetPath()
        pads = []
        if path and os.path.isfile(path):
            try:
                pads = core.board_pads(path)
            except Exception as e:  # noqa: BLE001
                self.ab_hint.SetLabel(_wrap(f"cannot read the antenna board: {e}", 58))
        self.ab_in.Set(["(automatic: nearest copper)"] + pads)
        self.ab_in.SetSelection(0)
        if want:
            for k, p in enumerate(pads):
                if p.split(" ")[0] == want:
                    self.ab_in.SetSelection(k + 1)
        elif len(pads) == 1:
            self.ab_in.SetSelection(1)
        else:  # the pad on a net named like an antenna / RF input
            for k, p in enumerate(pads):
                if any(t in p.upper() for t in ("ANT", "RF", "FEED", "IN")):
                    self.ab_in.SetSelection(k + 1)
                    break

    def on_ant_mode(self):
        m = self.ant_mode.GetSelection()
        user = m == 1
        for w in (self.ant_net, self.ant_feed, self.ant_gnd):
            w.Enable(user)
        self.ant_found.Show(m != 2)
        board = m == 3
        for c in self.board_grid.GetChildren():
            if c.GetWindow():
                c.GetWindow().Show(board)
        self.ab_hint.Show(board)
        for c in self.user_grid.GetChildren():
            if c.GetWindow():
                c.GetWindow().Show(not board)
        self.Layout()
        self.lpanel.FitInside()

    def antenna_choice(self) -> dict:
        m = self.ant_mode.GetSelection()
        if m == 2:
            return {"mode": "none"}
        if m == 3:
            fp, path, feed = self.ab_fp.GetStringSelection(), self.ab_file.GetPath(), self.ab_feed.GetStringSelection()
            if not fp or not feed:
                raise ValueError("Choose the antenna footprint and its feed pad (press Read Selection first).")
            if not path or not os.path.isfile(path):
                raise ValueError("Choose the antenna's own KiCad board file (.kicad_pcb).")
            ip = self.ab_in.GetSelection()
            d = next((x for x in self._fps if x["ref"] == fp), {})
            return {"mode": "board", "footprint": fp, "board": path, "feed": feed, "step": d.get("step", ""),
                    "input_pad": self.ab_in.GetString(ip).split(" ")[0] if ip > 0 else None}
        if m == 1:
            if not self.ant_net.GetStringSelection() or not self.ant_feed.GetStringSelection():
                raise ValueError("Choose the antenna net and its feed pad (press Read Selection first).")
            return {"mode": "user", "net": self.ant_net.GetStringSelection(), "feed": self.ant_feed.GetStringSelection(),
                    "ground_mode": self.GROUND_MODES[self.ant_gnd.GetSelection()]}
        return {"mode": "auto"}

    # -- create
    def create(self):
        try:
            ant = self.antenna_choice()
        except ValueError as e:
            wx.MessageBox(str(e), APP_NAME, wx.ICON_INFORMATION, self)
            return
        if ant.get("mode") != "none" and self.ant_trace.GetValue():
            ant["feed_trace"] = True
            ant["feed_offset"] = float(self.ant_off.GetValue())
        try:
            band = self.band.ranges()
        except ValueError:
            wx.MessageBox("Choose the operating band first.", APP_NAME, wx.ICON_INFORMATION, self)
            self.band.choice.SetFocus()
            return
        self.app.log("--- create setup ---")
        self.app.worker.run(lambda: core.create_setup(self.app.board(), self.app.proj(), log=self.app.log_threadsafe,
                                                      antenna=ant, band=band), self.created)

    def created(self, sections):
        self.sections = sections
        self.refresh()
        self.show_sections(sections)
        self.app.settings_page.refresh()
        self.app.simulate_page.refresh()
        self.app.casing_page.refresh()
        self.app.SetStatusText("Setup written - next: Simulate", 0)

    def show_sections(self, sections):
        warns = [w for s in sections for w in s.warn]
        cols = max(40, (self.warn.GetParent().GetSize().width - 30) // max(6, self.warn.GetCharWidth()))
        self.warn.SetLabel(_wrap("\n".join(warns), cols))
        self.desc.SetValue("\n\n".join(f"{s.title}\n{s.text}" for s in sections))
        has_ant = any(s.title.startswith("Antenna") and s.image for s in sections)
        if has_ant and self.show.GetSelection() == 0 and self.ant_mode.GetSelection() != 2:
            self.show.SetSelection(1)  # mark the antenna first: the user should check it
        self.show_picture()
        self.Layout()

    def show_picture(self):
        out = common.rfsim_dir(self.app.proj())
        ant = self.show.GetSelection() == 1
        pic = out / ("antenna_setup_preview.png" if ant else "rf_setup_preview.png")
        self.img.set_file(pic if pic.exists() else None)
        self.load_ports()
        for w in (self.port_lbl_in, self.p_in, self.port_lbl_out, self.p_out, self.b_ports):
            w.Show(not ant and self._ports is not None)
        if ant:
            a = self._antenna_cfg()
            self.port_why.SetLabel(f"Antenna feed {a['feed']['ref']}.{a['feed']['pad']} "
                                   f"({'set by you' if a.get('antenna_source') == 'user' else 'detected'}): "
                                   f"{a.get('antenna_reason', '')}" if a else "")
        self.port_why.SetLabel(_wrap(self.port_why.GetLabel().replace("\n", " "),
                                     max(40, (self.GetSize().width - self.LEFT_W - 60) // max(6, self.port_why.GetCharWidth()))))
        self.Layout()

    def _antenna_cfg(self):
        try:
            return json.loads((common.rfsim_dir(self.app.proj()) / "antenna.json").read_text())
        except Exception:
            return None

    def load_ports(self):
        self._ports = core.rf_ports(self.app.proj())
        if not self._ports:
            self.port_why.SetLabel("")
            return
        ports, ext = self._ports["ports"], self._ports["external"]
        self.p_in.Set(ports)
        self.p_out.Set(["(none)"] + ports)
        if ext:
            self.p_in.SetStringSelection(ext[0])
        self.p_out.SetStringSelection(ext[1] if len(ext) > 1 else "(none)")
        self.port_why.SetLabel("Why: " + "; ".join(self._ports["reason"]) if self._ports["reason"] else "")

    def apply_ports(self):
        inp = self.p_in.GetStringSelection()
        outp = self.p_out.GetStringSelection()
        outp = None if outp in ("", "(none)") else outp
        old_ext = " → ".join(self._ports["external"]) if self._ports else ""

        def done(_):
            if old_ext:
                self.desc.SetValue(self.desc.GetValue().replace(f"External ports {old_ext}",
                                                                f"External ports {' → '.join([inp] + ([outp] if outp else []))}"))
            self.show_picture()
            self.refresh()
            self.app.SetStatusText("Ports set - no new EM run needed, press Simulate to update the viewer", 0)
        self.app.worker.run(lambda: core.set_external_ports(self.app.board(), self.app.proj(), inp, outp), done)

    def show_in_kicad(self):
        refs = []
        if self.show.GetSelection() == 1:
            a = self._antenna_cfg()
            if a:
                refs = [a["feed"]["ref"]] + [sb.get("footprint") for sb in a.get("subboards", []) if sb.get("footprint")]
        elif self._ports:
            refs = sorted({p.split(".")[0] for p in self._ports["ports"]})
        if not refs:
            return
        try:
            n = core.highlight_in_kicad(self.app.board(), refs)
        except Exception as e:  # noqa: BLE001
            self.app.show_error(e, traceback.format_exc())
            return
        self.app.SetStatusText(f"{n} part(s) selected in the PCB editor: {', '.join(refs)}", 0)

    def refresh(self):
        self.cfgs.DeleteAllItems()
        self._infos = core.list_configs(self.app.proj())
        for c in self._infos:
            self.cfgs.Append([c.label, c.summary, core.fmt_when(c.updated)])
        bad = core.broken_configs(self.app.proj())
        if bad:
            cols = max(40, (self.warn.GetParent().GetSize().width - 30) // max(6, self.warn.GetCharWidth()))
            self.warn.SetLabel(_wrap("Not usable: " + "\n".join(bad), cols))
        self.show_picture()

    def inspect_mesh(self):
        if not self._infos:
            wx.MessageBox("Create a setup first.", APP_NAME, wx.ICON_INFORMATION, self)
            return
        i = self.cfgs.GetFirstSelected()
        c = self._infos[i if 0 <= i < len(self._infos) else 0]
        board, proj = self.app.board(), self.app.proj()
        self.app.SetStatusText(f"building the mesh of {c.label} ...", 0)

        def done(page):
            self.app.SetStatusText(f"Mesh of {c.label}: {page}", 0)
            self.app.results_page.show_mesh(c.path)
        self.app.worker.run(lambda: core.inspect_mesh(proj, c, board, self.app.log_threadsafe), done,
                            lambda e, tb: self.app.show_error(e, tb))

    def on_cfg(self, e):
        c = self._infos[e.GetIndex()]
        txt = c.out / "model.txt"
        extra = ""
        if c.kind == "antenna":
            try:
                a = json.loads(c.path.read_text())
                extra = (f"Antenna {'set by you' if a.get('antenna_source') == 'user' else 'detected'}: "
                         f"{a.get('antenna_reason', '')}\n")
            except Exception:
                pass
        self.desc.SetValue(f"{c.label}\n{c.summary}\n{extra}Config: {c.path}\n\n"
                           + (txt.read_text() if txt.exists() else "(model description after the first run)"))
        self.show.SetSelection(1 if c.kind == "antenna" else 0)
        self.show_picture()
        self.warn.SetLabel("")


# ---------------------------------------------------------------------------
# Simulate page
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Casing page: STEP parts around the board for the antenna simulation
# ---------------------------------------------------------------------------
def _spin(parent, lo, hi, inc, digits, width=104):
    s = wx.SpinCtrlDouble(parent, min=lo, max=hi, inc=inc, size=(width, -1))
    s.SetDigits(digits)
    return s


class CasingPage(wx.Panel):
    """Casing parts (STEP) placed around the board like a CAD assembly; material per part."""

    MODELS = [("shape", "shape (tessellated STEP)"), ("box", "hollow box (outer size + wall)")]
    AXES = "XYZ"

    def __init__(self, parent, app: "RfSimFrame"):
        super().__init__(parent)
        from kicad_rfsim import enclosure as E
        self.E = E
        self.app = app
        self.bodies: list = []
        self._loading = False
        self._job = 0
        main = wx.BoxSizer(wx.HORIZONTAL)
        left = wx.ScrolledWindow(self, style=wx.VSCROLL)
        left.SetScrollRate(0, 12)
        ls = wx.BoxSizer(wx.VERTICAL)

        sb, box = _box(left, "Casing parts (used by every antenna simulation)")
        self.lst = wx.CheckListBox(box, size=(-1, 100))
        sb.Add(self.lst, 0, wx.EXPAND | wx.ALL, PAD)
        row = wx.BoxSizer(wx.HORIZONTAL)
        self.b_add = wx.Button(box, label="Add STEP ...")
        self.b_dup = wx.Button(box, label="Duplicate")
        self.b_del = wx.Button(box, label="Remove")
        for b in (self.b_add, self.b_dup, self.b_del):
            row.Add(b, 0, wx.RIGHT, PAD)
        sb.Add(row, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        sb.Add(_hint(box, "Ticked parts go into every antenna simulation.\n"
                          "'Hollow box' is the fastest model of a plain housing."),
               0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        ls.Add(sb, 0, wx.EXPAND | wx.ALL, PAD)

        sm, mbox = _box(left, "Material and model")
        g = wx.FlexGridSizer(cols=2, vgap=PAD, hgap=PAD)
        g.AddGrowableCol(1)
        self.name = wx.TextCtrl(mbox)
        self.mat = wx.Choice(mbox, choices=list(E.MATERIALS))
        self.er = _spin(mbox, 1.0, 100.0, 0.05, 2)
        self.tand = _spin(mbox, 0.0, 1.0, 0.001, 4)
        self.fill = _spin(mbox, 1.0, 100.0, 5.0, 0)
        self.model = wx.Choice(mbox, choices=[t for _k, t in self.MODELS])
        self.wall = _spin(mbox, 0.2, 50.0, 0.1, 1)
        self.detail = wx.Choice(mbox, choices=list(E.DETAIL))
        for lab, w in (("Name", self.name), ("Material", self.mat), ("εr", self.er), ("tan δ", self.tand),
                       ("Fill (%)", self.fill), ("Model as", self.model), ("Wall (mm)", self.wall),
                       ("Detail", self.detail)):
            g.Add(wx.StaticText(mbox, label=lab), 0, wx.ALIGN_CENTER_VERTICAL)
            g.Add(w, 1, wx.EXPAND)
        sm.Add(g, 0, wx.EXPAND | wx.ALL, PAD)
        self.mnote = _hint(mbox, "")
        sm.Add(self.mnote, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        ls.Add(sm, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)

        sq, qbox = _box(left, "Placement (rotation about the part's centre, then shift)")
        q = wx.FlexGridSizer(cols=4, vgap=PAD, hgap=PAD)
        q.Add((1, 1))
        for a in self.AXES:
            q.Add(wx.StaticText(qbox, label=a), 0, wx.ALIGN_CENTER_HORIZONTAL)
        self.pos = [_spin(qbox, -2000, 2000, 0.5, 2) for _ in range(3)]
        self.rot = [_spin(qbox, -360, 360, 90, 1) for _ in range(3)]
        for lab, ws in (("Shift (mm)", self.pos), ("Rotate (°)", self.rot)):
            q.Add(wx.StaticText(qbox, label=lab), 0, wx.ALIGN_CENTER_VERTICAL)
            for w in ws:
                q.Add(w)
        sq.Add(q, 0, wx.ALL, PAD)
        ls.Add(sq, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)

        sa, abox = _box(left, "Align (like a joint)")
        ar = wx.BoxSizer(wx.HORIZONTAL)
        ar.Add(wx.StaticText(abox, label="Relative to"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.ref = wx.Choice(abox)
        ar.Add(self.ref, 1)
        sa.Add(ar, 0, wx.EXPAND | wx.ALL, PAD)
        ag = wx.FlexGridSizer(cols=3, vgap=PAD, hgap=PAD)
        ag.AddGrowableCol(1)
        self.how = [wx.Choice(abox, choices=list(E.ALIGN.values())) for _ in range(3)]
        self.off = [_spin(abox, -500, 500, 0.5, 2) for _ in range(3)]
        for a, c, o in zip(self.AXES, self.how, self.off):
            c.SetSelection(0)
            ag.Add(wx.StaticText(abox, label=a), 0, wx.ALIGN_CENTER_VERTICAL)
            ag.Add(c, 1, wx.EXPAND)
            ag.Add(o)
        sa.Add(ag, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, PAD)
        self.b_align = wx.Button(abox, label="Apply Alignment")
        sa.Add(self.b_align, 0, wx.ALL, PAD)
        sa.Add(_hint(abox, "Offset: gap (+) or overlap (-) in mm.\n"
                           "'Stack on': the part's lower face on the reference's upper face."),
               0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        ls.Add(sa, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)

        sv, vbox = _box(left, "Antenna board (soldered in)")
        self.vinfo = _hint(vbox, "")
        sv.Add(self.vinfo, 0, wx.ALL, PAD)
        vr = wx.BoxSizer(wx.HORIZONTAL)
        vr.Add(wx.StaticText(vbox, label="Turn"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.v_turn = wx.Choice(vbox, choices=["0°", "90°", "180°", "270°"])
        self.v_turn.SetSelection(0)
        vr.Add(self.v_turn, 0, wx.RIGHT, 2 * PAD)
        self.v_up = wx.CheckBox(vbox, label="upside down")
        vr.Add(self.v_up, 0, wx.ALIGN_CENTER_VERTICAL)
        sv.Add(vr, 0, wx.LEFT | wx.RIGHT, PAD)
        vs = wx.BoxSizer(wx.HORIZONTAL)
        vs.Add(wx.StaticText(vbox, label="Shift (mm)"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.v_sh = [_spin(vbox, -100, 100, 0.1, 2) for _ in range(3)]
        for a, w in zip(self.AXES, self.v_sh):
            vs.Add(wx.StaticText(vbox, label=a), 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, PAD)
            vs.Add(w, 0, wx.LEFT, 2)
        sv.Add(vs, 0, wx.ALL, PAD)
        self.v_reset = wx.Button(vbox, label="Automatic Placement")
        sv.Add(self.v_reset, 0, wx.LEFT | wx.BOTTOM, PAD)
        sv.Add(_hint(vbox, "Blue edges: KiCad's 3D model. Green: the simulated antenna board.\nThey should coincide."),
               0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        self.vbox_sizer = sv
        ls.Add(sv, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        self.v_turn.Bind(wx.EVT_CHOICE, self.on_vadj)
        self.v_up.Bind(wx.EVT_CHECKBOX, self.on_vadj)
        for w in self.v_sh:
            w.Bind(wx.EVT_SPINCTRLDOUBLE, self.on_vadj)
            w.Bind(wx.EVT_TEXT, self.on_vadj)
        self.v_reset.Bind(wx.EVT_BUTTON, self.on_vreset)
        self._vloading = False
        left.SetSizer(ls)
        left.SetMinSize((470, -1))
        _keep_scroll(left)
        main.Add(left, 0, wx.EXPAND)

        right = wx.BoxSizer(wx.VERTICAL)
        top = wx.BoxSizer(wx.HORIZONTAL)
        top.Add(wx.StaticText(self, label="Show"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.show = wx.Choice(self, choices=list(E.SHOW.values()))
        self.show.SetSelection(0)
        top.Add(self.show, 0)
        self.comp = wx.CheckBox(self, label="board with components")
        self.comp.SetToolTip("The board as KiCad exports it to STEP, with all 3D models (kicad-cli, first time "
                             "about half a minute; cached until the board changes)")
        top.Add(self.comp, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 2 * PAD)
        top.Add(_hint(self, "Simulation model: copper, feed port (red), mesh lines (blue), casing"), 0,
                wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 2 * PAD)
        right.Add(top, 0, wx.LEFT | wx.RIGHT | wx.TOP, PAD)
        self.web = None
        if webview is not None:
            try:
                backend = webview.WebViewBackendDefault
                if sys.platform == "win32" and webview.WebView.IsBackendAvailable(webview.WebViewBackendEdge):
                    backend = webview.WebViewBackendEdge
                self.web = webview.WebView.New(self, backend=backend)
                right.Add(self.web, 1, wx.EXPAND | wx.ALL, PAD)
            except Exception:  # noqa: BLE001
                self.web = None
        self.status = _hint(self, "")
        right.Add(self.status, 0, wx.ALL, PAD)
        main.Add(right, 1, wx.EXPAND)
        self.SetSizer(main)

        self.lst.Bind(wx.EVT_LISTBOX, lambda e: self.select(self.lst.GetSelection()))
        self.lst.Bind(wx.EVT_CHECKLISTBOX, self.on_check)
        self.b_add.Bind(wx.EVT_BUTTON, self.on_add)
        self.b_dup.Bind(wx.EVT_BUTTON, self.on_dup)
        self.b_del.Bind(wx.EVT_BUTTON, self.on_del)
        self.b_align.Bind(wx.EVT_BUTTON, self.on_align)
        self.mat.Bind(wx.EVT_CHOICE, self.on_material)
        self.show.Bind(wx.EVT_CHOICE, lambda e: self.update_preview())
        self.comp.Bind(wx.EVT_CHECKBOX, lambda e: (self.status.SetLabel("exporting the board with its 3D models ...")
                                                    if self.comp.GetValue() else None, self.update_preview()))
        self._show_vboard([])
        for w in (self.model, self.detail):
            w.Bind(wx.EVT_CHOICE, self.on_edit)
        self.name.Bind(wx.EVT_TEXT, self.on_edit)
        for w in [self.er, self.tand, self.fill, self.wall] + self.pos + self.rot:
            w.Bind(wx.EVT_SPINCTRLDOUBLE, self.on_edit)
            w.Bind(wx.EVT_TEXT, self.on_edit)

    # -- data
    def rdir(self) -> Path:
        return common.rfsim_dir(self.app.proj())

    def board_obj(self):
        from kicad_rfsim.board import Board
        p = self.app.proj() / self.app._board.name
        if not getattr(self, "_board_cache", None) or self._board_cache[0] != (p, p.stat().st_mtime):
            self._board_cache = ((p, p.stat().st_mtime), Board(p))
        return self._board_cache[1]

    def refresh(self):
        self.bodies = self.E.load(self.rdir())
        self._fill_list(0 if self.bodies else -1)
        self._stale = True
        if self.app.nb.GetCurrentPage() is self:  # else drawn when the tab is opened
            self._stale = False
            self.update_preview()

    def on_shown(self):
        if getattr(self, "_stale", True):
            self._stale = False
            self.update_preview()

    def _fill_list(self, sel: int):
        self.lst.Set([f"{b.name}  ({b.material})" for b in self.bodies])
        for i, b in enumerate(self.bodies):
            self.lst.Check(i, b.enabled)
        self.ref.Set(["Board"] + [b.name for b in self.bodies])
        self.ref.SetSelection(0)
        self.select(sel)

    def cur(self):
        i = self.lst.GetSelection()
        return self.bodies[i] if 0 <= i < len(self.bodies) else None

    def select(self, i: int):
        has = 0 <= i < len(self.bodies)
        if has:
            self.lst.SetSelection(i)
        for w in ([self.name, self.mat, self.er, self.tand, self.fill, self.model, self.wall, self.detail,
                   self.b_dup, self.b_del, self.b_align, self.ref] + self.pos + self.rot + self.how + self.off):
            w.Enable(has)
        if not has:
            return
        b = self.bodies[i]
        self._loading = True
        try:
            self.name.SetValue(b.name)
            names = list(self.E.MATERIALS)
            self.mat.SetSelection(names.index(b.material) if b.material in names else names.index("Custom"))
            pr = self.E.MATERIALS.get(b.material, self.E.MATERIALS["Custom"])
            self.er.SetValue(b.er if b.er is not None else pr["er"])
            self.tand.SetValue(b.tand if b.tand is not None else pr["tand"])
            self.fill.SetValue(100 * b.fill)
            self.model.SetSelection([k for k, _t in self.MODELS].index(b.model) if b.model in ("shape", "box") else 0)
            self.wall.SetValue(b.wall)
            self.detail.SetSelection(list(self.E.DETAIL).index(b.detail) if b.detail in self.E.DETAIL else 1)
            for k in range(3):
                self.pos[k].SetValue(float(b.pos[k]))
                self.rot[k].SetValue(float(b.rot[k]))
            self._note(b)
        finally:
            self._loading = False

    def _note(self, b):
        m = self.E.MATERIALS.get(b.material, self.E.MATERIALS["Custom"])
        pr = b.props()
        eff = "metal (perfect conductor)" if pr["pec"] else f"in the model: εr {pr['er']:.2f}, tan δ {pr['tand']:.4f}"
        self.mnote.SetLabel(f"Values: {m['src']}. {eff}")
        pec = bool(pr["pec"])
        for w in (self.er, self.tand, self.fill):
            w.Enable(not pec)
        self.wall.Enable(b.model == "box")

    def save(self):
        self.E.save(self.rdir(), self.bodies)

    # -- events
    def on_material(self, _e):
        b = self.cur()
        if b is None or self._loading:
            return
        b.material = self.mat.GetStringSelection()
        b.er = b.tand = None  # take the preset values
        if b.material == "Custom":
            b.er, b.tand = self.er.GetValue(), self.tand.GetValue()
        self.select(self.lst.GetSelection())
        self._changed(rebuild_list=True)

    def on_edit(self, _e):
        b = self.cur()
        if b is None or self._loading:
            return
        pr = self.E.MATERIALS.get(b.material, self.E.MATERIALS["Custom"])
        er, td = self.er.GetValue(), self.tand.GetValue()
        b.er = None if abs(er - pr["er"]) < 1e-9 and b.material != "Custom" else er
        b.tand = None if abs(td - pr["tand"]) < 1e-12 and b.material != "Custom" else td
        b.fill = self.fill.GetValue() / 100
        b.name = self.name.GetValue().strip() or b.name
        b.model = self.MODELS[max(0, self.model.GetSelection())][0]
        b.wall = self.wall.GetValue()
        b.detail = list(self.E.DETAIL)[max(0, self.detail.GetSelection())]
        b.pos = [w.GetValue() for w in self.pos]
        b.rot = [w.GetValue() for w in self.rot]
        self._note(b)
        self._changed()

    def on_check(self, e):
        i = e.GetInt()
        self.bodies[i].enabled = self.lst.IsChecked(i)
        self._changed()

    def _changed(self, rebuild_list=False):
        self.save()
        if rebuild_list:
            i = self.lst.GetSelection()
            self._fill_list(i)
        self._job += 1
        job = self._job
        wx.CallLater(350, lambda: job == self._job and self.update_preview())

    def on_add(self, _e):
        with wx.FileDialog(self, "Casing part (STEP or STL)", wildcard="STEP / STL|*.step;*.stp;*.STEP;*.STP;*.stl;*.STL",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST | wx.FD_MULTIPLE) as d:
            if d.ShowModal() != wx.ID_OK:
                return
            paths = [Path(p) for p in d.GetPaths()]
        proj = self.app.proj()
        for p in paths:
            try:
                f = str(Path(os.path.relpath(p, self.rdir()))) if p.drive == proj.drive else str(p)
            except ValueError:
                f = str(p)
            self.bodies.append(self.E.Body(name=p.stem, file=f))
        self.save()
        self._fill_list(len(self.bodies) - 1)
        self.status.SetLabel("Reading the STEP file(s) - the first time takes a moment ...")
        self.update_preview(center_new=len(paths))

    def on_dup(self, _e):
        b = self.cur()
        if b is None:
            return
        import copy
        nb = copy.deepcopy(b)
        nb.name = b.name + " copy"
        self.bodies.append(nb)
        self._fill_list(len(self.bodies) - 1)
        self._changed()

    def on_del(self, _e):
        i = self.lst.GetSelection()
        if 0 <= i < len(self.bodies):
            del self.bodies[i]
            self._fill_list(min(i, len(self.bodies) - 1))
            self._changed()

    def _bounds(self, b):
        E = self.E
        return E.bounds(E.place(E.raw_triangles(b, self.rdir()), b))

    def on_align(self, _e):
        b = self.cur()
        if b is None:
            return
        E = self.E
        try:
            r = self.ref.GetSelection()
            if r <= 0:
                rlo, rhi = E.board_bounds(self.board_obj())
            else:
                rlo, rhi = self._bounds(self.bodies[r - 1])
            lo, hi = self._bounds(b)
        except Exception as ex:  # noqa: BLE001
            self.app.show_error(ex)
            return
        keys = list(E.ALIGN)
        for ax in range(3):
            how = keys[max(0, self.how[ax].GetSelection())]
            if how != "keep":
                b.pos[ax] = float(b.pos[ax]) + E.align(lo, hi, rlo, rhi, ax, how, self.off[ax].GetValue())
        self.select(self.lst.GetSelection())
        self._changed()

    # -- soldered-in antenna board placement
    def _show_vboard(self, infos):
        has = bool(infos)
        self.vbox_sizer.GetStaticBox().Show(has)
        self.vbox_sizer.ShowItems(has)
        if not has:
            self.Layout()
            return
        inf = infos[0]
        if inf.get("error"):
            self.vinfo.SetLabel(f"{inf.get('footprint')}: {inf['error']}")
        else:
            st = (f"matches its STEP within {inf['step_residual']:.2f} mm" if inf.get("step_residual") is not None
                  else "no matching STEP - placed from the pads")
            self.vinfo.SetLabel(f"{inf['board']} on {inf['footprint']}: {st}\npads {inf['residual']:.2f} mm off"
                                + (f", input pad {inf['input_pad']}" if inf.get("input_pad") else ""))
            adj = inf.get("adjust") or {}
            self._vloading = True
            try:
                self.v_turn.SetSelection(int(round(float(adj.get("turn", 0)) / 90)) % 4)
                self.v_up.SetValue(bool(adj.get("upside")))
                for k, w in enumerate(self.v_sh):
                    w.SetValue(float((adj.get("shift") or [0, 0, 0])[k]))
            finally:
                self._vloading = False
        self.Layout()

    def on_vadj(self, _e):
        if self._vloading:
            return
        from kicad_rfsim.pipeline import save_subboard_adjust
        adj = {"turn": 90 * self.v_turn.GetSelection(), "upside": self.v_up.GetValue(),
               "shift": [round(w.GetValue(), 3) for w in self.v_sh]}
        if not adj["turn"] and not adj["upside"] and not any(adj["shift"]):
            adj = None
        try:
            save_subboard_adjust(self.rdir(), 0, adj)
        except Exception as ex:  # noqa: BLE001
            self.status.SetLabel(f"cannot save the placement: {ex}")
            return
        self._job += 1
        job = self._job
        wx.CallLater(350, lambda: job == self._job and self.update_preview())

    def on_vreset(self, _e):
        from kicad_rfsim.pipeline import save_subboard_adjust
        try:
            save_subboard_adjust(self.rdir(), 0, None)
        except Exception:  # noqa: BLE001
            pass
        self.update_preview()

    def update_preview(self, center_new: int = 0):
        """Tessellate (cached) and draw in a thread; new parts are first centred on the board."""
        self._center = getattr(self, "_center", 0) + center_new
        if getattr(self, "_busy", False):
            self._again = True
            return
        center_new, self._center = self._center, 0
        bodies = list(self.bodies)
        sel = self.lst.GetSelection()
        rd = self.rdir()
        show = list(self.E.SHOW)[max(0, self.show.GetSelection())]
        comp = self.comp.GetValue()

        def work():
            E = self.E
            board = self.board_obj()
            if center_new:
                bl, bh = E.board_bounds(board)
                for b in bodies[-center_new:]:
                    lo, hi = E.bounds(E.place(E.raw_triangles(b, rd), b))
                    b.pos = [E.align(lo, hi, bl, bh, ax, "center") for ax in range(3)]
                E.save(rd, bodies)
            out = rd / "results" / "enclosure_cache" / "preview.html"
            from kicad_rfsim.pipeline import model_view, subboard_scene
            try:
                extra, vinfos = subboard_scene(rd, progress=lambda m: None)
            except Exception as ex:  # noqa: BLE001
                extra, vinfos = [], [{"error": str(ex), "footprint": "antenna board"}]
            over, note = None, ""
            if show == "sim" and (rd / "antenna.json").exists():
                # the board as the solver gets it: merged copper, slabs, solder joints, port, mesh lines
                try:
                    extra, note = model_view(rd, progress=lambda m: None)
                    over = []
                except Exception as ex:  # noqa: BLE001 - keep the realistic board
                    note = f"simulation model not available: {ex}"
            elif comp:
                try:
                    over, note = E.board_3d_traces(board, rd, log=lambda m: None)
                except Exception as ex:  # noqa: BLE001 - keep the plain board
                    note = f"board with components not available: {ex}"
            E.write_preview(out, board, bodies, rd, sel if sel >= 0 else None, show=show, extra=extra,
                            board_override=over)
            sizes = []
            for b in bodies:
                if b.enabled:
                    lo, hi = E.bounds(E.place(E.raw_triangles(b, rd), b))
                    sz = hi - lo
                    _t, h = E.sim_triangles(b, rd)
                    sizes.append(f"{b.name}: {sz[0]:.1f} x {sz[1]:.1f} x {sz[2]:.1f} mm, FDTD cells ≤ {h:.1f} mm")
            if note:
                sizes.insert(0, note)
            return out, sizes, vinfos

        def done(r):
            out, sizes, vinfos = r
            self._show_vboard(vinfos)
            if self.web is not None:
                self.web.LoadURL(out.resolve().as_uri())
            self.status.SetLabel(" · ".join(sizes) if sizes else "No casing parts - the antenna is simulated in free space.")
            if center_new:
                self.select(self.lst.GetSelection())

        def fail(e):
            wx.CallAfter(self.status.SetLabel, f"Preview failed: {e}")

        def run():
            try:
                r = work()
            except Exception as e:  # noqa: BLE001
                fail(e)
                r = None
            wx.CallAfter(finish, r)

        def finish(r):
            self._busy = False
            if r is not None:
                done(r)
            if self._again:  # edits while drawing: draw once more with the latest state
                self._again = False
                self.update_preview()
        self._busy, self._again = True, False
        threading.Thread(target=run, daemon=True).start()


class PartModelDialog(wx.Dialog):
    """Pick a part of the RF chain setup, a Touchstone file, and the pad for each of its ports."""

    def __init__(self, parent, cfg_path: Path):
        super().__init__(parent, title="Vendor S-parameters for a part", style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.cfg_path = cfg_path
        self.ref, self.file, self.pads = None, None, []
        s = wx.BoxSizer(wx.VERTICAL)
        g = wx.FlexGridSizer(2, 2, PAD, PAD)
        g.AddGrowableCol(1)
        self.part = wx.Choice(self, choices=core.model_parts(cfg_path))
        self.fpick = wx.FilePickerCtrl(self, message="Touchstone file", wildcard="Touchstone|*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;"
                                       "*.S1P;*.S2P;*.S3P;*.S4P;*.S5P;*.S6P", style=wx.FLP_OPEN | wx.FLP_FILE_MUST_EXIST |
                                       wx.FLP_USE_TEXTCTRL, size=(380, -1))
        for lab, w in (("Part:", self.part), ("File:", self.fpick)):
            g.Add(wx.StaticText(self, label=lab), 0, wx.ALIGN_CENTER_VERTICAL)
            g.Add(w, 1, wx.EXPAND)
        s.Add(g, 0, wx.EXPAND | wx.ALL, 2 * PAD)
        self.map_box = wx.FlexGridSizer(0, 2, PAD, PAD)
        s.Add(self.map_box, 0, wx.LEFT | wx.RIGHT, 2 * PAD)
        s.Add(_hint(self, "Port numbers as in the file. Pads on ground are its reference."), 0, wx.ALL, 2 * PAD)
        s.Add(self.CreateStdDialogButtonSizer(wx.OK | wx.CANCEL), 0, wx.EXPAND | wx.ALL, 2 * PAD)
        self.SetSizerAndFit(s)
        self.choices = []
        self.part.Bind(wx.EVT_CHOICE, lambda e: self.build())
        self.fpick.Bind(wx.EVT_FILEPICKER_CHANGED, lambda e: self.build())
        self.Bind(wx.EVT_BUTTON, self.on_ok, id=wx.ID_OK)
        if self.part.GetCount():
            self.part.SetSelection(0)

    def build(self):
        self.map_box.Clear(True)
        self.choices = []
        ref, f = self.part.GetStringSelection(), self.fpick.GetPath()
        if not ref or not f:
            return
        try:
            n = core.touchstone_ports(f)
            pads = core.part_pad_choices(self.cfg_path, ref)
        except Exception as ex:  # noqa: BLE001
            self.map_box.Add(wx.StaticText(self, label=f"cannot read: {ex}"))
            self.Fit()
            return
        for k in range(n):
            c = wx.Choice(self, choices=pads)
            c.SetSelection(min(k, len(pads) - 1))
            self.map_box.Add(wx.StaticText(self, label=f"File port {k + 1} → pad"), 0, wx.ALIGN_CENTER_VERTICAL)
            self.map_box.Add(c, 0)
            self.choices.append(c)
        self.Layout()
        self.Fit()

    def on_ok(self, e):
        self.ref, self.file = self.part.GetStringSelection(), self.fpick.GetPath()
        self.pads = [c.GetStringSelection().split(" ")[0] for c in self.choices]
        if not self.ref or not self.file or not self.pads:
            wx.MessageBox("Choose the part and the file.", APP_NAME, wx.ICON_INFORMATION, self)
            return
        e.Skip()


FULL_CHOICES = ["Off", "Joined from the RF path and antenna runs (no extra run)"]
FULL_MODES = [False, "overlay"]


class SimulatePage(wx.Panel):
    def __init__(self, parent, app: "RfSimFrame"):
        super().__init__(parent)
        self.app = app
        self.cancel = threading.Event()
        main = wx.BoxSizer(wx.VERTICAL)

        top = wx.BoxSizer(wx.HORIZONTAL)
        sb, box = _box(self, "Setups to simulate")
        self.lst = wx.CheckListBox(box, size=(440, 110))
        sb.Add(self.lst, 1, wx.EXPAND | wx.ALL, PAD)
        self.force = wx.CheckBox(box, label="Run again even if layout and settings are unchanged")
        sb.Add(self.force, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        self.fields = wx.CheckBox(box, label="Wave view: record fields (one extra run per setup, with the parts in)")
        sb.Add(self.fields, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        frow = wx.BoxSizer(wx.HORIZONTAL)
        frow.Add(wx.StaticText(box, label="Whole-board wave view:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.full = wx.Choice(box, choices=FULL_CHOICES)
        self.full.SetSelection(0)
        self.full.SetToolTip("Joined: RF chain and antenna runs combined on one clock (no extra run)")
        frow.Add(self.full, 1)
        # a whole-board view needs the field recordings: tick that box for the user
        self.full.Bind(wx.EVT_CHOICE, lambda e: self.fields.SetValue(True) if self.full.GetSelection() else None)
        sb.Add(frow, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        crow = wx.BoxSizer(wx.HORIZONTAL)
        crow.Add(wx.StaticText(box, label="Run:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.what = wx.Choice(box, choices=["Simulation (settings of each setup)",
                                            "Mesh convergence check: Fast + Automatic",
                                            "Mesh convergence check: Fast + Automatic + Accurate"])
        self.what.SetSelection(0)
        self.what.SetToolTip("Runs each ticked setup on two or three meshes and compares the results. "
                             "Accurate takes 3-5x longer.")
        crow.Add(self.what, 1)
        sb.Add(crow, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        row = wx.BoxSizer(wx.HORIZONTAL)
        self.b_run = wx.Button(box, label="Start Simulation")
        self.b_stop = wx.Button(box, label="Stop")
        self.b_stop.Disable()
        row.Add(self.b_run, 0, wx.RIGHT, PAD)
        row.Add(self.b_stop, 0)
        sb.Add(row, 0, wx.ALL, PAD)
        top.Add(sb, 0, wx.EXPAND | wx.RIGHT, PAD)

        sp, pbox = _box(self, "Progress")
        self.stage = wx.StaticText(pbox, label="Idle")
        self.stage.SetFont(self.stage.GetFont().Bold())
        sp.Add(self.stage, 0, wx.ALL, PAD)
        self.gauge = wx.Gauge(pbox, range=1000, size=(-1, 16))
        sp.Add(self.gauge, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, PAD)
        self.eta = wx.StaticText(pbox, label=" ")
        sp.Add(self.eta, 0, wx.ALL, PAD)
        self.detail = _hint(pbox, " ")
        sp.Add(self.detail, 0, wx.LEFT | wx.RIGHT, PAD)
        sp.AddSpacer(PAD * 2)
        self.decay_lbl = wx.StaticText(pbox, label="Energy decay (the run stops when the fields have died down)")
        sp.Add(self.decay_lbl, 0, wx.LEFT | wx.RIGHT, PAD)
        self.decay = wx.Gauge(pbox, range=1000, size=(-1, 10))
        sp.Add(self.decay, 0, wx.EXPAND | wx.ALL, PAD)
        top.Add(sp, 1, wx.EXPAND)
        main.Add(top, 0, wx.EXPAND | wx.ALL, PAD)

        sl, lbox = _box(self, "Log")
        self.logc = wx.TextCtrl(lbox, style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_DONTWRAP)
        self.logc.SetFont(wx.Font(wx.FontInfo(9).Family(wx.FONTFAMILY_TELETYPE)))
        sl.Add(self.logc, 1, wx.EXPAND | wx.ALL, PAD)
        main.Add(sl, 1, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        self.SetSizer(main)

        self.pulse = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, lambda e: self.gauge.Pulse(), self.pulse)
        self.b_run.Bind(wx.EVT_BUTTON, lambda e: self.start())
        self.b_stop.Bind(wx.EVT_BUTTON, lambda e: self.stop())
        self._t0 = time.time()

    def refresh(self):
        self._infos = core.list_configs(self.app.proj())
        labels = [c.label + ("" if c.has_result else "  (no result yet)") for c in self._infos]
        self.lst.Set(labels)
        for i in range(len(self._infos)):
            self.lst.Check(i)
        for b in core.broken_configs(self.app.proj()):
            self.log("NOT LISTED - " + b)
        infos, proj = list(self._infos), self.app.proj()

        def estimate():  # runtime estimates without blocking the window
            for i, c in enumerate(infos):
                try:
                    txt = core.estimate_runtime(proj, c)
                except Exception:
                    txt = ""
                if txt:
                    wx.CallAfter(self._set_estimate, i, labels[i], txt, infos)
        threading.Thread(target=estimate, daemon=True).start()

    def _set_estimate(self, i, label, txt, infos):
        if infos != self._infos or i >= self.lst.GetCount():
            return
        checked = self.lst.IsChecked(i)
        self.lst.SetString(i, f"{label}   –   {txt}")
        self.lst.Check(i, checked)

    def log(self, msg: str):
        self.logc.AppendText(f"[{time.time() - self._t0:6.0f} s] {msg}\n")

    def start(self):
        names = [self._infos[i].path.name for i in self.lst.GetCheckedItems()]
        if not names:
            wx.MessageBox("Create a setup first (page Setup) and tick at least one.", APP_NAME, wx.ICON_INFORMATION, self)
            return
        exe = self.app.ensure_openems()
        if not exe:
            return
        from kicad_rfsim import solver
        self.cancel.clear()
        solver.set_cancel_event(self.cancel)
        self._t0 = time.time()
        self.logc.Clear()
        ver, probs = core.openems_check(exe)
        self.log(f"openEMS {ver}: {exe}")
        for pr in probs:
            self.log("WARNING - " + pr)
        force = self.force.GetValue()
        fields = self.fields.GetValue()
        full = FULL_MODES[self.full.GetSelection()]
        if full:
            fields = True
        board, proj = self.app.board(), self.app.proj()
        threads = 0  # all physical cores (solver.physical_cores)
        conv = self.what.GetSelection()
        if conv:
            levels = core.CONVERGENCE_LEVELS["quick" if conv == 1 else "full"]
            infos = [self._infos[i] for i in self.lst.GetCheckedItems()]
            self.log(f"mesh convergence check ({' + '.join(levels)}) of: " + ", ".join(c.label for c in infos))

            def cjob():
                snap, live = common.board_snapshot(board, proj)
                out = []
                with solver.meter(lambda s: wx.CallAfter(self.on_progress, s)):
                    for c in infos:
                        out.append(core.run_convergence(proj, c, levels, board_path=snap, threads=threads,
                                                        progress=self.app.log_threadsafe, openems_bin=exe,
                                                        force=force))
                return out
            if self.app.worker.run(cjob, self.done_convergence, self.failed):
                self.b_run.Disable()
                self.b_stop.Enable()
                self.stage.SetLabel("Starting the convergence check ...")
            return

        def job():
            from kicad_rfsim.pipeline import simulate_all
            snap, live = common.board_snapshot(board, proj)
            self.app.log_threadsafe("board snapshot incl. unsaved edits" if live else "using the saved board file")
            with solver.meter(lambda s: wx.CallAfter(self.on_progress, s)):
                return simulate_all(common.rfsim_dir(proj), board_path=snap, threads=threads,
                                    progress=self.app.log_threadsafe, openems_bin=exe, only=names, force=force,
                                    fields=fields, full_board=full)
        if self.app.worker.run(job, self.done, self.failed):
            self.b_run.Disable()
            self.b_stop.Enable()
            self.stage.SetLabel("Starting ...")

    def stop(self):
        self.cancel.set()
        from kicad_rfsim.solver import kill_all
        threading.Thread(target=kill_all, daemon=True).start()  # stop at once, not at openEMS' next line
        self.stage.SetLabel("Stopping ...")

    def on_progress(self, s: dict):
        self.stage.SetLabel(f"{s.get('label', '')}   –   run {s.get('job', 1)} of {s.get('jobs', 1)}")
        if s.get("phase") == "busy" or s.get("frac") is None:
            if not self.pulse.IsRunning():
                self.pulse.Start(80)
            self.eta.SetLabel(s.get("text", "working ..."))
            return
        self.pulse.Stop()
        frac = max(0.0, min(1.0, float(s.get("frac") or 0)))
        self.gauge.SetValue(int(1000 * frac))
        eta = s.get("eta_s")
        if s.get("phase") == "done":
            left = "done"
        elif eta is None:
            left = "estimating ..."
        elif s.get("eta_upper"):
            left = f"at most ~{_fmt_s(eta)} left (fields still settling)"
        else:
            left = f"~{_fmt_s(eta)} left"
        self.eta.SetLabel(f"{100 * frac:.0f} %   ·   {left}")
        self.detail.SetLabel(f"timestep {int(s.get('timestep', 0)):,} / {int(s.get('max_timesteps', 0)):,}   ·   "
                             f"{float(s.get('speed', 0)):.0f} MC/s   ·   {_fmt_s(s.get('elapsed_s', 0))} elapsed")
        db, tdb = float(s.get("db", 0)), float(s.get("target_db", 40) or 40)
        self.decay_lbl.SetLabel(f"Energy decay {db:.1f} of {tdb:.0f} dB (the run stops when the fields have died down)")
        self.decay.SetValue(int(1000 * min(1.0, db / tdb)))
        self.Layout()

    def _end(self):
        self.pulse.Stop()
        self.b_run.Enable()
        self.b_stop.Disable()
        from kicad_rfsim import solver
        solver.set_cancel_event(None)
        self.refresh()

    def done(self, results):
        self._end()
        self.stage.SetLabel("Finished")
        self.gauge.SetValue(1000)
        self.eta.SetLabel(f"{len(results)} setup(s) done in {_fmt_s(time.time() - self._t0)}")
        self.app.results_page.refresh(select_first=True)
        self.app.setup_page.refresh()
        self.app.nb.SetSelection(self.app.nb.FindPage(self.app.results_page))

    def done_convergence(self, results):
        self._end()
        self.stage.SetLabel("Convergence check finished")
        self.gauge.SetValue(1000)
        for r in results:
            self.log(f"{r['setup']}: {r['verdict']}")
        self.eta.SetLabel(f"{len(results)} setup(s) checked in {_fmt_s(time.time() - self._t0)}")
        rp = self.app.results_page
        rp.refresh(select_first=True)
        rp.view.SetSelection(4)
        self.app.nb.SetSelection(self.app.nb.FindPage(rp))
        rp.show()

    def failed(self, e, tb):
        self._end()
        from kicad_rfsim.solver import Cancelled
        if isinstance(e, Cancelled):
            self.stage.SetLabel("Stopped")
            self.log("stopped by the user")
            return
        self.stage.SetLabel("Failed")
        self.log(tb)
        self.app.show_error(e, tb)


# ---------------------------------------------------------------------------
# Results page
# ---------------------------------------------------------------------------
class ResultsPage(wx.Panel):
    def __init__(self, parent, app: "RfSimFrame"):
        super().__init__(parent)
        self.app = app
        split = wx.SplitterWindow(self, style=wx.SP_LIVE_UPDATE | wx.SP_3DSASH)
        left = wx.Panel(split)
        ls = wx.BoxSizer(wx.VERTICAL)
        self.lst = wx.ListCtrl(left, style=wx.LC_REPORT | wx.LC_SINGLE_SEL)
        for i, (t, w) in enumerate((("Result", 140), ("Updated", 78), ("Status", 82))):
            self.lst.InsertColumn(i, t, width=w)
        ls.Add(self.lst, 1, wx.EXPAND | wx.ALL, PAD)
        ls.Add(wx.StaticText(left, label="Show"), 0, wx.LEFT | wx.RIGHT, PAD)
        self.view = wx.RadioBox(left, choices=["Result", "How this was solved", "Wave view (animation)",
                                               "Mesh (as the solver gets it)", "Mesh convergence"],
                                majorDimension=1, style=wx.RA_SPECIFY_COLS)
        ls.Add(self.view, 0, wx.EXPAND | wx.ALL, PAD)
        self.b_browser = wx.Button(left, label="Open in Browser")
        self.b_folder = wx.Button(left, label="Open Result Folder")
        self.b_apply = wx.Button(left, label="Apply Values from File...")
        self.b_sp = wx.Button(left, label="Export S-Parameters...")
        self.b_sp.SetToolTip("Touchstone file of the result: antenna S11 (.s1p) or the RF chain N-port")
        self.b_single = wx.Button(left, label="Save Page as Single File...")
        self.b_single.SetToolTip("The page as one self-contained HTML file, to send or archive")
        self.b_free = wx.Button(left, label="Delete Field Recordings")
        self.b_free.SetToolTip("Shrink or delete the field recordings. Reports and the tuning viewer stay.")
        for b in (self.b_browser, self.b_folder, self.b_apply, self.b_sp, self.b_single, self.b_free):
            ls.Add(b, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        ls.Add(_hint(left, "In a tuning viewer, 'Apply to board'\nwrites the values to the footprints."),
               0, wx.ALL, PAD)
        left.SetSizer(ls)

        right = wx.Panel(split)
        rs = wx.BoxSizer(wx.VERTICAL)
        self.web = None
        if webview is not None:
            try:
                backend = webview.WebViewBackendDefault
                if sys.platform == "win32" and webview.WebView.IsBackendAvailable(webview.WebViewBackendEdge):
                    backend = webview.WebViewBackendEdge
                self.web = webview.WebView.New(right, backend=backend)
                try:
                    self.web.AddScriptMessageHandler("rfsim")
                    self.web.Bind(webview.EVT_WEBVIEW_SCRIPT_MESSAGE_RECEIVED, self.on_message)
                except Exception:
                    pass
            except Exception:
                self.web = None
        if self.web is not None:
            rs.Add(self.web, 1, wx.EXPAND)
        else:
            rs.Add(_hint(right, "Embedded viewer not available (WebView2 runtime missing) - use 'Open in Browser'."),
                   0, wx.ALL, 20)
        right.SetSizer(rs)
        split.SplitVertically(left, right, 310)
        split.SetMinimumPaneSize(200)
        s = wx.BoxSizer(wx.VERTICAL)
        s.Add(split, 1, wx.EXPAND)
        self.SetSizer(s)

        self._items: list = []
        self.lst.Bind(wx.EVT_LIST_ITEM_SELECTED, lambda e: (self.show(), self.show_size()))
        self.view.Bind(wx.EVT_RADIOBOX, lambda e: self.show())
        self.b_free.Bind(wx.EVT_BUTTON, self.on_free)
        self.b_sp.Bind(wx.EVT_BUTTON, self.on_export)
        self.b_single.Bind(wx.EVT_BUTTON, self.on_single)
        self.b_browser.Bind(wx.EVT_BUTTON, lambda e: self.current() and common.open_page(self.current()))
        self.b_folder.Bind(wx.EVT_BUTTON, self.on_folder)
        self.b_apply.Bind(wx.EVT_BUTTON, self.on_apply_file)

    def refresh(self, select_first=False):
        from kicad_rfsim.solver import load_record
        self.lst.DeleteAllItems()
        self._items = [c for c in core.list_configs(self.app.proj()) if c.has_result or (c.out / "mesh.html").exists()]
        fb = core.full_board_info(self.app.proj())
        if fb:
            self._items.append(fb)
        for c in self._items:
            rec = load_record(c.out) or {}
            txt, lev = core.result_status(rec)
            self.lst.Append([c.label, core.fmt_when(c.updated), txt])
            if lev == "warn":
                self.lst.SetItemTextColour(self.lst.GetItemCount() - 1, _warn_colour())
        if self._items and (select_first or self.lst.GetFirstSelected() < 0):
            self.lst.Select(0)
        elif not self._items and self.web is not None:
            self.web.SetPage("<html><body style='font:14px system-ui;color:#777;padding:30px'>No results yet. "
                             "Create a setup and run a simulation.</body></html>", "")

    def show_mesh(self, cfg_path: Path):
        """Show the mesh page of a setup (after Inspect Mesh on the Setup page)."""
        self.refresh()
        for i, c in enumerate(self._items):
            if c.path == cfg_path:
                self.lst.Select(i)
                break
        self.view.SetSelection(3)
        self.app.nb.SetSelection(self.app.nb.FindPage(self))
        self.show()

    def current(self) -> Path | None:
        i = self.lst.GetFirstSelected()
        if i < 0 or i >= len(self._items):
            return None
        c = self._items[i]
        if self.view.GetSelection() == 4:
            return c.out / "convergence" / "convergence.html"
        if self.view.GetSelection() == 3:
            return c.out / "mesh.html"
        if self.view.GetSelection() == 1:
            return c.out / "solver_info.html"
        if self.view.GetSelection() == 2 or c.kind == "fullboard":
            return c.out / "wave.html"
        return c.out / ("antenna_report.html" if c.kind == "antenna" else "tune.html")

    def show(self):
        p = self.current()
        if p is None or self.web is None:
            return
        if p.exists():
            self.web.LoadURL(p.resolve().as_uri())
        else:
            hint = ("Tick <b>Record fields for the wave view</b> on the Simulate page and run this setup again."
                    if self.view.GetSelection() == 2 else
                    "Select the setup on the Setup page and press <b>Inspect Mesh</b>."
                    if self.view.GetSelection() == 3 else
                    "On the Simulate page choose <b>Run: Mesh convergence check</b> and start it."
                    if self.view.GetSelection() == 4 else "Run it again with this version.")
            self.web.SetPage(f"<html><body style='font:14px system-ui;padding:30px'>Not available for this result. "
                             f"{hint}</body></html>", "")

    def _item(self):
        i = self.lst.GetFirstSelected()
        return self._items[i] if 0 <= i < len(self._items) else None

    def show_size(self):
        c = self._item()
        if c is None or c.kind == "fullboard":
            self.b_free.SetLabel("Delete Field Recordings")
            self.b_free.Enable(False)
            return
        b = core.field_data_size(c.out)
        raw = core.raw_field_size(c.out)
        if raw:
            self.b_free.SetLabel(f"Shrink Field Recordings ({core.fmt_bytes(b)})")
        else:
            self.b_free.SetLabel(f"Delete Field Recordings ({core.fmt_bytes(b)})" if b else "No Field Recordings")
        self.b_free.Enable(b > 0)
        self.b_free.GetParent().Layout()

    def on_free(self, _e):
        c = self._item()
        if c is None:
            return
        b = core.field_data_size(c.out)
        if core.raw_field_size(c.out):  # recordings of an older run: shrink them first, nothing is lost
            self.b_free.Enable(False)
            self.app.SetStatusText(f"shrinking the field recordings of {c.label} ...", 0)

            def done(freed):
                self.app.SetStatusText(f"field recordings shrunk: {core.fmt_bytes(freed)} freed, "
                                       f"{core.fmt_bytes(core.field_data_size(c.out))} left", 0)
                self.show_size()

            def fail(e, tb):
                self.show_size()
                self.app.show_error(e, tb)
            self.app.worker.run(lambda: core.shrink_field_data(c.out, self.app.log_threadsafe), done, fail)
            return
        if wx.MessageBox(f"Delete {core.fmt_bytes(b)} of field recordings of '{c.label}'?\n\n"
                         "The report, the tuning viewer and the wave pages stay. The whole-board overlay "
                         "and new wave views need a new run with fields.", "RF Sim",
                         wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION, self) != wx.YES:
            return
        n, freed = core.delete_field_data(c.out)
        self.app.SetStatusText(f"{n} files deleted, {core.fmt_bytes(freed)} freed", 0)
        self.show_size()

    def on_folder(self, _e):
        p = self.current()
        if p is None:
            return
        d = p.parent
        if sys.platform == "win32":
            os.startfile(str(d))
        else:
            wx.LaunchDefaultBrowser(d.as_uri())

    def on_message(self, e):
        try:
            data = json.loads(e.GetString())
        except Exception:
            return
        if isinstance(data, dict) and data.get("type") == "save":  # a file from a page (Touchstone ...)
            self.save_text(data.get("name") or "rfsim.txt", data.get("text", ""))
            return
        if isinstance(data, dict) and data.get("type") == "mesh":  # mesh settings from the mesh page
            self.rebuild_mesh(data)
            return
        self.app.apply_values(data, "tuning viewer")

    def rebuild_mesh(self, data: dict):
        """Mesh inspector: save the mesh settings the page sent, build the mesh again and show it."""
        proj = self.app.proj()
        infos = {c.path.resolve(): c for c in core.list_configs(proj)}
        c = infos.get(Path(str(data.get("config", ""))).resolve())
        if c is None:  # only the project's own setups
            return
        try:
            core.apply_mesh_settings(c.path, str(data.get("mode", "custom")), data.get("values") or {})
        except Exception as e:  # noqa: BLE001
            wx.MessageBox(f"Mesh settings not saved: {e}", APP_NAME, wx.ICON_WARNING, self)
            self.show()
            return
        self.app.log(f"{c.path.name}: mesh settings {data.get('mode')} saved from the mesh page")
        self.app.settings_page.refresh()
        self.app.simulate_page.refresh()
        board = self.app.board()
        self.app.SetStatusText(f"building the mesh of {c.label} ...", 0)

        def done(_page):
            self.app.SetStatusText(f"Mesh of {c.label} rebuilt", 0)
            self.show_mesh(c.path)

        def fail(e, tb):
            self.show()
            self.app.show_error(e, tb)
        self.app.worker.run(lambda: core.inspect_mesh(proj, c, board, self.app.log_threadsafe), done, fail)

    def save_text(self, name: str, text: str):
        i = self.lst.GetFirstSelected()
        start = self._items[i].out if 0 <= i < len(self._items) else Path.home()
        ext = Path(name).suffix.lstrip(".") or "txt"
        with wx.FileDialog(self, "Save", defaultDir=str(start), defaultFile=name,
                           wildcard=f"{ext.upper()} file (*.{ext})|*.{ext}|All files|*",
                           style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as d:
            if d.ShowModal() != wx.ID_OK:
                return
            Path(d.GetPath()).write_text(text, encoding="utf-8")
        self.app.SetStatusText(f"saved {d.GetPath()}", 0)

    def on_export(self, _e):
        """S-parameters of the selected result as Touchstone: antenna S11 (.s1p) or the EM N-port
        of the RF chain (.sNp, layout only - the tuning viewer exports the network with its values)."""
        i = self.lst.GetFirstSelected()
        if not 0 <= i < len(self._items):
            return
        c = self._items[i]
        try:
            src = core.sparam_file(c)
        except Exception as e:  # noqa: BLE001
            wx.MessageBox(str(e), APP_NAME, wx.ICON_INFORMATION, self)
            return
        self.save_text(src.name, src.read_text(encoding="utf-8", errors="replace"))

    def on_single(self, _e):
        """The page shown as one self-contained HTML file (plotly.js inlined)."""
        p = self.current()
        if p is None or not Path(p).exists():
            return
        from kicad_rfsim.pagepack import standalone
        name = f"{Path(p).parent.name}_{Path(p).name}" if Path(p).parent.name not in ("", ".") else Path(p).name
        self.save_text(name, standalone(p))

    def on_apply_file(self, _e):
        start = core.newest_values_file(self.app.proj())
        with wx.FileDialog(self, "Values exported from a tuning viewer", wildcard="RF Sim values (*.json)|*.json",
                           defaultDir=str(start.parent if start else Path.home()),
                           defaultFile=start.name if start else "", style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as d:
            if d.ShowModal() != wx.ID_OK:
                return
            data = json.loads(Path(d.GetPath()).read_text())
        self.app.apply_values(data, Path(d.GetPath()).name)


# ---------------------------------------------------------------------------
# Settings page
# ---------------------------------------------------------------------------
GROUP_LABELS = {"model": "Model", "mesh": "Mesh", "settings": "Antenna model", "solver": "Solver"}


class SettingsPage(wx.ScrolledWindow):
    def __init__(self, parent, app: "RfSimFrame"):
        super().__init__(parent, style=wx.VSCROLL)
        self.SetScrollRate(0, 12)
        _keep_scroll(self)
        self.app = app
        main = wx.BoxSizer(wx.VERTICAL)

        sbb, bbox = _box(self, "Operating band (all setups of this board)")
        self.b_band = wx.Button(bbox, label="Apply Band to All Setups")
        self.b_band.SetToolTip("Set the band in all setups of this board. Mesh settings stay.")
        self.band = BandRow(bbox, sbb, cols=150, inline=True, extra=self.b_band)
        sbb.AddSpacer(PAD)
        main.Add(sbb, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, PAD)
        self.b_band.Bind(wx.EVT_BUTTON, lambda e: self.apply_band())

        sb, box = _box(self, "Solver settings")
        row = wx.BoxSizer(wx.HORIZONTAL)
        row.Add(wx.StaticText(box, label="Setup:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.choice = wx.Choice(box, size=(220, -1))
        row.Add(self.choice, 0, wx.RIGHT, PAD * 3)
        row.Add(wx.StaticText(box, label="Settings:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.mode_choice = wx.Choice(box, choices=["Automatic (recommended)", "Fast (coarse, first look)",
                                                   "Accurate (fine, slow)", "Custom"])
        row.Add(self.mode_choice, 0, wx.ALIGN_CENTER_VERTICAL)
        self.mode_hint = _hint(box, "")
        row.Add(self.mode_hint, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, PAD * 2)
        sb.Add(row, 0, wx.ALL, PAD)
        sb.Add(_hint(box, "Frequencies can be changed in every mode. Custom: all settings, changes highlighted."),
               0, wx.LEFT | wx.RIGHT, PAD)
        self.pg = wxpg.PropertyGridManager(box, style=wxpg.PG_SPLITTER_AUTO_CENTER | wxpg.PG_DESCRIPTION
   )
        self.pg.SetDescBoxHeight(70)
        self.pg.SetMinSize((-1, 330))
        sb.Add(self.pg, 1, wx.EXPAND | wx.ALL, PAD)
        brow = wx.BoxSizer(wx.HORIZONTAL)
        self.b_reset = wx.Button(box, label="Reset to Setup Values")
        self.b_save = wx.Button(box, label="Save")
        brow.AddStretchSpacer()
        brow.Add(self.b_reset, 0, wx.RIGHT, PAD)
        brow.Add(self.b_save, 0)
        sb.Add(brow, 0, wx.EXPAND | wx.ALL, PAD)
        main.Add(sb, 1, wx.EXPAND | wx.ALL, PAD)

        so, obox = _box(self, "openEMS")
        orow = wx.BoxSizer(wx.HORIZONTAL)
        orow.Add(wx.StaticText(obox, label="openEMS.exe:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.picker = wx.FilePickerCtrl(obox, message="Select openEMS.exe",
                                        wildcard="openEMS.exe|openEMS.exe|All files|*",
                                        style=wx.FLP_USE_TEXTCTRL | wx.FLP_OPEN | wx.FLP_FILE_MUST_EXIST)
        orow.Add(self.picker, 1, wx.RIGHT, PAD)
        self.b_detect = wx.Button(obox, label="Search Again")
        orow.Add(self.b_detect, 0)
        so.Add(orow, 0, wx.EXPAND | wx.ALL, PAD)
        self.oems = _hint(obox, "")
        so.Add(self.oems, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        main.Add(so, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)

        sv, vbox = _box(self, "Vendor part libraries (tuning viewer: real parts instead of ideal L / C)")
        vrow = wx.BoxSizer(wx.HORIZONTAL)
        vrow.Add(wx.StaticText(vbox, label="Library folder:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.vpicker = wx.DirPickerCtrl(vbox, message="Folder with vendor S-parameter files",
                                        style=wx.DIRP_USE_TEXTCTRL | wx.DIRP_DIR_MUST_EXIST)
        vrow.Add(self.vpicker, 1)
        sv.Add(vrow, 0, wx.EXPAND | wx.ALL, PAD)
        self.vinfo = _hint(vbox, "")
        sv.Add(self.vinfo, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        main.Add(sv, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)

        sm, mbox = _box(self, "Vendor S-parameter files for single parts (RF chain setup)")
        mrow = wx.BoxSizer(wx.HORIZONTAL)
        self.mlist = wx.ListCtrl(mbox, style=wx.LC_REPORT | wx.LC_SINGLE_SEL, size=(-1, 78))
        for i, (t, w) in enumerate((("Part", 70), ("File", 260), ("File port → pad", 300))):
            self.mlist.InsertColumn(i, t, width=w)
        mrow.Add(self.mlist, 1, wx.EXPAND | wx.RIGHT, PAD)
        mb = wx.BoxSizer(wx.VERTICAL)
        self.b_madd = wx.Button(mbox, label="Add ...")
        self.b_mdel = wx.Button(mbox, label="Remove")
        mb.Add(self.b_madd, 0, wx.BOTTOM, PAD)
        mb.Add(self.b_mdel, 0)
        mrow.Add(mb, 0)
        sm.Add(mrow, 0, wx.EXPAND | wx.ALL, PAD)
        lrow = wx.BoxSizer(wx.HORIZONTAL)
        lrow.Add(wx.StaticText(mbox, label="Antenna data at port 2:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, PAD)
        self.lpicker = wx.FilePickerCtrl(mbox, message="Antenna S-parameters (e.g. chip antenna .s1p)",
                                         wildcard="Touchstone|*.s1p;*.s2p;*.S1P;*.S2P;*.ts",
                                         style=wx.FLP_OPEN | wx.FLP_FILE_MUST_EXIST | wx.FLP_USE_TEXTCTRL)
        lrow.Add(self.lpicker, 1, wx.RIGHT, PAD)
        self.b_lclr = wx.Button(mbox, label="Clear")
        lrow.Add(self.b_lclr, 0)
        sm.Add(lrow, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, PAD)
        self.minfo = _hint(mbox, "Switch, balun, filter: the S-parameter file replaces the part.\n"
                                 "Chip or measured antenna: its .s1p replaces the simulated antenna.")
        sm.Add(self.minfo, 0, wx.ALL, PAD)
        main.Add(sm, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, PAD)
        self.b_madd.Bind(wx.EVT_BUTTON, self.on_madd)
        self.b_mdel.Bind(wx.EVT_BUTTON, self.on_mdel)
        self.lpicker.Bind(wx.EVT_FILEPICKER_CHANGED, self.on_load_file)
        self.b_lclr.Bind(wx.EVT_BUTTON, lambda e: self.on_load_file(None))
        self.SetSizer(main)
        self.vpicker.Bind(wx.EVT_DIRPICKER_CHANGED, self.on_vendor)
        vd = core.load_app_settings().get("vendor_dir")
        if vd:
            self.vpicker.SetPath(vd)
        self.show_vendor(vd)

        self._infos, self._rows, self._cfg = [], [], None
        self.choice.Bind(wx.EVT_CHOICE, lambda e: (self.load(), self.show_models()))
        self.mode_choice.Bind(wx.EVT_CHOICE, lambda e: self.on_mode())
        self.b_reset.Bind(wx.EVT_BUTTON, lambda e: self.reset())
        self.b_save.Bind(wx.EVT_BUTTON, lambda e: self.save())
        self.pg.Bind(wxpg.EVT_PG_CHANGED, lambda e: (self.mark(), self._lock(self.mode() == "custom")))
        self.picker.Bind(wx.EVT_FILEPICKER_CHANGED, self.on_pick)
        self.b_detect.Bind(wx.EVT_BUTTON, lambda e: self.detect(clear=True))

    # -- vendor S-parameter files of single parts
    def _mcfg(self):
        i = self.choice.GetSelection()
        pref = self._infos[i].path if 0 <= i < len(self._infos) else None
        return core.circuit_config(self.app.proj(), pref)

    def show_models(self):
        self.mlist.DeleteAllItems()
        p = self._mcfg()
        for w in (self.b_madd, self.b_mdel, self.lpicker, self.b_lclr):
            w.Enable(p is not None)
        if p is None:
            return
        pm = core.part_models(p)
        for ref, m in pm["models"].items():
            self.mlist.Append([ref, Path(m["file"]).name, ", ".join(f"{k + 1} → {q}" for k, q in enumerate(m["pads"]))])
        self.lpicker.SetPath(pm["load_file"] or "")

    def on_madd(self, _e):
        p = self._mcfg()
        if p is None:
            return
        dlg = PartModelDialog(self, p)
        if dlg.ShowModal() == wx.ID_OK:
            try:
                notes = core.assign_part_model(p, dlg.ref, dlg.file, dlg.pads)
                self.app.log(f"{dlg.ref}: vendor model {Path(dlg.file).name}" + ("; " + "; ".join(notes) if notes else ""))
            except Exception as ex:  # noqa: BLE001
                wx.MessageBox(str(ex), APP_NAME, wx.ICON_WARNING, self)
        dlg.Destroy()
        self.show_models()
        self.app.simulate_page.refresh()

    def on_mdel(self, _e):
        p, i = self._mcfg(), self.mlist.GetFirstSelected()
        if p is None or i < 0:
            return
        core.remove_part_model(p, self.mlist.GetItemText(i, 0))
        self.show_models()

    def on_load_file(self, _e):
        p = self._mcfg()
        if p is None:
            return
        f = self.lpicker.GetPath() if _e is not None else None
        core.set_load_file(p, f or None)
        if _e is None:
            self.lpicker.SetPath("")
        self.app.log(f"port-2 load: {Path(f).name if f else 'simulated antenna / constant'} (next run of {p.stem})")

    # -- operating band
    def apply_band(self):
        try:
            r = self.band.ranges()
            names = core.apply_band(self.app.proj(), r)
        except Exception as e:  # noqa: BLE001
            wx.MessageBox(str(e), APP_NAME, wx.ICON_WARNING, self)
            return
        self.app.log(f"band {self.band.text.GetValue()} MHz written to: {', '.join(names) or 'no setup'}")
        self.app.SetStatusText(f"Band applied to {len(names)} setup(s) - the next run uses it", 0)
        self.load()
        self.app.simulate_page.refresh()

    # -- setups
    def refresh(self):
        try:
            r, why = core.project_band(self.app.proj())
            self.band.set(r, why if r else "no setup yet - choose the band on the Setup page")
        except Exception:  # noqa: BLE001
            pass
        sel = self.choice.GetStringSelection()
        self._infos = core.list_configs(self.app.proj())
        self.choice.Set([c.label for c in self._infos])
        if self._infos:
            i = self.choice.FindString(sel)
            self.choice.SetSelection(i if i >= 0 else 0)
        self.load()
        self.detect()
        self.show_models()

    def load(self):
        i = self.choice.GetSelection()
        enable = 0 <= i < len(self._infos)
        for w in (self.mode_choice, self.b_reset, self.b_save, self.b_band):
            w.Enable(enable)
        if not enable:
            self._build([])
            return
        self._path = self._infos[i].path
        self._cfg = json.loads(self._path.read_text())
        self._rows = core.settings_rows(self._cfg)
        custom = core.solver_mode(self._cfg) == "custom"
        self.set_mode(core.solver_mode(self._cfg))
        self._build(self._rows)
        self.on_mode(load=True)

    def _build(self, rows):
        """(Re)create the whole grid. Properties are never replaced one by one:
        ReplaceProperty on a selected/edited property crashes wxPython."""
        grid = self.pg.GetGrid()
        try:
            grid.ClearSelection(False)
        except Exception:
            pass
        self.pg.Freeze()
        try:
            self.pg.Clear()
            page = self.pg.AddPage("Settings")
            grp = None
            for r in rows:
                if r["group"] != grp:
                    grp = r["group"]
                    page.Append(wxpg.PropertyCategory(GROUP_LABELS.get(grp, grp)))
                page.Append(self._prop(r))
        finally:
            self.pg.Thaw()

    @staticmethod
    def _label(r):
        k = r["key"]
        unit = " (MHz)" if k in core.FREQ_KEYS else ""
        return k.replace("_", " ").capitalize() + unit

    def _prop(self, r):
        name, label, v, k = f"{r['group']}.{r['key']}", self._label(r), r["value"], r["key"]
        if k in core.FREQ_KEYS:
            if r["type"] == "list":
                p = wxpg.StringProperty(label, name, ", ".join(f"{x / 1e6:g}" for x in (v or [])))
            else:
                p = wxpg.FloatProperty(label, name, float(v) / 1e6 if v is not None else 0.0)
        elif r["choices"]:
            ch = list(r["choices"])
            if v not in ch:
                ch.append(str(v))
            p = wxpg.EnumProperty(label, name, ch, list(range(len(ch))), ch.index(v))
        elif r["type"] == "bool":
            p = wxpg.BoolProperty(label, name, bool(v))
            p.SetAttribute(wxpg.PG_BOOL_USE_CHECKBOX, True)
        elif r["type"] == "int":
            p = wxpg.IntProperty(label, name, int(v if v is not None else 0))
        elif r["type"] == "float" and v is not None:
            p = wxpg.FloatProperty(label, name, float(v))
        else:  # optional values: empty = automatic
            p = wxpg.StringProperty(label, name, "" if v is None else str(v))
        dflt = "automatic" if r["default"] is None else self._show(r, r["default"])
        p.SetHelpString(f"{r['doc']}\nKey: {name}   ·   default: {dflt}   ·   setup value: "
                        f"{'automatic' if r['auto'] is None else self._show(r, r['auto'])}")
        return p

    @staticmethod
    def _show(r, v):
        if r["key"] in core.FREQ_KEYS:
            if isinstance(v, (list, tuple)):
                return ", ".join(f"{x / 1e6:g}" for x in v) + " MHz"
            return f"{float(v) / 1e6:g} MHz"
        return str(v)

    def _read(self) -> list[dict]:
        rows = []
        for r in self._rows:
            r = dict(r)
            k = r["key"]
            raw = self.pg.GetPropertyValue(f"{r['group']}.{k}")
            if k in core.FREQ_KEYS:
                if r["type"] == "list":
                    r["value"] = [float(x) * 1e6 for x in str(raw).replace(";", ",").split(",") if x.strip()]
                else:
                    r["value"] = float(raw) * 1e6
            elif r["choices"]:
                r["value"] = self.pg.GetPropertyValueAsString(f"{r['group']}.{k}")
            elif r["type"] == "bool":
                r["value"] = bool(raw)
            elif r["type"] == "optint":
                t = str(raw).strip()
                if t == "" or t.lower() in ("auto", "none", "automatic"):
                    r["value"] = None
                else:
                    try:
                        r["value"] = int(float(t))
                    except ValueError:
                        raise ValueError(f"{self._label(r)}: '{t}' is not a whole number (leave empty for automatic)")
            elif r["type"] == "int":
                r["value"] = int(raw)
            elif r["type"] == "float" and r["value"] is not None:
                r["value"] = float(raw)
            else:
                s = str(raw).strip()
                if s == "" or s.lower() in ("auto", "none", "automatic"):
                    r["value"] = None
                else:
                    try:
                        r["value"] = float(s) if r["type"] == "float" else s
                    except ValueError:
                        raise ValueError(f"{self._label(r)}: '{s}' is not a number (leave empty for automatic)")
            rows.append(r)
        return rows

    def mark(self):
        """Highlight values that differ from the default."""
        try:
            rows = self._read()
        except ValueError:
            return
        acc = wx.Colour(42, 111, 219)
        for r in rows:
            name = f"{r['group']}.{r['key']}"
            differs = r["default"] is not None and not _same(r["value"], r["default"])
            self.pg.GetGrid().SetPropertyTextColour(name, acc if differs else
                                                    wx.SystemSettings.GetColour(wx.SYS_COLOUR_WINDOWTEXT))

    def mode(self) -> str:
        i = self.mode_choice.GetSelection()
        return core.MODES[i] if 0 <= i < len(core.MODES) else "auto"

    def set_mode(self, m: str):
        self.mode_choice.SetSelection(core.MODES.index(m) if m in core.MODES else 0)
        self.mode_hint.SetLabel(core.PRESETS.get(m, {}).get("text", "") if m in core.PRESETS else
                                "the values the setup chose for this board" if m == "auto" else
                                "every setting editable below")

    def _lock(self, custom: bool):
        """Presets: only the frequencies are editable; the grid stays enabled so it scrolls."""
        grey = wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT)
        face = wx.SystemSettings.GetColour(wx.SYS_COLOUR_BTNFACE)
        base = wx.SystemSettings.GetColour(wx.SYS_COLOUR_WINDOW)
        g = self.pg.GetGrid()
        for r in self._rows:
            name = f"{r['group']}.{r['key']}"
            ro = not custom and r["key"] not in core.FREQ_KEYS
            try:
                self.pg.SetPropertyReadOnly(name, ro)
                g.SetPropertyBackgroundColour(name, face if ro else base)
                if ro:
                    g.SetPropertyTextColour(name, grey)
            except Exception:  # noqa: BLE001
                pass
        g.Refresh()

    def on_mode(self, load=False):
        m = self.mode()
        custom = m == "custom"
        self.set_mode(m)
        self.pg.Enable(True)
        self.b_reset.Enable(custom)
        if not load and not custom and self._cfg is not None:
            # a preset: derive the values and store them right away
            wx.CallAfter(self._to_preset, m)
            return
        self.mark()
        self._lock(custom)

    def _to_preset(self, m: str):
        try:
            core.save_settings(self._path, self._rows, m)
        except Exception as e:  # noqa: BLE001
            wx.MessageBox(str(e), APP_NAME, wx.ICON_WARNING, self)
            return
        self.app.SetStatusText(f"{self._path.name}: {self.mode_choice.GetStringSelection()} settings saved", 0)
        self.load()
        self.app.simulate_page.refresh()

    def _to_auto(self):
        self._to_preset("auto")

    def reset(self):
        """Custom mode: put the setup's values back into the grid (saved with Save)."""
        self._rows = [dict(r, value=r["auto"]) for r in self._rows]
        wx.CallAfter(lambda: (self._build(self._rows), self.mark()))

    def save(self):
        try:
            rows = self._read()
            core.save_settings(self._path, rows, self.mode())
            synced = core.sync_sweep(self._path)
        except Exception as e:  # noqa: BLE001
            wx.MessageBox(str(e), APP_NAME, wx.ICON_WARNING, self)
            return
        self.app.SetStatusText(f"Settings saved to {self._path.name}"
                               + (f"; same sweep set in {', '.join(synced)}" if synced else ""), 0)
        if synced:
            self.app.log(f"sweep of {self._path.stem} also set in {', '.join(synced)} (same frequencies for all setups)")
        self.load()
        self.app.simulate_page.refresh()

    # -- openEMS
    def detect(self, clear=False):
        st = core.load_app_settings()
        if clear:
            st.pop("openems_bin", None)
            core.save_app_settings(st)
        exe = core.find_openems()
        if exe:
            self.picker.SetPath(exe)
            ver, probs = core.openems_check(exe)
            self.oems.SetLabel(f"Found{' openEMS ' + ver if ver else ''}: {exe}"
                               + "".join(f"\nWarning: {p}" for p in probs))
            self.oems.SetForegroundColour(_warn_colour() if probs else wx.NullColour)
        else:
            self.oems.SetLabel("openEMS not found. Select openEMS.exe, or unzip the Windows build into "
                               "AppData\\Local\\kicad-rfsim\\openEMS or AppData\\Roaming\\kicad-rfsim\\openEMS.")
        self.app.update_status()

    # -- vendor part libraries
    def on_vendor(self, _e):
        path = self.vpicker.GetPath()
        st = core.load_app_settings()
        st["vendor_dir"] = path
        core.save_app_settings(st)
        self.show_vendor(path)

    def show_vendor(self, path):
        if not core.apply_vendor_dir(path):
            self.vinfo.SetLabel("No library folder: the tuning viewer uses ideal parts (value, Q, ESL).")
            return
        self.vinfo.SetLabel("Reading the part library ...")

        def work():
            try:
                txt = core.vendor_summary(path)
            except Exception as e:  # noqa: BLE001
                txt = f"Could not read the library: {e}"
            wx.CallAfter(lambda: (self.vinfo.SetLabel(txt + " - the tuning viewers offer them after the next "
                                                      "Simulate (results are reused, no new EM run)."),
                                  self.Layout()))
        threading.Thread(target=work, daemon=True).start()

    def on_pick(self, _e):
        st = core.load_app_settings()
        st["openems_bin"] = self.picker.GetPath()
        core.save_app_settings(st)
        self.detect()


def _same(a, b) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(float(a) - float(b)) <= 1e-9 * max(1.0, abs(float(b)))
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(_same(x, y) for x, y in zip(a, b))
    return a == b


# ---------------------------------------------------------------------------
# main window
# ---------------------------------------------------------------------------
class RfSimFrame(wx.Frame):
    def __init__(self, kicad, board):
        super().__init__(None, title=APP_NAME, size=(1180, 780))
        self.kicad, self._board = kicad, board
        self.SetIcons(_icon_bundle())
        self.SetMinSize((900, 600))
        self.worker = Worker(self)
        self.CreateStatusBar(2)
        self.SetStatusWidths([-3, -2])

        panel = wx.Panel(self)
        self.nb = wx.Notebook(panel)
        self.setup_page = SetupPage(self.nb, self)
        self.casing_page = CasingPage(self.nb, self)
        self.simulate_page = SimulatePage(self.nb, self)
        self.results_page = ResultsPage(self.nb, self)
        self.settings_page = SettingsPage(self.nb, self)
        for p, t in ((self.setup_page, "Setup"), (self.casing_page, "Casing && 3D"), (self.simulate_page, "Simulate"),
                     (self.results_page, "Results"), (self.settings_page, "Solver Settings")):
            self.nb.AddPage(p, t)
        self.nb.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, self._on_tab)
        s = wx.BoxSizer(wx.VERTICAL)
        s.Add(self.nb, 1, wx.EXPAND | wx.ALL, PAD)
        panel.SetSizer(s)
        self.update_title()
        self.refresh_all()
        self.setup_page.read_selection()
        self.Bind(wx.EVT_CLOSE, self.on_close)
        self.Centre()

    # -- KiCad
    def board(self):
        try:
            self._board = self.kicad.get_board()
        except Exception:
            pass  # keep the last board (KiCad busy)
        return self._board

    def proj(self) -> Path:
        return Path(self._board.get_project().path)

    def update_title(self):
        try:
            self.SetTitle(f"{APP_NAME} – {self._board.name}")
        except Exception:
            self.SetTitle(APP_NAME)

    def update_status(self):
        exe = core.find_openems()
        self.SetStatusText("openEMS ready" if exe else "openEMS not found (Solver Settings)", 1)

    def refresh_all(self):
        for p in (self.setup_page, self.casing_page, self.simulate_page, self.settings_page):
            try:
                p.refresh()
            except Exception as e:  # noqa: BLE001
                self.log(f"refresh failed: {e}")
        self.results_page.refresh(select_first=True)
        self.update_status()

    # -- log / busy / errors
    def _on_tab(self, e):
        e.Skip()
        if self.nb.GetCurrentPage() is self.casing_page:
            self.casing_page.on_shown()

    def log(self, msg: str):
        self.simulate_page.log(msg)
        self.SetStatusText(msg.splitlines()[0][:160] if msg else "", 0)

    def log_threadsafe(self, msg: str):
        wx.CallAfter(self.log, msg)

    def set_busy(self, busy: bool):
        self.setup_page.b_create.Enable(not busy)
        self.setup_page.b_read.Enable(not busy)
        self.setup_page.b_mesh.Enable(not busy)
        if busy:
            wx.BeginBusyCursor()
        elif wx.IsBusy():
            wx.EndBusyCursor()

    def show_error(self, e, tb=""):
        self.log(tb or str(e))
        dlg = wx.MessageDialog(self, core.explain_error(e), APP_NAME, wx.OK | wx.ICON_ERROR)
        if tb:
            dlg.SetExtendedMessage("Details are in the log (page Simulate).")
        dlg.ShowModal()
        dlg.Destroy()

    def bring_to_front(self):
        if self.IsIconized():
            self.Iconize(False)
        self.Show()
        self.Raise()
        self.RequestUserAttention()
        try:
            self.update_title()
            self.setup_page.read_selection()
        except Exception:
            pass

    # -- openEMS
    def ensure_openems(self) -> str | None:
        exe = core.find_openems()
        if exe:
            return exe
        dlg = wx.MessageDialog(self, "openEMS was not found.", APP_NAME, wx.YES_NO | wx.CANCEL | wx.ICON_QUESTION)
        dlg.SetExtendedMessage("Select openEMS.exe yourself, or let RF Sim download the official Windows build "
                               f"({common.OPENEMS_RELEASE}, about 65 MB, from GitHub) into "
                               "AppData\\Local\\kicad-rfsim\\openEMS.")
        dlg.SetYesNoCancelLabels("Select openEMS.exe...", "Download", "Cancel")
        r = dlg.ShowModal()
        dlg.Destroy()
        if r == wx.ID_YES:
            with wx.FileDialog(self, "Select openEMS.exe", wildcard="openEMS.exe|openEMS.exe|All files|*",
                               style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as d:
                if d.ShowModal() != wx.ID_OK:
                    return None
                st = core.load_app_settings()
                st["openems_bin"] = d.GetPath()
                core.save_app_settings(st)
            self.settings_page.detect()
            return core.find_openems()
        if r == wx.ID_NO:
            self.log("downloading openEMS ...")
            self.worker.run(lambda: common.download_openems(self.log_threadsafe),
                            lambda exe: (self.settings_page.detect(),
                                         self.log(f"openEMS installed: {exe}" if exe else "download failed")))
        return None

    # -- values -> board
    def apply_values(self, data: dict, source: str):
        changes = [(r, core.describe_change(v)) for r, v in data.get("values", {}).items() if v.get("changed")]
        if not changes:
            wx.MessageBox("No value was changed in the tuning viewer.", APP_NAME, wx.ICON_INFORMATION, self)
            return
        txt = "\n".join(f"{r}  →  {t}" for r, t in changes)
        if wx.MessageBox(f"Write these values to the footprints?\n\n{txt}\n\nAll changes are one undo step "
                         "(Ctrl+Z in the PCB editor).", APP_NAME, wx.YES_NO | wx.ICON_QUESTION, self) != wx.YES:
            return
        try:
            rows = core.apply_values(self.board(), data)
        except Exception as e:  # noqa: BLE001
            self.show_error(e, traceback.format_exc())
            return
        done = [r for r in rows if r[3] == "changed"]
        msg = "\n".join(f"{r[0]}: {r[1]} → {r[2]}  ({r[3]})" for r in rows)
        wx.MessageBox(f"{len(done)} value(s) written ({source}).\n\n{msg}\n\nNext: Tools → Update Schematic from PCB "
                      "to carry the values into the schematic.", APP_NAME, wx.ICON_INFORMATION, self)

    def on_close(self, e):
        if self.worker.busy and self.simulate_page.b_stop.IsEnabled():
            if wx.MessageBox("A simulation is running. Stop it and close RF Sim?", APP_NAME,
                             wx.YES_NO | wx.ICON_QUESTION, self) != wx.YES:
                e.Veto()
                return
            self.simulate_page.cancel.set()
        from kicad_rfsim.solver import kill_all
        kill_all()  # openEMS would keep running on all cores after the window is gone
        try:
            pf = getattr(self, "_port_file", None)
            if pf and pf.read_text() == str(getattr(self, "_port_srv_port", "")):
                pf.unlink()
        except Exception:
            pass
        e.Skip()


def main(kicad=None, board=None):
    app = wx.App(False)
    app.SetAppName("kicad-rfsim")
    if kicad is None:
        try:
            kicad, board, _ = common.connect()
        except Exception as e:  # noqa: BLE001
            wx.MessageBox(f"Could not connect to the KiCad PCB editor:\n{e}\n\nOpen a board in the PCB editor and "
                          "enable the API (Preferences → Plugins).", APP_NAME, wx.ICON_ERROR)
            return
    port_file = _port_file(board)
    if _ask_running_instance(port_file):
        return  # this board already has a window: it comes to the front
    threading.Thread(target=common.cleanup_temp, daemon=True).start()
    frame = RfSimFrame(kicad, board)
    frame._port_srv_port = _serve_raise(frame, port_file).getsockname()[1]
    frame.Show()
    app.MainLoop()


if __name__ == "__main__":
    main()
