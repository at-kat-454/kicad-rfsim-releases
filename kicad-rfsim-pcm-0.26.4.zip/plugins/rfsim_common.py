"""Shared helpers for the RF Sim KiCad plugin actions (KiCad 10, IPC API)."""
from __future__ import annotations

import html
import json
import os
import sys
import tempfile
import time
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))  # bundled engine package "kicad_rfsim"

APP_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local" / "share")) / "kicad-rfsim"
OPENEMS_RELEASE = "v0.37.0"


# ---------------------------------------------------------------------------
# KiCad connection
# ---------------------------------------------------------------------------
def connect():
    from kipy import KiCad

    kicad = KiCad()
    board = kicad.get_board()
    proj_dir = Path(board.get_project().path)
    return kicad, board, proj_dir


def cleanup_temp(max_age_s: float = 86400.0, where: Path | None = None, prefix: str = "rfsim_"):
    """Remove old board snapshot folders (default: those earlier versions left in the temp folder)."""
    import shutil
    now = time.time()
    for d in Path(where or tempfile.gettempdir()).glob(prefix + "*"):
        try:
            if d.is_dir() and now - d.stat().st_mtime > max_age_s:
                shutil.rmtree(d, ignore_errors=True)
        except OSError:
            pass


def board_snapshot(board, proj_dir: Path) -> tuple[Path, bool]:
    """Copy of the open board including unsaved edits. Falls back to the file on disk.
    Snapshots live in the app folder and are removed after a day (earlier versions left one copy
    per run in the temp folder); each call gets its own folder, a running simulation keeps its file."""
    base = APP_DIR / "snapshots"
    base.mkdir(parents=True, exist_ok=True)
    cleanup_temp(86400.0, base, "s_")
    tmp = Path(tempfile.mkdtemp(prefix="s_", dir=base)) / board.name
    try:
        board.save_as(str(tmp), overwrite=True, include_project=False)
        if tmp.exists():
            return tmp, True
    except Exception:
        pass
    return proj_dir / board.name, False


def selected_nets(board, ground=None) -> list[str]:
    if ground is None:
        from kicad_rfsim.board import Board
        ground = Board._GND_NAMES
    nets: list[str] = []

    def add(n):
        name = getattr(n, "name", None) or (n if isinstance(n, str) else None)
        if name and name not in ground and name not in nets and not name.startswith("unconnected-"):
            nets.append(name)

    for it in board.get_selection():
        if hasattr(it, "net"):
            add(it.net)
        d = getattr(it, "definition", None)
        for p in getattr(d, "pads", []) if d is not None else []:
            add(getattr(p, "net", None))
    return nets


# ---------------------------------------------------------------------------
# project files
# ---------------------------------------------------------------------------
def rfsim_dir(proj_dir: Path) -> Path:
    d = proj_dir / "rfsim"
    d.mkdir(exist_ok=True)
    return d


def configs(proj_dir: Path) -> list[Path]:
    return sorted(rfsim_dir(proj_dir).glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)


# ---------------------------------------------------------------------------
# openEMS
# ---------------------------------------------------------------------------
def find_openems() -> str | None:
    """Path chosen in the RF Sim window, OPENEMS_BIN, PATH, or kicad-rfsim\\openEMS in AppData Local/Roaming."""
    from kicad_rfsim.openems_export import find_openems as _f
    try:
        configured = json.loads((APP_DIR / "settings.json").read_text()).get("openems_bin")
    except Exception:
        configured = None
    return _f(configured or None)


def download_openems(log) -> str | None:
    """Fetch the Windows build from the GitHub release into %LOCALAPPDATA%\\kicad-rfsim\\openEMS."""
    import io
    import urllib.request
    import zipfile

    api = f"https://api.github.com/repos/thliebig/openEMS-Project/releases/tags/{OPENEMS_RELEASE}"
    with urllib.request.urlopen(api, timeout=30) as r:
        rel = json.load(r)
    assets = [a for a in rel.get("assets", []) if a["name"].lower().endswith(".zip") and "win" in a["name"].lower()]
    if not assets:
        return None
    a = assets[0]
    log(f"downloading {a['name']} ({a['size']/1e6:.0f} MB) ...")
    with urllib.request.urlopen(a["browser_download_url"], timeout=600) as r:
        data = r.read()
    dest = APP_DIR / "openEMS"
    dest.mkdir(parents=True, exist_ok=True)
    zipfile.ZipFile(io.BytesIO(data)).extractall(dest)
    return find_openems()


# ---------------------------------------------------------------------------
# opening pages: Chrome if installed (or RFSIM_BROWSER), else the .html default app
# ---------------------------------------------------------------------------
def _find_browser() -> str | None:
    env = os.environ.get("RFSIM_BROWSER")
    if env and Path(env).exists():
        return env
    cands = []
    for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"), os.environ.get("LOCALAPPDATA")):
        if base:
            cands.append(Path(base) / "Google" / "Chrome" / "Application" / "chrome.exe")
    for c in cands:
        if c.exists():
            return str(c)
    return None


def open_page(path: Path):
    """Open a local HTML file. Passes the plain file path, not a file:// URI
    (URIs from the plugin process can end up as an empty browser start page)."""
    import subprocess

    path = Path(path).resolve()
    exe = _find_browser()
    try:
        if exe:
            subprocess.Popen([exe, str(path)], close_fds=True)
            return
        if sys.platform == "win32":
            os.startfile(str(path))  # default app for .html
            return
    except Exception:
        pass
    webbrowser.open(path.as_uri())


# ---------------------------------------------------------------------------
# browser pages (index of results for "Open in Browser")
# ---------------------------------------------------------------------------
_CSS = """body{font:14px/1.5 system-ui,sans-serif;margin:0;background:#fafaf8;color:#1d1d1b}
@media (prefers-color-scheme:dark){body{background:#181816;color:#ecebe6}}
main{max-width:860px;margin:0 auto;padding:20px 16px}h1{font-size:18px}a{color:#2a6fdb}"""


def show_page(path: Path, title: str, body_html: str):
    path.write_text(f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(title)}</title>"
                    f"<style>{_CSS}</style></head><body><main><h1>{html.escape(title)}</h1>{body_html}</main></body></html>",
                    encoding="utf-8")
    open_page(path)


def write_index(out: Path, results) -> Path:
    """Links to every report / viewer found under <project>/rfsim."""
    rows = []
    for p in sorted(out.rglob("antenna_report.html")) + sorted(out.rglob("tune.html")):
        kind = "Antenna report" if p.name == "antenna_report.html" else "Tuning viewer"
        rel = p.relative_to(out).as_posix()
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime))
        si = p.parent / "solver_info.html"
        info = f"<a href='{si.relative_to(out).as_posix()}'>how it was solved</a>" if si.exists() else ""
        rows.append(f"<tr><td>{kind}</td><td><a href='{rel}'>{html.escape(p.parent.name)}</a></td><td>{info}</td>"
                    f"<td>{when}</td></tr>")
    body = ("<table><tr><th>Type</th><th>Setup</th><th>Solver</th><th>Updated</th></tr>" + "".join(rows) + "</table>"
            "<p>Workflow: tune in the viewer → <b>Export values</b> → <b>RF Sim: Apply tuned values</b> in KiCad → "
            "<b>Tools → Update Schematic from PCB</b>.</p>")
    idx = out / "index.html"
    idx.write_text(f"<!doctype html><html><head><meta charset='utf-8'><title>RF Sim results</title><style>{_CSS}"
                   f"table{{border-collapse:collapse}}td,th{{padding:4px 10px;border-bottom:1px solid #ccc;text-align:left}}"
                   f"</style></head><body><main><h1>RF Sim results</h1>{body}</main></body></html>", encoding="utf-8")
    return idx


def selected_segments(board) -> list[list[tuple[float, float]]]:
    """End points (mm) of the selected traces / arcs in the PCB editor."""
    out = []
    for it in board.get_selection():
        a, b = getattr(it, "start", None), getattr(it, "end", None)
        if a is None or b is None or getattr(it, "reference_field", None) is not None:
            continue
        try:
            out.append([(a.x / 1e6, a.y / 1e6), (b.x / 1e6, b.y / 1e6)])
        except AttributeError:
            continue
    return out


def selected_refs(board) -> list[str]:
    """References of the selected footprints."""
    refs = []
    for it in board.get_selection():
        rf = getattr(it, "reference_field", None)
        if rf is not None:
            try:
                r = rf.text.value
            except Exception:
                continue
            if r and r not in refs:
                refs.append(r)
    return refs
