"""Write small synthetic .kicad_pcb files (tests, validation, examples).

The files follow the KiCad 10 format closely enough to open in KiCad (layer ids, uuids,
zone fill data), so generated test boards can also be run from the plugin window.
"""
from __future__ import annotations

import json
import uuid
from pathlib import Path


def _pts(poly):
    return " ".join(f"(xy {x:.4f} {y:.4f})" for x, y in poly)


def _u(seed: list) -> str:
    """Deterministic uuids (same board -> same file)."""
    seed[0] += 1
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"kicad-rfsim-synth/{seed[1]}/{seed[0]}"))


_USER_LAYERS = [(9, "F.Adhes", "user", "F.Adhesive"), (11, "B.Adhes", "user", "B.Adhesive"), (13, "F.Paste", "user", None),
                (15, "B.Paste", "user", None), (5, "F.SilkS", "user", "F.Silkscreen"), (7, "B.SilkS", "user", "B.Silkscreen"),
                (1, "F.Mask", "user", None), (3, "B.Mask", "user", None), (17, "Dwgs.User", "user", "User.Drawings"),
                (19, "Cmts.User", "user", "User.Comments"), (21, "Eco1.User", "user", "User.Eco1"),
                (23, "Eco2.User", "user", "User.Eco2"), (25, "Edge.Cuts", "user", None), (27, "Margin", "user", None),
                (31, "F.CrtYd", "user", "F.Courtyard"), (29, "B.CrtYd", "user", "B.Courtyard"), (35, "F.Fab", "user", None),
                (33, "B.Fab", "user", None)]

_FONT = "(effects (font (size 1 1) (thickness 0.15)))"


class SynthBoard:
    def __init__(self, thickness=1.6, er=4.4, tand=0.02, layers=("F.Cu", "B.Cu"), cu=0.035,
                 aux_origin=(0.0, 0.0), grid_origin=(0.0, 0.0), diel: list[float] | None = None, name: str = "synth"):
        """``diel``: dielectric thicknesses top to bottom (default: equal split of the rest)."""
        self.t, self.er, self.tand, self.layers, self.cu = thickness, er, tand, list(layers), cu
        self.aux, self.grid = aux_origin, grid_origin
        self.diel = diel
        self.items: list[str] = []
        self._seed = [0, name]

    def outline_rect(self, x0, y0, x1, y1):
        self.items.append(f'(gr_rect (start {x0} {y0}) (end {x1} {y1}) (stroke (width 0.1) (type default)) (fill no) '
                          f'(layer "Edge.Cuts") (uuid "{_u(self._seed)}"))')

    def outline_poly(self, pts):
        self.items.append(f'(gr_poly (pts {_pts(pts)}) (stroke (width 0.1) (type default)) (fill no) '
                          f'(layer "Edge.Cuts") (uuid "{_u(self._seed)}"))')

    def track(self, pts, width, net, layer="F.Cu"):
        for (xa, ya), (xb, yb) in zip(pts, pts[1:]):
            self.items.append(f'(segment (start {xa} {ya}) (end {xb} {yb}) (width {width}) (layer "{layer}") '
                              f'(net "{net}") (uuid "{_u(self._seed)}"))')

    def fill(self, poly, net, layer="F.Cu", clearance=0.2):
        """Copper zone, already filled (the fill equals the outline: keep other copper out of it)."""
        self.items.append(f'(zone (net "{net}") (layer "{layer}") (uuid "{_u(self._seed)}") (hatch edge 0.5) '
                          f'(connect_pads yes (clearance {clearance})) (min_thickness 0.2) (filled_areas_thickness no) '
                          f'(fill yes (thermal_gap 0.5) (thermal_bridge_width 0.5) (island_removal_mode 0)) '
                          f'(polygon (pts {_pts(poly)})) (filled_polygon (layer "{layer}") (pts {_pts(poly)})))')

    def copper_poly(self, pts, net, layer="F.Cu"):
        """Filled copper polygon of a net (a graphic shape on a copper layer, no zone: it is not refilled)."""
        self.items.append(f'(gr_poly (pts {_pts(pts)}) (stroke (width 0) (type solid)) (fill yes) '
                          f'(layer "{layer}") (net "{net}") (uuid "{_u(self._seed)}"))')

    def via(self, x, y, net, size=0.6, drill=0.3):
        self.items.append(f'(via (at {x} {y}) (size {size}) (drill {drill}) (layers "F.Cu" "B.Cu") (net "{net}") '
                          f'(uuid "{_u(self._seed)}"))')

    def footprint(self, ref, x, y, pads, angle=0.0, value="", models=(), lib: str | None = None, dnp: bool = False):
        """pads: list of (number, dx, dy, w, h, net, kind) with kind 'smd' or ('thru_hole', drill).
        ``lib``: library id, e.g. "Capacitor_SMD:C_0402_1005Metric" (sets the part kind)."""
        ps = []
        for num, dx, dy, w, h, net, kind in pads:
            nt = f'(net "{net}") ' if net else ""
            if kind == "smd":
                ps.append(f'(pad "{num}" smd rect (at {dx} {dy} {angle}) (size {w} {h}) (layers "F.Cu" "F.Mask" "F.Paste") '
                          f'{nt}(uuid "{_u(self._seed)}"))')
            else:
                ps.append(f'(pad "{num}" thru_hole circle (at {dx} {dy} {angle}) (size {w} {h}) (drill {kind[1]}) '
                          f'(layers "*.Cu" "*.Mask") {nt}(uuid "{_u(self._seed)}"))')
        ms = []
        for m in models:
            o, r = m.get("offset", (0, 0, 0)), m.get("rotate", (0, 0, 0))
            ms.append(f'(model "{m.get("path", "x.step")}" (offset (xyz {o[0]} {o[1]} {o[2]})) (scale (xyz 1 1 1)) '
                      f'(rotate (xyz {r[0]} {r[1]} {r[2]})))')
        lib = lib or f"synth:{ref}"
        self.items.append(
            f'(footprint "{lib}" (layer "F.Cu") (uuid "{_u(self._seed)}") (at {x} {y} {angle}) '
            f'(property "Reference" "{ref}" (at 0 -1.5 {angle}) (layer "F.SilkS") (uuid "{_u(self._seed)}") {_FONT}) '
            f'(property "Value" "{value}" (at 0 1.5 {angle}) (layer "F.Fab") (uuid "{_u(self._seed)}") {_FONT}) '
            f'(attr smd{" dnp" if dnp else ""}) {" ".join(ps)} {" ".join(ms)})')

    def text(self) -> str:
        n = len(self.layers)
        cu_id = {"F.Cu": 0, "B.Cu": 2}
        for k, l in enumerate(x for x in self.layers if x.startswith("In")):
            cu_id[l] = 4 + 2 * k
        lay = " ".join(f'({cu_id[l]} "{l}" signal)' for l in self.layers)
        lay += " " + " ".join(f'({i} "{nm}" {t}' + (f' "{al}")' if al else ")") for i, nm, t, al in _USER_LAYERS)
        st = ['(layer "F.Mask" (type "Top Solder Mask") (thickness 0.01))']
        diel = self.diel or [(self.t - n * self.cu) / max(n - 1, 1)] * (n - 1)
        for i, l in enumerate(self.layers):
            st.append(f'(layer "{l}" (type "copper") (thickness {self.cu}))')
            if i < n - 1:
                st.append(f'(layer "dielectric {i+1}" (type "{"core" if i == (n - 1) // 2 else "prepreg"}") '
                          f'(thickness {diel[i]:.4f}) (material "X") (epsilon_r {self.er}) (loss_tangent {self.tand}))')
        st.append('(layer "B.Mask" (type "Bottom Solder Mask") (thickness 0.01))')
        return (f'(kicad_pcb (version 20260206) (generator "pcbnew") (generator_version "10.0") '
                f'(general (thickness {self.t}) (legacy_teardrops no)) (paper "A4") (layers {lay}) '
                f'(setup (stackup {" ".join(st)} (copper_finish "None") (dielectric_constraints no)) '
                f'(pad_to_mask_clearance 0) (allow_soldermask_bridges_in_footprints no) '
                f'(aux_axis_origin {self.aux[0]} {self.aux[1]}) (grid_origin {self.grid[0]} {self.grid[1]})) '
                f'{" ".join(self.items)} (embedded_fonts no))\n')

    def write(self, path) -> Path:
        Path(path).write_text(self.text())
        return Path(path)

    def write_project(self, pcb_path) -> Path:
        """Board + a minimal .kicad_pro next to it, so KiCad opens it as a project."""
        p = self.write(pcb_path)
        pro = p.with_suffix(".kicad_pro")
        pro.write_text(json.dumps({"board": {"design_settings": {}}, "meta": {"filename": pro.name, "version": 3},
                                   "net_settings": {"classes": [{"name": "Default", "clearance": 0.2,
                                                                 "track_width": 0.25}], "meta": {"version": 4}}},
                                  indent=2))
        return p
