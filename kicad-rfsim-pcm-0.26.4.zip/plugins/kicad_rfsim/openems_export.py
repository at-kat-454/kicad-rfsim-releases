"""Build an openEMS (FDTD) model of a board region and run it.

The model is written as plain CSXCAD/openEMS XML, so only the openEMS
executable is needed (no Python bindings). This keeps the Windows setup simple.

Conventions
  * Units: mm (DeltaUnit 1e-3), KiCad x/y (y down; a mirror image is
    physically equivalent for S-parameters).
  * Copper is a zero-thickness conducting sheet at the dielectric surface.
  * Each port is a vertical lumped port from a pad down to the reference
    copper layer (normally the ground plane under the RF layer).
"""
from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from shapely.geometry import Point, Polygon, box
from shapely.ops import unary_union

from . import mesh as meshmod
from .board import Board

EPS0 = 8.8541878128e-12
C0 = 299792458.0
CU_SIGMA = 5.8e7


# ---------------------------------------------------------------------------
@dataclass
class Port:
    number: int
    ref: str
    pad: str
    net: str
    x0: float
    y0: float
    x1: float
    y1: float
    z_ref: float  # bottom (reference plane)
    z_sig: float  # top (pad)
    R: float = 50.0
    termination: bool = False  # added automatically to load a floating net; never excited

    @property
    def name(self) -> str:
        return f"{self.ref}.{self.pad}"


@dataclass
class MeshSettings:
    max_fine: float = 0.1  # mm, inside the region of interest
    max_coarse: float = 1.0  # mm, in the air margin
    min_cell: float = 0.02  # mm, lines closer than this are merged
    z_cells_per_dielectric: int = 4
    ratio: float = 1.4
    edge_min_len: float = 0.15  # only axis-aligned metal edges longer than this fix mesh lines
    # "thirds": two lines per metal edge, 1/3 cell inside and 2/3 outside the metal (openEMS
    # recommendation, removes most of the edge-singularity error); "edge": one line on the edge
    edge_rule: str = "thirds"


@dataclass
class ModelSettings:
    f_min: float = 0.3e9
    f_max: float = 3.0e9
    f_loss: float = 868e6  # frequency where tan(delta) is converted to a conductivity
    air_above: float = 3.0
    air_side: float = 2.0
    air_below: float = 3.0
    truncate_at: str | None = None  # copper layer used as PEC bottom wall (model ends there)
    # stop at 60 dB energy decay. The RF chain's S-matrix goes through circuit math (Kron reduction
    # of every part port); stopped at 40 dB its low end moved by up to 0.2 dB and a low-pass cutoff
    # by up to 4 % with the moment openEMS checks the energy (every ~4 s wall clock): v0.24.1
    end_criteria: float = 1e-6
    max_time_ns: float = 40.0  # run limit as simulated time; converted to timesteps from the mesh's dt
    max_timesteps: int | None = None  # explicit limit (overrides max_time_ns), None = from max_time_ns
    boundary: str = "MUR"
    # outer copper layers as metal of real thickness instead of zero-thickness sheets: more
    # accurate for narrow gaps (coplanar waveguide), smaller timestep (slower)
    copper_thickness: str = "auto"  # "auto" (on when copper / dielectric under it >= 0.1), "on", "off"
    # "dc_free": sine-modulated Gaussian (odd around its centre -> exactly zero DC).
    # A cosine Gaussian carries DC, which charges ground loops (static B-field in
    # PEC/via loops) and the FDTD energy then never decays.
    excitation: str = "dc_free"
    mesh: MeshSettings = field(default_factory=MeshSettings)


# ---------------------------------------------------------------------------
def lumped_geometry(board, specs: dict, layer_z: dict, region=None) -> list[dict]:
    """Lumped parts as flat boxes across the gap between their two pads (board coordinates),
    oriented along the pad axis, at the pads' copper layer. ``specs``: ref -> {kind, value, esr, esl}."""
    out = []
    for ref, sp in specs.items():
        if sp.get("kind") not in ("C", "L", "R", "short"):
            continue
        try:
            fp = board.footprint(ref)
        except KeyError:
            continue
        pads = [p for p in fp.pads if p.number and (p.on_layer("F.Cu") or p.on_layer("B.Cu"))]
        if len(pads) != 2:
            continue
        a, b = sorted(pads, key=lambda q: q.number)
        layer = "F.Cu" if a.on_layer("F.Cu") else "B.Cu"
        if layer not in layer_z:
            continue
        axis = 0 if abs(b.x - a.x) >= abs(b.y - a.y) else 1
        ga, gb = a.polygon().bounds, b.polygon().bounds
        if axis == 0:
            lo, hi = (ga, gb) if a.x < b.x else (gb, ga)
            x0, x1 = lo[2], hi[0]
            if x1 - x0 < 0.05:
                x0, x1 = min(a.x, b.x), max(a.x, b.x)
            w = 0.3 * min(ga[3] - ga[1], gb[3] - gb[1])
            yc = (a.y + b.y) / 2
            box_ = (x0, yc - w, x1, yc + w)
        else:
            lo, hi = (ga, gb) if a.y < b.y else (gb, ga)
            y0, y1 = lo[3], hi[1]
            if y1 - y0 < 0.05:
                y0, y1 = min(a.y, b.y), max(a.y, b.y)
            w = 0.3 * min(ga[2] - ga[0], gb[2] - gb[0])
            xc = (a.x + b.x) / 2
            box_ = (xc - w, y0, xc + w, y1)
        if region is not None and not region.contains(box(*box_)):
            continue
        out.append(dict(sp, ref=ref, axis=axis, box=box_, z=layer_z[layer], nets=(a.net, b.net)))
    return out


def lumped_l_cap(L: float, rp: float | None, f_max: float) -> float:
    """Explicit parallel capacitance for a lumped inductor (openEMS LEtype 0).

    Without a C, openEMS (v0.37.0, also master in Nov 2026) sizes the cell capacitance of a parallel
    RLC from ``GetCenterFreq() + GetCutOffFreq()`` of the excitation. A custom excitation (ours,
    the DC-free pulse) never sets the cut-off frequency, so that value is uninitialised memory: the
    same model gave a working 15 nH or a short depending on the command line, the field dumps and
    the end criterion (verification/series_l, v0.24.1). This C is what openEMS intends with the
    right f_max: its impedance at f_max is 20x that of the R / L (LUMPED_RLC_Z_FACT), i.e. it has
    no effect in band (SRF far above f_max), and it is never smaller than needed for stability.
    A large R (a high-Q inductor) is counted up to 10x the reactance at f_max: beyond that the C became
    too small and the run unstable at once (Q 40 at 2.44 GHz)."""
    xl = 2 * math.pi * f_max * L
    zmin = max(min(rp or 0.0, 10.0 * xl), xl)
    return 1.0 / (2 * math.pi * f_max * zmin * 20.0)


def add_lumped_xml(prop, items, y_sign: float = 1.0, f_max: float = 3e9):
    """LumpedElement (series RLC) / metal (0R) primitives. ``y_sign`` -1 for models whose global y
    points up (antenna model); ``f_max`` of the model (see lumped_l_cap)."""
    for lm in items:
        x0_, y0_, x1_, y1_ = lm["box"]
        if y_sign < 0:
            y0_, y1_ = -y1_, -y0_
        z_ = lm["z"]
        if lm["kind"] == "short":
            e, prims = prop("Metal", f"lumped_{lm['ref']}_0R")
        elif lm["kind"] == "C":
            # series RC; the ESL is folded into the capacitance at the reference frequency
            # (C_eff = C / (1 - w^2 L C)). openEMS' series RLC form overflowed (NaN) on a fine mesh
            # with thick copper (verification/series_c), the series RC form is stable.
            c = lm["value"]
            esl, f0 = lm.get("esl", 0.0), lm.get("f_ref", 868e6)
            k = 1 - (2 * math.pi * f0) ** 2 * esl * c
            if esl and k > 0.2:
                c = c / k
            vals = {"R": max(lm.get("esr", 0.0), 1e-3), "C": c}
            e, prims = prop("LumpedElement", f"lumped_{lm['ref']}", Direction=str(lm["axis"]), Caps="1",
                            LEtype="1", **{k: f"{v:.6g}" for k, v in vals.items()})
        elif lm["kind"] == "L":
            # parallel L with the loss as a parallel resistor: openEMS' series-RL form (no C) became
            # unstable on fine meshes (energy grew after the pulse); the parallel form is stable
            vals = {"L": lm["value"]}
            rp = lm.get("rp")
            if rp:
                vals["R"] = rp
            vals["C"] = lumped_l_cap(lm["value"], rp, f_max)
            e, prims = prop("LumpedElement", f"lumped_{lm['ref']}", Direction=str(lm["axis"]), Caps="1",
                            LEtype="0", **{k: f"{v:.6g}" for k, v in vals.items()})
        else:  # resistor: native parallel R
            e, prims = prop("LumpedElement", f"lumped_{lm['ref']}", Direction=str(lm["axis"]), Caps="1",
                            LEtype="0", R=f"{max(lm['value'], 1e-3):.6g}")
        b = ET.SubElement(prims, "Box", Priority="9")
        ET.SubElement(b, "P1", X=f"{x0_:.6g}", Y=f"{y0_:.6g}", Z=f"{z_:.6g}")
        ET.SubElement(b, "P2", X=f"{x1_:.6g}", Y=f"{y1_:.6g}", Z=f"{z_:.6g}")


def courant_dt(lines) -> float:
    """FDTD timestep (s) of a rectilinear mesh in mm (Courant limit of the smallest cells).
    openEMS' own timestep (TimeStepMethod 3) is a few % larger, so limits derived from this
    are slightly generous."""
    d = [float(np.min(np.diff(np.asarray(l, float)))) * 1e-3 for l in lines]
    return 1.0 / (C0 * math.sqrt(sum(1.0 / x ** 2 for x in d)))


def exact_dt(exe: str, xml: Path, cache_dir: Path | None = None) -> float | None:
    """openEMS' own timestep for a model (preprocessing only, ``--no-simulation``). Its timestep
    criterion is not the plain Courant limit, so the time limit is converted with this value.
    Cached by the mesh lines in ``cache_dir/dt_cache.json``."""
    import hashlib
    import re
    xml = Path(xml)
    root = ET.parse(xml).getroot()
    grid = root.find(".//RectilinearGrid")
    key = hashlib.sha256(ET.tostring(grid) if grid is not None else xml.read_bytes()).hexdigest()[:16]
    cache = Path(cache_dir) / "dt_cache.json" if cache_dir else None
    data = {}
    if cache and cache.exists():
        try:
            data = json.loads(cache.read_text())
        except Exception:
            data = {}
        if key in data:
            return float(data[key])
    kw = {"creationflags": 0x08000000} if os.name == "nt" else {}
    try:
        r = subprocess.run([exe, xml.name, "--no-simulation"], cwd=xml.parent, capture_output=True, text=True,
                           timeout=900, **kw)
    except Exception:
        return None
    finally:
        for f in ("et", "ht"):  # excitation dumps: one line per timestep, megabytes, unused
            try:
                (xml.parent / f).unlink()
            except OSError:
                pass
    m = re.search(r"FDTD timestep is:\s*([\d.eE+-]+)", r.stdout + r.stderr)
    if not m:
        return None
    dt = float(m.group(1))
    if cache:
        data[key] = dt
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(data))
    return dt


def limit_timesteps(explicit, max_time_ns: float, dt: float, floor: int = 2000) -> int:
    if explicit:
        return int(explicit)
    return max(floor, int(math.ceil(max_time_ns * 1e-9 / dt)))


def _metal_side(poly: Polygon, x: float, y: float, axis: int, eps: float = 1e-3) -> int:
    """-1 if the metal lies on the lower-coordinate side of an edge at (x, y) normal to ``axis``,
    +1 if on the higher side, 0 if on both / unclear."""
    from shapely.geometry import Point
    lo = Point(x - eps, y) if axis == 0 else Point(x, y - eps)
    hi = Point(x + eps, y) if axis == 0 else Point(x, y + eps)
    a, b = poly.contains(lo), poly.contains(hi)
    return -1 if a and not b else 1 if b and not a else 0


def edge_lines(edges, rule: str, h: float) -> list[float]:
    """Mesh lines for metal edges [(position, metal side)]. "thirds": h/3 inside the metal and
    2h/3 outside (h = fine cell); "edge": on the edge itself."""
    out = []
    for e in edges:
        pos, side = e if isinstance(e, tuple) else (e, 0)
        if rule == "thirds" and side:
            out += [pos + side * h / 3, pos - side * 2 * h / 3]
        else:
            out.append(pos)
    return out


def _inner_nets(model, external) -> list[str]:
    """Nets of the ports inside the chain. Nets of external and termination ports are the
    model's interfaces (antenna, input, terminated branches) and may leave the region."""
    ext = set(external or [])
    iface = {p.net for p in model.ports if p.termination or p.name in ext}
    return sorted({p.net for p in model.ports} - iface)


def region_cuts(board, region, nets, layers=None, ground: str = "GND", min_len: float = 0.05) -> list[dict]:
    """RF copper (``nets``) that crosses the region boundary: there the model cuts the trace
    off, which acts like an open stub end or a missing continuation. One entry per net and layer
    with the cut position and width."""
    reg = region if hasattr(region, "boundary") else box(*region)
    out = []
    for layer in layers or [l.name for l in board.stackup.copper]:
        for net in nets:
            if not net or net == ground:
                continue
            gs = [g for _, g in board.copper(layer, net)]
            if not gs:
                continue
            u = unary_union(gs)
            if not u.intersects(reg) or reg.contains(u):
                continue
            cut = u.intersection(reg.boundary)
            if cut.is_empty or cut.length < min_len:
                continue
            c = cut.centroid
            out.append({"net": net, "layer": layer, "x": round(c.x, 2), "y": round(c.y, 2),
                        "width": round(cut.length, 2)})
    return out


def split_holes(geom) -> list[Polygon]:
    """CSXCAD polygons have no holes: cut polygons until no part has holes."""
    out: list[Polygon] = []
    stack = [g for g in getattr(geom, "geoms", [geom])]
    while stack:
        p = stack.pop()
        if not isinstance(p, Polygon) or p.is_empty or p.area < 1e-6:
            continue
        if not p.interiors:
            out.append(p)
            continue
        h0 = Polygon(p.interiors[0])
        hb = h0.bounds
        if hb[2] - hb[0] < 1e-2 or h0.area < 1e-4:  # a hole of 10 um / 1e-4 mm^2 is no hole for any mesh: fill it
            p = Polygon(p.exterior, p.interiors[1:])
            stack.append(p)
            continue
        # a vertical line through a point inside the hole always cuts it (the centroid of an
        # L-shaped hole can lie outside it: the cut missed the hole and the loop never ended)
        cx = Polygon(p.interiors[0]).representative_point().x
        x0, y0, x1, y1 = p.bounds
        # the two halves overlap by 2 um: a mesh line exactly on the cut would otherwise lie on the
        # boundary of both pieces and miss the copper (a slot through a solid ground plane)
        e = 1e-3
        for half in (box(x0 - 1, y0 - 1, cx + e, y1 + 1), box(cx - e, y0 - 1, x1 + 1, y1 + 1)):
            part = p.intersection(half)
            stack.extend([g for g in getattr(part, "geoms", [part]) if isinstance(g, Polygon)])
    return out


class OpenEMSModel:
    def __init__(self, board: Board, region, port_pads: list[tuple[str, str]], ref_layer: str = "In1.Cu",
                 settings: ModelSettings | None = None, ground: str = "GND", lumped: dict | None = None):
        """``lumped``: ref -> {"kind": C|L|R|short, "value", "esr", "esl"}: fixed parts modelled inside
        the FDTD as lumped elements between their pads (no port, no extra excitation)."""
        self.board = board
        self.region = region if isinstance(region, Polygon) else box(*region)
        outline = board.outline()
        if outline is not None:
            self.region = self.region.intersection(outline)
        self.s = settings or ModelSettings()
        self.ground = ground
        self.ref_layer = ref_layer
        self._layer_z()
        self._geometry()
        self.ports = self._make_ports(port_pads)
        self.lumped = self._make_lumped(lumped or {})
        self._terminate_floating()
        self._mesh()

    # --- stackup -> z ------------------------------------------------------
    def _layer_z(self):
        st = self.board.stackup
        z = 0.0
        self.cu_z: dict[str, float] = {}
        self.dielectrics: list[tuple[str, float, float, float, float]] = []  # name, ztop, zbot, er, tand
        seq = [l for l in st.layers if l.kind in ("copper", "dielectric")]
        for l in seq:
            if l.kind == "copper":
                self.cu_z[l.name] = z
            else:
                self.dielectrics.append((l.name, z, z - l.thickness, l.epsilon_r or 4.5, l.loss_tangent or 0.0))
                z -= l.thickness
        self.layers = [n for n in self.cu_z]
        if self.s.truncate_at:
            zt = self.cu_z[self.s.truncate_at]
            self.layers = [n for n in self.layers if self.cu_z[n] >= zt - 1e-9]
            self.dielectrics = [d for d in self.dielectrics if d[2] >= zt - 1e-9]
        self.z_top = max(self.cu_z[n] for n in self.layers)
        self.z_bot = min(self.cu_z[n] for n in self.layers)

    # --- ports -------------------------------------------------------------
    def _make_ports(self, port_pads):
        ports = []
        for i, (ref, pad) in enumerate(port_pads, 1):
            p = self.board.footprint(ref).pad(pad)
            layer = "F.Cu" if p.on_layer("F.Cu") else "B.Cu"
            w, h = p.size
            a = abs(p.angle) % 180
            if 45 < a < 135:
                w, h = h, w
            hs = max(min(w, h) * 0.3, 0.05)
            ports.append(Port(i, ref, pad, p.net, p.x - hs, p.y - hs, p.x + hs, p.y + hs,
                              self.cu_z[self.ref_layer], self.cu_z[layer]))
        return ports

    def _make_lumped(self, specs: dict) -> list[dict]:
        """Geometry of lumped parts: a flat box across the gap between the two pads."""
        return lumped_geometry(self.board, specs, self.cu_z, self.region)

    def _terminate_floating(self):
        """Every conductor island must be tied to something resistive, otherwise
        static charge stays on it and the FDTD energy never decays.

        * ground islands without a via get a small stitch to the reference plane
          (typically slivers cut off at the region border);
        * signal islands without a port get a passive 50 ohm termination port
          (reported, never excited).
        """
        self.stitches: list[tuple[float, float, float, float, float]] = []  # x, y, half-size, z_ref, z_sheet
        for layer, nets in self.unions.items():
            zs = self.cu_z[layer]
            for net, u in nets.items():
                for isl in getattr(u, "geoms", [u]):
                    if not isinstance(isl, Polygon) or isl.area < 1e-4:
                        continue
                    grown = isl.buffer(1e-3)
                    if net == self.ground or net == "":
                        if any(grown.contains(Point(v[1], v[2])) for v in self.vias):
                            continue
                        inner = isl.buffer(-0.03)
                        pt = (inner if not inner.is_empty else isl).representative_point()
                        self.stitches.append((pt.x, pt.y, 0.03, self.cu_z[self.ref_layer], zs))
                        continue
                    if any(grown.contains(Point((p.x0 + p.x1) / 2, (p.y0 + p.y1) / 2)) for p in self.ports):
                        continue
                    if any(lm["kind"] in ("L", "R", "short") and net in lm["nets"] and
                           grown.intersects(box(*lm["box"]).buffer(0.3)) for lm in self.lumped):
                        continue  # tied to the rest through a lumped L / R / 0R
                    pads = [p for f in self.board.footprints for p in f.pads
                            if p.net == net and p.on_layer(layer) and p.number and grown.contains(Point(p.x, p.y))]
                    if pads:
                        c = self.region.centroid
                        p = min(pads, key=lambda q: (q.x - c.x) ** 2 + (q.y - c.y) ** 2)
                        x, y, hs, ref, pad = p.x, p.y, max(min(p.size) * 0.3, 0.05), p.ref, p.number
                    else:
                        inner = isl.buffer(-0.04)
                        pt = (inner if not inner.is_empty else isl).representative_point()
                        x, y, hs, ref, pad = pt.x, pt.y, 0.04, "net", net.split("/")[-1]
                    self.ports.append(Port(len(self.ports) + 1, ref, pad, net, x - hs, y - hs, x + hs, y + hs,
                                           self.cu_z[self.ref_layer], zs, termination=True))

    def _free_node(self, net: str, x: float, y: float, z0: float, z1: float, reach: float = 1.5):
        """Mesh node next to (x, y) for a vertical line of ``net`` between z0 and z1 that is not
        inside copper of another net on the layers it crosses; None if there is none within
        ``reach`` cells."""
        from shapely.geometry import Point
        xs, ys = np.asarray(self.x), np.asarray(self.y)
        ix, iy = int(np.argmin(abs(xs - x))), int(np.argmin(abs(ys - y)))
        cell = max(1e-3, float(np.diff(xs[max(0, ix - 1):ix + 2]).max(initial=0.1)),
                   float(np.diff(ys[max(0, iy - 1):iy + 2]).max(initial=0.1)))
        layers = [l for l in self.layers if l in self.unions and z0 - 1e-9 <= self.cu_z[l] <= z1 + 1e-9]
        others = [g for l in layers for n, g in self.unions[l].items() if n != net and not g.is_empty]
        cands = sorted(((float(xs[i]), float(ys[j])) for i in range(max(0, ix - 1), min(len(xs), ix + 2))
                        for j in range(max(0, iy - 1), min(len(ys), iy + 2))),
                       key=lambda q: (q[0] - x) ** 2 + (q[1] - y) ** 2)
        for q in cands:
            if (q[0] - x) ** 2 + (q[1] - y) ** 2 > (reach * cell) ** 2:
                break
            pt = Point(q).buffer(1e-4)
            if not any(g.intersects(pt) for g in others):
                return q
        return None

    # --- geometry ----------------------------------------------------------
    def _geometry(self):
        self.sheets: dict[str, list[tuple[str, Polygon]]] = {}
        self.unions: dict[str, dict[str, object]] = {}
        self.edge_x: list[float] = []
        self.edge_y: list[float] = []
        for layer in self.layers:
            if self.s.truncate_at == layer:
                continue  # replaced by PEC boundary
            items = self.board.copper(layer, region=self.region)
            by_net: dict[str, list] = {}
            for net, g in items:
                by_net.setdefault(net, []).append(g)
            polys = []
            rb = self.region.boundary if self.region is not None else None
            for net, gs in by_net.items():
                u = unary_union(gs).buffer(0)
                if rb is not None and not u.is_empty:
                    # slivers the region edge cut off a pour or trace (thinner than half the smallest cell)
                    # lie between mesh lines: openEMS would drop them anyway ("Unused primitive")
                    w = 0.5 * self.s.mesh.min_cell
                    keep, gone = [], 0
                    for part in getattr(u, "geoms", [u]):
                        if (isinstance(part, Polygon) and part.intersects(rb.buffer(1e-6))
                                and part.buffer(-w / 2).is_empty):
                            gone += 1
                            continue
                        keep.append(part)
                    if gone:
                        u = unary_union(keep) if keep else Polygon()
                        self.slivers = getattr(self, "slivers", 0) + gone
                self.unions.setdefault(layer, {})[net] = u
                for p in split_holes(u):
                    polys.append((net, p))
                # mesh lines at axis-aligned metal edges
                for part in getattr(u, "geoms", [u]):
                    if not isinstance(part, Polygon):
                        continue
                    for ring in [part.exterior, *part.interiors]:
                        c = list(ring.coords)
                        for (xa, ya), (xb, yb) in zip(c, c[1:]):
                            if abs(xa - xb) < 1e-4 and abs(ya - yb) > self.s.mesh.edge_min_len:
                                self.edge_x.append((xa, _metal_side(part, xa, (ya + yb) / 2, 0)))
                            if abs(ya - yb) < 1e-4 and abs(xa - xb) > self.s.mesh.edge_min_len:
                                self.edge_y.append((ya, _metal_side(part, (xa + xb) / 2, ya, 1)))
            self.sheets[layer] = polys
        self.vias = []
        self.cut_vias: list[tuple[str, float, float]] = []  # signal vias that would touch the PEC wall
        for v in self.board.vias:
            if not self.region.contains(box(v.x - 1e-3, v.y - 1e-3, v.x + 1e-3, v.y + 1e-3)):
                continue
            zs = [self.cu_z[l] for l in self.layers if self.board.via_on_layer(v, l)]
            if len(zs) >= 2 or (self.s.truncate_at and len(zs) >= 1):
                z0 = min(zs)
                if self.s.truncate_at and self.board.via_on_layer(v, self.s.truncate_at):
                    if v.net and v.net != self.ground:
                        # the PEC wall is ground: a via of another net would short that net to ground.
                        # Its copper below the wall is not modelled, so the via ends at the lowest layer above.
                        self.cut_vias.append((v.net, round(v.x, 2), round(v.y, 2)))
                        zs = [z for z in zs if z > self.cu_z[self.s.truncate_at] + 1e-9]
                        if len(zs) < 2:
                            continue
                        z0 = min(zs)
                    else:
                        z0 = self.cu_z[self.s.truncate_at]
                if max(zs) > z0:
                    self.vias.append((v.net, v.x, v.y, v.drill / 2, z0, max(zs)))

    # --- mesh ----------------------------------------------------------------
    def _mesh(self):
        m = self.s.mesh
        x0, y0, x1, y1 = self.region.bounds
        # priorities for merging close lines: metal edges 2, port / part / via boxes 1, region 0
        fx = [(v, 2) for v in edge_lines(self.edge_x, m.edge_rule, m.max_fine)] + [(x0, 0), (x1, 0)]
        fy = [(v, 2) for v in edge_lines(self.edge_y, m.edge_rule, m.max_fine)] + [(y0, 0), (y1, 0)]
        for p in self.ports:
            fx += [p.x0, p.x1]
            fy += [p.y0, p.y1]
        for sx, sy, sh, *_ in self.stitches:
            fx += [sx - sh, sx + sh]
            fy += [sy - sh, sy + sh]
        for lm in self.lumped:
            bx = lm["box"]
            fx += [bx[0], bx[2]]
            fy += [bx[1], bx[3]]
        for _, vx, vy, *_ in self.vias:
            fx.append(vx)
            fy.append(vy)
        a = self.s.air_side
        self.x = meshmod.axis_lines(fx, x0 - a, x1 + a, x0, x1, m.max_fine, m.max_coarse, m.min_cell, m.ratio)
        self.y = meshmod.axis_lines(fy, y0 - a, y1 + a, y0, y1, m.max_fine, m.max_coarse, m.min_cell, m.ratio)
        # z: copper planes fixed, n cells per dielectric (graded in thick cores)
        zl = sorted({self.cu_z[l] for l in self.layers} | {d[1] for d in self.dielectrics} | {d[2] for d in self.dielectrics})
        z = [zl[0]]
        thin = min(d[1] - d[2] for d in self.dielectrics) / m.z_cells_per_dielectric
        # cells next to a copper plane: not larger than the lateral fine cell. Coplanar lines keep their
        # field within about one gap of the copper; 4 cells across a 1.5 mm core (0.38 mm) put a 0.2 mm
        # gap into one cell (2-layer 1.6 mm board, 50 ohm GCPW: 37 instead of 50 ohm)
        near = min(thin, m.max_fine)
        for a_, b_ in zip(zl, zl[1:]):
            t = b_ - a_
            n = m.z_cells_per_dielectric
            if t / n > near * 1.05 and t <= thin * n * 1.5:  # thick single core: graded from both planes
                lo = meshmod.grow(a_, a_ + t / 2, near / m.ratio, m.ratio, t / n)
                hi = meshmod.grow(b_, b_ - t / 2, near / m.ratio, m.ratio, t / n)
                z += lo[:-1] + [a_ + t / 2] + hi[:-1][::-1] + [b_]
            elif t <= thin * n * 1.5:
                z += [a_ + t * k / n for k in range(1, n + 1)]
            else:  # thick core: grade from both planes
                lo = meshmod.grow(a_, a_ + t / 2, thin, m.ratio, m.max_fine * 2)
                hi = meshmod.grow(b_, b_ - t / 2, thin, m.ratio, m.max_fine * 2)
                z += lo[:-1] + [a_ + t / 2] + hi[:-1][::-1] + [b_]
        t_top, t_bot = self._outer_thickness()
        if t_top:
            z.append(self.z_top + t_top)
        top = meshmod.grow(self.z_top + t_top, self.z_top + t_top + self.s.air_above, near / m.ratio, m.ratio,
                           m.max_coarse)
        if self.s.truncate_at:
            bot = []
        else:
            if t_bot:
                z.insert(0, self.z_bot - t_bot)
            bot = meshmod.grow(self.z_bot - t_bot, self.z_bot - t_bot - self.s.air_below, thin, m.ratio,
                               m.max_coarse)[::-1]
        z = sorted(z)
        self.z = meshmod.merge_close(bot + z + top, 1e-4)
        # snap ports to mesh lines (one or more cells wide)
        for p in self.ports:
            p.z_ref = meshmod.snap(p.z_ref, self.z)
            p.z_sig = meshmod.snap(p.z_sig, self.z)

    def thick_copper(self) -> bool:
        """Resolved copper_thickness. "auto": on when the outer copper is at least 1/10 of the
        dielectric under it - zero-thickness sheets then read Z0 too high (0.2 mm prepreg, 35 um:
        microstrip +6 %, coplanar line with 0.2 mm gap +21 %, see verification/)."""
        v = self.s.copper_thickness
        if isinstance(v, bool):
            return v
        v = str(v).lower()
        if v in ("on", "true", "yes", "1"):
            return True
        if v in ("off", "false", "no", "0"):
            return False
        top = max(self.layers, key=lambda l: self.cu_z[l])
        t = self.board.stackup.layer(top).thickness
        below = [d for d in self.dielectrics if abs(d[1] - self.cu_z[top]) < 1e-6]
        h = (below[0][1] - below[0][2]) if below else 1.0
        return t >= 0.1 * h

    def _outer_thickness(self) -> tuple[float, float]:
        """Copper thickness of the top / bottom layer when modelled as thick metal (else 0)."""
        if not self.thick_copper():
            return 0.0, 0.0
        top = max(self.layers, key=lambda l: self.cu_z[l])
        bot = min(self.layers, key=lambda l: self.cu_z[l])
        tt = self.board.stackup.layer(top).thickness
        tb = 0.0 if (self.s.truncate_at == bot or bot == top) else self.board.stackup.layer(bot).thickness
        return tt, tb

    def _thick_layer(self, layer: str) -> tuple[float, float] | None:
        """(elevation, length) of a thick copper layer, None for a sheet."""
        t_top, t_bot = self._outer_thickness()
        z = self.cu_z[layer]
        if t_top and z == self.z_top:
            return z, t_top
        if t_bot and z == self.z_bot:
            return z - t_bot, t_bot
        return None

    @property
    def n_cells(self) -> int:
        return (len(self.x) - 1) * (len(self.y) - 1) * (len(self.z) - 1)

    def timestep_estimate(self) -> float:
        return courant_dt((self.x, self.y, self.z))

    @property
    def max_timesteps(self) -> int:
        """Run limit in timesteps: the explicit setting, else max_time_ns / dt of this mesh
        (openEMS' exact dt once known, the Courant estimate before)."""
        return limit_timesteps(self.s.max_timesteps, self.s.max_time_ns,
                               getattr(self, "dt_exact", None) or self.timestep_estimate())

    def broken_nets(self) -> list[dict]:
        """Ports of one net that the mesh no longer connects. The copper is rasterised the way
        the FDTD sees it (a mesh edge is metal when its midpoint lies in the copper) and the metal
        edges are followed from port to port; vias join the layers. A trace thinner than the
        cells - typically a diagonal or curved one - falls apart into pieces and the RF path is
        open in the simulation."""
        import shapely
        xs, ys = np.asarray(self.x), np.asarray(self.y)
        nx, ny = len(xs), len(ys)
        layers = [l for l in self.layers if l in self.unions]
        li = {l: k for k, l in enumerate(layers)}
        parent = list(range(len(layers) * nx * ny))

        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        def join(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb
        X, Y = np.meshgrid(xs, ys, indexing="ij")
        mx, my = (xs[:-1] + xs[1:]) / 2, (ys[:-1] + ys[1:]) / 2
        node_net: dict[tuple, np.ndarray] = {}
        for l in layers:
            for net, g in self.unions[l].items():
                if g.is_empty or not net or net == self.ground:
                    continue
                gb = g.buffer(1e-6)
                node_net[(l, net)] = shapely.contains_xy(gb, X, Y)
                ex = shapely.contains_xy(gb, *np.meshgrid(mx, ys, indexing="ij"))  # x edges (i..i+1, j)
                ey = shapely.contains_xy(gb, *np.meshgrid(xs, my, indexing="ij"))  # y edges (i, j..j+1)
                base = li[l] * nx * ny
                for i, j in zip(*np.nonzero(ex)):
                    join(base + i * ny + j, base + (i + 1) * ny + j)
                for i, j in zip(*np.nonzero(ey)):
                    join(base + i * ny + j, base + i * ny + j + 1)
        for net, vx, vy, _r, z0, z1 in self.vias:
            ls = [l for l in layers if z0 - 1e-9 <= self.cu_z[l] <= z1 + 1e-9]
            i, j = int(np.argmin(abs(xs - vx))), int(np.argmin(abs(ys - vy)))
            for a, b in zip(ls, ls[1:]):
                join(li[a] * nx * ny + i * ny + j, li[b] * nx * ny + i * ny + j)

        def port_node(p):
            l = next((l for l in layers if abs(self.cu_z[l] - p.z_sig) < 1e-6), None)
            if l is None or (l, p.net) not in node_net:
                return None
            m = node_net[(l, p.net)]
            i0, i1 = np.searchsorted(xs, [p.x0 - 1e-9, p.x1 + 1e-9])
            j0, j1 = np.searchsorted(ys, [p.y0 - 1e-9, p.y1 + 1e-9])
            cx, cy = (p.x0 + p.x1) / 2, (p.y0 + p.y1) / 2
            best = None
            for i in range(max(0, i0 - 1), min(nx, i1 + 1)):
                for j in range(max(0, j0 - 1), min(ny, j1 + 1)):
                    if m[i, j]:
                        d = (xs[i] - cx) ** 2 + (ys[j] - cy) ** 2
                        if best is None or d < best[0]:
                            best = (d, li[l] * nx * ny + i * ny + j)
            return best[1] if best else None
        by_net: dict[str, list] = {}
        for p in self.ports:
            if p.net and p.net != self.ground:
                by_net.setdefault(p.net, []).append(p)
        out = []
        for net, ps in by_net.items():
            if len(ps) < 2:
                continue
            groups: dict[int, list[str]] = {}
            for p in ps:
                n = port_node(p)
                groups.setdefault(find(n) if n is not None else -id(p), []).append(p.name)
            if len(groups) > 1:
                out.append({"net": net, "groups": list(groups.values())})
        return out

    def describe(self) -> str:
        x0, y0, x1, y1 = self.region.bounds
        lines = [f"Region {x1-x0:.2f} x {y1-y0:.2f} mm, layers {', '.join(self.layers)}"
                 + (f" (PEC at {self.s.truncate_at})" if self.s.truncate_at else ""),
                 f"Mesh {len(self.x)} x {len(self.y)} x {len(self.z)} lines = {self.n_cells/1e6:.2f} M cells, "
                 f"min cell {min(np.diff(self.x)):.3f}/{min(np.diff(self.y)):.3f}/{min(np.diff(self.z)):.4f} mm, "
                 f"dt ~ {self.timestep_estimate()*1e15:.1f} fs",
                 "Copper polygons: " + ", ".join(f"{l}={len(v)}" for l, v in self.sheets.items())
                 + f", vias={len(self.vias)}, ground stitches={len(self.stitches)}"
                 + (f", {self.slivers} slivers at the region edge left out" if getattr(self, "slivers", 0) else ""),
                 *[f"Via of {n} at ({x}, {y}) mm ends above {self.s.truncate_at} (the ground wall)"
                   for n, x, y in getattr(self, "cut_vias", [])],
                 "Ports:"]
        for p in self.ports:
            lines.append(f"  P{p.number}: {p.name:<8} net {p.net}" + ("  (termination)" if p.termination else ""))
        if self.lumped:
            lines.append("Parts inside the EM model (fixed, lumped):")
            for lm in self.lumped:
                v = lm.get("value") or 0
                txt = ("0R" if lm["kind"] == "short" else f"{v*1e12:.3g} pF" if lm["kind"] == "C" else
                       f"{v*1e9:.3g} nH" if lm["kind"] == "L" else f"{v:.3g} ohm")
                lines.append(f"  {lm['ref']:<8} {txt}")
        return "\n".join(lines)

    # --- XML -----------------------------------------------------------------
    def field_plane(self):
        """(lo, hi) of the recording plane: the region, in the middle of the dielectric under the
        top copper."""
        x0, y0, x1, y1 = self.region.bounds
        top = max(self.layers, key=lambda l: self.cu_z[l])
        below = sorted((self.cu_z[l] for l in self.cu_z if self.cu_z[l] < self.cu_z[top]), reverse=True)
        z = (self.cu_z[top] + below[0]) / 2 if below else self.cu_z[top] - 0.1
        return [x0, y0, z], [x1, y1, z]

    def write_xml(self, path: str | Path, excite: int | None, fields: dict | None = None) -> Path:
        s = self.s
        f0 = (s.f_min + s.f_max) / 2
        fc = (s.f_max - s.f_min) / 2
        root = ET.Element("openEMS")
        fdtd = ET.SubElement(root, "FDTD", NumberOfTimesteps=str(self.max_timesteps),
                             endCriteria=f"{s.end_criteria:g}", OverSampling="4", TimeStepMethod="3",
                             f_max=f"{s.f_max:g}")
        if s.excitation == "dc_free":
            w = 2 * math.pi * fc
            t0 = 9.0 / w
            fn = f"sin(2*pi*{f0:.6g}*(t-{t0:.6g}))*exp(-(({w:.6g}*t/3-3)^2))"
            ET.SubElement(fdtd, "Excitation", Type="10", f0=f"{s.f_max:g}", Function=fn)
        else:
            ET.SubElement(fdtd, "Excitation", Type="0", f0=f"{f0:g}", fc=f"{fc:g}")
        bc = {k: s.boundary for k in ("xmin", "xmax", "ymin", "ymax", "zmin", "zmax")}
        if s.truncate_at:
            bc["zmin"] = "PEC"
        ET.SubElement(fdtd, "BoundaryCond", **bc)
        csx = ET.SubElement(root, "ContinuousStructure", CoordSystem="0")
        grid = ET.SubElement(csx, "RectilinearGrid", DeltaUnit="0.001", CoordSystem="0")
        for tag, arr in (("XLines", self.x), ("YLines", self.y), ("ZLines", self.z)):
            e = ET.SubElement(grid, tag, Qty=str(len(arr)))
            e.text = ",".join(f"{v:.6g}" for v in arr)
        ET.SubElement(csx, "BackgroundMaterial", Epsilon="1", Mue="1", Kappa="0", Sigma="0")
        ET.SubElement(csx, "ParameterSet")
        props = ET.SubElement(csx, "Properties")
        pid = [0]

        def prop(tag, name, **attrs):
            e = ET.SubElement(props, tag, ID=str(pid[0]), Name=name, **attrs)
            pid[0] += 1
            return e, ET.SubElement(e, "Primitives")

        def vtx(parent, poly: Polygon):
            for x, y in list(poly.exterior.coords)[:-1]:
                ET.SubElement(parent, "Vertex", X1=f"{x:.6g}", X2=f"{y:.6g}")

        reg_parts = [g for g in getattr(self.region, "geoms", [self.region]) if isinstance(g, Polygon)]
        for name, zt, zb, er, tand in self.dielectrics:
            kappa = 2 * math.pi * s.f_loss * EPS0 * er * tand
            e, prims = prop("Material", name, Isotropy="1")
            for rp in reg_parts:
                for part in split_holes(rp):
                    lp = ET.SubElement(prims, "LinPoly", Priority="1", Elevation=f"{zb:.6g}", NormDir="2",
                                       QtyVertices=str(len(part.exterior.coords) - 1), Length=f"{zt - zb:.6g}")
                    vtx(lp, part)
            ET.SubElement(e, "Property", Epsilon=f"{er:g},{er:g},{er:g}", Mue="1,1,1",
                          Kappa=f"{kappa:g},{kappa:g},{kappa:g}", Sigma="0,0,0", Density="0")
        for layer, polys in self.sheets.items():
            nets = sorted({n for n, _ in polys})
            thick = self._thick_layer(layer)
            for net in nets:
                if thick:
                    e, prims = prop("Metal", f"{layer}:{net or 'nonet'}")
                else:
                    e, prims = prop("ConductingSheet", f"{layer}:{net or 'nonet'}",
                                    Conductivity=f"{CU_SIGMA:g}",
                                    Thickness=f"{self.board.stackup.layer(layer).thickness * 1e-3:g}")
                for n, p in polys:
                    if n != net:
                        continue
                    if thick:
                        pe = ET.SubElement(prims, "LinPoly", Priority="10", Elevation=f"{thick[0]:.6g}",
                                           NormDir="2", QtyVertices=str(len(p.exterior.coords) - 1),
                                           Length=f"{thick[1]:.6g}")
                    else:
                        pe = ET.SubElement(prims, "Polygon", Priority="10", Elevation=f"{self.cu_z[layer]:.6g}",
                                           NormDir="2", QtyVertices=str(len(p.exterior.coords) - 1))
                    vtx(pe, p)
        if self.vias:
            e, prims = prop("Metal", "vias")
            for net, vx, vy, r, z0, z1 in self.vias:
                c = ET.SubElement(prims, "Cylinder", Priority="10", Radius=f"{r:g}")
                ET.SubElement(c, "P1", X=f"{vx:.6g}", Y=f"{vy:.6g}", Z=f"{z0:.6g}")
                ET.SubElement(c, "P2", X=f"{vx:.6g}", Y=f"{vy:.6g}", Z=f"{z1:.6g}")
            # axis lines: keep the connection when the via is thinner than the cells (see antenna.py),
            # on a mesh node that is not inside copper of another net (a line snapped onto the RF
            # trace next to a ground via would short the trace)
            e, prims = prop("Metal", "via_axes")
            for net, vx, vy, r, z0, z1 in self.vias:
                node = self._free_node(net, vx, vy, z0, z1)
                if node is None:
                    continue
                b = ET.SubElement(prims, "Box", Priority="10")
                ET.SubElement(b, "P1", X=f"{node[0]:.6g}", Y=f"{node[1]:.6g}", Z=f"{z0:.6g}")
                ET.SubElement(b, "P2", X=f"{node[0]:.6g}", Y=f"{node[1]:.6g}", Z=f"{z1:.6g}")
        if self.stitches:
            e, prims = prop("Metal", "ground_stitches")
            for sx, sy, sh, z0, z1 in self.stitches:
                # a line on the nearest mesh node: a small box between mesh lines conducts nothing
                # (a GND pad "stitched" that way stayed floating)
                node = self._free_node(self.ground, sx, sy, z0, z1)
                if node is None:
                    continue
                mx, my = node
                b = ET.SubElement(prims, "Box", Priority="10")
                ET.SubElement(b, "P1", X=f"{mx:.6g}", Y=f"{my:.6g}", Z=f"{z0:.6g}")
                ET.SubElement(b, "P2", X=f"{mx:.6g}", Y=f"{my:.6g}", Z=f"{z1:.6g}")
        add_lumped_xml(prop, self.lumped, f_max=s.f_max)
        for p in self.ports:
            P1 = dict(X=f"{p.x0:.6g}", Y=f"{p.y0:.6g}", Z=f"{p.z_ref:.6g}")
            P2 = dict(X=f"{p.x1:.6g}", Y=f"{p.y1:.6g}", Z=f"{p.z_sig:.6g}")
            e, prims = prop("LumpedElement", f"port_resist_{p.number}", Direction="2", Caps="1",
                            R=f"{p.R:g}", LEtype="0")
            b = ET.SubElement(prims, "Box", Priority="5")
            ET.SubElement(b, "P1", **P1)
            ET.SubElement(b, "P2", **P2)
            if excite == p.number:
                e, prims = prop("Excitation", f"port_excite_{p.number}", Number="0", Enabled="1",
                                Frequency="0", Delay="0", Type="0", Excite="0,0,-1", PropDir="0,0,0")
                b = ET.SubElement(prims, "Box", Priority="5")
                ET.SubElement(b, "P1", **P1)
                ET.SubElement(b, "P2", **P2)
                ET.SubElement(e, "Weight", X="1", Y="1", Z="1")
            xm, ym = (p.x0 + p.x1) / 2, (p.y0 + p.y1) / 2
            zm = (p.z_ref + p.z_sig) / 2
            e, prims = prop("ProbeBox", f"port_ut_{p.number}", Number="0", Type="0", Weight="-1",
                            NormDir="-1", StartTime="0", StopTime="0")
            b = ET.SubElement(prims, "Box", Priority="0")
            ET.SubElement(b, "P1", X=f"{xm:.6g}", Y=f"{ym:.6g}", Z=f"{p.z_ref:.6g}")
            ET.SubElement(b, "P2", X=f"{xm:.6g}", Y=f"{ym:.6g}", Z=f"{p.z_sig:.6g}")
            e, prims = prop("ProbeBox", f"port_it_{p.number}", Number="0", Type="1", Weight="1",
                            NormDir="2", StartTime="0", StopTime="0")
            b = ET.SubElement(prims, "Box", Priority="0")
            ET.SubElement(b, "P1", X=f"{p.x0:.6g}", Y=f"{p.y0:.6g}", Z=f"{zm:.6g}")
            ET.SubElement(b, "P2", X=f"{p.x1:.6g}", Y=f"{p.y1:.6g}", Z=f"{zm:.6g}")
        if fields:
            from .fields import add_dumps
            lo, hi = self.field_plane()
            add_dumps(prop, lo, hi, fields.get("freqs", []), fields.get("oversampling", 10))
            if fields.get("top"):
                # second plane 0.5 mm above the top copper: the same height as the antenna run's
                # plane, so the two can be overlaid on one board picture
                from .fields import TOP_NAME
                zt = self.z_top + fields["top"]
                add_dumps(prop, [lo[0], lo[1], zt], [hi[0], hi[1], zt], [], fields.get("oversampling", 10),
                          td_name=TOP_NAME)
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        ET.indent(root)
        ET.ElementTree(root).write(path, encoding="UTF-8", xml_declaration=True)
        return path


# ---------------------------------------------------------------------------
def openems_search_dirs() -> list[Path]:
    """Folders searched (recursively) for openEMS.exe: kicad-rfsim under LOCALAPPDATA and APPDATA (Roaming)."""
    dirs = []
    for var in ("LOCALAPPDATA", "APPDATA"):
        v = os.environ.get(var)
        if v:
            dirs.append(Path(v) / "kicad-rfsim" / "openEMS")
    return dirs


FIXED_OPENEMS = ["/opt/openEMS/bin/openEMS", r"C:\opt\openEMS\openEMS.exe"]


def find_openems(configured: str | None = None) -> str | None:
    """openEMS executable: configured path (GUI setting), OPENEMS_BIN, PATH, the
    kicad-rfsim folders in AppData\\Local and AppData\\Roaming (any depth)."""
    for cand in [configured, os.environ.get("OPENEMS_BIN"), shutil.which("openEMS"), shutil.which("openEMS.exe")] + FIXED_OPENEMS:
        if cand and Path(cand).is_file():
            return str(cand)
    for d in openems_search_dirs():
        if d.is_dir():
            for name in ("openEMS.exe", "openEMS"):
                hits = sorted(d.rglob(name), key=lambda p: len(p.parts))
                hits = [h for h in hits if h.is_file()]
                if hits:
                    return str(hits[0])
    return None


def _read_probe(path: Path):
    t, v = [], []
    with open(path) as f:
        for line in f:
            if line.startswith("%") or not line.strip():
                continue
            a = line.split()
            t.append(float(a[0]))
            v.append(float(a[1]))
    return np.array(t), np.array(v)


def _dft(t, v, freq):
    dt = t[1] - t[0]
    return 2 * dt * np.exp(-2j * np.pi * np.outer(freq, t)) @ v


def run(model: OpenEMSModel, workdir: str | Path, freq: np.ndarray, excite: list[int] | None = None,
        threads: int = 0, openems_bin: str | None = None, log=print, engine: str = "auto",
        stats: list | None = None, label: str = "", parallel: int = 0, fields: dict | None = None,
        fields_port: int | set | None = None):
    """Run one FDTD simulation per excited port and return the S-matrix [f, i, j].

    Columns of ports that are not excited stay NaN. ``stats`` collects one
    ``solver.RunStats`` per run (timesteps, energy decay, runtime).
    """
    from concurrent.futures import ThreadPoolExecutor

    from .solver import ParallelMeter, check_cancel, openems_cmd, plan_parallel, run_openems, set_stage
    exe = openems_bin or find_openems()
    if exe is None:
        raise FileNotFoundError("openEMS executable not found (set OPENEMS_BIN)")
    workdir = Path(workdir)
    n = len(model.ports)
    excite = excite or [p.number for p in model.ports if not p.termination]
    S = np.full((len(freq), n, n), np.nan, dtype=complex)
    if model.s.max_timesteps is None and not getattr(model, "dt_exact", None):
        d0 = workdir / "dt_probe"
        d0.mkdir(parents=True, exist_ok=True)
        model.dt_exact = exact_dt(exe, model.write_xml(d0 / "model.xml", excite=excite[0]), workdir)
        shutil.rmtree(d0, ignore_errors=True)
        if model.dt_exact:
            log(f"[openEMS] timestep {model.dt_exact*1e15:.1f} fs -> limit {model.s.max_time_ns:g} ns = "
                f"{model.max_timesteps:,} timesteps")
    n_par, n_thr = plan_parallel(len(excite), model.n_cells, threads, parallel)
    if n_par > 1:
        log(f"[openEMS] {len(excite)} excitations, {n_par} at a time with {n_thr} threads each")
    meter = ParallelMeter(label or "RF chain", len(excite))

    def one(k, j):
        check_cancel()
        d = workdir / f"exc_{j}"
        if d.exists():
            shutil.rmtree(d)
        d.mkdir(parents=True)
        fports = fields_port if isinstance(fields_port, (set, list, tuple)) else {fields_port}
        xml = model.write_xml(d / "model.xml", excite=j, fields=fields if (fields and j in fports) else None)
        cmd = openems_cmd(exe, xml.name, n_thr, engine)
        name = f"{label + ': ' if label else ''}port {j} ({model.ports[j-1].name})"
        log(f"[openEMS] {k}/{len(excite)} exciting port {j} ({model.ports[j-1].name}) ...")
        if n_par == 1:
            set_stage(name, k, len(excite))
            em = None
        else:
            base = meter.emitter(j)
            em = (lambda st, _n=name, _b=base: _b(dict(st, _name=_n)))
        st = run_openems(cmd, d, d / "openEMS.log", model.max_timesteps, model.s.end_criteria, name, log, emit=em,
                         f_ref=model.s.f_loss, limit_key="max_time_ns" if model.s.max_timesteps is None else "max_timesteps")
        u, i = {}, {}
        for p in model.ports:
            t, uv = _read_probe(d / f"port_ut_{p.number}")
            ti, iv = _read_probe(d / f"port_it_{p.number}")
            u[p.number] = _dft(t, uv, freq)
            i[p.number] = _dft(ti, iv, freq)
        return j, st, u, i

    if n_par == 1:
        results = [one(k, j) for k, j in enumerate(excite, 1)]
    else:
        with ThreadPoolExecutor(n_par) as ex:
            futs = [ex.submit(one, k, j) for k, j in enumerate(excite, 1)]
            results = [f.result() for f in futs]
    for j, st, u, i in results:
        if stats is not None:
            stats.append(st)
        pj = model.ports[j - 1]
        a_j = 0.5 * (u[j] + i[j] * pj.R)
        for p in model.ports:
            uinc = 0.5 * (u[p.number] + i[p.number] * p.R)
            uref = u[p.number] - uinc
            S[:, p.number - 1, j - 1] = uref / a_j
    return S


def to_touchstone(S: np.ndarray, freq: np.ndarray, path: str | Path, z0: float = 50.0, names=None):
    import skrf as rf

    S = np.array(S)
    # fill missing columns by reciprocity where possible
    n = S.shape[1]
    for i in range(n):
        for j in range(n):
            if np.isnan(S[0, i, j]) and not np.isnan(S[0, j, i]):
                S[:, i, j] = S[:, j, i]
    ntw = rf.Network(frequency=rf.Frequency.from_f(freq, unit="hz"), s=S, z0=z0)
    if names:
        ntw.port_names = names
    ntw.write_touchstone(str(Path(path).with_suffix("")))
    return ntw
