"""3D placement of boards and STEP parts for the antenna model.

Global frame (right-handed, used by the antenna model):
    X = x_kicad,  Y = -y_kicad,  Z = up,  main board top copper at Z = 0.

A *plate* is a planar board (main board or a soldered-in sub-board). Its local
frame is the board's own KiCad frame with z = 0 at the top copper and z < 0
going down through the stackup. ``Placement`` maps local points to global:
    P = R @ p_local + t        (R has entries in {0, +1, -1})

Sub-boards (e.g. a vertical antenna PCB from its own KiCad project) are placed
through the main-board footprint's 3D model entry. KiCad conventions for STEP
origin, rotation order and sign are not documented precisely, so the placement
is *fitted*: all plausible conventions are tried and the one whose sub-board
copper lands on the footprint pads is used. The residual is reported.
"""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass

import numpy as np

from .board import Board, Footprint


def rot(axis: str, deg: float) -> np.ndarray:
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    if axis == "x":
        m = [[1, 0, 0], [0, c, -s], [0, s, c]]
    elif axis == "y":
        m = [[c, 0, s], [0, 1, 0], [-s, 0, c]]
    else:
        m = [[c, -s, 0], [s, c, 0], [0, 0, 1]]
    return np.array(m)


def snap_rotation(R: np.ndarray, tol: float = 1e-6) -> np.ndarray | None:
    """Return R rounded to a signed permutation matrix, or None if not axis-aligned."""
    Rr = np.round(R)
    if np.abs(R - Rr).max() > tol:
        return None
    return Rr


@dataclass
class Placement:
    R: np.ndarray
    t: np.ndarray
    convention: str = "identity"
    residual: float = 0.0  # mm, mean pad misalignment of the fit
    step_residual: float | None = None  # mm, board corners vs. the footprint's STEP (None: no STEP used)
    model_R: np.ndarray | None = None  # footprint 3D model frame -> global (how KiCad places the STEP)
    model_t: np.ndarray | None = None

    def apply(self, pts: np.ndarray) -> np.ndarray:
        """pts: (n, 3) local -> global."""
        return pts @ self.R.T + self.t

    def normal_axis(self) -> int:
        """Global axis of the plate normal (local z)."""
        return int(np.argmax(np.abs(self.R[:, 2])))

    def plane_axes(self) -> tuple[int, int]:
        n = self.normal_axis()
        return (n + 1) % 3, (n + 2) % 3


MAIN = Placement(np.diag([1.0, -1.0, 1.0]), np.zeros(3), "main board")  # local (x, y_kicad, z) -> global


def local_pt(x, y, z):
    return np.array([x, y, z], dtype=float)


# ---------------------------------------------------------------------------
# sub-board placement from a footprint 3D model entry
# ---------------------------------------------------------------------------
def _origins(sub: Board) -> dict[str, tuple[float, float]]:
    o = {"page": (0.0, 0.0), "aux": sub.aux_origin, "grid": sub.grid_origin}
    ol = sub.outline()
    if ol is not None:
        x0, y0, x1, y1 = ol.bounds
        o["center"] = ((x0 + x1) / 2, (y0 + y1) / 2)
    return o


def model_transforms(fp: Footprint, model: dict | None = None):
    """Candidate maps footprint-model frame (STEP, y up, z up) -> global frame."""
    model = model or (fp.models[0] if fp.models else {"offset": (0, 0, 0), "rotate": (0, 0, 0), "scale": (1, 1, 1)})
    off = np.array(model["offset"], float)
    rx, ry, rz = model["rotate"]
    sc = np.array(model.get("scale", (1, 1, 1)), float)
    if fp.side == "B":
        raise NotImplementedError("3D parts on bottom-side footprints are not supported yet")
    Rf = rot("z", fp.angle)
    for order, sign, offy in itertools.product(("xyz", "zyx"), (1, -1), (1, -1)):
        Rm = np.eye(3)
        seq = [("x", rx), ("y", ry), ("z", rz)] if order == "xyz" else [("z", rz), ("y", ry), ("x", rx)]
        for ax, ang in seq:
            Rm = rot(ax, sign * ang) @ Rm
        o = np.array([off[0], offy * off[1], off[2]])
        yield f"order={order},sign={sign:+d},offy={offy:+d}", Rf @ Rm @ np.diag(sc), Rf @ o + np.array([fp.x, -fp.y, 0.0])


def candidate_placements(main: Board, fp: Footprint, sub: Board, model: dict | None = None):
    """Yield (name, Placement) for all plausible KiCad STEP/model conventions (sub-board local -> global)."""
    T_sub = sub.stackup.thickness
    S = np.diag([1.0, -1.0, 1.0])  # KiCad (x, y down) -> STEP (x, y up)
    for (oname, (ox, oy)), zref in itertools.product(_origins(sub).items(), ("bottom", "top")):
        s0 = np.array([-ox, oy, T_sub if zref == "bottom" else 0.0])
        for mname, R, t in model_transforms(fp, model):
            Rs = snap_rotation(R @ S)
            if Rs is None:
                continue
            yield f"origin={oname},z={zref},{mname}", Placement(Rs, R @ s0 + t, "", model_R=R, model_t=t)


KICAD_CONVENTION = "order=xyz,sign=-1,offy=+1"  # KiCad 3D viewer: T * Rz(-z) * Ry(-y) * Rx(-x) * S


def outline_samples(sub: Board, step: float = 2.0) -> np.ndarray:
    """Points on the board outline (local frame), on the top and bottom face: corners and every
    ``step`` mm along the edges - a STEP export of the board has vertices on all of them."""
    ol = sub.outline()
    if ol is None:
        return np.zeros((0, 3))
    T = sub.stackup.thickness
    pts = []
    for p in getattr(ol, "geoms", [ol]):
        for ring in [p.exterior] + list(p.interiors):
            c = np.array(ring.coords)
            pts += [tuple(v) for v in c]
    a = np.array(pts, float)
    return np.vstack([np.c_[a, np.zeros(len(a))], np.c_[a, np.full(len(a), -T)]])


def _nearest(q: np.ndarray, cloud: np.ndarray, chunk: int = 256) -> np.ndarray:
    out = np.empty(len(q))
    for i in range(0, len(q), chunk):
        d = ((q[i:i + chunk, None, :] - cloud[None, :, :]) ** 2).sum(-1)
        out[i:i + chunk] = np.sqrt(d.min(1))
    return out


def step_frame_fit(sub: Board, step_pts: np.ndarray) -> list[tuple[float, str, str]]:
    """How the sub-board sits in its own STEP export: [(residual mm, origin, z), ...] best first.
    The STEP frame is KiCad's (x, -y) about an origin (page / aux / grid / board centre), with the
    board bottom (z = bottom) or the top copper (z = top) at z = 0. Residual: mean distance of the
    board corners to the nearest STEP vertex - 0 for the right choice."""
    loc = outline_samples(sub)
    if not len(loc) or not len(step_pts):
        return []
    cloud = step_pts
    if len(cloud) > 60000:
        cloud = cloud[np.linspace(0, len(cloud) - 1, 60000).astype(int)]
    T = sub.stackup.thickness
    out = []
    for (oname, (ox, oy)), zref in itertools.product(_origins(sub).items(), ("bottom", "top")):
        q = np.c_[loc[:, 0] - ox, oy - loc[:, 1], loc[:, 2] + (T if zref == "bottom" else 0.0)]
        out.append((float(_nearest(q, cloud).mean()), oname, zref))
    out.sort()
    return out


def adjust(pl: Placement, sub: Board, adj: dict | None) -> Placement:
    """User correction of a fitted placement: ``turn`` (degrees about the vertical through the
    board centre, steps of 90), ``upside`` (board turned upside down), ``shift`` [x, y, z] mm."""
    if not adj:
        return pl
    ol = sub.outline()
    x0, y0, x1, y1 = ol.bounds if ol is not None else (0, 0, 0, 0)
    c = pl.apply(np.array([[(x0 + x1) / 2, (y0 + y1) / 2, -sub.stackup.thickness / 2]]))[0]
    R = np.eye(3)
    if adj.get("upside"):
        n = pl.normal_axis()
        h = next(a for a in (0, 1, 2) if a != n and a != 2) if n != 2 else 0  # horizontal axis in the board plane
        R = snap_rotation(rot("xyz"[h], 180.0)) @ R
    turn = float(adj.get("turn", 0.0)) % 360
    if turn:
        R = snap_rotation(rot("z", turn)) @ R
    sh = np.asarray(adj.get("shift", (0.0, 0.0, 0.0)), float)
    return Placement(snap_rotation(R @ pl.R), R @ (pl.t - c) + c + sh, pl.convention + " + adjusted", pl.residual,
                     pl.step_residual, pl.model_R, pl.model_t)


def fit_step_part(main: Board, fp_ref: str, vertices: np.ndarray, model: dict | None = None) -> tuple[Placement, list]:
    """Pick the model convention that puts a metal part (STEP frame vertices) onto its pads."""
    fp = main.footprint(fp_ref)
    targets = np.array([[p.x, -p.y, 0.0] for p in fp.pads if p.number] or [[fp.x, -fp.y, 0.0]])
    v = vertices if len(vertices) <= 4000 else vertices[np.linspace(0, len(vertices) - 1, 4000).astype(int)]
    ranking = []
    for name, R, t in model_transforms(fp, model):
        g = v @ R.T + t
        d = np.sqrt(((targets[:, None, :] - g[None, :, :]) ** 2).sum(-1)).min(1)
        below = max(0.0, -g[:, 2].min() - main.stackup.thickness - 0.2)
        ranking.append((float(d.mean() + 2 * below), name, Placement(R, t, name)))
    ranking.sort(key=lambda r: r[0])
    pl = ranking[0][2]
    pl.residual = ranking[0][0]
    return pl, [(s, n) for s, n, _ in ranking[:5]]


def _sample_copper(sub: Board, n_max: int = 4000) -> np.ndarray:
    pts = []
    for f in sub.footprints:
        for p in f.pads:
            if p.on_layer("F.Cu") or p.on_layer("B.Cu"):
                z = 0.0 if p.on_layer("F.Cu") else -sub.stackup.thickness
                g = p.polygon()
                pts += [(x, y, z) for x, y in g.exterior.coords]
    for t in sub.tracks:
        z = 0.0 if t.layer == "F.Cu" else -sub.stackup.thickness if t.layer == "B.Cu" else None
        if z is None:
            continue
        g = t.polygon()
        pts += [(x, y, z) for x, y in g.exterior.coords[::2]]
    for zn in sub.zones:
        for layer, gs in zn.filled.items():
            if layer not in ("F.Cu", "B.Cu"):
                continue
            z = 0.0 if layer == "F.Cu" else -sub.stackup.thickness
            for g in gs:
                c = list(g.exterior.coords)
                pts += [(x, y, z) for x, y in c[:: max(1, len(c) // 200)]]
    a = np.array(pts, float) if pts else np.zeros((0, 3))
    if len(a) > n_max:
        a = a[np.linspace(0, len(a) - 1, n_max).astype(int)]
    return a


def _sub_pad_centres(sub: Board, netted: bool = False) -> np.ndarray:
    """Pad centres of the sub-board (local frame), one per copper side of each pad.
    netted=True: only pads on a net (the feed side of the antenna board)."""
    T = sub.stackup.thickness
    pts = []
    for f in sub.footprints:
        for p in f.pads:
            if netted and not p.net:
                continue
            if p.on_layer("F.Cu"):
                pts.append((p.x, p.y, 0.0))
            if p.on_layer("B.Cu"):
                pts.append((p.x, p.y, -T))
    return np.array(pts, float) if pts else np.zeros((0, 3))


def _free_axes(pl: Placement) -> list[int]:
    """Horizontal global axes along which the board may slide (not its plate normal)."""
    n = pl.normal_axis()
    return [a for a in (0, 1) if a != n]


def _inplane_dist(pl: Placement, targets: np.ndarray, g: np.ndarray) -> np.ndarray:
    """Per target pad: distance to the nearest sub-board pad along the slide axes and height.

    The plate-normal offset is left out: solder pads of a vertical board sit beside
    its faces, not on them."""
    ax = _free_axes(pl) + [2]
    d = targets[:, None, ax] - g[None, :, ax]
    d[..., -1] = (np.abs(d[..., -1]) - 3.0).clip(min=0)  # edge pads may sit up to 3 mm above the main board
    return np.sqrt((d ** 2).sum(-1)).min(1)


def _refine_inplane(pl: Placement, targets: np.ndarray, pads: np.ndarray, max_shift: float = 5.0, iters: int = 6):
    """Slide the placement along its free horizontal axes so sub-board pads meet the
    footprint pads (STEP origins often sit on a tab or pad, not on a board origin)."""
    ax = _free_axes(pl)
    if not ax:
        return
    t0 = pl.t.copy()
    for _ in range(iters):
        g = pl.apply(pads)
        d = targets[:, None, :] - g[None, :, :]
        nn = np.sqrt((d[..., ax] ** 2).sum(-1)).argmin(1)
        shift = np.zeros(3)
        for a in ax:
            shift[a] = np.mean(d[np.arange(len(targets)), nn, a])
        if np.abs(shift).max() < 1e-6:
            break
        pl.t = pl.t + shift
    if np.abs(pl.t - t0).max() > max_shift:
        pl.t = t0


def fit_subboard(main: Board, fp_ref: str, sub: Board, model: dict | None = None,
                 step_pts: np.ndarray | None = None) -> tuple[Placement, list]:
    """Choose the convention whose sub-board copper meets the footprint pads.

    Per candidate the board is first slid along its free horizontal axes so its pads
    meet the footprint pads (the STEP origin is often a tab or pad, not a board origin).
    Score: mean pad distance (slide axes + height), small tie-breakers for the pad face
    and for the connected (feed) pad, plus a penalty for copper below the main board.
    ``residual`` is the plain mean pad misalignment in mm.
    """
    fp = main.footprint(fp_ref)
    frame = step_frame_fit(sub, step_pts) if step_pts is not None and len(step_pts) else []
    pick = None
    if frame and frame[0][0] < 0.3:  # the STEP decides where the board sits in its model frame
        pick = (frame[0][1], frame[0][2])
    # all copper pads count, also unnamed mechanical solder pads of vertical antennas
    targets = np.array([[p.x, -p.y, 0.0] for p in fp.pads if p.on_layer("F.Cu") or p.kind == "thru_hole"])
    if len(targets) == 0:
        targets = np.array([[fp.x, -fp.y, 0.0]])
    samples = _sample_copper(sub)
    if len(samples) == 0:
        raise ValueError("sub-board has no copper")
    pads = _sub_pad_centres(sub)
    feeds = _sub_pad_centres(sub, netted=True)
    feed_targets = np.array([[p.x, -p.y, 0.0] for p in fp.pads if p.number and p.net and p.on_layer("F.Cu")])
    ranking = []
    for name, pl in candidate_placements(main, fp, sub, model):
        if pick and not name.startswith(f"origin={pick[0]},z={pick[1]},"):
            continue
        if len(pads):
            _refine_inplane(pl, targets, pads)
            g = pl.apply(pads)
            d = _inplane_dist(pl, targets, g)
            pl.residual = float(d.mean())
            # tie-breakers: which face the pads are on (both horizontal axes), and the
            # connected pad of the footprint should meet a connected pad of the sub-board
            dh = np.sqrt(((targets[:, None, :2] - g[None, :, :2]) ** 2).sum(-1)).min(1)
            d = d + 0.1 * dh
            if len(feeds) and len(feed_targets):
                gf = pl.apply(feeds)
                d = d + 0.5 * np.sqrt(((feed_targets[:, None, :2] - gf[None, :, :2]) ** 2).sum(-1)).min(1).mean()
        else:
            d = np.sqrt(((targets[:, None, :] - pl.apply(samples)[None, :, :]) ** 2).sum(-1)).min(1)
            pl.residual = float(d.mean())
        g = pl.apply(samples)
        below = max(0.0, -g[:, 2].min() - main.stackup.thickness - 0.2)
        score = float(d.mean() + 2 * below) - (0.05 if name.endswith(KICAD_CONVENTION) else 0.0)
        if pick:
            pl.step_residual = frame[0][0]
        ranking.append((score, name, pl))
    ranking.sort(key=lambda r: r[0])
    best = ranking[0]
    pl = best[2]
    pl.convention = best[1]
    return pl, [(s, n) for s, n, _ in ranking[:5]]


def manual_placement(fp_x: float, fp_y_kicad: float, rotate_deg=(90.0, 0.0, 0.0), offset=(0.0, 0.0, 0.0),
                     origin=(0.0, 0.0), board_angle: float = 0.0) -> Placement:
    """Explicit placement: sub-board local point (x, y, z) -> global.

    The sub-board (x - ox, -(y - oy), z) is rotated by ``rotate_deg`` (X then Y then Z),
    rotated by ``board_angle`` around Z, then moved to the footprint position + offset.
    """
    S = np.diag([1.0, -1.0, 1.0])
    s0 = np.array([-origin[0], origin[1], 0.0])
    Rm = rot("z", rotate_deg[2]) @ rot("y", rotate_deg[1]) @ rot("x", rotate_deg[0])
    Rf = rot("z", board_angle)
    R = snap_rotation(Rf @ Rm @ S)
    if R is None:
        raise ValueError("only rotations in steps of 90 degrees are supported")
    t = Rf @ (Rm @ s0 + np.array(offset, float)) + np.array([fp_x, -fp_y_kicad, 0.0])
    return Placement(R, t, "manual")
