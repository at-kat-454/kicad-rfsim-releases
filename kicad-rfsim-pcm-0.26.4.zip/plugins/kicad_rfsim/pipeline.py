"""End-to-end pipeline used by the CLI and the KiCad plugin.

  init_config  -> sim JSON from seed nets (region + ports chosen automatically)
  simulate     -> EM run (cached by geometry hash) + circuit + tuning viewer
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import time
from pathlib import Path

import numpy as np

from shapely.ops import unary_union

from .board import Board
from .rfpath import find_rf_cluster, parse_value, part_kind


def auto_margin(board: Board) -> float:
    """Region margin around the RF pads: the field of a line spreads ~3 dielectric heights to the side
    (1 mm on 0.2 mm prepreg, ~4.6 mm on a 1.6 mm 2-layer board, where 1 mm cut the trace itself)."""
    try:
        h = sum(d.thickness for d in board.stackup.dielectric_between("F.Cu", _ref_layer(board)))
    except Exception:  # noqa: BLE001
        h = 0.0
    return round(max(1.0, 3.0 * h), 2)


def init_config(board: Board, seeds: list[str], name: str = "rf", margin: float | None = None,
                external: list[str] | None = None, board_rel: str | None = None, band=None) -> dict:
    c = find_rf_cluster(board, seeds)
    ports: list[str] = []
    xs, ys = [], []
    for ref in c.parts:
        fp = board.footprint(ref)
        for p in fp.pads:
            if not p.number or not p.on_layer("F.Cu"):
                continue
            xs.append(p.x)
            ys.append(p.y)
            if p.net and p.net != c.ground and part_kind(fp) in ("C", "L", "R", "ic", "connector"):
                ports.append(f"{ref}.{p.number}")
    for ref, pad, _net in c.port_candidates:
        p = board.footprint(ref).pad(pad)
        if p.on_layer("F.Cu"):
            ports.append(f"{ref}.{pad}")
            xs.append(p.x)
            ys.append(p.y)
    seen, uniq = set(), []
    for p in ports:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    if external is None:  # largest boundary IC pin + a pad on the first seed net
        ics = sorted({r for r, _, _ in c.port_candidates}, key=lambda r: -len(board.footprint(r).pads))
        external = [f"{r}.{p}" for r, p, _ in c.port_candidates if ics and r == ics[0]][:1]
        seed_pads = [q for q in uniq if board.footprint(q.split(".")[0]).pad(q.split(".", 1)[1]).net == seeds[0]]
        external += seed_pads[:1]
    margin = auto_margin(board) if margin is None else margin
    region = [min(xs) - margin, min(ys) - margin, max(xs) + margin, max(ys) + margin]
    cfg = {
        "name": name,
        "board": board_rel or str(board.path),
        "output": "results",
        "region": [round(v, 3) for v in region],
        "ports": uniq,
        "external": external,
        "ref_layer": _ref_layer(board),
        "points": 271,
        "model": {"f_min": 0.3e9, "f_max": 3.0e9, "truncate_at": _ref_layer(board)},
        "mesh": {"max_fine": 0.1, "min_cell": 0.04, "z_cells_per_dielectric": 3},
        "marks_hz": [868e6, 1736e6, 2604e6],
        "solver": {"engine": "auto", "threads": 0},
    }
    return set_band(cfg, band) if band else cfg


def q_ref(cfg: dict) -> float:
    """Frequency the default part Q refers to: from the operating band (868 MHz in older setups)."""
    return float(cfg.get("f_q") or 868e6)


def _short_check(board, cfg, model) -> list[dict]:
    """Overlapping copper of an RF net and another net inside the region (see checks.short_check)."""
    from .checks import short_check
    try:
        nets = {board.footprint(q.split(".")[0]).pad(q.split(".", 1)[1]).net for q in cfg.get("ports", [])}
        nets.discard(None)
        nets.discard(cfg.get("ground", "GND"))
        return short_check(board, cfg["region"], sorted(nets), list(getattr(model, "layers", [])))
    except Exception:  # noqa: BLE001 - a check must never stop a run
        return []


def lumped_specs(board: Board, refs, values: dict | None = None, f_q: float | None = None) -> dict:
    """Lumped-element specs of fixed parts (value from the footprint, losses from Q at f_Q).
    ``values``: ref -> value text that replaces the footprint value (a BOM variant, e.g. "0R").
    ``f_q``: reference frequency of the default Q (the band centre)."""
    import math

    from .circuit import element_from_value
    out = {}
    for ref in refs or []:
        try:
            fp = board.footprint(ref)
        except KeyError:
            continue
        q = fp.properties.get("RF.Q")
        alt = (values or {}).get(ref)
        kind = part_kind(fp)
        if alt is not None:  # the unit of the variant value decides (an inductor fitted on a capacitor place)
            u = alt.strip().rstrip("Ω").lower()
            kind = "L" if u.endswith("h") else "C" if u.endswith("f") else "R" if u[-1:] in ("r", "0") else kind
        el = element_from_value(kind, alt if alt is not None else fp.value, fp.dnp and alt is None,
                                float(q) if q else None, f_q)
        if el.kind == "open":
            continue
        esr = el.esr or 0.0
        if el.kind == "C" and el.q:
            esr += 1 / (2 * math.pi * el.f_q * el.value * el.q)
        elif el.kind == "L" and el.q:
            esr += 2 * math.pi * el.f_q * el.value / el.q
        spec = {"kind": el.kind, "value": el.value, "esr": esr, "esl": el.esl or 0.0, "f_ref": el.f_q}
        if el.kind == "L" and esr > 0:  # series loss -> equivalent parallel resistance at f_Q
            x = 2 * math.pi * el.f_q * el.value
            spec["rp"] = x * x / esr
        out[ref] = spec
    return out


def ground_pad_ports(board: Board, ports: list[str], ground: str = "GND") -> list[str]:
    """GND pads of the shunt parts that are tuned (have a port on their other pad). With a port on
    the GND pad too, the pad, its trace and via to the ground plane are part of the EM result;
    otherwise the part would be connected to an ideal ground at its pad (at 2 GHz a few tenths of
    a nH matter: up to 3 dB in a C-L-C low-pass)."""
    from .rfpath import part_kind
    have = set(ports)
    out = []
    for ref in dict.fromkeys(q.split(".")[0] for q in ports):
        try:
            fp = board.footprint(ref)
        except KeyError:
            continue
        pads = [p for p in fp.pads if p.number]
        if len(pads) != 2 or part_kind(fp) not in ("C", "L", "R"):
            continue
        for p in pads:
            q = f"{ref}.{p.number}"
            if p.net == ground and q not in have and p.on_layer("F.Cu"):
                out.append(q)
    return out


def build_circuit_model(board: Board, cfg: dict, ms=None, ground_ports: bool = True):
    """OpenEMSModel of an RF chain config (ports + fixed parts as lumped elements).
    ``ground_ports``: also a port on the GND pad of every tuned shunt part (see ground_pad_ports;
    config key "ground_ports": false turns it off)."""
    from .openems_export import MeshSettings, ModelSettings, OpenEMSModel
    if ms is None:
        ms = ModelSettings(**cfg.get("model", {}), mesh=MeshSettings(**cfg.get("mesh", {})))
    cu = [l.name for l in board.stackup.copper]
    ref = cfg.get("ref_layer", "In1.Cu")
    if ref not in cu:  # setups made before 2-layer boards were handled named In1.Cu
        ref = _ref_layer(board)
    if ms.truncate_at and ms.truncate_at not in cu:
        ms.truncate_at = ref
    names = list(cfg["ports"])
    region = list(cfg["region"])
    gp = ground_pad_ports(board, names) if ground_ports and cfg.get("ground_ports", True) else []
    names += gp
    lumped = cfg.get("lumped", [])
    if gp or lumped:
        # the GND pads of tuned and fixed shunt parts and the via next to them belong in the model
        # (same region for the S-matrix runs and the wave run)
        for q in ground_pad_ports(board, list(cfg["ports"]) + [f"{r}.?" for r in lumped]):
            pd = board.footprint(q.split(".")[0]).pad(q.split(".", 1)[1])
            m = max(pd.size) / 2 + 1.0
            region = [min(region[0], pd.x - m), min(region[1], pd.y - m), max(region[2], pd.x + m),
                      max(region[3], pd.y + m)]
    ports = [tuple(p.split(".", 1)) for p in names]
    return OpenEMSModel(board, tuple(region), ports, ref_layer=ref, settings=ms,
                        lumped=lumped_specs(board, cfg.get("lumped", []), f_q=q_ref(cfg)))


def cut_via_notes(model) -> list[str]:
    """Vias of signal nets that reach the layer replaced by the ground wall (truncate_at)."""
    by_net: dict[str, list] = {}
    for n, x, y in getattr(model, "cut_vias", []):
        by_net.setdefault(n, []).append(f"({x}, {y})")
    return [f"{n}: {len(v)} via(s) at {', '.join(v[:4])}{' ...' if len(v) > 4 else ''} mm go down to "
            f"{model.s.truncate_at}, which the RF chain model replaces by a ground wall. The vias end above "
            f"it, so {n} is not shorted to ground; copper of {n} on {model.s.truncate_at} is not modelled."
            for n, v in by_net.items()]


def circuit_model_on_mesh(board: Board, cfg: dict, ms, progress=print):
    """RF chain model whose mesh keeps the RF path connected. A trace thinner than the cells
    (diagonal / curved) falls apart in the FDTD and the path would be open: Automatic and preset
    meshes are refined until every port is connected again. Returns (model, note, broken nets)."""
    mesh_s = ms.mesh
    model = build_circuit_model(board, cfg, ms)
    note = None
    broken = model.broken_nets()
    custom = cfg.get("solver", {}).get("mode", "auto") == "custom"
    tries = 0
    while broken and not custom and tries < 4:
        tries += 1
        old = mesh_s.max_fine
        mesh_s.max_fine = round(old * 0.7, 4)
        mesh_s.min_cell = min(mesh_s.min_cell, mesh_s.max_fine / 2)
        progress(f"mesh: {broken[0]['net']} falls apart at {old:g} mm cells - refined to {mesh_s.max_fine:g} mm")
        model = build_circuit_model(board, cfg, ms)
        broken = model.broken_nets()
        note = f"mesh refined from the setup's max_fine to {mesh_s.max_fine:g} mm so the RF path stays connected"
    return model, note, broken


def inspect_mesh(config_path, board_path=None, progress=print, estimate: str = "", tune: dict | None = None) -> Path:
    """Mesh inspector page (mesh.html in the result folder) for a setup, before any run: the
    model built exactly as the next simulation would build it, rasterised on its mesh.
    ``tune``: the editable mesh settings (plugin); the page then compares with the previous mesh."""
    from .meshview import write_mesh_view
    from .solver import check_keys
    config_path = Path(config_path)
    cfg = json.loads(config_path.read_text())
    base = config_path.parent
    out = base / cfg.get("output", "rfsim") / cfg["name"]
    out.mkdir(parents=True, exist_ok=True)
    checks, notes = [], []
    if cfg.get("type") == "antenna":
        progress("building antenna model")
        model = build_antenna_model(cfg, base, board_path, progress, out)
        checks = model.mesh_problems()
        notes = [n for n in model.notes if n.startswith(("feed", "mesh"))]
        xml = model.write_xml(out / "mesh_check.xml")
        ys = -1.0
        title = f"antenna {cfg['name']}"
        pnames = {1: (f"feed on the trace after {model.feed.trace.get('after')}" if model.feed.trace
                      else f"feed {model.feed.ref}.{model.feed.pad}")}
    else:
        from .openems_export import MeshSettings, ModelSettings
        bp = Path(board_path) if board_path else (base / cfg["board"])
        board = Board(bp)
        mesh_s = check_keys(MeshSettings, cfg.get("mesh", {}), "mesh")
        ms = check_keys(ModelSettings, cfg.get("model", {}), "model")
        ms.mesh = mesh_s
        progress("building RF chain model")
        model, note, broken = circuit_model_on_mesh(board, cfg, ms, progress)
        if note:
            notes.append(note)
        for b in broken:
            checks.append(f"RF path falls apart on the mesh: {b['net']} (" +
                          " | ".join(", ".join(g) for g in b["groups"]) + ")")
        if getattr(model, "slivers", 0):
            notes.append(f"{model.slivers} slivers at the region edge left out")
        notes.extend(cut_via_notes(model))
        exc = next((p.number for p in model.ports if not p.termination), None)
        xml = model.write_xml(out / "mesh_check.xml", excite=exc)
        ys = 1.0
        pnames = {p.number: p.name + (" (termination)" if p.termination else "") for p in model.ports}
        title = f"RF chain {cfg['name']}"
    mode = cfg.get("solver", {}).get("mode", "auto")
    notes.insert(0, f"Solver settings: {mode}. The page shows the mesh the next run will use.")
    prev = None
    try:
        prev = json.loads((out / "mesh_summary.json").read_text())
    except (OSError, ValueError):
        pass
    page = write_mesh_view(xml, out / "mesh.html", title, checks, notes, y_sign=ys, estimate=estimate,
                           progress=progress, port_names=pnames, tune=tune, previous=prev)
    progress(f"mesh view: {page}")
    return page


def _geometry_hash(model) -> str:
    h = hashlib.sha256()
    for layer, polys in sorted(model.sheets.items()):
        for net, p in sorted(polys, key=lambda t: (t[0], round(t[1].centroid.x, 4), round(t[1].centroid.y, 4))):
            h.update(f"{layer}|{net}|{p.wkt}".encode())
    for v in model.vias:
        h.update(repr([round(x, 5) if isinstance(x, float) else x for x in v]).encode())
    for p in model.ports:
        h.update(f"{p.name}|{p.x0:.5f}|{p.y0:.5f}|{p.x1:.5f}|{p.y1:.5f}|{p.z_ref}|{p.z_sig}".encode())
    h.update(repr((model.x, model.y, model.z)).encode())
    h.update(repr(dataclasses.asdict(model.s)).encode())  # every model / mesh setting
    for lm in getattr(model, "lumped", []):
        h.update(repr({k: (round(v, 15) if isinstance(v, float) else v) for k, v in lm.items()}).encode())
    return h.hexdigest()[:16]


FR4, COPPER = "#2f6b3e", "#c8913a"


def _scene_circuit(model, top: str):
    """3D scene of an RF chain model (y flipped to point up): dielectric slab + top copper."""
    from shapely.affinity import scale as _scale

    from .fields import mesh3d, slab, triangulate
    flip = lambda g: _scale(g, 1, -1, origin=(0, 0))  # noqa: E731
    zt = model.cu_z[top]
    zb = min(model.cu_z[l] for l in model.cu_z)
    scene = [mesh3d(slab(flip(model.region), zb, zt), FR4, "board", 0.9)]
    tris = []
    for net, poly in model.sheets.get(top, []):
        for a, b, c in triangulate(flip(poly)):
            tris.append([(*a, zt + 0.02), (*b, zt + 0.02), (*c, zt + 0.02)])
    scene.append(mesh3d(tris, COPPER, "copper"))
    # the field is recorded under the copper; it is drawn just above it (see-through) so both are visible
    return scene, zt + 0.06


def _scene_antenna(model):
    """3D scene of an antenna model: main board slab, antenna copper incl. soldered-in boards."""
    from shapely.affinity import scale as _scale

    from .fields import mesh3d, slab, triangulate
    czs = model._cu_z(model.main)
    ol = model.main.outline()
    scene = []
    if ol is not None:
        scene.append(mesh3d(slab(_scale(ol, 1, -1, origin=(0, 0)), min(czs.values()), max(czs.values())), FR4,
                            "board", 0.9))
    tris = []
    for sh in model.sheets:
        if not (sh.get("antenna") or not str(sh["name"]).startswith("main")):
            continue
        a = sh["axis"]
        for t in triangulate(sh["poly"]):
            tri = []
            for u, v in t:
                pt = [0.0, 0.0, 0.0]
                pt[a], pt[(a + 1) % 3], pt[(a + 2) % 3] = sh["elev"] + (0.02 if a == 2 else 0.0), u, v
                tri.append(tuple(pt))
            tris.append(tri)
    scene.append(mesh3d(tris, COPPER, "antenna copper"))
    from .enclosure import model_traces
    scene += model_traces(model)  # casing parts, see-through
    return scene, model.field_plane()[0][2]


def _sub_wave_views(model, out, cfg, scene, progress) -> list[tuple[str, str]]:
    """Wave views in the plane of each standing antenna board (see AntennaModel.sub_field_planes).
    Returns [(link label, file name)] for the main wave view."""
    from . import boardpic
    from .fields import read_fields, write_wave_view
    links = []
    for fp in model.sub_field_planes():
        F = read_fields(out / "antenna_run", fp["name"], fp["name"] + "_fd", normal=fp["n"])
        if F is None:
            continue
        n, h, sg = fp["n"], fp["h"], fp["s"]
        # page axes: u = s * (global h) to the right, v = global z up (read_fields: x = in-plane axis
        # with the lower index = h, y = z)
        if sg < 0:
            F = dict(F)
            F["x"] = -F["x"][::-1]
            F["td"] = F["td"][..., ::-1]
            F["fd"] = {f: a[..., ::-1] for f, a in F.get("fd", {}).items()}
        sb = fp["sub"]
        pl = sb.placement

        def to_page(x, y, pl=pl, h=h, sg=sg):
            g = pl.apply(np.array([[x, y, 0.0]]))[0]
            return sg * g[h], -g[2]  # picture coordinates: y down
        try:
            pic = boardpic.transform(boardpic.picture(sb.board), to_page)
        except Exception as e:  # noqa: BLE001
            progress(f"antenna board picture failed: {e}")
            pic = None
        outl = []
        for sh in model.sheets:
            if sh["name"].startswith(sb.name + ":") and sh["axis"] == n:
                a1, a2 = (n + 1) % 3, (n + 2) % 3
                pts = []
                for p1, p2 in sh["poly"].exterior.coords:
                    g = [0.0, 0.0, 0.0]
                    g[a1], g[a2] = p1, p2
                    pts.append((sg * g[h], g[2]))
                outl.append((sh["name"], pts))
        fn = f"wave_{sb.name}.html"
        side = "+-"[sg < 0] + "xy"[h]
        write_wave_view(F, outl, out / fn, f"Wave view – {cfg['name']} – antenna board {Path(sb.board.path).name}",
                        f"E-field normal to the antenna board, 1 mm in front of its top copper (seen from the front, "
                        f"{side} to the right, z up)",
                        y_up=True, show="mag", scene=scene, plane_opacity=0.6, pic=pic,
                        plane3d={"n": n, "e": fp["e"], "h": h, "s": sg}, links=[("Board plane →", "wave.html")],
                        comp_label="E normal to the antenna board (sign = direction)",
                        where="E-field on a plane parallel to the standing antenna board, 1 mm in front of its top "
                              "copper. Pulse: the broadband excitation climbing the antenna. Steady state: the field "
                              "at one frequency over one RF period.")
        progress(f"wave view (antenna board): {out / fn}")
        links.append((f"Antenna board plane ({sb.name})", fn))
    return links


def _wave_run_circuit(board, cfg, ms, out, f, external, part_refs, so, openems_bin, progress, rec,
                      overlay: bool = False):
    """Extra run for the wave view: the RF chain with every part at its board value inside the
    FDTD (lumped), input port excited, output port 50 ohm. Unlike the S-matrix runs (bare layout,
    every part pad a port), the wave really passes through the matching network.
    ``overlay``: also excite the output port and record a plane 0.5 mm above the top copper, so
    the whole-board overlay (overlay.py) can join this run with the antenna run."""
    import copy

    from .fields import TOP_NAME, read_fields, write_wave_view
    from .openems_export import run
    from .overlay import write_meta
    wcfg = copy.deepcopy(cfg)
    wcfg["ports"] = list(external)
    keep_out = {external[0].split(".")[0]}  # only the input part: the source sits on its pad
    wcfg["lumped"] = sorted(set(cfg.get("lumped", [])) | {r for r in part_refs if r not in keep_out})
    model = build_circuit_model(board, wcfg, ms, ground_ports=False)
    num = {p.name: p.number for p in model.ports}
    p_in = num.get(external[0], 1)
    p_out = num.get(external[1]) if len(external) > 1 else None
    exc = [p_in] + ([p_out] if overlay and p_out else [])
    progress(f"wave run: {len(model.lumped)} parts inside the EM model, excited at "
             + " and ".join(external[:len(exc)]))
    stats = []
    fl = {"freqs": cfg.get("marks_hz", [868e6])[:3]}
    if overlay:
        fl["top"] = 0.5
    run(model, out / "wave_run", f, excite=exc, threads=so.threads, openems_bin=openems_bin, log=progress,
        engine=so.engine, stats=stats, label=f"{cfg['name']}: wave run", fields=fl, fields_port=set(exc),
        parallel=so.parallel)
    for st in stats:
        rec.add(st)
    top = max(model.layers, key=lambda l: model.cu_z[l])
    if overlay and p_out:
        write_meta(out / "wave_run", port_in=p_in, port_out=p_out, R=float(model.ports[p_in - 1].R),
                   f_min=float(ms.f_min), f_max=float(ms.f_max), td_name=TOP_NAME,
                   names=[external[0], external[1]],
                   outlines=_outlines(model.sheets.get(top, [])), parts=[lm["ref"] for lm in model.lumped])
    F = read_fields(out / "wave_run" / f"exc_{p_in}")
    if F is None:
        progress("wave run: no field data")
        return
    scene, pz = _scene_circuit(model, top)
    vals = ", ".join(f"{lm['ref']}" for lm in model.lumped)
    write_wave_view(F, _outlines(model.sheets.get(top, [])), out / "wave.html", f"Wave view – {cfg['name']}",
                    f"excited at {external[0]}, output {external[1] if len(external) > 1 else '-'} 50 ohm; "
                    f"parts in the model at their board values: {vals}; field under {top}",
                    scene=scene, plane_z=pz, plane_opacity=0.7, pic=_picture(board, progress, model.region))
    progress(f"wave view: {out / 'wave.html'}")


def _compact_runs(root: Path, progress=print):
    """After a run: shrink the field recordings below ``root`` (see fields.compact_fields), drop the
    near-field surfaces once the far field is computed and openEMS' excitation signal dumps
    (``et`` / ``ht``: one text line per timestep, nothing reads them). The pages, S-parameters and
    the whole-board overlay keep working."""
    from .fields import compact_fields
    n = freed = 0
    for f in list(Path(root).rglob("et")) + list(Path(root).rglob("ht")):
        if f.is_file():
            freed += f.stat().st_size
            f.unlink()
    for d in sorted({p.parent for p in Path(root).rglob("fld_*.h5")}):
        k, b = compact_fields(d)
        n, freed = n + k, freed + b
    for d in sorted({p.parent for p in Path(root).rglob("nf2ff_E_*.h5")}):
        if (d / "nf2ff.h5").exists():
            for f in list(d.glob("nf2ff_E_*.h5")) + list(d.glob("nf2ff_H_*.h5")):
                freed += f.stat().st_size
                f.unlink()
    if freed > 0:
        progress(f"field recordings: {n} compacted, {freed / 2**20:.0f} MB freed")


def _pair(rfsim_dir: Path):
    """(antenna config path, RF chain config path) of a project, or None."""
    cfgs = list_configs(rfsim_dir)
    ant = next((c for c in cfgs if json.loads(c.read_text()).get("type") == "antenna"), None)
    rf = next((c for c in cfgs if json.loads(c.read_text()).get("type") != "antenna"), None)
    return (ant, rf) if ant and rf else None


def overlay_ready(rfsim_dir: Path) -> bool:
    """Both runs have the recordings the overlay needs."""
    pr = _pair(Path(rfsim_dir))
    if not pr:
        return False
    from .overlay import read_meta
    ant, rf = pr
    acfg, rcfg = json.loads(ant.read_text()), json.loads(rf.read_text())
    ad = ant.parent / acfg.get("output", "rfsim") / acfg["name"] / "antenna_run"
    wd = rf.parent / rcfg.get("output", "rfsim") / rcfg["name"] / "wave_run"
    m = read_meta(wd)
    from .fields import recording_exists
    return bool(read_meta(ad) and m and recording_exists(wd / f"exc_{m['port_out']}", m["td_name"]))


def overlay_board(rfsim_dir: Path, progress=print) -> dict | None:
    """Whole-board wave view from the RF path and antenna runs (no extra simulation, see overlay.py)."""
    from .overlay import build_overlay, read_meta, write_overlay_view
    rfsim_dir = Path(rfsim_dir)
    pr = _pair(rfsim_dir)
    if not pr:
        progress("whole-board view needs an antenna setup and an RF chain setup")
        return None
    ant, rf = pr
    acfg, rcfg = json.loads(ant.read_text()), json.loads(rf.read_text())
    ad = ant.parent / acfg.get("output", "rfsim") / acfg["name"] / "antenna_run"
    wd = rf.parent / rcfg.get("output", "rfsim") / rcfg["name"] / "wave_run"
    am, pm = read_meta(ad), read_meta(wd)
    if not am or not pm:
        progress("whole-board view: run the antenna and the RF path with the wave view first")
        return None
    feed = f"{acfg['feed']['ref']}.{acfg['feed']['pad']}"
    if pm["names"][1] != feed:
        progress(f"WARNING whole-board view: RF path output {pm['names'][1]} is not the antenna feed {feed}")
    marks = rcfg.get("marks_hz", [868e6])[:3]
    progress("whole board: joining the RF path and antenna recordings")
    R = build_overlay((wd / f"exc_{pm['port_in']}", wd / f"exc_{pm['port_out']}"), ad, pm, am,
                      f_ref=marks[0], marks=marks)
    out = rfsim_dir / acfg.get("output", "rfsim") / "full_board"
    out.mkdir(parents=True, exist_ok=True)
    lo, hi = R["band"]
    note = (f"pulse {R['fc']/1e6:.0f} MHz into {pm['names'][0]} (band {lo/1e6:.0f}-{hi/1e6:.0f} MHz shared by "
            f"both runs); parts at their board values: {', '.join(pm['parts']) or '-'}; antenna fed at {feed}")
    path = write_overlay_view(R, am["outlines"] + pm["outlines"], out / "wave.html",
                              "Wave view – whole board (RF path + antenna)", note, am.get("board"), pic=am.get("pic"))
    for s in R["ss"]:
        progress(f"whole board at {s['f']/1e6:.0f} MHz: input match {20*np.log10(max(abs(s['s11']), 1e-9)):.1f} dB, "
                 f"{100*abs(s['x'])**2*(1-abs(s['GA'])**2):.0f} % of the power reaches the antenna")
    (out / "full_board.json").write_text(json.dumps({"type": "overlay", "antenna": ant.name, "rf": rf.name}))
    progress(f"wave view: {path}")
    return {"out": str(out), "viewer": str(path), "reused": False}


def vendor_folder(cfg: dict | None = None) -> str | None:
    """Folder with vendor part libraries: config key "vendor_dir", else RFSIM_VENDOR_DIR (the plugin
    sets it from its settings)."""
    import os
    return (cfg or {}).get("vendor_dir") or os.environ.get("RFSIM_VENDOR_DIR") or None


def vendor_data(board, c, f, cfg, progress=print):
    """(ref -> footprint size, vendor payload for the viewer) - empty without a library."""
    import os

    from .vendor import footprint_size, load_index, viewer_payload
    sizes = {}
    for ref in c.parts:
        try:
            sizes[ref] = footprint_size(board.footprint(ref).lib_id)
        except KeyError:
            pass
    folder = vendor_folder(cfg)
    if not folder:
        return sizes, {}
    try:
        parts = load_index(folder, os.environ.get("RFSIM_CACHE_DIR") or folder, progress)
    except Exception as e:  # a broken library must not break the result
        progress(f"WARNING part library {folder}: {e}")
        return sizes, {}
    ks = {(part_kind(board.footprint(r)), sz) for r, sz in sizes.items() if sz}
    pay = viewer_payload(parts, f, {k for k in ks if k[0] in ("C", "L")})
    if pay:
        n = sum(len(g["parts"]) for kd in pay.values() for gs in kd.values() for g in gs)
        progress(f"part library: {n} vendor parts for the tuning viewer")
    return sizes, pay


def _picture(board, progress=print, region=None):
    """Board top view for the wave views (decoration: a failure only drops the picture)."""
    from .boardpic import picture
    try:
        return picture(board, region.buffer(1.0) if region is not None else None)
    except Exception as e:  # noqa: BLE001
        progress(f"WARNING wave view: no board picture ({e})")
        return None


def touchstone_load(base: Path, file: str, f: np.ndarray, progress=print) -> dict | None:
    """Port-2 load from a Touchstone file (S11 of a .s1p, or port 1 of a larger file): a chip
    antenna's vendor data (valid on the vendor's evaluation board) or a VNA measurement."""
    import skrf as rf
    p = Path(file)
    p = p if p.is_absolute() else base / p
    try:
        raw = rf.Network(str(p))
    except Exception as e:  # noqa: BLE001
        progress(f"WARNING load file {p.name}: not readable ({e})")
        return None
    lo, hi = float(raw.f[0]), float(raw.f[-1])
    if f[0] < lo * 0.999 or f[-1] > hi * 1.001:
        progress(f"WARNING load file {p.name} covers {lo/1e6:.0f}-{hi/1e6:.0f} MHz only - outside it the "
                 f"load is held at the edge values")
    s11 = raw.s[:, 0, 0]
    z0 = float(np.real(raw.z0[0, 0]))
    zz = z0 * (1 + s11) / (1 - s11)
    fe = np.clip(f, lo, hi)
    return {"name": p.name, "file": True, "zr": np.interp(fe, raw.f, zz.real).tolist(),
            "zi": np.interp(fe, raw.f, zz.imag).tolist(), "eff": {}, "valid": [lo, hi]}


def _outlines(polys) -> list:
    return [(n, list(p.exterior.coords)) for n, p in polys if n and p.area > 1e-3]


def simulate(config_path: str | Path, board_path: str | Path | None = None, threads: int = 0,
             progress=print, force: bool = False, openems_bin: str | None = None, fields: bool = False,
             overlay: bool = False, cfg_override: dict | None = None, out_dir: Path | None = None) -> dict:
    """Run (or reuse) the EM simulation and write the tuning viewer.

    ``board_path`` overrides the board in the config (the plugin passes a
    temporary copy with unsaved edits). ``cfg_override`` / ``out_dir``: run a variant of the setup
    (other settings) into another folder, e.g. the mesh convergence check. Returns paths of the results.
    """
    from .openems_export import MeshSettings, ModelSettings, run, to_touchstone
    from .render import render_model
    from .tune import auto_circuit
    from .viewer import write_viewer

    config_path = Path(config_path)
    cfg = cfg_override if cfg_override is not None else json.loads(config_path.read_text())
    if cfg.get("type") == "antenna":
        return simulate_antenna(config_path, board_path, threads, progress, force, openems_bin, fields or overlay,
                                overlay=overlay, cfg_override=cfg_override, out_dir=out_dir)
    base = config_path.parent
    bp = Path(board_path) if board_path else (base / cfg["board"])
    board = Board(bp)
    from .solver import RunRecord, check_keys, load_record, mesh_stats, settings_table, solver_options
    mesh_s = check_keys(MeshSettings, cfg.get("mesh", {}), "mesh")
    ms = check_keys(ModelSettings, cfg.get("model", {}), "model")
    ms.mesh = mesh_s
    so = solver_options(cfg, threads)
    progress("building model")
    model, mesh_note, broken = circuit_model_on_mesh(board, cfg, ms, progress)
    if broken:
        progress("WARNING mesh: the RF path falls apart on this mesh (" + "; ".join(
            " | ".join(", ".join(g) for g in b["groups"]) for b in broken) +
            f") - the result would show an open path. Lower mesh.max_fine below {mesh_s.max_fine:g} mm "
            "(narrowest diagonal / curved trace) or use the Automatic settings.")
    out = Path(out_dir) if out_dir else base / cfg.get("output", "rfsim") / cfg["name"]
    out.mkdir(parents=True, exist_ok=True)
    (out / "model.txt").write_text(model.describe())
    render_model(model, str(out / "model_preview.png"))
    gh = _geometry_hash(model)
    cache = out / "result.npz"
    f = np.linspace(ms.f_min, ms.f_max, int(cfg.get("points", 271)))
    reuse = False
    if cache.exists() and not force:
        try:
            reuse = str(np.load(cache)["geometry_hash"]) == gh
        except Exception:
            reuse = False
    er_max = max([l.epsilon_r for l in board.stackup.layers if l.epsilon_r] or [4.5])
    rec = RunRecord("circuit", cfg["name"], settings_table({"model": ms, "mesh": mesh_s}),
                    dataclasses.asdict(so), model.describe(), mesh_stats((model.x, model.y, model.z), ms.f_max, er_max))
    for msg in cut_via_notes(model):
        rec.notes.append(msg)
        progress("WARNING: " + msg)
    from .openems_export import _inner_nets, region_cuts
    for cut in region_cuts(board, model.region, _inner_nets(model, cfg.get("external") or []), model.layers):
        msg = (f"region boundary cuts {cut['net']} on {cut['layer']} at ({cut['x']}, {cut['y']}) mm, "
               f"{cut['width']} mm wide - the trace ends there in the model; enlarge the region if it matters")
        rec.notes.append(msg)
        progress("WARNING: " + msg)
    # wave view: its own run with the parts inside the model (see _wave_run_circuit); needed when
    # it is missing or the EM result is new
    fields = fields or overlay
    want_fields = fields and (not (out / "wave.html").exists() or not reuse)
    if overlay:
        from .overlay import read_meta
        m = read_meta(out / "wave_run")
        from .fields import recording_exists
        if not m or not recording_exists(out / "wave_run" / f"exc_{m['port_out']}", m["td_name"]):
            want_fields = True
    if reuse:
        progress("layout unchanged - reusing EM result")
        old = load_record(out)
        rec.reused, rec.runs = True, (old or {}).get("runs", [])
    else:
        n_exc = sum(1 for p in model.ports if not p.termination)
        progress(f"EM simulation: {model.n_cells/1e6:.2f} M cells, {n_exc} excitations")
        t0 = time.time()
        stats = []
        ext_ports = cfg.get("external") or [model.ports[0].name]
        fport = next((p.number for p in model.ports if p.name == ext_ports[0]), 1)
        S = run(model, out, f, threads=so.threads, openems_bin=openems_bin, log=progress, engine=so.engine,
                stats=stats, label=cfg["name"], parallel=so.parallel)
        for st in stats:
            rec.add(st)
        names = [p.name for p in model.ports]
        np.savez(cache, f=f, S=S, names=np.array(names), geometry_hash=np.array(gh))
        to_touchstone(S, f, out / f"{cfg['name']}.s{len(names)}p", names=names)
        progress(f"EM done in {(time.time()-t0)/60:.1f} min")
    from .tune import load_em
    f, S, names = load_em(cache)
    from .checks import circuit_checks, connectivity_check, geometry_check
    rec.checks = circuit_checks(S, f, list(names)) + geometry_check(
        sorted(out.glob("exc_*/openEMS.log")), lambda name: name.split(":")[0] in model.layers) + \
        connectivity_check(broken, mesh_s.max_fine) + _short_check(board, cfg, model)
    if mesh_note:
        rec.notes.append(mesh_note)
    for ch in rec.checks:
        if not ch["ok"]:
            progress(f"WARNING plausibility: {ch['name']} {ch['value']} (expected {ch['limit']})")
    c, stamped = auto_circuit(board, f, S, names, f_q=q_ref(cfg))
    # vendor N-port models for ICs (switch, balun ...): {"S1": {"file": "x.s3p", "pads": ["5", "1", "3"]}}
    for ref, mdef in cfg.get("nport_models", {}).items():
        import skrf as rf
        from .circuit import s2y
        mf = Path(mdef["file"])
        raw = rf.Network(str(mf if mf.is_absolute() else base / mf))
        lo, hi = float(raw.f[0]), float(raw.f[-1])
        if f[0] < lo * 0.999 or f[-1] > hi * 1.001:
            msg = (f"{ref}: vendor model {mdef['file']} covers {lo/1e6:.0f}-{hi/1e6:.0f} MHz, the simulation "
                   f"{f[0]/1e6:.0f}-{f[-1]/1e6:.0f} MHz - outside its range the model is extrapolated (unreliable)")
            rec.notes.append(msg)
            progress("WARNING: " + msg)
        ntw = raw.interpolate(rf.Frequency.from_f(f, unit="hz"), kind="cubic", fill_value="extrapolate")
        nodes = [f"{ref}.{p}" for p in mdef["pads"]]
        missing = [n for n in nodes if n not in names]
        if missing:
            raise ValueError(f"{ref}: pads {missing} are not EM ports")
        z0 = float(np.real(ntw.z0[0, 0]))
        c.set_nport(ref, nodes, s2y(ntw.s, z0))
        c.parts.pop(ref, None)  # the vendor model replaces the part's lumped value
        stamped.append(ref)
        progress(f"{ref}: vendor S-parameters {Path(mdef['file']).name} on pads {', '.join(mdef['pads'])}")
    external = cfg.get("external") or names[:2]
    if want_fields or (fields and force):
        _wave_run_circuit(board, cfg, ms, out, f, external, list(c.parts), so, openems_bin, progress, rec,
                          overlay=overlay)
    load = None
    if cfg.get("load_antenna"):  # simulated antenna impedance at external port 2
        acfg_path = base / cfg["load_antenna"]
        acfg = json.loads(acfg_path.read_text())
        rp = acfg_path.parent / acfg.get("output", "rfsim") / acfg["name"] / "antenna_result.npz"
        if rp.exists():
            from .antenna import load_result
            ar = load_result(rp)
            load = {"name": acfg["name"], "zr": np.interp(f, ar.f, ar.zin.real).tolist(),
                    "zi": np.interp(f, ar.f, ar.zin.imag).tolist(),
                    "eff": {str(k): v["eff_rad"] for k, v in ar.farfield.items()},
                    "valid": [float(ar.f[0]), float(ar.f[-1])]}
        else:
            progress(f"antenna result {rp} missing - viewer uses a constant load")
    if cfg.get("load_file"):  # measured / vendor antenna data (e.g. a chip antenna's .s1p) instead
        load = touchstone_load(base, cfg["load_file"], f, progress) or load
    sizes, vend = vendor_data(board, c, f, cfg, progress)
    html = write_viewer(c, external, out / "tune.html", title=f"RF tuning – {cfg['name']}",
                        marks_hz=cfg.get("marks_hz", [868e6]), board_name=bp.name, load=load,
                        kind_hints={r: part_kind(board.footprint(r)) for r in c.parts}, sizes=sizes, vendor=vend,
                        source=tuple(cfg["source_impedance"]) if cfg.get("source_impedance") else None,
                        band=cfg.get("band"))
    progress(f"viewer: {html}")
    _compact_runs(out, progress)
    info = rec.save(out)
    return {"out": str(out), "viewer": str(html), "stamped": stamped, "reused": reuse, "info": str(info)}


# ---------------------------------------------------------------------------
# antennas
# ---------------------------------------------------------------------------
def _resolve_model_path(path: str, proj_dir: Path) -> Path:
    import os
    import re

    def rep(m):
        k = m.group(1)
        if k == "KIPRJMOD":
            return str(proj_dir)
        return os.environ.get(k, m.group(0))
    return Path(re.sub(r"\$\{([^}]+)\}", rep, path))


def _name_tokens(stem: str) -> set[str]:
    import re
    return {t for t in re.split(r"[^a-z0-9]+", stem.lower()) if t}


def _name_score(step_stem: str, pcb_stem: str) -> int:
    """Shared name tokens; a token also counts if one is the prefix of the other
    (``short`` ~ ``shortsolder``). 0 unless a token with a digit (part number) is shared."""
    a, b = _name_tokens(step_stem), _name_tokens(pcb_stem)
    hits = {x for x in a if any(y == x or y.startswith(x) or x.startswith(y) for y in b if min(len(x), len(y)) >= 3)}
    if not any(any(c.isdigit() for c in x) for x in hits):
        return 0
    return len(hits)


def step_info(step_path: Path) -> dict:
    """Header of a STEP file: {"kicad": exported by KiCad (a circuit board), "products": names}.
    KiCad names the board's product after the board file (``MyAnt`` for MyAnt.kicad_pcb)."""
    import re
    try:
        with open(step_path, "rb") as fh:
            head = fh.read(3 << 20).decode("latin-1", errors="replace")
    except OSError:
        return {"kicad": False, "products": []}
    fn = re.search(r"FILE_NAME\s*\((.*?)\);", head, re.S)
    # a board exported by KiCad names Pcbnew / kicad2step / kicad-cli as originating system; library parts
    # made with "kicad StepUp" (FreeCAD) or the CadQuery generators also say "kicad" but are single parts
    kicad = bool(fn and re.search(r"pcbnew|kicad2step|kicad[ _-]?cli|kicad to step", fn.group(1), re.I)
                 and not re.search(r"stepup|ksu", fn.group(1), re.I))
    prods = []
    for m in re.finditer(r"PRODUCT\s*\(\s*'([^']*)'", head):
        n = m.group(1).strip()
        if n and n not in prods and not re.fullmatch(r"(?i)(open cascade.*|unknown|none|pcb|board)", n):
            prods.append(n)
    return {"kicad": kicad, "products": prods[:20]}


def find_subboard_project(step_path: Path, proj_dir: Path, exclude: Path | None = None) -> Path | None:
    """Find the antenna's own KiCad board for a 3D model.

    1. a .kicad_pcb with the same name as the STEP file (STEP folder, project and up to
       two parent folders, three levels deep),
    2. a .kicad_pcb named like the board KiCad wrote into the STEP header (PRODUCT name),
    3. otherwise the board whose name shares the most tokens with the STEP name (or that board
       name), including its part number (``TI_DN038_short.step`` -> ``TI_DN038_Vertical_ShortSolder.kicad_pcb``).
    """
    stem = step_path.stem
    roots = [step_path.parent, proj_dir, proj_dir.parent, proj_dir.parent.parent]
    pats = ["{}.kicad_pcb", "*/{}.kicad_pcb", "*/*/{}.kicad_pcb", "*/*/*/{}.kicad_pcb"]
    seen, cands = set(), []
    ex = Path(exclude).resolve() if exclude else None
    names = [stem]
    if step_path.exists():  # 3. the board name KiCad wrote into the STEP header
        names += [n for n in step_info(step_path)["products"] if n != stem and "/" not in n and "\\" not in n]
    for r in roots:
        if not r.exists():
            continue
        for nm in names:
            for pat in pats:
                for p in r.glob(pat.format(nm)):
                    if p.resolve() != ex and "-backups" not in str(p):
                        return p
    for r in roots:
        if not r.exists():
            continue
        for pat in pats:
            for p in r.glob(pat.format("*")):
                rp = p.resolve()
                if rp in seen or rp == ex or "-backups" in str(p):
                    continue
                seen.add(rp)
                sc = max(_name_score(n, p.stem) for n in names)
                if sc >= 2:
                    cands.append((sc, -len(p.parts), p))
    if cands:
        cands.sort(key=lambda c: (c[0], c[1]), reverse=True)
        return cands[0][2]
    return None


def _ref_layer(board: Board) -> str:
    """Copper layer right below the top layer (In1.Cu on 4 layers, B.Cu on 2 layers)."""
    cu = [l.name for l in board.stackup.copper]
    return cu[1] if len(cu) > 1 else "In1.Cu"


def set_band(cfg: dict, ranges) -> dict:
    """Write the operating band (MHz ranges) into a setup: sweep, far field / markers, point count and
    the Q reference frequency, in the current values and in the setup's automatic values (so the mesh
    presets keep them). Antenna and RF chain setups of one band get the same sweep."""
    from .bands import derive
    d = derive(ranges)
    cfg["band"] = d["ranges_mhz"]
    cfg["f_q"] = d["f_q"]
    targets = [cfg] + ([cfg["_auto"]] if isinstance(cfg.get("_auto"), dict) else [])
    if cfg.get("type") == "antenna":
        for t in targets:
            t.setdefault("settings", {}).update(d["antenna"])
    else:
        c = d["circuit"]
        for t in targets:
            m = t.setdefault("model", {})
            m["f_min"], m["f_max"] = c["f_min"], c["f_max"]
        cfg["points"], cfg["marks_hz"] = c["points"], c["marks_hz"]
    return cfg


def init_antenna_config(board: Board, antenna_nets: list[str], feed: str, name: str = "antenna",
                        board_rel: str | None = None, f0: float = 868e6, subboards=None, step_parts=None,
                        ground_mode: str = "auto", band=None) -> dict:
    cfg = {
        "type": "antenna",
        "name": name,
        "board": board_rel or str(board.path),
        "output": "results",
        "antenna_nets": antenna_nets,
        "feed": {"ref": feed.split(".")[0], "pad": feed.split(".", 1)[1], "ground": ground_mode,
                 "ref_layer": _ref_layer(board)},
        "subboards": subboards or [],
        "step_parts": step_parts or [],
        "settings": {"f_min": round(f0 * 0.6), "f_max": round(f0 * 1.5), "f_points": 201,
                     "f_farfield": [f0 * 0.98, f0, f0 * 1.02], "f_loss": f0,
                     "max_antenna": 0.4, "max_board": 2.0, "min_cell": 0.08},
        "solver": {"engine": "auto", "threads": 0},
    }
    return set_band(cfg, band) if band else cfg


def trace_feed(board: Board, points: list[tuple], net: str, feed_pad: str | None = None, offset: float = 0.0,
               gap: float | None = None, exclude: tuple = ()) -> dict:
    """Feed point on an antenna trace segment (``points``: the segment's two ends in KiCad mm, as the
    PCB editor's selection gives them). The feed sits where the segment leaves the last matching pad
    (``feed_pad`` "REF.PAD", else the nearest pad of ``net`` of another part) plus half the port gap and
    ``offset`` mm. Returns {x, y, layer, net, dir: [ux, uy] towards the antenna, width, gap, offset}."""
    from shapely.geometry import LineString, Point
    tr = None
    for t in board.tracks:
        if t.net != net or len(t.points) < 2:
            continue
        a, b = t.points[0], t.points[-1]
        for p0, p1 in ((a, b), (b, a)):
            if (abs(p0[0] - points[0][0]) < 1e-3 and abs(p0[1] - points[0][1]) < 1e-3
                    and abs(p1[0] - points[1][0]) < 1e-3 and abs(p1[1] - points[1][1]) < 1e-3):
                tr = t
    if tr is None:
        raise ValueError(f"The selected segment is not a trace of the antenna net {net}. Select one segment of the "
                         f"antenna trace after the matching network.")
    pads = []
    if feed_pad and "." in feed_pad:
        r, n = feed_pad.split(".", 1)
        try:
            pads = [board.footprint(r).pad(n)]
        except KeyError:
            pads = []
    if not pads:
        pads = [pd for f in board.footprints if f.ref not in exclude for pd in f.pads if pd.net == net]
    a, b = np.array(tr.points[0], float), np.array(tr.points[-1], float)
    polys = [pd.polygon() for pd in pads]
    da = min(pg.distance(Point(*a)) for pg in polys) if polys else 0.0
    db = min(pg.distance(Point(*b)) for pg in polys) if polys else 0.0
    p0, p1 = (a, b) if da <= db else (b, a)  # p0: end at the matching pad
    seg = LineString([tuple(p0), tuple(p1)])
    u = (p1 - p0) / max(seg.length, 1e-9)
    g = gap or round(max(0.2, min(0.5, tr.width)), 3)
    near = [pd.polygon() for f in board.footprints if f.ref not in exclude for pd in f.pads
            if pd.net == net and pd.on_layer(tr.layer) and pd.polygon().distance(Point(*p0)) < tr.width]
    pad_u = unary_union(near) if near else None  # every pad the trace starts in (the last matching pad)
    after = None
    for f in board.footprints:
        if f.ref in exclude:
            continue
        for pd in f.pads:
            if pd.net == net and pd.on_layer(tr.layer) and pd.polygon().distance(Point(*p0)) < tr.width:
                if after is None or pd.polygon().distance(Point(*p0)) < after[1]:
                    after = (f"{f.ref}.{pd.number}", pd.polygon().distance(Point(*p0)))
    t_exit = 0.0
    if pad_u is not None and not pad_u.is_empty:  # where the trace leaves the pad copper
        for t in np.arange(0.0, seg.length, 0.01):
            if not pad_u.buffer(1e-3).contains(Point(*(p0 + u * t))):
                t_exit = t
                break
    t = min(t_exit + g / 2 + 0.05 + offset, max(seg.length - g / 2 - 0.05, g / 2))
    q = p0 + u * t
    return {"x": round(float(q[0]), 4), "y": round(float(q[1]), 4), "layer": tr.layer, "net": net,
            "dir": [round(float(u[0]), 6), round(float(u[1]), 6)], "width": tr.width, "gap": g,
            "offset": offset, "segment": [list(map(float, p0)), list(map(float, p1))],
            "after": after[0] if after else feed_pad}


def subboard_step(main: Board, sd: dict, base: Path) -> Path | None:
    """The STEP the footprint shows the antenna board with (sd["step"] or the footprint's 3D model)."""
    if sd.get("step"):
        p = Path(sd["step"])
        p = p if p.is_absolute() else (base / p)
        return p if p.exists() else None
    try:
        fp = main.footprint(sd["footprint"])
    except KeyError:
        return None
    for m in fp.models:
        if m.get("hide"):
            continue
        p = _resolve_model_path(m["path"], base.parent)
        if not p.is_absolute():
            p = base.parent / p
        if p.suffix.lower() in (".step", ".stp") and p.exists():
            return p
    return None


def place_subboard(main: Board, sd: dict, base: Path, progress=print):
    """(sub-board, Placement, info) of a soldered-in antenna board.

    Automatic placement: the footprint's 3D model entry, with every plausible KiCad convention;
    the footprint's STEP (the antenna board's own export) fixes where the board sits in the model
    frame, the footprint pads fix the rest. Then the user's correction ``adjust``."""
    from .geom3d import adjust, fit_subboard, manual_placement
    bpath = Path(sd["board"])
    sb = Board(bpath if bpath.is_absolute() else base / bpath)
    pl_cfg = sd.get("placement", "auto")
    info = {"board": sb.path.name, "step": None}
    if pl_cfg == "auto":
        step = subboard_step(main, sd, base)
        pts = None
        if step is not None:
            try:
                from .cadview import step_mesh
                m = step_mesh(step, base / "results" / "enclosure_cache")
                pts = np.vstack([V for V, _T in m["faces"].values()] + [e for e in m["edges"]])
                info["step"] = str(step)
            except Exception as e:  # noqa: BLE001 - fall back to the pads only
                progress(f"antenna board: STEP {step.name} not readable ({e}) - placement from the pads only")
        pl, ranking = fit_subboard(main, sd["footprint"], sb, step_pts=pts)
        msg = f"antenna board {sb.path.name}: {pl.convention}, pad misalignment {pl.residual:.2f} mm"
        if pl.step_residual is not None:
            msg += f", matches its STEP {Path(info['step']).name} within {pl.step_residual:.2f} mm"
        elif info["step"]:
            msg += f" (its STEP {Path(info['step']).name} does not show this board - placement from the pads only)"
        progress(msg)
        if pl.residual > 1.0:
            progress("WARNING: antenna board does not land on the footprint pads - correct it on the Casing & 3D page")
    else:
        fp = main.footprint(sd["footprint"])
        pl = manual_placement(fp.x, fp.y, pl_cfg.get("rotate", (90, 0, 0)), pl_cfg.get("offset", (0, 0, 0)),
                              pl_cfg.get("origin", (0, 0)), fp.angle + pl_cfg.get("angle", 0.0))
    if sd.get("adjust"):
        pl = adjust(pl, sb, sd["adjust"])
        progress(f"antenna board {sb.path.name}: corrected by hand {sd['adjust']}")
    info.update(convention=pl.convention, residual=pl.residual, step_residual=pl.step_residual)
    return sb, pl, info


def subboard_scene(rfsim_dir: Path, progress=print) -> tuple[list[dict], list[dict]]:
    """3D view of the soldered-in antenna boards of a project's antenna setup: each board as
    simulated (placed, with its copper) and its STEP where KiCad shows it (see-through, blue
    edges) - if both coincide, the placement is right. Returns (traces, infos)."""
    from .cadview import board_traces, mesh_traces, step_mesh
    rfsim_dir = Path(rfsim_dir)
    p = rfsim_dir / "antenna.json"
    if not p.exists():
        return [], []
    cfg = json.loads(p.read_text())
    if not cfg.get("subboards"):
        return [], []
    main = Board(rfsim_dir / cfg["board"])
    tr, infos = [], []
    for i, sd in enumerate(cfg["subboards"]):
        try:
            sb, pl, info = place_subboard(main, sd, rfsim_dir, progress)
        except Exception as e:  # noqa: BLE001
            infos.append({"error": str(e), "footprint": sd.get("footprint")})
            continue
        info["footprint"] = sd["footprint"]
        info["adjust"] = sd.get("adjust") or {}
        info["input_pad"] = sd.get("input_pad")
        infos.append(info)
        for t in board_traces(sb, pl, name=f"antenna board {sb.path.stem}"):
            t["legendgroup"] = "antenna"
            tr.append(t)
        if info.get("step") and pl.model_R is not None:
            R, t0 = pl.model_R, pl.model_t
            for t in mesh_traces(step_mesh(Path(info["step"]), rfsim_dir / "results" / "enclosure_cache"),
                                 lambda P, R=R, t0=t0: np.asarray(P) @ R.T + t0, opacity=0.25,
                                 name=f"{sd['footprint']} 3D model as KiCad shows it", edge_color="#2a6fdb"):
                t["legendgroup"] = "kicad3d"
                tr.append(t)
    return tr, infos


def _to3d(axis: int, elev: float, u: float, v: float) -> tuple[float, float, float]:
    p = [0.0, 0.0, 0.0]
    p[axis], p[(axis + 1) % 3], p[(axis + 2) % 3] = elev, u, v
    return tuple(p)


def model_view(rfsim_dir: Path, progress=print, mesh_lines: bool = True) -> tuple[list[dict], str]:
    """The antenna model as the solver gets it (no casing - the casing page draws that): dielectric
    slabs, the copper sheets after merging (antenna copper orange, board copper bronze), solder joints,
    the feed port (red) and the mesh lines on the top copper and on standing antenna boards.
    Returns (plotly traces, one-line summary)."""
    from .fields import mesh3d, triangulate
    rfsim_dir = Path(rfsim_dir)
    cfg = json.loads((rfsim_dir / "antenna.json").read_text())
    cfg = dict(cfg, use_enclosure=False)
    m = build_antenna_model(cfg, rfsim_dir, progress=progress,
                            workdir=rfsim_dir / cfg.get("output", "rfsim") / cfg["name"])
    tr = []
    diel = []
    for sl in m.slabs:  # extruded outline along its normal
        a = sl["axis"]
        e0, e1 = sl["elev"], sl["elev"] + sl["len"]
        for t in triangulate(sl["poly"]):
            diel.append([_to3d(a, e1, *q) for q in t])
            diel.append([_to3d(a, e0, *q) for q in t])
        c = list(sl["poly"].exterior.coords)
        for (ua, va), (ub, vb) in zip(c, c[1:]):
            diel.append([_to3d(a, e0, ua, va), _to3d(a, e0, ub, vb), _to3d(a, e1, ub, vb)])
            diel.append([_to3d(a, e0, ua, va), _to3d(a, e1, ub, vb), _to3d(a, e1, ua, va)])
    if diel:
        tr.append(mesh3d(diel, "#2f6b3a", "dielectric (as simulated)", 0.35))
    ant, brd = [], []
    for sh in m.sheets:
        a = sh["axis"]
        off = 0.012 if a == 2 else 0.0  # just above the slab face, no z-fighting
        tris = [[_to3d(a, sh["elev"] + off, *q) for q in t] for t in triangulate(sh["poly"])]
        (ant if sh.get("antenna") else brd).extend(tris)
    if brd:
        tr.append(mesh3d(brd, "#b08d3c", "board copper (as simulated, merged)", 1.0))
    if ant:
        tr.append(mesh3d(ant, "#d0661c", "antenna copper (as simulated)", 1.0))
    from .enclosure import _box_tris
    sold = [t for _n, lo, hi in m.boxes for t in _box_tris(lo, hi)]
    if sold:
        tr.append(mesh3d(sold, "#c9ccd1", "solder joints", 1.0))
    st, sp = np.array(m.port["start"], float), np.array(m.port["stop"], float)
    lo, hi = np.minimum(st, sp), np.maximum(st, sp)
    lo, hi = lo - (hi - lo < 1e-6) * 0.05, hi + (hi - lo < 1e-6) * 0.05
    tr.append(mesh3d(_box_tris(lo, hi), "#e0322b", "feed port", 1.0))
    if mesh_lines:  # mesh lines where the antenna is: the top copper and each standing antenna board
        L = [np.asarray(x) for x in m.lines]
        boxes = [(np.asarray(z[0]), np.asarray(z[1])) for z in m.zones]
        zlo = np.min([b[0] for b in boxes], 0) - 2 if boxes else np.array([L[0][0], L[1][0], L[2][0]])
        zhi = np.max([b[1] for b in boxes], 0) + 2 if boxes else np.array([L[0][-1], L[1][-1], L[2][-1]])
        planes = [(2, 0.02)] + [(fp["n"], fp["e"]) for fp in m.sub_field_planes(offset=0.0)]
        xs, ys, zs = [], [], []
        for n, e in planes:
            a1, a2 = (n + 1) % 3, (n + 2) % 3
            for ax, other in ((a1, a2), (a2, a1)):
                for v in L[ax][(L[ax] >= zlo[ax]) & (L[ax] <= zhi[ax])]:
                    for w in (zlo[other], zhi[other]):
                        p = [0.0, 0.0, 0.0]
                        p[n], p[ax], p[other] = e, v, w
                        xs.append(p[0]), ys.append(p[1]), zs.append(p[2])
                    xs.append(None), ys.append(None), zs.append(None)
        tr.append({"type": "scatter3d", "mode": "lines", "x": xs, "y": ys, "z": zs, "name": "mesh lines",
                   "line": {"color": "rgba(30,60,140,0.35)", "width": 1}, "hoverinfo": "skip"})
    for t in tr:
        t.setdefault("legendgroup", "model")
    d = [float(np.min(np.diff(x))) for x in m.lines]
    note = (f"simulation model: {m.n_cells/1e6:.2f} M cells, smallest cell {min(d):.3f} mm; mesh lines drawn on the "
            f"top copper and on standing antenna boards; red = feed port")
    probs = m.mesh_problems()
    if probs:
        note += " - " + "; ".join(probs)
    return tr, note


def save_subboard_adjust(rfsim_dir: Path, index: int, adjust: dict | None):
    p = Path(rfsim_dir) / "antenna.json"
    cfg = json.loads(p.read_text())
    sd = cfg["subboards"][index]
    if adjust:
        sd["adjust"] = adjust
    else:
        sd.pop("adjust", None)
    p.write_text(json.dumps(cfg, indent=2))


# ---------------------------------------------------------------------------
# antenna model cache: building the model takes 4-15 s on a real board (copper merge, feed port,
# mesh); Setup, the runtime estimate, the mesh inspector, the 3D view and the run all need it
# ---------------------------------------------------------------------------
_CODE_FILES = ("antenna.py", "pipeline.py", "enclosure.py", "geom3d.py", "board.py", "mesh.py", "sexpr.py",
               "openems_export.py", "synth.py")
_CODE_HASH: str | None = None


def _code_hash() -> str:
    global _CODE_HASH
    if _CODE_HASH is None:
        h = hashlib.sha256()
        for f in _CODE_FILES:
            try:
                h.update((Path(__file__).parent / f).read_bytes())
            except OSError:
                pass
        _CODE_HASH = h.hexdigest()[:16]
    return _CODE_HASH


def model_cache_dir() -> Path | None:
    """Local cache folder (never the project: a pickle from a shared project would run code)."""
    import os
    if os.environ.get("RFSIM_NO_CACHE"):
        return None
    d = os.environ.get("RFSIM_CACHE_DIR")
    if d:
        return Path(d)
    root = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".cache")
    return Path(root) / "kicad-rfsim" / "model_cache"


def _stamp(p: Path):
    try:
        st = Path(p).stat()
        return [str(p), st.st_size, st.st_mtime_ns]
    except OSError:
        return [str(p), -1, -1]


def _model_deps(model, cfg: dict, base: Path) -> list[Path]:
    deps = [Path(base) / "enclosure.json"] + list_configs(base)  # RF chain setups give the kept RF nets
    for sb in model.subs:
        deps.append(Path(sb.board.path))
    for i, sd in enumerate(cfg.get("subboards", [])):
        st = subboard_step(model.main, sd, base)
        if st:
            deps.append(st)
    deps += [Path(mp.stl) for mp in model.parts]
    for bd in model.bodies:
        if bd.get("stl"):
            deps.append(Path(bd["stl"]))
    try:
        from . import enclosure
        deps += [enclosure.path_of(b, base) for b in enclosure.load(base) if b.enabled]
    except Exception:  # noqa: BLE001
        pass
    return deps


def build_antenna_model(cfg: dict, base: Path, board_path: Path | None = None, progress=print,
                        workdir: Path | None = None, cache: bool = True):
    """Antenna model of a setup; taken from the local cache when board, setup, casing, antenna
    board files and program version are unchanged."""
    import pickle
    base = Path(base)
    bp = Path(board_path) if board_path else (base / cfg["board"])
    cdir = model_cache_dir() if cache else None
    key = None
    if cdir is not None:
        try:
            h = hashlib.sha256()
            h.update(_code_hash().encode())
            h.update(json.dumps(cfg, sort_keys=True, default=str).encode())
            h.update(str(base.resolve()).encode())
            h.update(str(Path(workdir).resolve() if workdir else "").encode())
            h.update(bp.read_bytes())
            key = h.hexdigest()[:24]
            f = cdir / f"{key}.pkl"
            if f.exists():
                deps, model = pickle.loads(f.read_bytes())
                if all(_stamp(Path(d[0])) == d for d in deps):
                    progress("antenna model unchanged - taken from the cache")
                    return model
        except Exception:  # noqa: BLE001 - a broken cache entry is rebuilt
            key = key
    model = _build_antenna_model(cfg, base, board_path, progress, workdir)
    if cdir is not None and key:
        try:
            cdir.mkdir(parents=True, exist_ok=True)
            deps = [_stamp(d) for d in _model_deps(model, cfg, base)]
            tmp = cdir / f"{key}.tmp"
            tmp.write_bytes(pickle.dumps((deps, model), protocol=pickle.HIGHEST_PROTOCOL))
            tmp.replace(cdir / f"{key}.pkl")
            old = sorted(cdir.glob("*.pkl"), key=lambda q: q.stat().st_mtime, reverse=True)
            for q in old[40:]:  # keep the cache small
                q.unlink(missing_ok=True)
        except Exception:  # noqa: BLE001 - the cache is only a speed-up
            pass
    return model


def _build_antenna_model(cfg: dict, base: Path, board_path: Path | None = None, progress=print,
                         workdir: Path | None = None):
    from .antenna import AntennaModel, AntennaSettings, Feed, MetalPart, SubBoard, step_to_stl, transform_stl

    bp = Path(board_path) if board_path else (base / cfg["board"])
    main = Board(bp)
    subs = []
    for i, sd in enumerate(cfg.get("subboards", [])):
        try:
            sb, pl, _info = place_subboard(main, sd, base, progress)
        except FileNotFoundError as e:
            raise FileNotFoundError(f"Antenna board of {sd.get('footprint', '?')} not found: "
                                    f"{e.filename or sd.get('board', '')}. Select its .kicad_pcb again on the Setup "
                                    f"page (Antenna: Antenna board).") from None
        subs.append(SubBoard(sb, pl, f"sub{i}", solder_to=sd["footprint"], input_pad=sd.get("input_pad") or None))
    parts = []
    for i, sp in enumerate(cfg.get("step_parts", [])):
        fp = main.footprint(sp["footprint"])
        src = Path(sp["file"]) if sp.get("file") else _resolve_model_path(fp.models[0]["path"], base.parent)
        if not src.is_absolute():
            src = base / src
        wd = workdir or (base / cfg.get("output", "rfsim") / cfg["name"])
        wd.mkdir(parents=True, exist_ok=True)
        if not src.exists():
            raise FileNotFoundError(f"3D model of the antenna part {sp['footprint']} not found: {src}. "
                                    f"Select the file again on the Casing & 3D page.")
        stl = src if src.suffix.lower() == ".stl" else step_to_stl(src, wd / f"part{i}_local.stl", sp.get("mesh", 0.5))
        from .antenna import read_stl
        from .geom3d import fit_step_part
        pl, _ = fit_step_part(main, sp["footprint"], read_stl(stl).reshape(-1, 3))
        progress(f"STEP part {src.name}: {pl.convention}, pad distance {pl.residual:.2f} mm")
        parts.append(MetalPart(transform_stl(stl, wd / f"part{i}.stl", pl), f"part{i}"))
    fd = cfg["feed"]
    check_feed(main, fd)
    from .solver import check_keys
    st = check_keys(AntennaSettings, cfg.get("settings", {}), "settings")
    bodies = []
    if cfg.get("use_enclosure", True):  # casing parts of the project (Enclosure page, rfsim/enclosure.json)
        from . import enclosure
        cb = [b for b in enclosure.load(base) if b.enabled]
        if cb:
            wd = workdir or (base / cfg.get("output", "rfsim") / cfg["name"])
            bodies = enclosure.prepare(cb, base, wd)
            progress(f"casing: {', '.join(b.name + ' (' + b.material + ')' for b in cb)}")
    rf_nets = cfg["rf_nets"] if "rf_nets" in cfg else rf_chain_nets(main, base)
    if fd.get("trace"):  # fed on the antenna trace: the RF chain behind the feed becomes ground (no RF zones)
        st.rf_path_mesh = False
    model = AntennaModel(main, Feed(fd["ref"], fd["pad"], fd.get("ground", "auto"), fd.get("ref_layer", "In1.Cu"),
                                    trace=fd.get("trace")),
                         cfg.get("antenna_nets", []), st, subs, parts,
                         lumped=lumped_specs(main, cfg.get("lumped", []), cfg.get("lumped_values"), q_ref(cfg)),
                         zones=list(cfg.get("zones", [])) + (rf_chain_zones(main, base, st, rf_nets) if st.rf_path_mesh else []),
                         bodies=bodies, rf_nets=rf_nets)
    return model


def rf_chain_nets(board: Board, base: Path) -> list[str]:
    """Signal nets of the project's RF chain setups (their port and fixed-part pads): the antenna model
    keeps this copper and its clearances exactly; the rest of the board becomes plain planes."""
    nets: set[str] = set()
    gnd = set(Board._GND_NAMES)
    for c in list_configs(base):
        try:
            d = json.loads(c.read_text())
        except Exception:  # noqa: BLE001
            continue
        if d.get("type") == "antenna":
            continue
        refs = [p.split(".", 1) for p in d.get("ports", []) if "." in p]
        for ref, pad in refs:
            try:
                n = board.footprint(ref).pad(pad).net
            except KeyError:
                continue
            if n and n not in gnd:
                nets.add(n)
        for ref in d.get("lumped", []):
            try:
                nets |= {pd.net for pd in board.footprint(ref).pads if pd.net and pd.net not in gnd}
            except KeyError:
                pass
    return sorted(nets)


def rf_chain_zones(board: Board, base: Path, st, rf_nets: list[str]) -> list[tuple]:
    """Fine-mesh zones of the antenna model over the RF chain setups' regions (x0, y0, x1, y1, cell):
    without them the RF traces (0.2-0.4 mm) fall through the 2 mm board mesh. Cell = narrowest RF
    trace / 2, at least 1.25 x min_cell and at most max_antenna (setting rf_cell overrides)."""
    widths = [t.width for t in board.tracks if t.net in rf_nets and t.width > 0]
    cell = st.rf_cell or min(st.max_antenna, max(1.25 * st.min_cell, (min(widths) if widths else 0.4) / 1.5))
    out = []
    for c in list_configs(base):
        try:
            d = json.loads(c.read_text())
        except Exception:  # noqa: BLE001
            continue
        if d.get("type") == "antenna" or len(d.get("region", [])) != 4:
            continue
        # only where RF copper is: the RF traces' bounding box inside the region (+0.5 mm)
        x0, y0, x1, y1 = (float(v) for v in d["region"])
        from shapely.geometry import box as _box
        reg = _box(x0, y0, x1, y1)
        cu = [g for lay in [l.name for l in board.stackup.copper] for n, g in board.copper(lay)
              if n in rf_nets and g.intersects(reg)]
        if cu:
            from shapely.ops import unary_union
            bx0, by0, bx1, by1 = unary_union(cu).intersection(reg).buffer(0.5).bounds
            out.append((bx0, by0, bx1, by1, round(cell, 4)))
    return out


def check_feed(board, fd: dict) -> None:
    """Clear message when the antenna feed of a setup is not on the board (renamed part, other board)."""
    ref, pad = fd.get("ref", ""), str(fd.get("pad", ""))
    tr = fd.get("trace")
    if tr:
        from shapely.geometry import Point
        cu = [g for n, g in board.copper(tr.get("layer", "F.Cu"), tr.get("net"))]
        if not cu or not any(g.buffer(1e-3).contains(Point(tr["x"], tr["y"])) for g in cu):
            raise ValueError(f"The antenna feed point ({tr['x']:.2f}, {tr['y']:.2f}) mm is no longer on the trace of "
                             f"{tr.get('net')} - the layout changed. Select the antenna trace segment again and "
                             f"create the setup again.")
        return
    try:
        fp = board.footprint(ref)
    except KeyError:
        raise ValueError(f"The antenna feed {ref}.{pad} is not on this board: there is no part {ref}. "
                         f"The part was renamed or the setup belongs to another board. "
                         f"Create the setup again on the Setup page.") from None
    if pad not in {p.number for p in fp.pads}:
        pads = sorted({p.number for p in fp.pads if p.number}, key=lambda n: (len(n), n))
        raise ValueError(f"The antenna feed {ref}.{pad} does not exist: {ref} has the pads {', '.join(pads) or 'none'}. "
                         f"Set the feed pad on the Setup page or create the setup again.")


def simulate_antenna(config_path, board_path=None, threads: int = 0, progress=print, force: bool = False,
                     openems_bin: str | None = None, fields: bool = False, overlay: bool = False,
                     cfg_override: dict | None = None, out_dir: Path | None = None) -> dict:
    from .antenna import load_result, run_antenna
    from .antenna_report import write_report

    config_path = Path(config_path)
    cfg = cfg_override if cfg_override is not None else json.loads(config_path.read_text())
    base = config_path.parent
    out = Path(out_dir) if out_dir else base / cfg.get("output", "rfsim") / cfg["name"]
    out.mkdir(parents=True, exist_ok=True)
    progress("building antenna model")
    model = build_antenna_model(cfg, base, board_path, progress, out)
    (out / "model.txt").write_text(model.describe())
    progress(model.describe())
    tmp = model.write_xml(out / "model_check.xml")
    gh = hashlib.sha256(tmp.read_bytes()).hexdigest()[:16]
    hfile = out / "antenna_hash.txt"
    rp = out / "antenna_result.npz"
    from .solver import RunRecord, load_record, mesh_stats, settings_table, solver_options
    so = solver_options(cfg, threads)
    er_max = max([l.epsilon_r for l in model.main.stackup.layers if l.epsilon_r] or [4.5])
    rec = RunRecord("antenna", cfg["name"], settings_table({"settings": model.s}), dataclasses.asdict(so),
                    model.describe(), mesh_stats(model.lines, model.s.f_max, er_max))
    if fields and not (out / "wave.html").exists():
        force = True
    if overlay:
        from .overlay import read_meta
        if not read_meta(out / "antenna_run"):
            force = True
    if rp.exists() and hfile.exists() and hfile.read_text() == gh and not force:
        progress("antenna geometry unchanged - reusing result")
        res = load_result(rp)
        reused = True
        rec.reused, rec.runs = True, (load_record(out) or {}).get("runs", [])
    else:
        t0 = time.time()
        stats = []
        from .solver import useful_threads
        res = run_antenna(model, out, threads=so.threads or useful_threads(model.n_cells), openems_bin=openems_bin, log=progress,
                          engine=so.engine, stats=stats, label=cfg["name"],
                          fields={"freqs": list(model.s.f_farfield)[:3], "oversampling": 4} if fields else None)
        if fields:
            from .fields import TD_NAME, read_fields, write_wave_view
            from .overlay import write_meta
            F = read_fields(out / "antenna_run")
            if F is not None:
                outl = [(sh["name"], list(sh["poly"].exterior.coords)) for sh in model.sheets
                        if sh["axis"] == 2 and sh.get("antenna")]
                ol = model.main.outline()
                pic = _picture(model.main, progress)
                write_meta(out / "antenna_run", R=float(model.port["R"]), f_min=float(model.s.f_min),
                           f_max=float(model.s.f_max), td_name=TD_NAME,
                           outlines=[(n, [(x, -y) for x, y in pts]) for n, pts in outl],
                           board=[(x, y) for x, y in ol.exterior.coords] if ol is not None else [],
                           pic=pic)
                if ol is not None:
                    outl.append(("outline", [(x, -y) for x, y in ol.exterior.coords]))
                scene, pz = _scene_antenna(model)
                subs = _sub_wave_views(model, out, cfg, scene, progress)
                write_wave_view(F, outl, out / "wave.html", f"Wave view – {cfg['name']}",
                                f"antenna fed at {model.feed.ref}.{model.feed.pad}; E-field 0.5 mm above the board",
                                y_up=True, show="mag", scene=scene, plane_z=pz, plane_opacity=0.6,
                                pic=pic, links=[(f"{lab} →", fn) for lab, fn in subs])
                progress(f"wave view: {out / 'wave.html'}")
        _compact_runs(out, progress)
        for st in stats:
            rec.add(st)
        hfile.write_text(gh)
        progress(f"antenna done in {(time.time()-t0)/60:.1f} min")
        reused = False
    from .checks import antenna_checks, geometry_check
    rec.checks = antenna_checks(res) + geometry_check(
        [out / "antenna_run" / "openEMS.log"], lambda name: name.count(":") >= 2 and not name.endswith(":board"))
    for ch in rec.checks:
        if not ch["ok"]:
            progress(f"WARNING plausibility: {ch['name']} {ch['value']} (expected {ch['limit']})")
    import skrf as rf
    ntw = rf.Network(frequency=rf.Frequency.from_f(res.f, unit="hz"), s=res.s11.reshape(-1, 1, 1), z0=50)
    ntw.write_touchstone(str(out / f"{cfg['name']}_feed"))
    sheets = []
    try:  # static pattern sheets; optional
        from .pattern_plot import write_pattern_sheets
        sheets = write_pattern_sheets(res, out, title=cfg["name"])
    except Exception as e:  # noqa: BLE001
        progress(f"pattern sheets skipped: {e}")
    html = write_report(model, res, out / "antenna_report.html", f"Antenna – {cfg['name']}", sheets=sheets,
                        band=cfg.get("band"))
    progress(f"report: {html}")
    info = rec.save(out)
    return {"out": str(out), "viewer": str(html), "reused": reused, "info": str(info)}


def broken_configs(rfsim_dir: Path) -> list[tuple[Path, str]]:
    """JSON files in the rfsim folder that cannot be read (the setup would silently disappear otherwise)."""
    out = []
    for c in sorted(Path(rfsim_dir).glob("*.json")):
        try:
            d = json.loads(c.read_text())
        except UnicodeDecodeError:
            out.append((c, "not a text file"))
            continue
        except ValueError as e:
            out.append((c, f"not valid JSON ({e})"))
            continue
        except OSError as e:
            out.append((c, f"cannot be read ({e})"))
            continue
        if not isinstance(d, dict):
            continue
        if d.get("type") == "antenna":
            miss = [k for k in ("name", "feed") if k not in d]
            if not miss and not isinstance(d["feed"], dict) or (not miss and not {"ref", "pad"} <= set(d["feed"])):
                miss = ["feed.ref / feed.pad"]
            if miss:
                out.append((c, f"antenna setup without {', '.join(miss)}"))
        elif "ports" in d and "region" in d and "name" not in d:
            out.append((c, "RF chain setup without name"))
    return out


def list_configs(rfsim_dir: Path) -> list[Path]:
    """Simulation configs in a project's rfsim folder (antenna first; other JSON files are skipped)."""
    ant, rest = [], []
    for c in sorted(Path(rfsim_dir).glob("*.json")):
        try:
            d = json.loads(c.read_text())
        except Exception:
            continue
        if not isinstance(d, dict) or "name" not in d:
            continue
        if d.get("type") == "antenna":
            if isinstance(d.get("feed"), dict) and {"ref", "pad"} <= set(d["feed"]):
                ant.append(c)
        elif "ports" in d and "region" in d:
            rest.append(c)
    return ant + rest


def simulate_all(rfsim_dir: Path, board_path=None, threads=0, progress=print, openems_bin=None,
                 only: list[str] | None = None, force: bool = False, fields: bool = False,
                 full_board: bool | str = False) -> list[dict]:
    """Antenna configs first (their Zin feeds the circuit viewers), then circuit configs.
    ``only``: config file names to run (default all). ``full_board``: True / "overlay" joins the
    RF path and antenna runs into one whole-board view (no extra run)."""
    overlay = full_board is True or full_board == "overlay"
    from .solver import check_cancel
    out = []
    for c in list_configs(rfsim_dir):
        if only is not None and c.name not in only:
            continue
        check_cancel()
        progress(f"=== {c.name} ===")
        out.append(simulate(c, board_path, threads, progress, force=force, openems_bin=openems_bin, fields=fields,
                            overlay=overlay))
    if overlay:
        progress("=== whole board (RF path + antenna) ===")
        r = overlay_board(rfsim_dir, progress)
        if r:
            out.append(r)
    return out


def detect_antennas(board: Board, nets: list[str], proj_dir: Path, ground: str = "GND") -> list[dict]:
    """Accepted antennas among ``nets`` (see antenna_detect: printed antennas are checked
    against the ground plane beneath; soldered-in ones are AE*/ANT* footprints with a 3D model).
    Returns dicts {kind, nets, feed, reason, subboard | step, ...}."""
    from .antenna_detect import antenna_candidates
    return [c for c in antenna_candidates(board, nets, proj_dir, ground) if c["accepted"]]


def _source_side(board: Board, f0, net0: str, stop: set[str], ground: str = "GND", max_hops: int = 8):
    """Follow the chain behind the outside part ``f0`` (away from ``net0`` and the selection) through
    passives and filters to the first IC. Returns (ic_ref, parts_crossed) or None (a connector,
    a part to ground only, or a dead end)."""
    if part_kind(f0) == "connector":
        return None
    by_net: dict[str, list] = {}
    for f in board.footprints:
        for n in f.nets:
            by_net.setdefault(n, []).append(f)
    seen_n = {net0, ground, ""}
    seen_p = set(stop) | {f0.ref}
    front = [n for n in f0.nets if n not in seen_n]
    for hop in range(1, max_hops + 1):
        nxt = []
        for n in front:
            if n in seen_n:
                continue
            seen_n.add(n)
            for f in by_net.get(n, []):
                if f.ref in seen_p or f.dnp:
                    continue
                seen_p.add(f.ref)
                k = part_kind(f)
                if k == "ic":
                    return f.ref, hop
                if k == "connector":
                    continue
                if k == "R":
                    v = parse_value(f.value)
                    if v is not None and v >= 10.0:
                        continue
                nxt += [m for m in f.nets if m not in seen_n]
        front = nxt
        if not front:
            break
    return None


def init_config_selection(board: Board, refs: list[str], name: str = "rf", margin: float | None = None,
                          antenna_feed: str | None = None, board_rel: str | None = None, ground: str = "GND",
                          band=None):
    """Small circuit setup from selected footprints (the parts you want to tune).

    * every non-ground pad of the selected parts becomes a port,
    * where the chain continues to a part that is not selected, that part's pad on
      the shared net becomes a port. The one that leads to the RF chip is the input port
      (external port 1); the others (a coax test connector, a second branch) stay ports that
      are left open in the tuning, so the region never cuts the copper between them,
    * unselected parts from a selected net to ground are fixed lumped parts of the EM model,
    * the antenna feed pad (if any) is external port 2,
    * the region is the bounding box of all these pads plus ``margin``.
    Returns (config, notes).
    """
    sel = [board.footprint(r) for r in refs]
    selset = set(refs)
    ports: list[str] = []
    for f in sel:
        for p in f.pads:
            if p.number and p.net and p.net != ground and p.on_layer("F.Cu"):
                ports.append(f"{f.ref}.{p.number}")
    sel_nets = {board.footprint(q.split(".")[0]).pad(q.split(".", 1)[1]).net for q in ports}
    notes = []
    inputs = []  # (footprint, pad) of unselected parts on a selected net that carry the chain on
    shunts = []  # unselected parts from a selected net to ground only: fixed parts of the EM model
    for net in sorted(sel_nets):
        if antenna_feed and board.footprint(antenna_feed.split(".")[0]).pad(antenna_feed.split(".", 1)[1]).net == net:
            continue
        for f in board.footprints:
            if f.ref in selset or f.dnp:
                continue
            for p in f.pads:
                if p.net == net and p.number and p.on_layer("F.Cu"):
                    other = {q.net for q in f.pads if q.number and q.net} - {net, ground}
                    if not other and part_kind(f) in ("C", "L", "R"):
                        if f not in shunts:
                            shunts.append(f)
                    else:
                        inputs.append((f, p))
    # input = the outside pad where the chain comes from: the one that leads to the RF chip.
    # A connector (coax test port, U.FL) is a side branch: it stays a port, open in the tuning.
    src = {f"{f.ref}.{p.number}": _source_side(board, f, p.net, selset, ground) for f, p in inputs}
    ext_in = None
    if inputs:
        a = (board.footprint(antenna_feed.split(".")[0]).pad(antenna_feed.split(".", 1)[1]) if antenna_feed else None)

        def rank(fp):
            ic = src[f"{fp[0].ref}.{fp[1].number}"]
            d = (fp[1].x - a.x) ** 2 + (fp[1].y - a.y) ** 2 if a is not None else 0.0
            return (ic is not None, part_kind(fp[0]) != "connector", -(ic[1] if ic else 0), d)
        f, p = max(inputs, key=rank)
        ext_in = f"{f.ref}.{p.number}"
        if len({(fp[0].ref) for fp in inputs}) > 1:
            notes.append("several unselected parts touch the selection: " +
                         ", ".join(sorted({f"{fp[0].ref}.{fp[1].number}" for fp in inputs})) + f"; input port = {ext_in}")
    ext_out = antenna_feed
    if not antenna_feed and inputs:
        # no antenna: a two-port between the two outside connections (e.g. a filter)
        others = [fp for fp in inputs if f"{fp[0].ref}.{fp[1].number}" != ext_in]
        if others:
            fi = board.footprint(ext_in.split(".")[0]).pad(ext_in.split(".", 1)[1])
            f2, p2 = max(others, key=lambda fp: (fp[1].x - fi.x) ** 2 + (fp[1].y - fi.y) ** 2)
            ext_out = f"{f2.ref}.{p2.number}"
            notes[:] = [f"two-port between {ext_in} and {ext_out} (unselected neighbours)"]
    # the other outside connections stay ports inside the region (open in the tuning), so the
    # region never cuts the copper that joins them
    side = []
    for f, p in inputs:
        q = f"{f.ref}.{p.number}"
        if q not in (ext_in, ext_out) and q not in ports and q not in side:
            side.append(q)
            notes.append(f"{q} ({f.value or part_kind(f)}) is a side branch of the selection: it is a port in the EM "
                         f"model and left open in the tuning" + (" (connector not plugged)" if part_kind(f) == "connector"
                                                                 else "") + ".")
    if ext_out and ext_out not in ports:
        ports.append(ext_out)
    if ext_in is None:
        ext_in = ports[0]
        notes.append(f"no connection to unselected parts found - input port = {ext_in}")
    ordered = [ext_in] + ([ext_out] if ext_out else []) + [p for p in ports + side if p not in (ext_in, ext_out)]
    xs, ys = [], []
    for q in ordered:
        p = board.footprint(q.split(".")[0]).pad(q.split(".", 1)[1])
        xs.append(p.x)
        ys.append(p.y)
    for f in shunts + [board.footprint(r) for r in selset]:
        # fixed shunt parts (lumped) and every pad of the selected parts - also the GND pad of a tuned
        # shunt part, whose path to the plane (pad, stub, via) belongs into the model
        for p in f.pads:
            if p.number:
                xs.append(p.x)
                ys.append(p.y)
    margin = auto_margin(board) if margin is None else margin
    region = [min(xs) - margin, min(ys) - margin, max(xs) + margin, max(ys) + margin]
    # parts inside the region that touch the RF nets but are not ports -> they would be missing
    from shapely.geometry import box as _box
    reg = _box(*region)
    lumped: list[str] = []
    rf_nets = sel_nets | {board.footprint(ext_in.split(".")[0]).pad(ext_in.split(".", 1)[1]).net}
    port_refs = {q.split(".")[0] for q in ordered}
    for f in board.footprints:
        if f.ref in selset or f.dnp or f.ref in port_refs:
            continue
        if any(p.net in rf_nets and reg.contains(_box(p.x, p.y, p.x, p.y).buffer(1e-3)) for p in f.pads):
            if lumped_specs(board, [f.ref]):
                lumped.append(f.ref)
                notes.append(f"{f.ref} ({f.value}) is in the region but not selected - it is part of the EM model "
                             f"with its value (fixed, not tunable). Select it to tune it.")
            else:
                notes.append(f"{f.ref} ({f.value or 'no value'}) is in the region but has no usable value or is DNP - "
                             f"treated as not mounted.")
    cfg = {
        "name": name, "board": board_rel or str(board.path), "output": "results", "scope": "selection",
        "selection": list(refs),
        "region": [round(v, 3) for v in region], "ports": ordered, "lumped": lumped,
        "external": [ext_in] + ([ext_out] if ext_out else []),
        "external_reason": ([f"input {ext_in}: unselected neighbour on a shared net"
                             + (f", leads to {src[ext_in][0]} (the RF chip side)" if src.get(ext_in) else
                                ", farthest from the antenna feed" if antenna_feed and len(inputs) > 1 else "")
                             if inputs else f"input {ext_in}: first port (no unselected neighbour found)"]
                            + ([f"output {ext_out}: antenna feed" if antenna_feed and ext_out == antenna_feed else
                                f"output {ext_out}: second unselected neighbour (two-port)"] if ext_out else [])),
        "ref_layer": _ref_layer(board), "points": 271,
        "model": {"f_min": 0.3e9, "f_max": 3.0e9, "truncate_at": _ref_layer(board)},
        "mesh": {"max_fine": 0.1, "min_cell": 0.04, "z_cells_per_dielectric": 3},
        "marks_hz": [868e6, 1736e6, 2604e6],
        "solver": {"engine": "auto", "threads": 0},
    }
    if antenna_feed:
        cfg["load_antenna"] = "antenna.json"
    if band:
        set_band(cfg, band)
    return cfg, notes
