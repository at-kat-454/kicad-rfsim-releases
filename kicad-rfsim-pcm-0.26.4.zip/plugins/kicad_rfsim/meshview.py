"""Mesh inspector: the FDTD model as openEMS gets it, before a run.

Reads the openEMS XML (grid lines, materials, metal, ports) and rasterises slices through the
model on the real mesh:

* cell faces in the slice plane coloured by material (dielectric, casing, air; the material of
  the higher permittivity of the two sides when the plane is a material boundary),
* metal as openEMS sees it: an edge of the mesh is metal when its midpoint lies in the copper
  (the same midpoint rule as the model checks), so staircased traces, gaps closed by the mesh
  and traces that fall apart are visible,
* ports and lumped parts, the far-field box, the exact copper outline of sheets in the plane.

The page (``write_mesh_view``) adds the mesh statistics (cells, smallest / largest cell and where,
neighbour ratio, cells per wavelength, timestep, memory) and a cell-size chart per axis.
"""
from __future__ import annotations

import html
import json
import math
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import shapely
from shapely.geometry import Polygon

C0 = 299_792_458.0
AX = "xyz"
# in-plane axes of a slice with normal n, drawn as (right, up)
PLANE = {2: (0, 1), 1: (0, 2), 0: (1, 2)}


# ---------------------------------------------------------------------------
# reading the XML
# ---------------------------------------------------------------------------
def _p(e, s=1.0):
    return np.array([float(e.get("X")), float(e.get("Y")), float(e.get("Z"))]) * s


def _poly(e, s):
    pts = [(float(v.get("X1")) * s, float(v.get("X2")) * s) for v in e.findall("Vertex")]
    g = Polygon(pts)
    return g if g.is_valid else g.buffer(0)


def parse(xml_path: Path) -> dict:
    """Grid (mm), properties and primitives of an openEMS XML file."""
    root = ET.parse(xml_path).getroot()
    fd = root.find("FDTD")
    grid = root.find("ContinuousStructure/RectilinearGrid")
    s = float(grid.get("DeltaUnit", "0.001")) / 1e-3  # to mm
    lines = [np.array(sorted(float(v) * s for v in grid.find(t).text.split(","))) for t in ("XLines", "YLines", "ZLines")]
    props = []
    for e in root.find("ContinuousStructure/Properties"):
        kind, name = e.tag, e.get("Name", "")
        eps = 1.0
        pe = e.find("Property")
        if pe is not None and pe.get("Epsilon"):
            eps = float(pe.get("Epsilon").split(",")[0])
        prims = []
        pr = e.find("Primitives")
        for q in (pr if pr is not None else []):
            prio = int(q.get("Priority", "0"))
            if q.tag == "Box":
                a, b = _p(q.find("P1"), s), _p(q.find("P2"), s)
                prims.append({"t": "box", "lo": np.minimum(a, b), "hi": np.maximum(a, b), "prio": prio})
            elif q.tag in ("Polygon", "LinPoly"):
                n = int(q.get("NormDir"))
                el = float(q.get("Elevation")) * s
                ln = float(q.get("Length", "0")) * s
                g = _poly(q, s)
                if g.is_empty:
                    continue
                prims.append({"t": "poly" if q.tag == "Polygon" else "lin", "n": n, "elev": min(el, el + ln),
                              "len": abs(ln), "g": g, "prio": prio})
            elif q.tag == "Cylinder":
                a, b = _p(q.find("P1"), s), _p(q.find("P2"), s)
                prims.append({"t": "cyl", "a": a, "b": b, "r": float(q.get("Radius")) * s, "prio": prio})
            elif q.tag == "PolyhedronReader":
                f = Path(q.get("FileName", ""))
                if f.exists():
                    from .antenna import read_stl
                    tri = read_stl(f).reshape(-1, 3, 3) * s
                    prims.append({"t": "stl", "tri": tri, "lo": tri.reshape(-1, 3).min(0),
                                  "hi": tri.reshape(-1, 3).max(0), "prio": prio, "file": f.name})
        props.append({"kind": kind, "name": name, "eps": eps, "prims": prims,
                      "R": e.get("R"), "C": e.get("C"), "L": e.get("L"), "dir": e.get("Direction")})
    bc = fd.find("BoundaryCond")
    model = {"lines": lines, "props": props, "timesteps": int(fd.get("NumberOfTimesteps", "0")),
            "end_criteria": float(fd.get("endCriteria", "1e-4")), "f_max": float(fd.get("f_max", "0") or 0),
            "boundary": dict(bc.attrib) if bc is not None else {}}
    model["materials"] = materials(model)
    return model


# ---------------------------------------------------------------------------
# point tests (vectorised)
# ---------------------------------------------------------------------------
def _snap(v, lines):
    return lines[int(np.argmin(np.abs(lines - v)))]


def _stl_inside(tri, P, axis_ray: int):
    """Points inside the closed surface: crossings of a ray along ``axis_ray`` (points share their
    two other coordinates in groups - one ray per group)."""
    p, q = [k for k in range(3) if k != axis_ray]
    out = np.zeros(len(P), bool)
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    det = (b[:, q] - c[:, q]) * (a[:, p] - c[:, p]) + (c[:, p] - b[:, p]) * (a[:, q] - c[:, q])
    ok = np.abs(det) > 1e-12
    keys = np.round(P[:, [p, q]], 7)
    uniq, inv = np.unique(keys, axis=0, return_inverse=True)
    inv = inv.reshape(-1)
    lo_p = np.minimum(np.minimum(a[:, p], b[:, p]), c[:, p])
    hi_p = np.maximum(np.maximum(a[:, p], b[:, p]), c[:, p])
    lo_q = np.minimum(np.minimum(a[:, q], b[:, q]), c[:, q])
    hi_q = np.maximum(np.maximum(a[:, q], b[:, q]), c[:, q])
    for gi, (x, y) in enumerate(uniq):
        x, y = x + 1.3e-6, y + 0.7e-6  # no ray through a triangle edge
        m = ok & (lo_p <= x) & (hi_p >= x) & (lo_q <= y) & (hi_q >= y)
        if not m.any():
            continue
        A, B, Cc, dm = a[m], b[m], c[m], det[m]
        l1 = ((B[:, q] - Cc[:, q]) * (x - Cc[:, p]) + (Cc[:, p] - B[:, p]) * (y - Cc[:, q])) / dm
        l2 = ((Cc[:, q] - A[:, q]) * (x - Cc[:, p]) + (A[:, p] - Cc[:, p]) * (y - Cc[:, q])) / dm
        l3 = 1 - l1 - l2
        hit = (l1 >= 0) & (l2 >= 0) & (l3 >= 0)
        if not hit.any():
            continue
        z = np.sort(l1[hit] * A[hit, axis_ray] + l2[hit] * B[hit, axis_ray] + l3[hit] * Cc[hit, axis_ray])
        sel = inv == gi
        out[sel] = (np.searchsorted(z, P[sel, axis_ray]) % 2) == 1
    return out


def _inside(pr: dict, P: np.ndarray, lines, ray_axis: int, tol: float) -> np.ndarray:
    """Points of P (N x 3, mm) inside a primitive as the mesh sees it: zero-thickness sheets and
    degenerate boxes lie on their nearest mesh line."""
    t = pr["t"]
    if t == "box":
        lo, hi = pr["lo"].copy(), pr["hi"].copy()
        m = np.ones(len(P), bool)
        for k in range(3):
            if hi[k] - lo[k] < 1e-9:
                v = _snap(lo[k], lines[k])
                m &= np.abs(P[:, k] - v) < tol
            else:
                m &= (P[:, k] >= lo[k] - 1e-9) & (P[:, k] <= hi[k] + 1e-9)
        return m
    if t in ("poly", "lin"):
        n = pr["n"]
        a1, a2 = (n + 1) % 3, (n + 2) % 3
        if t == "poly":
            m = np.abs(P[:, n] - _snap(pr["elev"], lines[n])) < tol
        else:
            m = (P[:, n] >= pr["elev"] - 1e-9) & (P[:, n] <= pr["elev"] + pr["len"] + 1e-9)
        if m.any():
            idx = np.nonzero(m)[0]
            m[idx] = shapely.contains_xy(pr["g"], P[idx, a1], P[idx, a2])
        return m
    if t == "cyl":
        a, b, r = pr["a"], pr["b"], pr["r"]
        d = b - a
        k = int(np.argmax(np.abs(d)))
        o = [j for j in range(3) if j != k]
        lo, hi = min(a[k], b[k]), max(a[k], b[k])
        return ((P[:, k] >= lo - 1e-9) & (P[:, k] <= hi + 1e-9)
                & ((P[:, o[0]] - a[o[0]]) ** 2 + (P[:, o[1]] - a[o[1]]) ** 2 <= r * r))
    if t == "stl":
        m = np.all((P >= pr["lo"] - 1e-9) & (P <= pr["hi"] + 1e-9), axis=1)
        if m.any():
            idx = np.nonzero(m)[0]
            m[idx] = _stl_inside(pr["tri"], P[idx], ray_axis)
        return m
    return np.zeros(len(P), bool)


def _touches(pr: dict, n: int, c: float, lines) -> bool:
    """Can the primitive reach the plane axis n = c? (cheap bounding test)"""
    t = pr["t"]
    if t == "box":
        lo, hi = pr["lo"][n], pr["hi"][n]
        if hi - lo < 1e-9:
            lo = hi = _snap(lo, lines[n])
        return lo - 1e-9 <= c <= hi + 1e-9
    if t in ("poly", "lin"):
        if pr["n"] == n:
            if t == "poly":
                return abs(_snap(pr["elev"], lines[n]) - c) < 1e-9
            return pr["elev"] - 1e-9 <= c <= pr["elev"] + pr["len"] + 1e-9
        a1 = (pr["n"] + 1) % 3
        b = pr["g"].bounds
        if n == a1:
            return b[0] - 1e-9 <= c <= b[2] + 1e-9
        return b[1] - 1e-9 <= c <= b[3] + 1e-9
    if t == "cyl":
        lo = np.minimum(pr["a"], pr["b"]) - pr["r"]
        hi = np.maximum(pr["a"], pr["b"]) + pr["r"]
        return lo[n] - 1e-9 <= c <= hi[n] + 1e-9
    if t == "stl":
        return pr["lo"][n] - 1e-9 <= c <= pr["hi"][n] + 1e-9
    return False


# ---------------------------------------------------------------------------
# materials and slices
# ---------------------------------------------------------------------------
METAL = ("Metal", "ConductingSheet")


def materials(model: dict) -> list[dict]:
    """Legend entries: 0 = air (background), then one per dielectric / casing material, last metal."""
    out = [{"name": "air", "eps": 1.0, "kind": "air"}]
    seen = {}
    for p in model["props"]:
        if p["kind"] == "Material":
            key = (p["name"].split("_")[0] if p["name"].startswith("case") else p["name"], round(p["eps"], 3))
            if key not in seen:
                seen[key] = len(out)
                out.append({"name": _mat_label(p["name"]), "eps": p["eps"],
                            "kind": "casing" if p["name"].startswith("case") else "dielectric"})
            p["mid"] = seen[key]
    out.append({"name": "metal (volume)", "eps": 1e9, "kind": "metal"})
    for p in model["props"]:
        if p["kind"] in METAL:
            p["mid"] = len(out) - 1
    return out


def _rle(a: np.ndarray) -> list[int]:
    """Run-length code of a flat integer array: [value, count, value, count, ...]."""
    a = np.asarray(a).ravel()
    if not len(a):
        return []
    cut = np.nonzero(np.diff(a))[0] + 1
    starts = np.r_[0, cut]
    counts = np.diff(np.r_[starts, len(a)])
    return np.column_stack([a[starts], counts]).ravel().astype(int).tolist()


def slice_data(model: dict, n: int, k: int) -> dict:
    """One slice on mesh line k of axis n: face materials, metal edges, ports, outlines."""
    L = model["lines"]
    u, v = PLANE[n]
    c = float(L[n][k])
    lu, lv = L[u], L[v]
    uc, vc = (lu[:-1] + lu[1:]) / 2, (lv[:-1] + lv[1:]) / 2
    cell_n = np.diff(L[n])
    eps_n = 1e-4 * float(min(cell_n[max(k - 1, 0)], cell_n[min(k, len(cell_n) - 1)]))
    tol = 1e-6

    def pts(us, vs, w):
        U, V = np.meshgrid(us, vs, indexing="ij")
        P = np.zeros((U.size, 3))
        P[:, u], P[:, v], P[:, n] = U.ravel(), V.ravel(), w
        return P

    props = [p for p in model["props"] if "mid" in p]
    touching = [(p, pr) for p in props for pr in p["prims"] if _touches(pr, n, c, L)]
    # faces: material on both sides of the plane, higher permittivity wins (metal highest)
    nf = len(uc) * len(vc)
    best = np.zeros(nf, np.int16)
    best_eps = np.ones(nf)
    for side in (-1, 1):
        w = c + side * eps_n
        if not (L[n][0] <= w <= L[n][-1]):
            continue
        P = pts(uc, vc, w)
        prio = np.full(nf, -1)
        mid = np.zeros(nf, np.int16)
        meps = np.ones(nf)
        for p, pr in touching:
            if pr["t"] == "poly" or (pr["t"] == "box" and np.any(pr["hi"] - pr["lo"] < 1e-9)):
                continue  # zero-thickness: edges only
            m = _inside(pr, P, L, u, tol) & (pr["prio"] >= prio)
            if m.any():
                prio[m] = pr["prio"]
                mid[m] = p["mid"]
                meps[m] = 1e9 if p["kind"] in METAL else p["eps"]
        up = meps > best_eps
        best[up], best_eps[up] = mid[up], meps[up]
    # metal edges in the plane (midpoint rule)
    metal = [(p, pr) for p, pr in touching if p["kind"] in METAL]

    def edges(us, vs, ray):
        """0 = no metal, 1 = ground / board copper, 2 = signal or antenna copper (wins)."""
        P = pts(us, vs, c)
        m = np.zeros(len(P), np.int8)
        for p, pr in metal:
            hit = _inside(pr, P, L, ray, tol)
            m[hit] = np.maximum(m[hit], _metal_class(p["name"]))
        return m.reshape(len(us), len(vs))

    eu = edges(uc, lv, v)  # edges along u: (cells u) x (nodes v)
    ev = edges(lu, vc, u)  # edges along v: (nodes u) x (cells v)
    # ports, lumped parts and the far-field box crossing the plane
    marks = []
    for p in model["props"]:
        kind = None
        if p["kind"] == "LumpedElement":
            kind = "port" if p["name"].startswith("port_resist") else "lumped"
        elif p["kind"] == "DumpBox" and p["name"] == "nf2ff_E":
            kind = "nf2ff"
        if not kind:
            continue
        for pr in p["prims"]:
            if pr["t"] != "box":
                continue
            lo, hi = pr["lo"].copy(), pr["hi"].copy()
            for q in range(3):
                if hi[q] - lo[q] < 1e-9 and kind != "nf2ff":
                    lo[q] = hi[q] = _snap(lo[q], L[q])
            if kind == "nf2ff":
                if not (lo[n] - 1e-9 <= c <= hi[n] + 1e-9) or hi[n] - lo[n] < 1e-9:
                    continue  # draw the box once from its sides that cross the plane
            elif not (lo[n] - 1e-9 <= c <= hi[n] + 1e-9):
                continue
            label = p.get("label") or p["name"].replace("port_resist_", "port ").replace("lumped_", "")
            marks.append({"kind": kind, "label": label, "u": [round(lo[u], 5), round(hi[u], 5)],
                          "v": [round(lo[v], 5), round(hi[v], 5)]})
    # exact outlines of the copper sheets lying in this plane
    outl = []
    for p, pr in metal:
        if pr["t"] == "poly" and pr["n"] == n:
            a1 = (n + 1) % 3
            g = pr["g"]
            for poly in getattr(g, "geoms", [g]):
                xy = np.array(poly.exterior.coords)
                uu, vv = (xy[:, 0], xy[:, 1]) if a1 == u else (xy[:, 1], xy[:, 0])
                if len(xy) > 400:  # keep the page small: simplified outline
                    s = poly.simplify(0.005)
                    xy = np.array(s.exterior.coords)
                    uu, vv = (xy[:, 0], xy[:, 1]) if a1 == u else (xy[:, 1], xy[:, 0])
                outl.append([np.round(uu, 4).tolist(), np.round(vv, 4).tolist()])
    return {"n": n, "k": int(k), "c": round(c, 6), "faces": _rle(best), "eu": _rle(eu),
            "ev": _rle(ev), "marks": marks, "outlines": outl,
            "metal_edges": int((eu > 0).sum() + (ev > 0).sum())}


def _ground_names() -> set:
    from .board import Board
    return set(Board._GND_NAMES) | {"board", "nonet", "ground_stitches", "vias", "via_axes"}


_GROUND = _ground_names()


def _metal_class(name: str) -> int:
    """1 = ground / board copper / vias, 2 = signal or antenna copper (the RF path to look at)."""
    tok = name.split(":")
    if tok[0].startswith("sub") and len(tok) >= 2:
        return 2  # antenna board: all of it is antenna
    if tok[-1] in _GROUND or name in _GROUND or "via" in tok[-1] or tok[-1].startswith("main"):
        return 1
    return 2


def _layer_label(name: str) -> str:
    """'main:F.Cu:GND' -> 'F.Cu', 'sub0:B.Cu' -> 'antenna board B.Cu', 'F.Cu:Net-(AE1)' -> 'F.Cu'."""
    tok = name.split(":")
    lay = next((t for t in tok if t.endswith(".Cu")), None)
    if lay is None:
        return name.split("_")[0]
    return ("antenna board " if tok[0].startswith("sub") else "") + lay


def _mat_label(name: str) -> str:
    """Casing material 'case0_80440001_43c60d1fdf' -> 'casing 80440001'; 'main:dielectric 1' -> 'board dielectric 1'."""
    if name.startswith("case") and "_" in name:
        return "casing " + "_".join(name.split("_")[1:-1])
    return name.replace("main:", "board ").replace("sub0:", "antenna board ").replace("sub1:", "antenna board 2 ")


def _plane_names(model: dict) -> dict:
    """Names of the copper planes (for the slice list): {(axis, line index): text}."""
    L = model["lines"]
    out: dict = {}
    for p in model["props"]:
        if p["kind"] not in METAL:
            continue
        for pr in p["prims"]:
            if pr["t"] == "poly":
                n = pr["n"]
                k = int(np.argmin(np.abs(L[n] - pr["elev"])))
                out.setdefault((n, k), set()).add(_layer_label(p["name"]))
    return {key: ", ".join(sorted(v))[:60] for key, v in out.items()}


def pick_slices(model: dict, max_per_axis: int = 9) -> list[tuple[int, int, str]]:
    """Slices worth looking at: every copper plane, the middle of each dielectric, the ports,
    the smallest cells, evenly spread positions."""
    L = model["lines"]
    names = _plane_names(model)
    want: dict = {}

    def add(n, k, why):
        k = int(min(max(k, 0), len(L[n]) - 1))
        want.setdefault((n, k), why)

    for (n, k), nm in names.items():
        add(n, k, nm)
    for p in model["props"]:
        if p["kind"] == "LumpedElement" and p["name"].startswith("port_resist"):
            for pr in p["prims"]:
                if pr["t"] == "box":
                    mid = (pr["lo"] + pr["hi"]) / 2
                    for n in (0, 1):
                        add(n, int(np.argmin(np.abs(L[n] - mid[n]))), p["name"].replace("port_resist_", "port "))
        if p["kind"] == "Material" and not p["name"].startswith("case"):
            for pr in p["prims"][:1]:
                if pr["t"] == "lin" and pr["n"] == 2:
                    z = pr["elev"] + pr["len"] / 2
                    add(2, int(np.argmin(np.abs(L[2] - z))), f"inside {_mat_label(p['name'])}")
    for n in range(3):
        d = np.diff(L[n])
        i = int(np.argmin(d))
        add(n, i, "smallest cell")
        count = sum(1 for (a, _b) in want if a == n)
        for t in np.linspace(0.2, 0.8, max(0, min(4, max_per_axis - count))):
            add(n, int(round(t * (len(L[n]) - 1))), "")
    return sorted((n, k, why) for (n, k), why in want.items())


# ---------------------------------------------------------------------------
# statistics
# ---------------------------------------------------------------------------
def mesh_summary(model: dict) -> dict:
    L = model["lines"]
    f = model["f_max"] or 1e9
    lam = C0 / f * 1e3  # mm
    ax = []
    for n in range(3):
        d = np.diff(L[n])
        r = np.maximum(d[1:] / d[:-1], d[:-1] / d[1:]) if len(d) > 1 else np.array([1.0])
        i, j, q = int(np.argmin(d)), int(np.argmax(d)), int(np.argmax(r))
        ax.append({"axis": AX[n], "lines": len(L[n]), "cells": len(d), "lo": float(L[n][0]), "hi": float(L[n][-1]),
                   "min": float(d[i]), "min_at": float((L[n][i] + L[n][i + 1]) / 2),
                   "max": float(d[j]), "max_at": float((L[n][j] + L[n][j + 1]) / 2),
                   "ratio": float(r[q]), "ratio_at": float(L[n][q + 1]),
                   "n_ratio15": int((r > 1.5).sum()), "n_ratio2": int((r > 2.0).sum())})
    cells = int(np.prod([len(l) - 1 for l in L]))
    dmin = [a["min"] * 1e-3 for a in ax]
    dt = 1.0 / (C0 * math.sqrt(sum(1 / x ** 2 for x in dmin)))
    eps_max = max([p["eps"] for p in model["props"] if p["kind"] == "Material"] or [1.0])
    return {"axes": ax, "cells": cells, "lambda_mm": lam, "f_max": f,
            "cells_per_lambda_air": lam / max(a["max"] for a in ax),
            "eps_max": eps_max, "dt_courant": dt, "dt_openems": 0.55 * dt,
            "timesteps": model["timesteps"], "end_db": -10 * math.log10(model["end_criteria"]),
            "ram_mb": cells * 80 / 1e6, "boundary": model["boundary"]}


def per_material_cells(model: dict, slices: list[dict], mats: list[dict]) -> list[dict]:
    """Largest cell side found inside each material in the computed slices -> cells per wavelength."""
    L = model["lines"]
    lam = C0 / (model["f_max"] or 1e9) * 1e3
    big = {i: 0.0 for i in range(len(mats))}
    for s in slices:
        n = s["n"]
        u, v = PLANE[n]
        du, dv = np.diff(L[u]), np.diff(L[v])
        f = np.repeat(np.array(s["faces"][0::2]), np.array(s["faces"][1::2])).reshape(len(du), len(dv))
        k = min(s["k"], len(L[n]) - 2)
        dn = np.diff(L[n])[k]
        for mi in np.unique(f):
            m = f == mi
            side = max(float(du[np.any(m, axis=1)].max()), float(dv[np.any(m, axis=0)].max()), float(dn))
            big[int(mi)] = max(big[int(mi)], side)
    out = []
    for i, mt in enumerate(mats):
        if mt["kind"] == "metal" or not big[i]:
            continue
        lm = lam / math.sqrt(mt["eps"])
        out.append({"name": mt["name"], "eps": mt["eps"], "max_cell": big[i], "per_lambda": lm / big[i]})
    return out


# ---------------------------------------------------------------------------
# page
# ---------------------------------------------------------------------------
def write_mesh_view(xml_path: Path, out: Path, title: str, checks: list[str] | None = None,
                    notes: list[str] | None = None, y_sign: float = 1.0, estimate: str = "",
                    max_slices: int = 40, progress=lambda *_a: None, port_names: dict | None = None,
                    tune: dict | None = None, previous: dict | None = None) -> Path:
    """``tune``: editable mesh settings (the plugin applies them and rebuilds the page);
    ``previous``: the summary of the mesh before (mesh_summary.json), shown as a comparison."""
    model = parse(Path(xml_path))
    for p in model["props"]:  # "port_resist_3" -> "port_resist_3" with the label "P3 Z1.2"
        if p["kind"] == "LumpedElement" and p["name"].startswith("port_resist_") and port_names:
            num = p["name"].rsplit("_", 1)[-1]
            if num.isdigit() and int(num) in port_names:
                p["label"] = f"P{num} {port_names[int(num)]}"
    mats = model["materials"]
    picks = pick_slices(model)[:max_slices]
    slices = []
    for i, (n, k, why) in enumerate(picks):
        progress(f"mesh view: slice {i + 1} of {len(picks)} ({AX[n]} = {model['lines'][n][k]:.3f} mm)")
        s = slice_data(model, n, k)
        s["why"] = why
        slices.append(s)
    summ = mesh_summary(model)
    summ["materials"] = per_material_cells(model, slices, mats)
    data = {"title": title, "lines": [np.round(l, 6).tolist() for l in model["lines"]], "materials": mats,
            "slices": slices, "summary": summ, "checks": checks or [], "notes": notes or [], "y_sign": y_sign,
            "estimate": estimate, "tune": tune, "previous": previous,
            "current": _brief(summ, estimate, tune)}
    page = _PAGE.replace("__TITLE__", html.escape(title)).replace("__DATA__", json.dumps(data, separators=(",", ":")))
    out = Path(out)
    out.write_text(page, encoding="utf-8")
    try:
        (out.parent / "mesh_summary.json").write_text(json.dumps(data["current"]))
    except OSError:
        pass
    return out


def _brief(summ: dict, estimate: str, tune: dict | None) -> dict:
    """Key numbers of a mesh, kept for the comparison with the next mesh."""
    mats = [m for m in summ.get("materials", []) if m["eps"] > 1.01] or summ.get("materials", [])
    return {"cells": summ["cells"], "dt_fs": summ["dt_openems"] * 1e15, "timesteps": summ["timesteps"],
            "per_lambda": min((m["per_lambda"] for m in mats), default=None),
            "per_lambda_air": summ["cells_per_lambda_air"], "estimate": estimate,
            "min_cell": min(a["min"] for a in summ["axes"]),
            "mode": (tune or {}).get("mode"),
            "values": {f["key"]: f["value"] for f in (tune or {}).get("fields", [])}}


_PAGE = r"""<!doctype html><html><head><meta charset="utf-8"><title>Mesh - __TITLE__</title>
<style>
:root{--bg:#fafaf8;--fg:#1f2328;--mut:#6a6f76;--card:#fff;--bd:#dedcd6;--acc:#2b6cb0;--warn:#c4521b;--ok:#2f7d32}
body{margin:0;font:14px system-ui,Segoe UI,sans-serif;background:var(--bg);color:var(--fg)}
header{padding:12px 18px 4px}h1{font-size:20px;margin:0}.sub{color:var(--mut);font-size:13px;margin-top:2px}
.wrap{display:flex;gap:14px;padding:10px 18px;flex-wrap:wrap}
.card{background:var(--card);border:1px solid var(--bd);border-radius:8px;padding:12px 14px}
.view{flex:1 1 640px;min-width:340px}.side{flex:0 1 380px;min-width:300px;display:flex;flex-direction:column;gap:12px}
.bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:8px}
select,button{font:inherit;padding:3px 8px;border:1px solid var(--bd);border-radius:5px;background:#fff}
button.on{background:var(--acc);color:#fff;border-color:var(--acc)}
canvas{width:100%;border:1px solid var(--bd);border-radius:6px;background:#fff;cursor:grab;touch-action:none}
.cvwrap{position:relative}
#lgo{position:absolute;top:8px;right:8px;max-width:46%;background:rgba(255,255,255,0.93);border:1px solid var(--bd);border-radius:6px;
 padding:6px 9px;font-size:12px;line-height:1.55;box-shadow:0 1px 4px #0001}
#lgo .t{font-weight:600;display:flex;justify-content:space-between;gap:10px;cursor:pointer;user-select:none}
#lgo.min .it{display:none}#lgo .it{display:flex;align-items:center;gap:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ln{display:inline-block;width:14px;height:0;border-top:3px solid;vertical-align:middle}
#tip{font:12px ui-monospace,Consolas,monospace;color:var(--mut);min-height:34px;white-space:pre}
table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:3px 6px;border-bottom:1px solid #eee;text-align:left}
th{color:var(--mut);font-weight:600}td.n{text-align:right;font-variant-numeric:tabular-nums}
.w{color:var(--warn)}.g{color:var(--ok)}.lg{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:12px;margin-top:6px}
.sw{display:inline-block;width:12px;height:12px;border-radius:2px;vertical-align:-2px;margin-right:4px;border:1px solid #0002}
h2{font-size:15px;margin:0 0 6px}ul{margin:4px 0 0 18px;padding:0}li{margin:2px 0}
.charts canvas{height:110px;cursor:pointer}
#tune input[type=number]{width:78px;font:inherit;padding:2px 4px;border:1px solid var(--bd);border-radius:4px;text-align:right}
#tune input.chg{border-color:var(--acc);background:#eef4fb}#tune td{vertical-align:middle}
#tune .pre{display:flex;gap:6px;margin:2px 0 8px}#tune .act{display:flex;gap:8px;align-items:center;margin-top:8px}
#tune .pv{margin-top:8px;font-size:13px;line-height:1.5}#tune table.tf td.n{white-space:nowrap}#tune #tStat{flex:1;min-width:0}#tune .up{color:var(--ok)}#tune .dn{color:var(--warn)}
label{user-select:none}
</style></head><body>
<header><h1>Mesh – __TITLE__</h1><div class="sub" id="sub"></div></header>
<div class="wrap">
<div class="card view">
 <div class="bar">
  <span>Slice</span><select id="ori"><option value="2">top view (x-y)</option><option value="1">side view (x-z)</option><option value="0">side view (y-z)</option></select>
  <select id="sl"></select>
  <button id="prev">◀</button><button id="next">▶</button>
  <button id="fit">Fit board</button><button id="rf">RF / antenna</button><button id="antb" style="display:none" title="side view in the plane of the soldered-in antenna board">Antenna board</button><button id="all">Whole domain</button><button id="small">Smallest cell</button><button id="goTune" title="change the mesh settings and rebuild">Adjust mesh …</button>
 </div>
 <div class="bar">
  <label><input type="checkbox" id="cMesh" checked> mesh lines</label>
  <label><input type="checkbox" id="cMat" checked> materials</label>
  <label><input type="checkbox" id="cMet" checked> metal on the mesh</label>
  <label><input type="checkbox" id="cOut" checked> copper outline</label>
  <label><input type="checkbox" id="cPort" checked> ports / parts</label>
  <span>colour</span><select id="mode"><option value="mat">by material</option><option value="size">by cell size</option></select>
 </div>
 <div class="cvwrap"><canvas id="cv" height="560"></canvas><div id="lgo"></div></div>
 <div id="tip"></div>
</div>
<div class="side">
 <div class="card" id="tune"><h2>Mesh accuracy</h2><div id="tuneBody"></div></div>
 <div class="card"><h2>Mesh</h2><table id="stats"></table></div>
 <div class="card"><h2>Cells per wavelength</h2><table id="mats"></table>
  <div class="sub">At the highest simulated frequency; 15–20 or more is good, below 10 the result is inaccurate. Largest cell found in the shown slices.</div></div>
 <div class="card" id="chk"><h2>Checks</h2><ul id="checks"></ul></div>
</div>
<div class="card charts" style="flex:1 1 100%"><h2>Cell size along each axis</h2>
 <div class="sub">Bar = one cell (log scale). Red: more than 1.5× its neighbour. Click to jump to that position.</div>
 <canvas id="ch0"></canvas><canvas id="ch1"></canvas><canvas id="ch2"></canvas></div>
</div>
<script>
const D=__DATA__;const AX="xyz";const PL={2:[0,1],1:[0,2],0:[1,2]};
const L=D.lines;const $=id=>document.getElementById(id);
const COL={air:"#ffffff",dielectric:["#9bc59d","#7fb3c8","#c8b27f","#b9a0d0","#d09b9b"],casing:["#cfd8e3","#e3d5c4","#d6e3c4"],metal:"#7a5a2a"};
const matCol=D.materials.map((m,i)=>m.kind==="air"?COL.air:m.kind==="metal"?COL.metal:(m.kind==="casing"?COL.casing:COL.dielectric)[i%(m.kind==="casing"?3:5)]);
function unrle(a,n){const o=new Int16Array(n);let p=0;for(let i=0;i<a.length;i+=2){o.fill(a[i],p,p+a[i+1]);p+=a[i+1];}return o;}
const cache={};function S(i){if(!cache[i]){const s=D.slices[i],[u,v]=PL[s.n],nu=L[u].length-1,nv=L[v].length-1;
 cache[i]={s,u,v,nu,nv,f:unrle(s.faces,nu*nv),eu:unrle(s.eu,nu*(nv+1)),ev:unrle(s.ev,(nu+1)*nv)};}return cache[i];}
const fmt=(x,d=3)=>(+x).toFixed(d);
const sm=D.summary;
$("sub").textContent=`${sm.cells.toLocaleString()} cells (${sm.axes.map(a=>a.cells).join(" × ")}) · f max ${(sm.f_max/1e9).toFixed(3)} GHz · ${D.slices.length} slices`+(D.estimate?` · ${D.estimate}`:"");
// stats table
(function(){let h="<tr><th></th>"+sm.axes.map(a=>`<th>${a.axis}</th>`).join("")+"</tr>";
 const row=(t,f,cls)=>{h+=`<tr><td>${t}</td>`+sm.axes.map(a=>`<td class="n ${cls?cls(a):""}">${f(a)}</td>`).join("")+"</tr>";};
 row("lines",a=>a.lines);row("extent mm",a=>`${fmt(a.lo,1)} … ${fmt(a.hi,1)}`);
 row("smallest cell mm",a=>fmt(a.min,4));row("largest cell mm",a=>fmt(a.max,3));
 row("max neighbour ratio",a=>fmt(a.ratio,2),a=>a.ratio>2?"w":"");row("cells > 1.5× neighbour",a=>a.n_ratio15,a=>a.n_ratio15?"w":"");
 h+=`<tr><td>timestep</td><td class="n" colspan="3">≈ ${(sm.dt_openems*1e15).toFixed(1)} fs (Courant ${(sm.dt_courant*1e15).toFixed(1)} fs)</td></tr>`;
 h+=`<tr><td>max timesteps</td><td class="n" colspan="3">${sm.timesteps.toLocaleString()} (stops at ${sm.end_db.toFixed(0)} dB)</td></tr>`;
 h+=`<tr><td>memory</td><td class="n" colspan="3">≈ ${sm.ram_mb<1000?sm.ram_mb.toFixed(0)+" MB":(sm.ram_mb/1000).toFixed(1)+" GB"}</td></tr>`;
 h+=`<tr><td>boundary</td><td class="n" colspan="3">${[...new Set(Object.values(sm.boundary))].join(", ")}</td></tr>`;
 $("stats").innerHTML=h;
 let m="<tr><th>material</th><th>ε<sub>r</sub></th><th>max cell</th><th>cells/λ</th></tr>";
 for(const q of sm.materials){m+=`<tr><td>${q.name}</td><td class="n">${fmt(q.eps,2)}</td><td class="n">${fmt(q.max_cell,3)}</td><td class="n ${q.per_lambda<10?"w":q.per_lambda>=15?"g":""}">${q.per_lambda.toFixed(0)}</td></tr>`;}
 $("mats").innerHTML=m;
 const ck=D.checks.length?D.checks.map(c=>`<li class="w">${c}</li>`).join(""):'<li class="g">No mesh problem found (planes, port ends, zero-width cells, feed connections).</li>';
 $("checks").innerHTML=ck+D.notes.map(c=>`<li>${c}</li>`).join("");})();
// mesh accuracy: change the mesh settings here, the plugin saves them and rebuilds this page
(function(){const T=D.tune,P=D.previous,C=D.current||{};const host=window.rfsim&&window.rfsim.postMessage?window.rfsim:null;
 if(!T&&!P){$("tune").style.display="none";$("goTune").style.display="none";return}
 $("goTune").onclick=()=>$("tune").scrollIntoView({behavior:"smooth",block:"start"});
 const isA=T&&T.kind==="antenna";const fineK=isA?"max_antenna":"max_fine";
 const epsD=Math.max(1,...D.materials.filter(m=>m.kind==="dielectric").map(m=>m.eps));
 const lam=299792458/(sm.f_max||1e9)*1e3;
 const dB=v=>-10*Math.log10(v);
 const PRE=[["fast","Fast"],["auto","Automatic"],["accurate","Accurate"]];
 let h="";
 if(T){
  h+=`<div class="pre">${PRE.map(([m,t])=>`<button data-p="${m}" class="${T.mode===m?"on":""}">${t}</button>`).join("")}<button data-p="custom" class="${T.mode==="custom"?"on":""}" disabled>Custom</button></div><table class="tf">`;
  for(const f of T.fields){const id=`t_${f.key}`;let inp;
   if(f.type==="bool")inp=`<input type="checkbox" id="${id}" ${f.value?"checked":""}>`;
   else if(f.key==="end_criteria")inp=`<input type="number" id="${id}" step="5" min="10" max="80" value="${dB(f.value).toFixed(0)}"> dB`;
   else inp=`<input type="number" id="${id}" step="any" min="0" value="${f.value==null?"":f.value}" placeholder="${f.optional?"auto":""}">`;
   h+=`<tr title="${(f.doc||"").replace(/"/g,"&quot;")}"><td>${f.label}</td><td class="n">${inp}</td></tr>`;}
  h+=`</table><div class="pv" id="tPrev"></div><div class="act"><button id="tApply">${host?"Apply and rebuild mesh":"Apply (in RF Sim)"}</button><span class="sub" id="tStat"></span></div>`;
 }
 if(P){const row=(t,a,b,fm,good)=>{const ch=a!=null&&b!=null&&Math.abs(b-a)>1e-9*Math.abs(a);
   return `<tr><td>${t}</td><td class="n">${a==null?"–":fm(a)}</td><td class="n ${ch?(good(b,a)?"up":"dn"):""}">${b==null?"–":fm(b)}</td></tr>`};
  h+=`<h2 style="margin-top:10px">Before → now</h2><table><tr><th></th><th>before${P.mode?" ("+P.mode+")":""}</th><th>now${C.mode?" ("+C.mode+")":""}</th></tr>`+
   row("cells",P.cells,C.cells,v=>(v/1e6).toFixed(2)+" M",(b,a)=>b<a)+
   row("cells/λ (dielectric, worst)",P.per_lambda,C.per_lambda,v=>v.toFixed(0),(b,a)=>b>a)+
   row("smallest cell",P.min_cell,C.min_cell,v=>v.toFixed(4)+" mm",(b,a)=>b>a)+
   row("timestep",P.dt_fs,C.dt_fs,v=>v.toFixed(1)+" fs",(b,a)=>b>a)+
   `<tr><td>runtime</td><td class="n">${P.estimate||"–"}</td><td class="n">${C.estimate||"–"}</td></tr></table>`;}
 $("tuneBody").innerHTML=h;
 if(!T)return;
 const val=f=>{const e=$(`t_${f.key}`);if(f.type==="bool")return e.checked;if(e.value==="")return f.optional?null:f.value;
  const x=+e.value;return f.key==="end_criteria"?+Math.pow(10,-x/10).toPrecision(3):(f.type==="int"?Math.round(x):x)};
 const same=(a,b)=>a==null||b==null?a==b:Math.abs(a-b)<=1e-9*Math.max(1,Math.abs(a))||a===b;
 function mode(){for(const [m] of PRE){if(T.fields.every(f=>same(val(f),f.presets[m])))return m}return "custom"}
 function preview(){const v={};for(const f of T.fields){v[f.key]=val(f);$(`t_${f.key}`).classList.toggle("chg",!same(v[f.key],f.value))}
  const o=Object.fromEntries(T.fields.map(f=>[f.key,f.value]));const m=mode();
  document.querySelectorAll("#tune .pre button").forEach(b=>b.classList.toggle("on",b.dataset.p===m));
  const pl=c=>c?lam/Math.sqrt(epsD)/c:null;const q=x=>x==null?"–":x.toFixed(0);
  const cls=x=>x==null?"":x<10?"dn":x>=15?"up":"";
  let t=`<div>${isA?"Antenna":"RF region"} cell ${v[fineK]} mm → <b class="${cls(pl(v[fineK]))}">${q(pl(v[fineK]))} cells/λ</b> in ε<sub>r</sub> ${epsD.toFixed(2)} at ${(sm.f_max/1e9).toFixed(2)} GHz (15–20 or more is good)</div>`;
  if(!isA)t+=`<div class="sub">In the RF chain the trace widths set this cell, not the wavelength: keep 3 or more cells across the narrowest RF trace.</div>`;
  if(isA)t+=`<div>Board cell ${v.max_board} mm → ${q(pl(v.max_board))} cells/λ (far from the antenna; 10 is enough)</div>`;
  let r=Math.pow(o[fineK]/v[fineK],2)*(o.min_cell/v.min_cell)*(dB(v.end_criteria)/dB(o.end_criteria));
  if(isA)r*=o.max_board/v.max_board;
  if(!isA&&v.z_cells_per_dielectric)r*=v.z_cells_per_dielectric/o.z_cells_per_dielectric;
  if(Math.abs(r-1)>0.02)t+=`<div>Runtime roughly ×${r<1?r.toFixed(2):r.toFixed(1)} of the current mesh (estimate; <i>Apply</i> builds the real mesh and shows its numbers).</div>`;
  $("tPrev").innerHTML=t;}
 for(const f of T.fields)$(`t_${f.key}`).addEventListener("input",preview);
 document.querySelectorAll("#tune .pre button[data-p]").forEach(b=>b.onclick=()=>{const m=b.dataset.p;if(m==="custom")return;
  for(const f of T.fields){const e=$(`t_${f.key}`),x=f.presets[m];if(f.type==="bool")e.checked=!!x;
   else if(f.key==="end_criteria")e.value=dB(x).toFixed(0);else e.value=x==null?"":x;}preview()});
 $("tApply").onclick=()=>{const m=mode();const values={};for(const f of T.fields){(values[f.group]=values[f.group]||{})[f.key]=val(f)}
  const msg={type:"mesh",config:T.config,mode:m,values};
  if(!host){$("tStat").textContent="Open this page from RF Sim (Results → Mesh) to apply the settings.";return}
  $("tApply").disabled=true;$("tStat").textContent="saving and rebuilding the mesh …";host.postMessage(JSON.stringify(msg))};
 preview();})();
// legend (inside the view, only what the slice shows)
let lgMin=false;
function matLabel(m){return m.name+(m.kind==="dielectric"||m.kind==="casing"?` (ε<sub>r</sub> ${fmt(m.eps,2)})`:"")}
function legend(c){const it=[];const sw=(col,t,bd)=>`<div class="it"><span class="sw" style="background:${col};${bd||""}"></span><span>${t}</span></div>`;
 const li=(col,t,dash)=>`<div class="it"><span class="ln" style="border-color:${col};${dash?"border-top-style:dashed":""}"></span><span>${t}</span></div>`;
 const mode=$("mode").value;
 if(mode==="size")it.push(`<div class="it"><span class="sw" style="background:linear-gradient(90deg,${sizeCol(1,1,10)},${sizeCol(10,1,10)})"></span>cell size: small → large</div>`);
 else if($("cMat").checked){const used=new Set(c.f);D.materials.forEach((m,i)=>{if(used.has(i))it.push(sw(matCol[i],matLabel(m)))})}
 if($("cMet").checked){const has=k=>c.eu.includes(k)||c.ev.includes(k);
  if(has(2))it.push(sw("#e8590c","RF / antenna copper (as the FDTD sees it)"));if(has(1))it.push(sw("#a0703a","ground / board copper, vias"));
  if(has(1)||has(2))it.push('<div class="it" style="color:var(--mut)">filled cell = all 4 edges metal</div>')}
 if($("cOut").checked&&c.s.outlines.length)it.push(li("rgba(31,58,147,0.7)","exact copper outline"));
 if($("cPort").checked){const k=new Set(c.s.marks.map(m=>m.kind));if(k.has("port"))it.push(sw("#fff","port","border:2px solid #e53935"));
  if(k.has("lumped"))it.push(sw("#fff","lumped part","border:2px solid #8e24aa"));if(k.has("nf2ff"))it.push(li("#2b6cb0","far-field surface",true))}
 if($("cMesh").checked)it.push(li("rgba(60,60,60,0.5)","mesh line"));
 $("lgo").className=lgMin?"min":"";$("lgo").innerHTML=`<div class="t" id="lgt"><span>Legend</span><span>${lgMin?"▸":"▾"}</span></div>`+it.join("");
 $("lgt").onclick=()=>{lgMin=!lgMin;legend(c)}}
// slice selector
let cur=0;const ori=$("ori"),sel=$("sl");
function bestSlice(n){let b=-1,score=-1;D.slices.forEach((s,i)=>{if(s.n!==n)return;const sc=s.metal_edges+(s.marks.some(m=>m.kind==="port")?1e7:0);if(sc>score){score=sc;b=i;}});return b;}
function fill(keep){const n=+ori.value;sel.innerHTML="";D.slices.forEach((s,i)=>{if(s.n!==n)return;const o=document.createElement("option");o.value=i;
 o.textContent=`${AX[n]} = ${fmt(s.c,3)} mm${s.why?" – "+s.why:""}`;sel.appendChild(o);});if(sel.options.length&&!keep){cur=bestSlice(n);}}
ori.onchange=()=>{fill();fitView();draw();};sel.onchange=()=>{cur=+sel.value;draw();};
$("prev").onclick=()=>{if(sel.selectedIndex>0){sel.selectedIndex--;cur=+sel.value;draw();}};
$("next").onclick=()=>{if(sel.selectedIndex<sel.options.length-1){sel.selectedIndex++;cur=+sel.value;draw();}};
// view transform
const cv=$("cv"),cx=cv.getContext("2d");let view={s:1,ox:0,oy:0};
function resize(){const r=cv.getBoundingClientRect();cv.width=Math.round(r.width*devicePixelRatio);cv.height=Math.round(560*devicePixelRatio);}
function metalBox(c,rf){const {nu,nv,u,v}=c,lu=L[u],lv=L[v];let a=1e9,b=-1e9,p=1e9,q=-1e9;const ok=k=>rf?k===2:k>0;
 for(let i=0;i<nu;i++)for(let j=0;j<=nv;j++)if(ok(c.eu[i*(nv+1)+j])){a=Math.min(a,lu[i]);b=Math.max(b,lu[i+1]);p=Math.min(p,lv[j]);q=Math.max(q,lv[j]);}
 for(let i=0;i<=nu;i++)for(let j=0;j<nv;j++)if(ok(c.ev[i*nv+j])){a=Math.min(a,lu[i]);b=Math.max(b,lu[i]);p=Math.min(p,lv[j]);q=Math.max(q,lv[j+1]);}
 if(rf)for(const m of c.s.marks)if(m.kind!=="nf2ff"){a=Math.min(a,m.u[0]);b=Math.max(b,m.u[1]);p=Math.min(p,m.v[0]);q=Math.max(q,m.v[1]);}
 return b>a?[a,b,p,q]:null;}
function fitView(all,rf){resize();const n=+ori.value,[u,v]=PL[n];const lu=L[u],lv=L[v];let box=[lu[0],lu[lu.length-1],lv[0],lv[lv.length-1]];
 if(!all){const mb=metalBox(S(cur),rf)||metalBox(S(cur),false);if(mb){const mu=(mb[1]-mb[0])*0.06+0.5,mv=(mb[3]-mb[2])*0.06+0.5;box=[mb[0]-mu,mb[1]+mu,mb[2]-mv,mb[3]+mv];}}
 const w=box[1]-box[0],h=box[3]-box[2];const s=Math.min(cv.width/w,cv.height/h)*0.96;view={s,ox:(cv.width-w*s)/2-box[0]*s,oy:(cv.height+h*s)/2+box[2]*s};}
const X=a=>a*view.s+view.ox,Y=b=>view.oy-b*view.s,IX=x=>(x-view.ox)/view.s,IY=y=>(view.oy-y)/view.s;
function idx(arr,v){let lo=0,hi=arr.length-1;while(hi-lo>1){const m=(lo+hi)>>1;if(arr[m]<=v)lo=m;else hi=m;}return lo;}
function sizeCol(d,dmin,dmax){const t=Math.max(0,Math.min(1,Math.log(d/dmin)/Math.log(Math.max(dmax/dmin,1.0001))));
 const r=Math.round(230-200*t),g=Math.round(80+120*t),b=Math.round(60+170*t);return `rgb(${r},${g},${b})`;}
function draw(){const c=S(cur),{s,u,v,nu,nv}=c;const lu=L[u],lv=L[v];cx.setTransform(1,0,0,1,0,0);cx.fillStyle="#f3f2ee";cx.fillRect(0,0,cv.width,cv.height);
 const i0=Math.max(0,idx(lu,IX(0))),i1=Math.min(nu-1,idx(lu,IX(cv.width))+1),j0=Math.max(0,idx(lv,IY(cv.height))),j1=Math.min(nv-1,idx(lv,IY(0))+1);
 const mode=$("mode").value;
 if($("cMat").checked||mode==="size"){let dmin=1e9,dmax=0;if(mode==="size"){for(let i=0;i<nu;i++)for(let j=0;j<nv;j++){const d=Math.min(lu[i+1]-lu[i],lv[j+1]-lv[j]);if(d<dmin)dmin=d;if(d>dmax)dmax=d;}}
  for(let i=i0;i<=i1;i++){const xa=X(lu[i]),xb=X(lu[i+1]);for(let j=j0;j<=j1;j++){const m=c.f[i*nv+j];
   cx.fillStyle=mode==="size"?sizeCol(Math.min(lu[i+1]-lu[i],lv[j+1]-lv[j]),dmin,dmax):matCol[m];const ya=Y(lv[j+1]),yb=Y(lv[j]);cx.fillRect(xa,ya,xb-xa+0.6,yb-ya+0.6);}}}
 const px=view.s*Math.min(lu[1]-lu[0],lv[1]-lv[0]);
 if($("cMesh").checked){cx.strokeStyle="rgba(60,60,60,0.35)";cx.lineWidth=1;cx.beginPath();
  const step=Math.max(1,Math.floor(2/Math.max(1e-9,view.s*Math.min(...lu.slice(1).map((x,i)=>x-lu[i])))));
  for(let i=i0;i<=i1+1;i++){const x=Math.round(X(lu[i]))+0.5;cx.moveTo(x,Y(lv[j0]));cx.lineTo(x,Y(lv[Math.min(j1+1,nv)]));}
  for(let j=j0;j<=j1+1;j++){const y=Math.round(Y(lv[j]))+0.5;cx.moveTo(X(lu[i0]),y);cx.lineTo(X(lu[Math.min(i1+1,nu)]),y);}cx.stroke();}
 if($("cMet").checked){// cells whose four edges are all metal: drawn as filled copper (planes look solid)
  for(let i=i0;i<=i1;i++){const xa=X(lu[i]),xb=X(lu[i+1]);for(let j=j0;j<=j1;j++){
   const e1=c.eu[i*(nv+1)+j],e2=c.eu[i*(nv+1)+j+1],e3=c.ev[i*nv+j],e4=c.ev[(i+1)*nv+j];
   if(e1&&e2&&e3&&e4){cx.fillStyle=Math.max(e1,e2,e3,e4)===2?"rgba(240,140,80,0.75)":"rgba(196,150,96,0.75)";const ya=Y(lv[j+1]),yb=Y(lv[j]);cx.fillRect(xa,ya,xb-xa+0.6,yb-ya+0.6);}}}
  cx.lineCap="round";cx.lineWidth=Math.max(1.5,Math.min(4,0.18*view.s*0.1+1.5));
  for(const cls of [1,2]){cx.strokeStyle=cls===1?"#a0703a":"#e8590c";cx.beginPath();
  for(let i=i0;i<=i1;i++)for(let j=j0;j<=Math.min(j1+1,nv);j++){if(c.eu[i*(nv+1)+j]===cls){cx.moveTo(X(lu[i]),Y(lv[j]));cx.lineTo(X(lu[i+1]),Y(lv[j]));}}
  for(let i=i0;i<=Math.min(i1+1,nu);i++)for(let j=j0;j<=j1;j++){if(c.ev[i*nv+j]===cls){cx.moveTo(X(lu[i]),Y(lv[j]));cx.lineTo(X(lu[i]),Y(lv[j+1]));}}cx.stroke();}}
 if($("cOut").checked){cx.strokeStyle="rgba(31,58,147,0.55)";cx.lineWidth=1;for(const o of s.outlines){cx.beginPath();o[0].forEach((a,q)=>{const x=X(a),y=Y(o[1][q]);q?cx.lineTo(x,y):cx.moveTo(x,y);});cx.closePath();cx.stroke();}}
 if($("cPort").checked){cx.font=`${12*devicePixelRatio}px system-ui`;for(const m of s.marks){const xa=X(m.u[0]),xb=X(m.u[1]),ya=Y(m.v[1]),yb=Y(m.v[0]);
  if(m.kind==="nf2ff"){cx.setLineDash([8,6]);cx.strokeStyle="#2b6cb0";cx.lineWidth=1.5;cx.strokeRect(xa,ya,xb-xa,yb-ya);cx.setLineDash([]);continue;}
  cx.strokeStyle=m.kind==="port"?"#e53935":"#8e24aa";cx.fillStyle=cx.strokeStyle;cx.lineWidth=3;
  if(Math.abs(xb-xa)<3&&Math.abs(yb-ya)<3){cx.beginPath();cx.arc(xa,ya,5,0,7);cx.fill();}else{cx.strokeRect(xa-1,ya-1,xb-xa+2,yb-ya+2);}
  cx.fillText(m.label,Math.max(xa,xb)+6,Math.min(ya,yb)+12*devicePixelRatio);}}
 // scale bar
 const mm=[0.01,0.02,0.05,0.1,0.2,0.5,1,2,5,10,20,50,100].find(q=>q*view.s>80*devicePixelRatio)||100;
 cx.fillStyle="#333";cx.fillRect(16,cv.height-20,mm*view.s,4);cx.font=`${12*devicePixelRatio}px system-ui`;cx.fillText(mm+" mm",16,cv.height-26);
 sel.value=cur;legend(c);}
// interaction
let drag=null;cv.onpointerdown=e=>{drag={x:e.offsetX,y:e.offsetY,ox:view.ox,oy:view.oy};cv.setPointerCapture(e.pointerId);cv.style.cursor="grabbing";};
cv.onpointerup=()=>{drag=null;cv.style.cursor="grab";};
cv.onpointermove=e=>{const k=devicePixelRatio;if(drag){view.ox=drag.ox+(e.offsetX-drag.x)*k;view.oy=drag.oy+(e.offsetY-drag.y)*k;draw();return;}
 const c=S(cur),{u,v,nu,nv}=c,lu=L[u],lv=L[v];const a=IX(e.offsetX*k),b=IY(e.offsetY*k);
 if(a<lu[0]||a>lu[nu]||b<lv[0]||b>lv[nv]){$("tip").textContent="";return;}const i=idx(lu,a),j=idx(lv,b);const m=D.materials[c.f[i*nv+j]];
 const kc=[0,0,0];kc[u]=a;kc[v]=b;kc[c.s.n]=c.s.c;
 $("tip").textContent=`${AX[u]} ${fmt(a)}  ${AX[v]} ${fmt(b)} mm  (KiCad x ${fmt(kc[0])}, y ${fmt(kc[1]*D.y_sign)})   cell ${AX[u]}${i} ${AX[v]}${j}\n`+
  `cell ${fmt(lu[i+1]-lu[i],4)} × ${fmt(lv[j+1]-lv[j],4)} mm   ${m.name}${m.kind!=="air"&&m.kind!=="metal"?" εr "+fmt(m.eps,2):""}`;};
cv.addEventListener("wheel",e=>{e.preventDefault();const k=devicePixelRatio,f=Math.exp(-e.deltaY*0.0015);const x=e.offsetX*k,y=e.offsetY*k;
 view.ox=x-(x-view.ox)*f;view.oy=y-(y-view.oy)*f;view.s*=f;draw();},{passive:false});
["cMesh","cMat","cMet","cOut","cPort","mode"].forEach(id=>$(id).onchange=draw);
{const sub=D.slices.map((s,i)=>[s,i]).filter(([s])=>s.n!==2&&/antenna board/.test(s.why||""));
 if(sub.length){$("antb").style.display="";$("antb").onclick=()=>{const [s,i]=sub.reduce((b,x)=>x[0].metal_edges>b[0].metal_edges?x:b);
  ori.value=String(s.n);fill(true);cur=i;fitView(false,true);draw();}}}
$("fit").onclick=()=>{fitView(false);draw();};$("all").onclick=()=>{fitView(true);draw();};$("rf").onclick=()=>{fitView(false,true);draw();};
$("small").onclick=()=>{const n=+ori.value,[u,v]=PL[n];const a=sm.axes[u],b=sm.axes[v];const cu=a.min_at,cvv=b.min_at;resize();
 view.s=cv.width/(Math.max(a.min,b.min)*60);view.ox=cv.width/2-cu*view.s;view.oy=cv.height/2+cvv*view.s;draw();};
window.addEventListener("resize",()=>{fitView();draw();});
// charts
function chart(n){const el=$("ch"+n);const r=el.getBoundingClientRect();el.width=r.width*devicePixelRatio;el.height=110*devicePixelRatio;const g=el.getContext("2d");
 const l=L[n],d=l.slice(1).map((x,i)=>x-l[i]);const lo=Math.min(...d),hi=Math.max(...d);const W=el.width,H=el.height,pad=40*devicePixelRatio;
 const xs=x=>pad+(x-l[0])/(l[l.length-1]-l[0])*(W-pad-8),ys=q=>H-16*devicePixelRatio-(Math.log(q/lo)/Math.log(Math.max(hi/lo,1.0001)))*(H-30*devicePixelRatio);
 g.fillStyle="#fff";g.fillRect(0,0,W,H);g.font=`${11*devicePixelRatio}px system-ui`;g.fillStyle="#666";
 g.fillText(AX[n],6,H/2);g.fillText(fmt(hi,3),6,14*devicePixelRatio);g.fillText(fmt(lo,4),6,H-18*devicePixelRatio);
 for(let i=0;i<d.length;i++){const rr=Math.max(i?d[i]/d[i-1]:1,i?d[i-1]/d[i]:1,i<d.length-1?d[i]/d[i+1]:1,i<d.length-1?d[i+1]/d[i]:1);
  g.fillStyle=rr>1.5?"#d84315":"#5b8bd6";const x0=xs(l[i]),x1=xs(l[i+1]);g.fillRect(x0,ys(d[i]),Math.max(1,x1-x0-0.3),H-16*devicePixelRatio-ys(d[i])+2);}
 g.fillStyle="#666";g.fillText(`${fmt(l[0],1)} mm`,pad,H-2);const t=`${fmt(l[l.length-1],1)} mm`;g.fillText(t,W-8-g.measureText(t).width,H-2);
 el.onclick=e=>{const x=l[0]+(e.offsetX*devicePixelRatio-pad)/(W-pad-8)*(l[l.length-1]-l[0]);
  // a slice of this axis next to x, else centre the view on x
  let best=-1,bd=1e9;D.slices.forEach((s,i)=>{if(s.n===n&&Math.abs(s.c-x)<bd){bd=Math.abs(s.c-x);best=i;}});
  if(best>=0){ori.value=n;fill(true);cur=best;fitView();draw();}};}
fill();fitView();draw();[0,1,2].forEach(chart);
</script></body></html>
"""
