"""Antenna detection with reasons, ground-plane check and a marking picture.

Printed antenna candidates are nets with lots of copper (>= 15 mm track or
>= 20 mm² zone) and at most two pads. A long trace over a solid ground plane is a
transmission line, not an antenna, so the copper is checked against the ground
on the other copper layers ("beneath"):

* >= 85 % over ground: rejected (trace / microstrip over a ground plane),
* 15 ... 85 %: accepted, "partly over ground" - typical for inverted-F and meander
  antennas whose feed / shorting section runs over ground while the radiating
  arm sits over the ground-free area,
* <= 15 %: accepted, over a ground-free area.

Soldered-in antennas are footprints AE*/ANT* with a 3D model (sub-board or STEP).
The feed of a printed antenna is the pad of a series part on the antenna net
(the part that continues to the matching network); shunt parts to ground are
only used when there is nothing else.
"""
from __future__ import annotations

import re
from pathlib import Path

from shapely.ops import unary_union

from .board import Board

OVER_GROUND_REJECT = 0.85
OVER_GROUND_PARTLY = 0.15


def ground_beneath(board: Board, net: str, ground: str = "GND") -> dict:
    """Copper of ``net`` and how much of it lies over ground on other copper layers."""
    layers = [l.name for l in board.stackup.copper] or ["F.Cu", "B.Cu"]
    ant_by_layer = {}
    for lay in layers:
        g = [geo for _, geo in board.copper(lay, net)]
        if g:
            ant_by_layer[lay] = unary_union(g)
    if not ant_by_layer:
        return {"area": 0.0, "over_ground": 0.0, "fraction": 0.0, "layers": [], "antenna": None, "ground": None,
                "covered": None}
    ant = unary_union(list(ant_by_layer.values()))
    covered = []
    gnd_all = []
    for lay, a in ant_by_layer.items():
        others = [geo for l2 in layers if l2 != lay for _, geo in board.copper(l2, ground)]
        if others:
            gu = unary_union(others)
            gnd_all.append(gu)
            covered.append(a.intersection(gu))
    cov = unary_union(covered) if covered else None
    area = ant.area
    over = cov.area if cov is not None and not cov.is_empty else 0.0
    return {"area": area, "over_ground": over, "fraction": over / area if area else 0.0,
            "layers": list(ant_by_layer), "antenna": ant, "ground": unary_union(gnd_all) if gnd_all else None,
            "covered": cov}


def _feed_pad(board: Board, net: str, pads, ground: str):
    """Pad on the antenna net that leads on to the RF chain: a series part first."""
    def score(fp_pad):
        f, p = fp_pad
        others = {q.net for q in f.pads if q.number and q.net and q.net != net}
        series = bool(others - {ground})
        return (0 if series else 1, 0 if not f.dnp else 1)
    return sorted(pads, key=score)[0]


def antenna_candidates(board: Board, nets: list[str], proj_dir: Path, ground: str = "GND") -> list[dict]:
    """Every antenna candidate among ``nets`` with ``accepted`` and a ``reason``."""
    from .pipeline import _resolve_model_path, find_subboard_project, step_info
    out = []
    pads_by_net: dict[str, list] = {}
    for f in board.footprints:
        for p in f.pads:
            if p.net:
                pads_by_net.setdefault(p.net, []).append((f, p))
    for n in nets:
        if n == ground:
            continue
        L = sum(t.length for t in board.tracks if t.net == n)
        A = sum(g.area for z in board.zones if z.net == n for gs in z.filled.values() for g in gs)
        pads = pads_by_net.get(n, [])
        if not ((L >= 15 or A >= 20) and len(pads) <= 2 and pads):
            continue
        gb = ground_beneath(board, n, ground)
        fr = gb["fraction"]
        f, p = _feed_pad(board, n, pads, ground)
        c = {"kind": "printed", "nets": [n], "feed": f"{f.ref}.{p.number}", "track_mm": round(L, 1),
             "zone_mm2": round(A, 1), "over_ground": round(fr, 3), "source": "detected"}
        if fr >= OVER_GROUND_REJECT:
            c.update(accepted=False, reason=f"{L:.0f} mm of copper, but {100*fr:.0f} % of it lies over a ground "
                                            f"plane - a trace, not an antenna")
        elif fr > OVER_GROUND_PARTLY:
            c.update(accepted=True, reason=f"{L:.0f} mm of copper, {100*fr:.0f} % over ground (feed / shorting "
                                           f"section), the rest over a ground-free area")
        else:
            c.update(accepted=True, reason=f"{L:.0f} mm of copper over a ground-free area")
        out.append(c)
    for f in board.footprints:
        if not any(p.net in nets for p in f.pads) or not f.models:
            continue
        feed = next((p for p in f.pads if p.net in nets and p.net != ground), None)
        if feed is None:
            continue
        step = _resolve_model_path(f.models[0]["path"], proj_dir)
        if not step.is_absolute():
            step = proj_dir / step
        info = step_info(step) if step.suffix.lower() in (".step", ".stp") and step.exists() else {"kicad": False,
                                                                                                    "products": []}
        named = bool(re.match(r"^(AE|ANT)\d", f.ref))
        if not named and not info["kicad"]:
            continue
        sub = find_subboard_project(step, proj_dir, exclude=getattr(board, "path", None))
        c = {"nets": [feed.net], "feed": f"{f.ref}.{feed.number}", "footprint": f.ref, "source": "detected",
             "step": str(step)}
        if sub:
            c.update(kind="subboard", subboard=str(sub), accepted=True,
                     reason=f"footprint {f.ref} carries the antenna board {Path(sub).name} (3D model {step.name})")
        elif info["kicad"]:
            nm = info["products"][0] if info["products"] else step.stem
            c.update(kind="board_missing", accepted=False,
                     reason=f"footprint {f.ref}: its 3D model {step.name} is a KiCad board ('{nm}'), but its "
                            f".kicad_pcb was not found - a STEP has no copper. Choose 'Antenna board' and "
                            f"select the board file")
        else:
            c.update(kind="step", accepted=True,
                     reason=f"footprint {f.ref} with 3D model {step.name} (imported as metal)")
        out.append(c)
    return out


def user_antenna(board: Board, net: str, feed: str, proj_dir: Path, ground: str = "GND",
                 ground_mode: str = "auto") -> dict:
    """An antenna defined by the user: its net and feed pad ("REF.PAD")."""
    ref = feed.split(".")[0]
    fp = board.footprint(ref)
    if net not in fp.nets:
        raise ValueError(f"feed pad {feed} is not on net {net}")
    c = {"kind": "printed", "nets": [net], "feed": feed, "source": "user", "accepted": True,
         "ground_mode": ground_mode, "reason": "defined by the user"}
    if re.match(r"^(AE|ANT)\d", ref) and fp.models:  # a soldered-in antenna footprint
        for d in antenna_candidates(board, [net], proj_dir, ground):
            if d.get("footprint") == ref:
                d.update(source="user", feed=feed, ground_mode=ground_mode, reason="defined by the user; " + d["reason"])
                return d
    gb = ground_beneath(board, net, ground)
    c["over_ground"] = round(gb["fraction"], 3)
    return c


def render_antenna(board: Board, cand: dict, out: str | Path, ground: str = "GND", dpi: int = 140) -> Path:
    """Top view that marks the antenna: its copper (over ground darker), ground beneath, the feed.
    With a feed on the antenna trace a second panel shows the selected trace segment, the port gap
    and the direction towards the antenna."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import PathPatch
    from matplotlib.path import Path as MPath
    from shapely.geometry import MultiPoint, box

    net = cand["nets"][0]
    gb = ground_beneath(board, net, ground)
    ref, pad = cand["feed"].split(".", 1)
    fpad = board.footprint(ref).pad(pad)
    tp = cand.get("feed_point")  # feed on the antenna trace: (x, y)
    tr = cand.get("feed_trace")  # the selected trace segment (trace feed)
    fp = board.footprint(cand["footprint"]) if cand["kind"] != "printed" else None
    line = None
    if fp is not None:  # the antenna net's copper on the board (from the matching network to the antenna)
        line = unary_union([g for lay in ("F.Cu", "B.Cu") for _n, g in board.copper(lay, net)])

    def patch(ax, geom, **kw):
        if geom is None or geom.is_empty:
            return
        for g in getattr(geom, "geoms", [geom]):
            if g.geom_type != "Polygon":
                continue
            verts, codes = [], []
            for ring in [g.exterior] + list(g.interiors):
                c = list(ring.coords)
                verts += c
                codes += [MPath.MOVETO] + [MPath.LINETO] * (len(c) - 2) + [MPath.CLOSEPOLY]
            ax.add_patch(PathPatch(MPath(verts, codes), **kw))

    def draw(ax, detail: bool):
        ol = board.outline()
        if ol is not None:
            x, y = ol.exterior.xy
            ax.plot(x, y, color="#888", lw=1.0)
        patch(ax, gb["ground"], facecolor="#d9d9d9", edgecolor="none", zorder=1)
        if detail:  # the other copper of the feed layer, for orientation
            lay = tr.get("layer", "F.Cu")
            win = box(tr["x"] - 4, tr["y"] - 4, tr["x"] + 4, tr["y"] + 4)
            other = unary_union([g for n, g in board.copper(lay, region=win) if n != net])
            patch(ax, other, facecolor="#b8b8b8", edgecolor="#8a8a8a", lw=0.3, zorder=2)
        if cand["kind"] == "printed":
            patch(ax, gb["antenna"], facecolor="#f28c28", edgecolor="#a35200", lw=0.4, zorder=3)
            patch(ax, gb["covered"], facecolor="#8a4a10", edgecolor="none", zorder=4)
            geom = gb["antenna"]
        else:
            patch(ax, line, facecolor="#f28c28", edgecolor="#a35200", lw=0.4, zorder=3)
            for p in fp.pads:
                patch(ax, p.polygon(), facecolor="#f28c28", edgecolor="#a35200", lw=0.5, zorder=3)
            geom = unary_union([p.polygon() for p in fp.pads])
            if not detail:
                x0, y0, x1, y1 = geom.buffer(1.0).bounds
                ax.add_patch(plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ls="--", ec="#a35200", lw=1.0,
                                           zorder=3))
                ax.annotate(f"{fp.ref} (soldered-in antenna)", (x1, y0), xytext=(4, -4), textcoords="offset points",
                            color="#a35200", fontsize=8, va="top")
        view_extra = []
        if tr:
            (sx0, sy0), (sx1, sy1) = tr["segment"]
            w, gp = tr.get("width", 0.3), tr.get("gap", 0.3)
            ux, uy = tr["dir"]
            cxp, cyp = tr["x"], tr["y"]
            if detail:
                ax.plot([sx0, sx1], [sy0, sy1], color="#1f6fd1", lw=3.0, solid_capstyle="butt", zorder=5)
                ax.annotate("selected trace", ((sx0 + sx1) / 2, (sy0 + sy1) / 2), xytext=(0, -16),
                            textcoords="offset points", color="#1f6fd1", fontsize=8, ha="center", va="top",
                            weight="bold", zorder=8)
                gx, gy = -uy * w * 0.9, ux * w * 0.9
                for o in (-gp / 2, gp / 2):  # the port gap: the two ends of the cut
                    ax.plot([cxp + ux * o - gx, cxp + ux * o + gx], [cyp + uy * o - gy, cyp + uy * o + gy],
                            color="#d00000", lw=1.8, zorder=7)
                ax.annotate("", (cxp + ux * 1.4, cyp + uy * 1.4), xytext=(cxp + ux * gp / 2, cyp + uy * gp / 2),
                            arrowprops=dict(arrowstyle="-|>", color="#d00000", lw=1.4), zorder=7)
                ax.annotate("to the antenna", (cxp + ux * 1.4, cyp + uy * 1.4), xytext=(4, 6),
                            textcoords="offset points", color="#d00000", fontsize=7.5, zorder=8)
                ax.annotate("behind the feed:\nground in the model", (cxp - ux * gp / 2, cyp - uy * gp / 2),
                            xytext=(cxp - ux * 1.6 - uy * 0.9, cyp - uy * 1.6 + ux * 0.9), textcoords="data",
                            color="#444", fontsize=7.5, ha="center", va="center", zorder=8,
                            bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.85),
                            arrowprops=dict(arrowstyle="-", color="#777", lw=0.8))
            else:
                ax.plot([sx0, sx1], [sy0, sy1], color="#1f6fd1", lw=3.0, solid_capstyle="butt", zorder=5)
            view_extra = [(sx0, sy0), (sx1, sy1)]
        if tp:
            ax.plot([tp[0]], [tp[1]], marker="o", ms=11 if not detail else 16, mfc="none", mec="#d00000", mew=2.0,
                    zorder=6)
            if not detail:
                ax.annotate(f"feed on the trace\n(after {cand['feed']})", (tp[0], tp[1]), xytext=(-8, 14),
                            textcoords="offset points", color="#d00000", fontsize=9, weight="bold", ha="right",
                            zorder=6)
            ax.plot([fpad.x], [fpad.y], marker="x", ms=7, mec="#777", zorder=6)
            if detail:
                ax.annotate(cand["feed"], (fpad.x, fpad.y), xytext=(-4, -10), textcoords="offset points",
                            color="#555", fontsize=7.5, ha="right", zorder=8)
            view_extra.append((tp[0], tp[1]))
        else:
            ax.plot([fpad.x], [fpad.y], marker="o", ms=11, mfc="none", mec="#d00000", mew=2.2, zorder=6)
            ax.annotate(f"feed {cand['feed']}", (fpad.x, fpad.y), xytext=(10, 10), textcoords="offset points",
                        color="#d00000", fontsize=9, weight="bold", zorder=6)
        if detail:
            r = max(2.0, 1.6 * ((sx1 - sx0) ** 2 + (sy1 - sy0) ** 2) ** 0.5)
            ax.set_xlim(tr["x"] - r, tr["x"] + r)
            ax.set_ylim(tr["y"] + r * 0.75, tr["y"] - r * 0.75)
        elif geom is not None and not geom.is_empty:
            extra = [fpad.polygon()] + ([MultiPoint(view_extra)] if view_extra else [])
            x0, y0, x1, y1 = unary_union([geom] + extra).bounds
            m = max(4.0, 0.25 * max(x1 - x0, y1 - y0))
            ax.set_xlim(x0 - m, x1 + m)
            ax.set_ylim(y1 + m, y0 - m)
        ax.set_aspect("equal")
        ax.set_xlabel("x / mm")
        if not detail:
            ax.set_ylabel("y / mm")

    if tr:
        fig, (ax, ax2) = plt.subplots(1, 2, figsize=(11.5, 5.6), gridspec_kw={"width_ratios": [1, 1.15]})
    else:
        fig, ax = plt.subplots(figsize=(7.5, 5.6))
        ax2 = None
    draw(ax, False)
    kind = {"printed": "printed antenna", "subboard": "antenna board", "step": "antenna (3D model)"}[cand["kind"]]
    src = "set by you" if cand.get("source") == "user" else "detected"
    ax.set_title(f"{kind} ({src}): net {net.split('/')[-1]}", fontsize=10)
    hs = [plt.Line2D([], [], color="#f28c28", lw=8, label="antenna copper"),
          plt.Line2D([], [], color="#8a4a10", lw=8, label="antenna copper over ground"),
          plt.Line2D([], [], color="#d9d9d9", lw=8, label="ground on other layers"),
          plt.Line2D([], [], color="#d00000", marker="o", mfc="none", lw=0, label="feed point")]
    hs = hs if cand["kind"] == "printed" else [hs[0], hs[3]]
    if tr:
        hs.append(plt.Line2D([], [], color="#1f6fd1", lw=3, label="selected trace (feed segment)"))
    ax.legend(handles=hs, fontsize=7, loc="best")
    if ax2 is not None:
        draw(ax2, True)
        ax2.set_title(f"feed on the selected trace, after {cand['feed']} "
                      f"(gap {tr.get('gap', 0):.2f} mm, offset {tr.get('offset', 0):.2f} mm)", fontsize=9)
    fig.tight_layout()
    out = Path(out)
    fig.savefig(out, dpi=dpi)
    plt.close(fig)
    return out
