"""Rectilinear FDTD mesh generation (1-D line sets, combined per axis)."""
from __future__ import annotations

import math

import numpy as np


def _clean(v: float) -> float:
    """Round away float noise (1e-9 mm). openEMS matches a sheet to a mesh line with a
    tolerance relative to the coordinate, so a line at 2.8e-17 never matches a sheet at 0:
    the copper was silently dropped ("Unused primitive")."""
    v = round(float(v), 9)
    return 0.0 if v == 0 else v


def merge_close(lines, min_cell: float) -> list[float]:
    """Sort and merge lines closer than ``min_cell``. ``lines``: floats or (value, priority);
    a cluster becomes the mean of its highest-priority lines, so metal-edge lines (the
    1/3-2/3 rule) are not dragged off the edge by a nearby port or pad box line."""
    s = sorted((v, 1) if not isinstance(v, tuple) else v for v in lines)
    if not s:
        return []

    def pick(cl):
        top = max(p for _, p in cl)
        vs = [v for v, p in cl if p == top]
        return _clean(sum(vs) / len(vs))
    out, cluster = [], [s[0]]
    for v in s[1:]:
        if v[0] - cluster[-1][0] < min_cell:
            cluster.append(v)
        else:
            out.append(pick(cluster))
            cluster = [v]
    out.append(pick(cluster))
    return out


def fill_max(lines: list[float], max_cell: float) -> list[float]:
    """Subdivide every gap larger than ``max_cell`` uniformly."""
    out = [lines[0]]
    for a, b in zip(lines, lines[1:]):
        n = math.ceil((b - a) / max_cell - 1e-9)
        for k in range(1, n):
            out.append(a + (b - a) * k / n)
        out.append(b)
    return out


def grow(start: float, end: float, first: float, ratio: float, max_cell: float) -> list[float]:
    """Geometrically graded lines from ``start`` towards ``end`` (excl. start)."""
    out = []
    d = 1 if end > start else -1
    pos, step = start, first
    while True:
        step = min(step * ratio, max_cell)
        if d * (end - (pos + d * step)) < step * 0.5:
            out.append(end)
            break
        pos += d * step
        out.append(pos)
    return out


def graded_fill(a: float, b: float, s_left: float, s_right: float, max_cell: float, ratio: float) -> list[float]:
    """Lines strictly inside (a, b): cells start at ``s_left``/``s_right`` and grow
    by ``ratio`` towards the middle, never exceeding ``max_cell``."""
    left, right = [], []
    pl, pr = a, b
    sl, sr = min(s_left, max_cell), min(s_right, max_cell)
    while pr - pl > sl + sr:
        if sl <= sr:
            pl += sl
            left.append(pl)
            sl = min(sl * ratio, max_cell)
        else:
            pr -= sr
            right.append(pr)
            sr = min(sr * ratio, max_cell)
    gap = pr - pl
    n = max(1, math.ceil(gap / max(sl, sr) - 1e-9))
    mids = [pl + gap * k / n for k in range(1, n)]
    return left + mids + right[::-1]


def axis_lines(fixed: list[float], lo: float, hi: float, fine_lo: float, fine_hi: float,
               max_fine: float, max_coarse: float, min_cell: float, ratio: float = 1.4) -> list[float]:
    """Full mesh line set for one axis.

    ``fixed`` lines (metal edges, port boxes) are kept (merged if closer than
    ``min_cell``). Gaps between them are filled with graded cells: small next to
    small fixed cells, growing by ``ratio`` up to ``max_fine`` inside
    [fine_lo, fine_hi] and up to ``max_coarse`` in the margin to ``lo``/``hi``.
    """
    fixed = [(v, 1) if not isinstance(v, tuple) else v for v in fixed]
    core = [v for v in fixed if fine_lo - 1e-9 <= v[0] <= fine_hi + 1e-9] + [(fine_lo, 0), (fine_hi, 0)]
    core = merge_close(core, min_cell)
    gaps = [b - a for a, b in zip(core, core[1:])]
    out = [core[0]]
    for i, (a, b) in enumerate(zip(core, core[1:])):
        g = gaps[i]
        nl = gaps[i - 1] if i > 0 else max_fine
        nr = gaps[i + 1] if i + 1 < len(gaps) else max_fine
        sl = min(max(nl * ratio, min_cell), max_fine)
        sr = min(max(nr * ratio, min_cell), max_fine)
        out += graded_fill(a, b, sl, sr, max_fine, ratio) + [b]
    core = out
    first_lo = core[1] - core[0]
    first_hi = core[-1] - core[-2]
    below = grow(core[0], lo, first_lo, ratio, max_coarse)[::-1] if lo < core[0] - min_cell else []
    above = grow(core[-1], hi, first_hi, ratio, max_coarse) if hi > core[-1] + min_cell else []
    return merge_close(below + core + above, min_cell * 0.5)


def snap(v: float, lines: list[float]) -> float:
    return min(lines, key=lambda x: abs(x - v))


def smooth(lines, ratio_max: float = 3.0, max_iter: int = 12) -> list[float]:
    """Split cells that are more than ``ratio_max`` times larger than a neighbour (merging close
    lines can leave a 0.1 mm cell next to a 0.4 mm one; large jumps reflect part of the wave and
    cost accuracy). Only lines are added: no existing line moves, no cell gets smaller than the
    smallest one (the timestep stays)."""
    out = [float(v) for v in lines]
    for _ in range(max_iter):
        d = np.diff(out)
        if len(d) < 2:
            break
        left, right = np.r_[np.inf, d[:-1]], np.r_[d[1:], np.inf]
        lim = ratio_max * (1 + 1e-9)
        add = []
        dmin = float(d.min())
        for i in np.nonzero(((d > lim * left) | (d > lim * right)) & (d / 3 >= dmin))[0]:
            # graded split: a third of the cell next to the small neighbour, so the rest of the
            # cell still fits its other neighbour (halving would cascade through graded cells)
            if d[i] > lim * left[i]:
                add.append(out[i] + d[i] / 3)
            if d[i] > lim * right[i]:
                add.append(out[i + 1] - d[i] / 3)
        if not add:
            break
        out = sorted(set(out + add))
    return out
