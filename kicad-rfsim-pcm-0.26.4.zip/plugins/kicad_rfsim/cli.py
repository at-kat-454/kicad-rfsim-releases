"""Command line interface: kicad-rfsim <command> ...

  info    board.kicad_pcb                      stackup, outline, counts
  rfpath  board.kicad_pcb --seed NET [...]     RF nets, parts, port candidates
  check   board.kicad_pcb --seed NET           closed-form Z0 / reference plane per RF net
  render  board.kicad_pcb --region x0 y0 x1 y1 --seed NET -o out.png
  build   sim.json                              write openEMS XML + preview picture
  run     sim.json                              run openEMS, write Touchstone
  simulate cfg.json                             full pipeline (circuit or antenna config) incl. viewer/report
  simulate-all rfsim_dir                        all configs of a project, antenna first
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from .board import Board
from .rfpath import find_rf_cluster


def _load_sim(path: str):
    from .openems_export import MeshSettings, ModelSettings, OpenEMSModel

    cfg = json.loads(Path(path).read_text())
    base = Path(path).parent
    board = Board(base / cfg["board"])
    mesh = MeshSettings(**cfg.get("mesh", {}))
    ms = ModelSettings(**{k: v for k, v in cfg.get("model", {}).items()}, mesh=mesh)
    ports = [tuple(p.split(".", 1)) for p in cfg["ports"]]
    model = OpenEMSModel(board, tuple(cfg["region"]), ports, ref_layer=cfg.get("ref_layer", "In1.Cu"), settings=ms)
    out = base / cfg.get("output", "rfsim_out") / cfg.get("name", Path(path).stem)
    return cfg, board, model, out


def main(argv=None):
    ap = argparse.ArgumentParser(prog="kicad-rfsim", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("info")
    p.add_argument("board")
    for name in ("rfpath", "check"):
        p = sub.add_parser(name)
        p.add_argument("board")
        p.add_argument("--seed", action="append", required=True, help="start net (repeatable)")
        p.add_argument("--boundary", action="append", default=[], help="extra boundary part refs")
        p.add_argument("--freq", type=float, default=868e6)
    p = sub.add_parser("render")
    p.add_argument("board")
    p.add_argument("--region", type=float, nargs=4, required=True)
    p.add_argument("--seed", action="append", default=[])
    p.add_argument("--layers", nargs="+", default=["F.Cu", "In1.Cu"])
    p.add_argument("-o", "--out", default="region.png")
    for name in ("build", "run"):
        p = sub.add_parser(name)
        p.add_argument("sim")
        p.add_argument("--threads", type=int, default=0)
        p.add_argument("--excite", type=int, nargs="*")
    p = sub.add_parser("simulate")
    p.add_argument("cfg")
    p.add_argument("--threads", type=int, default=0)
    p.add_argument("--force", action="store_true")
    p = sub.add_parser("simulate-all")
    p.add_argument("dir")
    p.add_argument("--threads", type=int, default=0)
    a = ap.parse_args(argv)
    if a.cmd in ("simulate", "simulate-all"):
        from .solver import console_meter, meter
        _m = meter(console_meter())
        _m.__enter__()
    if a.cmd == "simulate":
        from .pipeline import simulate
        print(simulate(a.cfg, threads=a.threads, force=a.force))
        return
    if a.cmd == "simulate-all":
        from .pipeline import simulate_all
        for r in simulate_all(Path(a.dir), threads=a.threads):
            print(r)
        return

    if a.cmd == "info":
        print(Board(a.board).summary())
    elif a.cmd in ("rfpath", "check"):
        b = Board(a.board)
        c = find_rf_cluster(b, a.seed, a.boundary)
        if a.cmd == "rfpath":
            print(c.describe(b))
        else:
            from . import analysis
            print(analysis.summarize(analysis.check_rf_tracks(b, c.nets), a.freq))
    elif a.cmd == "render":
        from .render import render_region
        b = Board(a.board)
        nets = find_rf_cluster(b, a.seed).nets if a.seed else []
        print(render_region(b, tuple(a.region), nets, None, layers=tuple(a.layers), out=a.out))
    elif a.cmd in ("build", "run"):
        from .openems_export import run, to_touchstone
        from .render import render_model
        cfg, board, model, out = _load_sim(a.sim)
        out.mkdir(parents=True, exist_ok=True)
        print(model.describe())
        render_model(model, str(out / "model_preview.png"))
        if a.cmd == "build":
            model.write_xml(out / "model.xml", excite=1)
            print(f"wrote {out / 'model.xml'}")
            return
        f = np.linspace(model.s.f_min, model.s.f_max, int(cfg.get("points", 271)))
        S = run(model, out, f, excite=a.excite, threads=a.threads)
        names = [p.name for p in model.ports]
        np.savez(out / "result.npz", f=f, S=S, names=np.array(names))
        ntw = to_touchstone(S, f, out / f"{cfg.get('name', 'layout')}.s{len(names)}p", names=names)
        print(f"wrote {out}  ({len(names)} ports)")


if __name__ == "__main__":
    sys.exit(main())
