"""Static radiation pattern sheets: six orthographic views of the 3D pattern and annotated polar cuts.

The 3D views are drawn with an own orthographic projection (painter's algorithm), so they do not depend
on matplotlib's 3D toolkit. Frame: x right, y up on the board, z out of the
top side; theta from +z, phi from +x towards +y. A view "Theta t, Phi p" looks at the pattern from the
direction (t, p).
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np

# rainbow colour scale (blue - cyan - green - yellow - orange - red)
RAINBOW_STOPS = [(0.0, "#0010ff"), (0.2, "#00b4ff"), (0.42, "#18d400"), (0.66, "#e8f000"), (0.84, "#ff9000"),
              (1.0, "#ff1400")]
WIRE = "#26306e"
AXES = (("x", (1, 0, 0), "#e01010"), ("y", (0, 1, 0), "#10b010"), ("z", (0, 0, 1), "#1030e0"))
# (name, view direction, screen up)
SIX_VIEWS = (("Theta = 0, Phi = 0", (0, 0, 1), (0, 1, 0)),
             ("Theta = 180, Phi = 0", (0, 0, -1), (0, 1, 0)),
             ("Theta = 90, Phi = 0", (1, 0, 0), (0, 0, 1)),
             ("Theta = 90, Phi = 180", (-1, 0, 0), (0, 0, 1)),
             ("Theta = 90, Phi = 270", (0, -1, 0), (0, 0, 1)),
             ("Theta = 90, Phi = 90", (0, 1, 0), (0, 0, 1)))


def rainbow_cmap():
    from matplotlib.colors import LinearSegmentedColormap
    return LinearSegmentedColormap.from_list("rainbow", RAINBOW_STOPS)


def _closed(theta, phi, A):
    """Add the phi = 360 column so the surface closes."""
    th = np.asarray(theta, float)
    ph = np.asarray(phi, float)
    A = np.asarray(A, float)
    if ph[-1] < 360 - 1e-6 and abs(ph[0]) < 1e-6:
        ph = np.append(ph, 360.0)
        A = np.concatenate([A, A[:, :1]], axis=1)
    return th, ph, A


def surface_points(theta, phi, A, floor):
    """Surface points (n_theta, n_phi, 3): radius = dB above the floor."""
    th, ph, A = _closed(theta, phi, A)
    T, P = np.meshgrid(np.deg2rad(th), np.deg2rad(ph), indexing="ij")
    r = np.maximum(A - floor, 0.0)
    u = np.stack([np.sin(T) * np.cos(P), np.sin(T) * np.sin(P), np.cos(T)], axis=-1)
    return th, ph, A, r[..., None] * u


def _basis(view, up):
    v = np.asarray(view, float)
    v /= np.linalg.norm(v)
    u = np.asarray(up, float)
    right = np.cross(u, v)  # screen x
    right /= np.linalg.norm(right)
    up2 = np.cross(v, right)
    return right, up2, v


def draw_view(ax, theta, phi, A, floor, top, view, up, cmap=None, wire_step=15.0, axis_len=1.3, shade=True,
              title=""):
    """One orthographic view of the 3D pattern on a 2D matplotlib axes."""
    from matplotlib.collections import PolyCollection

    cmap = cmap or rainbow_cmap()
    th, ph, Acl, S = surface_points(theta, phi, A, floor)
    right, up2, v = _basis(view, up)
    X, Y, Dp = S @ right, S @ up2, S @ v
    nt, npf = X.shape
    polys, fcs, ecs, lws = [], [], [], []
    items = []
    on = lambda a: abs(a / wire_step - round(a / wire_step)) < 1e-6  # noqa: E731
    for i in range(nt - 1):
        for j in range(npf - 1):
            q = [(i, j), (i, j + 1), (i + 1, j + 1), (i + 1, j)]
            pts = np.array([S[a, b] for a, b in q])
            depth = float(np.mean(pts @ v))
            val = float(np.mean([Acl[a, b] for a, b in q]))
            c = np.array(cmap((min(max(val, floor), top) - floor) / max(top - floor, 1e-9)))
            if shade:
                n = np.cross(pts[2] - pts[0], pts[3] - pts[1])
                nn = np.linalg.norm(n)
                lam = abs(float(n @ v)) / nn if nn > 0 else 1.0
                c[:3] *= 0.72 + 0.28 * lam
            edges = []
            if on(th[i]) and th[i] not in (0.0, 180.0):
                edges.append(((i, j), (i, j + 1)))
            if on(ph[j]):
                edges.append(((i, j), (i + 1, j)))
            items.append((depth, [(X[a, b], Y[a, b]) for a, b in q], c, edges))
    items.sort(key=lambda t: t[0])  # far (most negative along v) first
    for depth, poly, c, edges in items:
        polys.append(poly)
        fcs.append(c)
        ecs.append(c)
        lws.append(0.25)
        for (a, b), (cc, d) in edges:
            polys.append([(X[a, b], Y[a, b]), (X[cc, d], Y[cc, d])])
            fcs.append((0, 0, 0, 0))
            ecs.append(WIRE)
            lws.append(0.55)
    R = max(top - floor, 1e-9)
    L = axis_len * R
    # axes behind the pattern first, then the pattern, then the axes in front
    behind, front = [], []
    for name, e, col in AXES:
        e = np.asarray(e, float)
        (behind if float(e @ v) < -1e-9 else front).append((name, e, col))

    def axis(name, e, col, z):
        x1, y1 = L * float(e @ right), L * float(e @ up2)
        if abs(x1) < 1e-6 * L and abs(y1) < 1e-6 * L:
            ax.plot([0], [0], "o", color=col, ms=4, zorder=z)
            return
        ax.annotate("", xy=(x1, y1), xytext=(0, 0), zorder=z,
                    arrowprops=dict(arrowstyle="-|>", color=col, lw=1.4, mutation_scale=9, shrinkA=0, shrinkB=0))
        ax.text(x1 * 1.06, y1 * 1.06, name, color=col, fontsize=8, ha="left" if x1 >= -1e-9 else "right",
                va="bottom" if y1 >= -1e-9 else "top", zorder=z)

    for a in behind:
        axis(*a, z=1)
    ax.add_collection(PolyCollection(polys, facecolors=fcs, edgecolors=ecs, linewidths=lws, zorder=2))
    for a in front:
        axis(*a, z=3)
    lim = L * 1.12
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    ax.set_aspect("equal")
    ax.axis("off")
    if title:
        ax.set_title(title, fontsize=8, y=-0.08)


def lobes(ang, val):
    """Main lobe, 3 dB width and side lobe level of a closed cut. ang: uniform, without repeat."""
    val = np.asarray(val, float)
    n = len(val)
    m = int(np.argmax(val))
    top = float(val[m])
    step = float(ang[1] - ang[0])

    def edge(d):
        for s in range(1, n):
            i, p = (m + d * s) % n, (m + d * (s - 1)) % n
            if val[i] < top - 3:
                return (s - 1 + (val[p] - (top - 3)) / (val[p] - val[i])) * step
        return None

    def valley(d):
        s = 1
        while s < n and val[(m + d * s) % n] <= val[(m + d * (s - 1)) % n]:
            s += 1
        return s - 1

    lft, rgt = edge(-1), edge(1)
    a, b = valley(-1), valley(1)
    side = max((val[(m + s) % n] for s in range(b + 1, n - a)), default=None) if a + b < n - 1 else None
    return {"top": top, "dir": float(ang[m]), "width": None if lft is None or rgt is None else lft + rgt,
            "sll": None if side is None or lft is None or rgt is None else float(side) - top}


def cut(theta, phi, A, which):
    """A cut through the pattern. which: 0 or 90 (phi plane, angle = theta 0..360), 'h' (theta = 90)."""
    th, ph, A = np.asarray(theta, float), np.asarray(phi, float), np.asarray(A, float)
    if which == "h":
        i = int(np.argmin(abs(th - 90)))
        return ph.copy(), A[i].copy()
    j = int(np.argmin(abs(((ph - which) + 180) % 360 - 180)))
    j2 = int(np.argmin(abs(((ph - which - 180) + 180) % 360 - 180)))
    ang = np.concatenate([th, 360 - th[1:-1][::-1]])
    val = np.concatenate([A[:, j], A[1:-1, j2][::-1]])
    return ang, val


def lobe_text(L, which, f_hz=None, unit="dBi"):
    d = L["dir"]
    if which == "h":
        dtxt = f"Phi = {d:.0f}°"
    elif d <= 180:
        dtxt = f"Theta = {d:.0f}°"
    else:
        dtxt = f"Theta = {360 - d:.0f}°, Phi = {(which + 180) % 360:.0f}°"
    rows = ([f"Frequency = {f_hz / 1e6:.1f} MHz"] if f_hz else []) + [
        f"Main lobe magnitude = {L['top']:.2f} {unit}", f"Main lobe direction = {dtxt}",
        "Angular width (3 dB) = " + ("-" if L["width"] is None else f"{L['width']:.1f}°"),
        "Side lobe level = " + ("-" if L["sll"] is None else f"{L['sll']:.1f} dB")]
    return "\n".join(rows)


def draw_cut(ax, theta, phi, comps, which, floor, top, f_hz=None, title="", info=True):
    """Polar cut. comps: list of (label, A_dB, style); the first one is analysed."""
    for k, (lab, A, st) in enumerate(comps):
        ang, val = cut(theta, phi, A, which)
        a = np.deg2rad(np.append(ang, ang[0] + 360))
        ax.plot(a, np.maximum(np.append(val, val[0]), floor), st, lw=1.6 if k == 0 else 1.0, label=lab)
    ax.set_theta_zero_location("N")
    ax.set_theta_direction(-1)
    ax.set_ylim(floor, top + 1)
    ax.set_rlabel_position(45)
    ax.tick_params(labelsize=7)
    ax.grid(alpha=0.4)
    if title:
        ax.set_title(title, fontsize=9, pad=12)
    if info and comps:
        ang, val = cut(theta, phi, comps[0][1], which)
        ax.text(1.08, 0.02, lobe_text(lobes(ang, val), which, f_hz), transform=ax.transAxes, fontsize=7,
                va="bottom", ha="left", family="monospace")


def six_view_figure(theta, phi, A, floor=None, top=None, title="", cbar_label="dBi", cmap=None, fig=None):
    """Six orthographic views with one colour bar."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.cm import ScalarMappable
    from matplotlib.colors import Normalize

    A = np.asarray(A, float)
    top = float(np.max(A)) if top is None else top
    floor = float(np.min(A)) if floor is None else floor
    cmap = cmap or rainbow_cmap()
    fig = fig or plt.figure(figsize=(9.6, 6.0))
    gs = fig.add_gridspec(2, 4, width_ratios=[1, 1, 1, 0.12], wspace=0.05, hspace=0.18)
    for k, (name, view, up) in enumerate(SIX_VIEWS):
        ax = fig.add_subplot(gs[k // 3, k % 3])
        draw_view(ax, theta, phi, A, floor, top, view, up, cmap=cmap, title=name)
    cax = fig.add_subplot(gs[0, 3])
    sm = ScalarMappable(norm=Normalize(floor, top), cmap=cmap)
    cb = fig.colorbar(sm, cax=cax, ticks=np.linspace(floor, top, 5))
    cb.ax.set_yticklabels([f"{t:.2f}" for t in np.linspace(floor, top, 5)], fontsize=7)
    cb.set_label(cbar_label, fontsize=8)
    if title:
        fig.suptitle(title, fontsize=10)
    return fig


def write_pattern_sheet(ffd: dict, f_hz: float, path, quantity: str = "gain", rng: float | None = None,
                        title: str = "") -> Path:
    """One page per far-field frequency: six views and three annotated cuts.

    ffd: far-field dict of one frequency (D, theta, phi, Prad, Pinc, optional Dth/Dph).
    quantity: 'gain' (realised gain = EIRP at 0 dBm into the feed) or 'directivity'.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    db = lambda a: 10 * np.log10(np.maximum(np.asarray(a, float), 1e-6))  # noqa: E731
    off = 10 * math.log10(max(ffd["Prad"] / ffd["Pinc"], 1e-9)) if quantity == "gain" else 0.0
    th, ph = np.asarray(ffd["theta"]), np.asarray(ffd["phi"])
    A = db(ffd["D"]) + off
    top = float(A.max())
    floor = max(float(A.min()), top - 60) if rng is None else top - rng
    qn = "Realised gain (dBi)" if quantity == "gain" else "Directivity (dBi)"
    fig = plt.figure(figsize=(11.0, 11.0))
    sub = fig.add_gridspec(2, 1, height_ratios=[1.3, 1], hspace=0.02)
    top_fig = fig.add_subfigure(sub[0])
    six_view_figure(th, ph, A, floor, top, title=f"{title}  {qn} at {f_hz / 1e6:.1f} MHz".strip(), fig=top_fig)
    comps = [("total", A, "-")]
    if "Dth" in ffd:
        comps += [("Eθ", db(ffd["Dth"]) + off, "--"), ("Eφ", db(ffd["Dph"]) + off, ":")]
    bot = fig.add_subfigure(sub[1])
    gs = bot.add_gridspec(1, 3, wspace=0.75)
    for k, (which, lab) in enumerate(((0, "Phi = 0 (xz), angle = Theta"), (90, "Phi = 90 (yz), angle = Theta"),
                                      ("h", "Theta = 90 (xy), angle = Phi"))):
        ax = bot.add_subplot(gs[0, k], projection="polar")
        draw_cut(ax, th, ph, comps, which, floor, top, f_hz=None, title=lab, info=False)
        ang, val = cut(th, ph, A, which)
        ax.text(0.5, -0.32, lobe_text(lobes(ang, val), which), transform=ax.transAxes, fontsize=7, ha="center",
                va="top", family="monospace")
        if k == 0:
            ax.legend(loc="upper left", bbox_to_anchor=(-0.35, 1.18), fontsize=7, frameon=False)
    path = Path(path)
    fig.savefig(path, dpi=110)
    plt.close(fig)
    return path


def write_pattern_sheets(res, out_dir, title: str = "", quantity: str = "gain") -> list[Path]:
    """Pattern sheets (PNG) for all far-field frequencies of an antenna result."""
    out = []
    for fx, d in res.farfield.items():
        if not (np.isfinite(d.get("Pinc", np.nan)) and d["Pinc"] > 0 and np.all(np.isfinite(d["D"]))):
            continue
        out.append(write_pattern_sheet(d, fx, Path(out_dir) / f"pattern_{fx / 1e6:.0f}MHz.png", quantity,
                                       title=title))
    return out


ctia_cmap = rainbow_cmap  # older name
