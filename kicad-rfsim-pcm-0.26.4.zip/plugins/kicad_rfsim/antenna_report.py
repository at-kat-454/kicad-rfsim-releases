"""Self-contained HTML report for an antenna simulation."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import shapely

from .viewer import _plotly_tag


def _geometry_traces(model, max_sheets: int = 4000):
    """Triangulated sheets for a 3D preview (antenna copper highlighted)."""
    tr = {"ant": ([], [], [], [], [], []), "board": ([], [], [], [], [], []), "diel": ([], [], [], [], [], [])}

    def add(key, axis, elev, poly):
        n = axis
        a1, a2 = (n + 1) % 3, (n + 2) % 3
        try:
            tris = shapely.constrained_delaunay_triangles(poly)
        except Exception:
            return
        X, Y, Z, I, J, K = tr[key]
        for t in getattr(tris, "geoms", []):
            c = list(t.exterior.coords)[:3]
            base = len(X)
            for u, v in c:
                p = [0.0, 0.0, 0.0]
                p[a1], p[a2], p[n] = u, v, elev
                X.append(round(p[0], 3)); Y.append(round(p[1], 3)); Z.append(round(p[2], 3))
            I.append(base); J.append(base + 1); K.append(base + 2)

    for sh in model.sheets[:max_sheets]:
        add("ant" if sh["antenna"] else "board", sh["axis"], sh["elev"], sh["poly"].simplify(0.05))
    for sl in model.slabs:
        add("diel", sl["axis"], sl["elev"], sl["poly"].simplify(0.05))
    return tr


def write_report(model, res, path, title="Antenna simulation", load_note: str = "", sheets=(), band=None):
    f = res.f
    zin = res.zin
    s11 = res.s11
    ff = []
    dead = not np.all(np.isfinite(s11)) or not np.any(np.abs(np.asarray(res.zin)) > 0)
    for fx, d in res.farfield.items():
        th, ph, D = np.asarray(d["theta"]), np.asarray(d["phi"]), np.asarray(d["D"])
        Pinc = d["Pinc"]
        if not (np.isfinite(Pinc) and Pinc > 0 and np.all(np.isfinite(D))):
            dead = True  # no power entered the antenna: no pattern to show
            continue
        G_real = D * d["Prad"] / Pinc
        db = lambda a: np.round(10 * np.log10(np.maximum(np.asarray(a), 1e-6)), 2).tolist()  # noqa: E731
        pol = {"Dth": db(d["Dth"]), "Dph": db(d["Dph"])} if "Dth" in d and np.shape(d["Dth"]) == D.shape else {}
        ff.append({
            "f": fx, "theta": th.tolist(), "phi": ph.tolist(), **pol,
            "gdb": float(10 * np.log10(max(d["Prad"] / Pinc, 1e-9))),
            "DdBi": db(D),
            "Dmax": 10 * np.log10(d["Dmax"]), "eff_rad": d["eff_rad"],
            "eff_tot": d["Prad"] / Pinc, "Gmax_real": 10 * np.log10(max(G_real.max(), 1e-9)),
            "mismatch": 10 * np.log10(max(d["Pacc"] / Pinc, 1e-9)),
        })
    geo = _geometry_traces(model)
    try:
        from .enclosure import model_traces
        geo["casing"] = model_traces(model, opacity=0.15)
    except Exception:  # noqa: BLE001
        geo["casing"] = []
    data = {"title": title, "f": f.tolist(), "zr": zin.real.round(3).tolist(), "zi": zin.imag.round(3).tolist(),
            "s11": (20 * np.log10(np.abs(s11) + 1e-12)).round(3).tolist(), "ff": ff, "geo": geo,
            "describe": model.describe(), "sheets": [Path(x).name for x in sheets],
            "band": [[lo * 1e6, hi * 1e6] for lo, hi in band] if band else None,
            "note": (("NO RESULT: no power entered the antenna (the excitation did not reach the simulation). "
                      "The curves below are meaningless. ") if dead else "") + load_note}
    from .bands import js as _bands_js
    from .pagepack import pack_page
    html = pack_page(_TPL.replace("__PLOTLY__", _plotly_tag(path)).replace("__TITLE__", title)
                     .replace("__BANDSJS__", _bands_js()), data)
    Path(path).write_text(html, encoding="utf-8")
    return path


_TPL = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>__PLOTLY__
<style>
:root{--bg:#fafaf8;--fg:#1d1d1b;--mut:#6b6b66;--card:#fff;--line:#e3e2dc;--acc:#2a6fdb}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff}}
:root[data-theme="dark"]{--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 system-ui,sans-serif}
header{padding:14px 16px;border-bottom:1px solid var(--line)}h1{font-size:17px;margin:0}.sub{color:var(--mut);font-size:12px}
main{padding:14px 16px;display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(420px,1fr))}
@media(max-width:480px){main{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px;min-width:0}
.plot{height:360px}.tall{height:440px}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;font-size:13px}
td,th{padding:4px 6px;border-bottom:1px solid var(--line);text-align:right}td:first-child,th:first-child{text-align:left}
pre{white-space:pre-wrap;font-size:12px;color:var(--mut)}select{font:inherit}
.ctl{display:flex;flex-wrap:wrap;gap:6px 16px;align-items:center;font-size:13px;color:var(--mut)}.ctl label{display:flex;gap:6px;align-items:center}
</style></head><body>
<header><a class="sinfo" href="solver_info.html" style="float:right;font-size:12px;color:var(--acc)">How this was solved →</a><h1 id="t"></h1><div class="sub" id="note"></div></header>
<main>
<section class="card" style="grid-column:1/-1"><div class="ctl"><label>Band <select id="band" style="max-width:320px"></select></label>
<label title="Touchstone file of a VNA measurement of the antenna (.s1p), drawn over the simulation">Measurement <input type="file" id="meas" accept=".s1p,.S1P,.s2p,.S2P,.txt" style="max-width:200px"></label>
<span id="measinfo" class="sub"></span>
<label>Show <select id="qty"><option value="db">|S11| in dB</option><option value="lin">|S11| linear</option><option value="vswr">VSWR</option>
<option value="rl">return loss (dB)</option><option value="ml">mismatch loss (dB)</option></select></label>
<label>Y axis <select id="yr"><option value="auto">auto</option><option value="10">0 … 10 dB</option><option value="20">0 … 20 dB</option>
<option value="40">0 … 40 dB</option><option value="60">0 … 60 dB</option></select></label>
<button id="ts" style="font:inherit;font-size:12px" title="S11 at the feed (50 ohm) as a Touchstone file">S11 as Touchstone (.s1p)</button>
<span id="bandsum"></span></div></section>
<section class="card"><div style="font-weight:600">Far field</div><table id="tab"></table>
<div class="sub" style="margin-top:6px">Total efficiency and realised gain include the mismatch to 50 Ω at the feed.</div><pre id="desc"></pre></section>
<section class="card"><div id="p1" class="plot"></div></section>
<section class="card"><div id="p2" class="plot"></div></section>
<section class="card"><div id="p6" class="plot"></div></section>
<section class="card" style="grid-column:1/-1"><div class="ctl"><label>Pattern at <select id="fsel"></select></label>
<label>Quantity <select id="qsel"><option value="d">Directivity (dBi)</option><option value="g">Realised gain (dBi) = EIRP at 0 dBm</option></select></label>
<label>Polarisation <select id="csel"><option value="abs">total (abs)</option><option value="th">E&theta; only</option><option value="ph">E&phi; only</option></select></label>
<label>Style <select id="ssel"><option value="ctia">rainbow with grid</option><option value="smooth">smooth</option></select></label>
<label>range <select id="prng"><option value="full">min to max</option><option value="20">20 dB</option><option value="30">30 dB</option><option value="40">40 dB</option></select></label></div>
<div class="ctl" style="margin-top:6px"><label>View <select id="vsel"><option value="free">3D, free</option><option value="six">six views</option>
<option value="t0">Theta 0 (from +z, top)</option><option value="t180">Theta 180 (from -z, bottom)</option><option value="p0">Theta 90, Phi 0 (from +x)</option>
<option value="p180">Theta 90, Phi 180 (from -x)</option><option value="p90">Theta 90, Phi 90 (from +y)</option><option value="p270">Theta 90, Phi 270 (from -y)</option></select></label>
<label><input type="checkbox" id="onb" checked> over the board</label>
<label>size <input type="range" id="psz" min="20" max="250" value="90"></label>
<label>opacity <input type="range" id="pop" min="15" max="100" value="100"></label></div>
<div id="p3" style="height:600px"></div>
<div class="sub">x right, y up on the board, z out of the top side; &theta; from +z, &phi; from +x. Views: the direction the
pattern is seen from. Realised gain includes the feed mismatch (= EIRP in dBm at 0 dBm in). <span id="sheets"></span></div></section>
<section class="card" style="grid-column:1/-1"><div class="ctl"><label>Cut <select id="cutsel"><option value="0">Phi = 0 (xz plane)</option>
<option value="90">Phi = 90 (yz plane)</option><option value="h">Theta = 90 (xy plane)</option></select></label>
</div>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:10px"><div id="p4" style="height:440px"></div>
<div><table id="cuttab"></table></div></div></section>
<section class="card"><div id="p5" class="tall"></div></section>
</main>
<script>__BANDSJS__
const D=__DATA__;document.getElementById('t').textContent=D.title;document.getElementById('note').textContent=D.note;
document.getElementById('desc').textContent=D.describe;
const css=getComputedStyle(document.documentElement),fg=css.getPropertyValue('--fg'),ln=css.getPropertyValue('--line');
const base=(t)=>({title:{text:t,font:{size:13}},margin:{l:50,r:10,t:36,b:40},paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{color:fg},
 xaxis:{gridcolor:ln},yaxis:{gridcolor:ln},legend:{orientation:'h',y:-0.2}});
const fG=D.f.map(x=>x/1e9);const cfg={responsive:true,displaylogo:false};
const marks=D.ff.map(o=>({type:'line',x0:o.f/1e9,x1:o.f/1e9,yref:'paper',y0:0,y1:1,line:{dash:'dot',width:1,color:'#999'}}));
// ---- reflection at the feed: |S11| dB / linear, VSWR, return loss, mismatch loss (as in the tuning viewer)
const gm=(zr,zi)=>Math.hypot(zr-50,zi)/Math.max(1e-12,Math.hypot(zr+50,zi));
const QTY={db:{n:'|S11|',u:'dB',f:g=>20*Math.log10(g+1e-15),r:'neg'},lin:{n:'|S11|',u:'',f:g=>g},
 vswr:{n:'VSWR',u:'',f:g=>(1+g)/Math.max(1e-9,1-g)},rl:{n:'return loss',u:'dB',f:g=>-20*Math.log10(g+1e-15),r:'pos'},
 ml:{n:'mismatch loss',u:'dB',f:g=>-10*Math.log10(Math.max(1e-15,1-g*g)),r:'pos'}};
let MEAS=null;
function drawP1(){const q=document.getElementById('qty').value,Q=QTY[q],yr=document.getElementById('yr').value;
 const tr=[{x:fG,y:D.zr.map((r,k)=>Q.f(gm(r,D.zi[k]))),name:Q.n+' (50 Ω)'}];
 if(MEAS)tr.push({x:MEAS.f.map(x=>x/1e9),y:MEAS.zr.map((r,k)=>Q.f(gm(r,MEAS.zi[k]))),name:(q==='db'||q==='lin'?'S11':Q.n)+' measured',meas:true,line:{color:'#7b3fb0'}});
 const el=document.getElementById('p1'),lay=el.layout?{...el.layout}:{...base('Reflection at the feed'),xaxis:{title:{text:'f / GHz'},gridcolor:ln},shapes:marks};
 const rng=yr!=='auto'&&Q.r?{range:Q.r==='neg'?[-(+yr),0]:[0,+yr],autorange:false}:(q==='vswr'&&yr!=='auto'?{range:[1,10],autorange:false}:{autorange:true});
 lay.yaxis={title:{text:Q.u?Q.n+' / '+Q.u:Q.n},gridcolor:ln,...rng};Plotly.react('p1',tr,lay,cfg)}
drawP1();['qty','yr'].forEach(id=>document.getElementById(id).onchange=drawP1);
Plotly.newPlot('p2',[{x:fG,y:D.zr,name:'R'},{x:fG,y:D.zi,name:'X'}],{...base('Feed impedance'),xaxis:{title:'f / GHz',gridcolor:ln},yaxis:{title:'Ω',gridcolor:ln},shapes:marks},cfg);
{const t=D.f.map(f=>(f/1e6).toFixed(0)+' MHz');const mk=(D.ff||[]).map(o=>o.f).filter(Boolean);
 const ki=mk.map(fm=>D.f.reduce((b,f,k)=>Math.abs(f-fm)<Math.abs(D.f[b]-fm)?k:b,0));
 Plotly.newPlot('p6',[{type:'scattersmith',real:D.zr.map(r=>r/50),imag:D.zi.map(x=>x/50),mode:'lines',name:'Zin',text:t,
  hovertemplate:'%{text}<br>z = %{real:.2f} %{imag:+.2f}j<extra></extra>'},
  {type:'scattersmith',real:ki.map(k=>D.zr[k]/50),imag:ki.map(k=>D.zi[k]/50),mode:'markers+text',text:ki.map(k=>(D.f[k]/1e6).toFixed(0)),
  textposition:'top right',marker:{size:8},name:'far-field frequencies',hoverinfo:'skip'}],
  {...base('Feed impedance on the Smith chart (Z₀ = 50 Ω)'),smith:{bgcolor:'rgba(0,0,0,0)',realaxis:{gridcolor:ln},imaginaryaxis:{gridcolor:ln}}},cfg)}
// ---- Touchstone export of S11 at the feed
document.getElementById('ts').onclick=()=>{let t=`! RF Sim - ${D.title}\n! S11 at the antenna feed (lumped port, 50 ohm), from Zin\n# Hz S RI R 50\n`;
 D.f.forEach((f,k)=>{const zr=D.zr[k],zi=D.zi[k],d=(zr+50)**2+zi**2,gr=((zr-50)*(zr+50)+zi*zi)/d,gi=(zi*(zr+50)-(zr-50)*zi)/d;
  t+=`${f.toFixed(0)} ${gr.toExponential(9)} ${gi.toExponential(9)}\n`});
 const name=(D.title||'antenna').replace(/[^\w]+/g,'_')+'.s1p';const host=window.rfsim&&window.rfsim.postMessage?window.rfsim:null;
 if(host){host.postMessage(JSON.stringify({type:'save',name,text:t}));return}
 const b=new Blob([t],{type:'text/plain'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click()};
// ---- measurement overlay (Touchstone .s1p; for .s2p S11 is used)
function parseTS(txt,name){let unit=1e9,fmt='MA',R=50;const nums=[];
 for(let l of txt.split(/\r?\n/)){l=l.split('!')[0].trim();if(!l)continue;
  if(l.startsWith('#')){const t=l.slice(1).trim().toUpperCase().split(/\s+/);t.forEach((w,i)=>{if(w==='HZ')unit=1;else if(w==='KHZ')unit=1e3;else if(w==='MHZ')unit=1e6;else if(w==='GHZ')unit=1e9;
   else if(w==='DB'||w==='MA'||w==='RI')fmt=w;else if(w==='R'&&t[i+1])R=+t[i+1]});continue}
  if(/^\[/.test(l))continue;l.split(/\s+/).forEach(x=>{const v=+x;if(!isNaN(v))nums.push(v)})}
 const np=/s2p$/i.test(name)?2:1,per=1+2*np*np,out={f:[],zr:[],zi:[],db:[]};
 for(let i=0;i+per<=nums.length;i+=per){const a=nums[i+1],b=nums[i+2];let g=fmt==='RI'?[a,b]:fmt==='MA'?[a*Math.cos(b*Math.PI/180),a*Math.sin(b*Math.PI/180)]:[10**(a/20)*Math.cos(b*Math.PI/180),10**(a/20)*Math.sin(b*Math.PI/180)];
  const d=(1-g[0])**2+g[1]**2,zr=R*(1-g[0]**2-g[1]**2)/d,zi=R*2*g[1]/d;const gr=[(zr-50),zi],gd=[(zr+50),zi],m=Math.hypot(...gr)/Math.hypot(...gd);
  out.f.push(nums[i]*unit);out.zr.push(zr);out.zi.push(zi);out.db.push(20*Math.log10(m+1e-15))}
 return out.f.length?out:null}
document.getElementById('meas').onchange=e=>{const fl=e.target.files[0];if(!fl)return;const rd=new FileReader();rd.onload=()=>{const M=parseTS(rd.result,fl.name);
 const info=document.getElementById('measinfo');if(!M){info.textContent=' not a Touchstone file';return}
 info.textContent=` ${fl.name}: ${M.f.length} points`;const mG=M.f.map(x=>x/1e9),col='#7b3fb0';
 for(const id of ['p2','p6']){const el=document.getElementById(id);const keep=el.data.filter(t=>!t.meas);Plotly.react(id,keep,el.layout,cfg)}
 MEAS=M;drawP1();
 Plotly.addTraces('p2',[{x:mG,y:M.zr,name:'R measured',meas:true,line:{color:col}},{x:mG,y:M.zi,name:'X measured',meas:true,line:{color:col,dash:'dash'}}]);
 Plotly.addTraces('p6',[{type:'scattersmith',real:M.zr.map(r=>r/50),imag:M.zi.map(x=>x/50),mode:'lines',name:'measured',meas:true,line:{color:col},
  text:M.f.map(f=>(f/1e6).toFixed(0)+' MHz'),hovertemplate:'%{text}<br>z = %{real:.2f} %{imag:+.2f}j<extra>measured</extra>'}])};rd.readAsText(fl)};
let h='<tr><th>f</th><th>D<sub>max</sub></th><th>η<sub>rad</sub></th><th>η<sub>tot</sub></th><th>G<sub>real,max</sub></th><th>mismatch</th></tr>';
for(const o of D.ff)h+=`<tr><td>${(o.f/1e6).toFixed(0)} MHz</td><td>${o.Dmax.toFixed(2)} dBi</td><td>${(100*o.eff_rad).toFixed(1)} %</td><td>${(100*o.eff_tot).toFixed(1)} %</td><td>${o.Gmax_real.toFixed(2)} dBi</td><td>${o.mismatch.toFixed(2)} dB</td></tr>`;
document.getElementById('tab').innerHTML=h;
const sel=document.getElementById('fsel');D.ff.forEach((o,i)=>{const op=document.createElement('option');op.value=i;op.textContent=(o.f/1e6).toFixed(0)+' MHz';sel.appendChild(op)});
const G=D.geo;function geoTraces(){const out=[];const add=(k,c,name,op)=>{const a=G[k];if(a&&a[0].length)out.push({type:'mesh3d',x:a[0],y:a[1],z:a[2],i:a[3],j:a[4],k:a[5],color:c,opacity:op,name,flatshading:true,hoverinfo:'name',showlegend:false})};
 add('diel','#2f6b3a','board',0.55);add('board','#b08d3c','board copper',0.35);add('ant','#d0661c','antenna copper',1.0);(G.casing||[]).forEach(m=>out.push(Object.assign({},m,{showlegend:false,hoverinfo:'name'})));return out}
function bbox(keys){let lo=[1e9,1e9,1e9],hi=[-1e9,-1e9,-1e9];for(const k of keys){const a=G[k];if(!a)continue;for(let q=0;q<3;q++)for(const v of a[q]){if(v<lo[q])lo[q]=v;if(v>hi[q])hi[q]=v}}return[lo,hi]}
const [alo,ahi]=bbox(['ant']),[glo,ghi]=bbox(['diel','board','ant']);
const ctr=alo[0]<1e8?alo.map((v,q)=>(v+ahi[q])/2):[0,0,0];const ext=glo[0]<1e8?Math.max(...ghi.map((v,q)=>v-glo[q])):50;
const RAINBOW=[[0,'#0010ff'],[0.2,'#00b4ff'],[0.42,'#18d400'],[0.66,'#e8f000'],[0.84,'#ff9000'],[1,'#ff1400']];
const VIEWS={t0:{e:[0,0,1],u:[0,1,0],n:'Theta = 0, Phi = 0'},t180:{e:[0,0,-1],u:[0,1,0],n:'Theta = 180, Phi = 0'},
 p0:{e:[1,0,0],u:[0,0,1],n:'Theta = 90, Phi = 0'},p180:{e:[-1,0,0],u:[0,0,1],n:'Theta = 90, Phi = 180'},
 p270:{e:[0,-1,0],u:[0,0,1],n:'Theta = 90, Phi = 270'},p90:{e:[0,1,0],u:[0,0,1],n:'Theta = 90, Phi = 90'}};
const SIX=['t0','t180','p0','p180','p270','p90'];
const $=(id)=>document.getElementById(id);
function patData(o,comp){const q=$('qsel').value,c=comp||$('csel').value,off=q==='g'?(o.gdb||0):0;
 const pick=c==='th'&&o.Dth?o.Dth:c==='ph'&&o.Dph?o.Dph:o.DdBi;const A=pick.map(r=>r.map(v=>v+off));
 const top=Math.max(...o.DdBi.flat())+off,mn=Math.min(...o.DdBi.flat())+off,r=$('prng').value;
 const floor=r==='full'?Math.max(mn,top-60):top-(+r);
 return{A,top,floor,name:(q==='g'?'Realised gain':'Directivity')+(c==='th'?' (Eθ)':c==='ph'?' (Eφ)':'')}}
function ticks(P){const v=[0,1,2,3,4].map(i=>P.floor+(P.top-P.floor)*i/4);return{tickvals:v,ticktext:v.map(x=>x.toFixed(2))}}
function patTraces(o,P,opt){const ctia=opt.style==='ctia',th=o.theta.map(x=>x*Math.PI/180),ph=o.phi.map(x=>x*Math.PI/180),A=P.A;
 const k=opt.k,org=opt.org,sc=opt.scene||'scene',rad=(i,j)=>Math.max(A[i][j]-P.floor,0)*k;
 const U=(t,p)=>[Math.sin(t)*Math.cos(p),Math.sin(t)*Math.sin(p),Math.cos(t)];
 const X=[],Y=[],Z=[],C=[];let best=[0,0,1],bv=-1e9;
 for(let i=0;i<th.length;i++){const xr=[],yr=[],zr=[],cr=[];for(let j=0;j<=ph.length;j++){const jj=j%ph.length,r=rad(i,jj),u=U(th[i],ph[jj]);
  if(A[i][jj]>bv){bv=A[i][jj];best=u}xr.push(org[0]+r*u[0]);yr.push(org[1]+r*u[1]);zr.push(org[2]+r*u[2]);cr.push(A[i][jj])}
  X.push(xr);Y.push(yr);Z.push(zr);C.push(cr)}
 const out=[{type:'surface',x:X,y:Y,z:Z,surfacecolor:C,colorscale:ctia?RAINBOW:'Viridis',cmin:P.floor,cmax:P.top,scene:sc,
  showscale:!!opt.showscale,colorbar:Object.assign({title:{text:'dBi'},len:0.42,y:1,yanchor:'top',thickness:14,x:1},ticks(P)),
  opacity:opt.opacity,name:P.name,hovertemplate:'%{surfacecolor:.2f} dBi<extra></extra>',
  lighting:ctia?{ambient:0.8,diffuse:0.4,specular:0.05,roughness:0.9}:{},contours:{x:{highlight:false},y:{highlight:false},z:{highlight:false}}}];
 const R=Math.max((P.top-P.floor)*k,1e-9);
 if(ctia){const lx=[],ly=[],lz=[],on=(v)=>Math.abs(v/15-Math.round(v/15))<1e-6,f=1.004,pt=(i,j)=>{const r=rad(i,j)*f,u=U(th[i],ph[j]);
   lx.push(org[0]+r*u[0]);ly.push(org[1]+r*u[1]);lz.push(org[2]+r*u[2])},gap=()=>{lx.push(null);ly.push(null);lz.push(null)};
  o.theta.forEach((t,i)=>{if(!on(t)||t===0||t===180)return;for(let j=0;j<=ph.length;j++)pt(i,j%ph.length);gap()});
  o.phi.forEach((p,j)=>{if(!on(p))return;for(let i=0;i<th.length;i++)pt(i,j);gap()});
  out.push({type:'scatter3d',mode:'lines',x:lx,y:ly,z:lz,line:{color:'#26306e',width:1.6},hoverinfo:'skip',showlegend:false,scene:sc});
  const L=R*1.3,ax=[[1,0,0,'#e01010','x'],[0,1,0,'#10b010','y'],[0,0,1,'#1030e0','z']];
  for(const [a,b,c,col,nm] of ax){const tip=[org[0]+a*L,org[1]+b*L,org[2]+c*L];
   out.push({type:'scatter3d',mode:'lines+text',x:[org[0],tip[0]],y:[org[1],tip[1]],z:[org[2],tip[2]],text:['',nm],textposition:'middle right',
    textfont:{color:col,size:13},line:{color:col,width:5},hoverinfo:'skip',showlegend:false,scene:sc});
   out.push({type:'cone',x:[tip[0]],y:[tip[1]],z:[tip[2]],u:[a],v:[b],w:[c],anchor:'tip',sizemode:'absolute',sizeref:L*0.09,
    colorscale:[[0,col],[1,col]],showscale:false,hoverinfo:'skip',scene:sc})}}
 else{const L=R*1.25;out.push({type:'scatter3d',mode:'lines+text',x:[org[0],org[0]+L*best[0]],y:[org[1],org[1]+L*best[1]],z:[org[2],org[2]+L*best[2]],
  line:{width:6,color:'#e8453c'},text:['',`max ${P.top.toFixed(1)} dBi`],textposition:'top center',hoverinfo:'skip',showlegend:false,scene:sc})}
 return out}
function cam(v,d){const V=VIEWS[v];d=d||1.2;return{eye:{x:d*V.e[0],y:d*V.e[1],z:d*V.e[2]},up:{x:V.u[0],y:V.u[1],z:V.u[2]},center:{x:0,y:0,z:0},projection:{type:'orthographic'}}}
function pattern(){const o=D.ff[+sel.value||0];if(!o){return}
 const P=patData(o),v=$('vsel').value,style=$('ssel').value,ctia=style==='ctia';
 const noax={visible:false,showgrid:false,zeroline:false,showbackground:false};
 if(v==='six'){const tr=[],lay={...base(`${P.name} at ${(o.f/1e6).toFixed(0)} MHz, six views`),showlegend:false,annotations:[]};
  SIX.forEach((w,n)=>{const sc=n?'scene'+(n+1):'scene',c=n%3,r=Math.floor(n/3);
   tr.push(...patTraces(o,P,{k:1,org:[0,0,0],style,scene:sc,showscale:n===0,opacity:1}));
   const R=1.38*(P.top-P.floor),ax={...noax,range:[-R,R]};
   lay[sc]={domain:{x:[c/3,(c+1)/3-0.01],y:[r?0:0.5,r?0.47:0.95]},aspectmode:'manual',aspectratio:{x:1.9,y:1.9,z:1.9},xaxis:ax,yaxis:ax,zaxis:ax,camera:cam(w),dragmode:false};
   lay.annotations.push({text:VIEWS[w].n,x:(c+0.5)/3,y:r?0:0.5,xref:'paper',yref:'paper',showarrow:false,yanchor:'top',font:{size:12}})});
  Plotly.react('p3',tr,lay,cfg);cuts(o,P);return}
 const onb=$('onb').checked,k=onb?(+$('psz').value/100)*ext/2/Math.max(P.top-P.floor,1):1,org=onb?ctr:[0,0,0];
 const tr=(onb?geoTraces():[]).concat(patTraces(o,P,{k,org,style,showscale:true,opacity:onb?+$('pop').value/100:1}));
 const axs=(t)=>ctia?noax:{title:t};
 const scene={aspectmode:'data',xaxis:axs(onb?'x / mm':'x'),yaxis:axs(onb?'y / mm':'y'),zaxis:axs(onb?'z / mm':'z')};
 if(v!=='free'){scene.camera=cam(v);if(!onb){const R=1.38*(P.top-P.floor);for(const q of ['xaxis','yaxis','zaxis'])scene[q]={...scene[q],range:[-R,R]};
  scene.aspectmode='manual';scene.aspectratio={x:1.5,y:1.5,z:1.5}}}else scene.camera={eye:{x:0.95,y:-0.95,z:0.65}};
 Plotly.react('p3',tr,{...base(`${P.name} at ${(o.f/1e6).toFixed(0)} MHz`+(onb?' over the board':'')+(v!=='free'?', '+VIEWS[v].n:'')),
  showlegend:false,scene,uirevision:v+style+(onb?1:0)},cfg);cuts(o,P)}
// ---- polar cuts with main lobe, 3 dB width and side lobe level
function lobes(ang,val){const n=val.length;let m=0;for(let i=1;i<n;i++)if(val[i]>val[m])m=i;const top=val[m];
 const wrap=(i)=>((i%n)+n)%n,step=(ang[1]-ang[0]);
 const edge=(dir)=>{for(let s=1;s<n;s++){const i=wrap(m+dir*s),p=wrap(m+dir*(s-1));if(val[i]<top-3){const fr=(val[p]-(top-3))/(val[p]-val[i]);return(s-1+fr)*step}}return null};
 const l=edge(-1),r=edge(1),width=l!=null&&r!=null?l+r:null;
 const valley=(dir)=>{let s=1;while(s<n&&val[wrap(m+dir*s)]<=val[wrap(m+dir*(s-1))])s++;return s-1};
 const a=valley(-1),b=valley(1);let side=null;
 if(a+b<n-1){for(let s=b+1;s<n-a;s++){const v=val[wrap(m+s)];if(side==null||v>side)side=v}}
 return{top,dir:ang[m],width,sll:(side==null||width==null)?null:side-top}}
function cuts(o,P){const idx=(arr,v)=>arr.reduce((b,x,i)=>Math.abs(x-v)<Math.abs(arr[b]-v)?i:b,0),c=$('cutsel').value;
 const comp=[['abs','total','solid'],['th','Eθ','dash'],['ph','Eφ','dot']].filter(([k])=>k==='abs'||o.Dth);
 const series=comp.map(([k,nm,ds])=>{const A=patData(o,k).A;let t,r;
  if(c==='h'){const i=idx(o.theta,90);t=o.phi.slice();r=A[i].slice()}
  else{const p0=+c,j=idx(o.phi,p0),j2=idx(o.phi,(p0+180)%360);t=o.theta.concat(o.theta.slice(1,-1).reverse().map(x=>360-x));
   r=o.theta.map((_,i)=>A[i][j]).concat(o.theta.slice(1,-1).reverse().map((_,q)=>A[o.theta.length-2-q][j2]))}
  t=t.concat([t[0]+360]);r=r.concat([r[0]]);return{k,nm,ds,t,r}});
 const tr=series.map(s=>({type:'scatterpolar',theta:s.t,r:s.r.map(v=>Math.max(v,P.floor)),name:s.nm,mode:'lines',line:{dash:s.ds,width:s.k==='abs'?2.4:1.4}}));
 const lab=c==='h'?'Theta = 90 (xy plane), angle = Phi':`Phi = ${c} (${c==='0'?'xz':'yz'} plane), angle = Theta`;
 Plotly.react('p4',tr,{...base(`${patData(o,'abs').name} (dBi), ${lab}`),polar:{bgcolor:'rgba(0,0,0,0)',radialaxis:{range:[P.floor,P.top+1],gridcolor:ln,angle:45,tickangle:45,tickfont:{size:10}},
  angularaxis:{direction:'clockwise',rotation:90,gridcolor:ln,dtick:30}}},cfg);
 const s0=series[0],nr=s0.t.length-1,L=lobes(s0.t.slice(0,nr),s0.r.slice(0,nr)),dir=L.dir;
 const dtxt=c==='h'?`Phi = ${dir.toFixed(0)}°`:(dir<=180?`Theta = ${dir.toFixed(0)}°, Phi = ${c}°`:`Theta = ${(360-dir).toFixed(0)}°, Phi = ${(+c+180)}°`);
 const rows=[['Frequency',`${(o.f/1e6).toFixed(1)} MHz`],['Main lobe magnitude',`${L.top.toFixed(2)} dBi`],['Main lobe direction',dtxt],
  ['Angular width (3 dB)',L.width==null?'-':`${L.width.toFixed(1)}°`],['Side lobe level',L.sll==null?'-':`${L.sll.toFixed(1)} dB`]];
 $('cuttab').innerHTML=rows.map(([a,b])=>`<tr><td>${a}</td><td>${b}</td></tr>`).join('')}
// ---- band presets: shading in the S11 / impedance plots, worst case in the band
{const bsel=document.getElementById('band');fillBands(bsel,D.f[0],D.f[D.f.length-1]);const DBAND=addDesignBand(bsel,D.band);
 const apply=()=>{const b=bandOf(bsel);const sh=bandShapes(b,1e9).concat(marks);
  Plotly.relayout('p1',{shapes:sh});Plotly.relayout('p2',{shapes:sh});
  if(b){const [lo,hi]=bandEdges(b),m=Math.max(0.15*(hi-lo),0.01*lo);Plotly.relayout('p1',{'xaxis.range':[(lo-m)/1e9,(hi+m)/1e9]});Plotly.relayout('p2',{'xaxis.range':[(lo-m)/1e9,(hi+m)/1e9]})}
  else{Plotly.relayout('p1',{'xaxis.autorange':true});Plotly.relayout('p2',{'xaxis.autorange':true})}
  const out=document.getElementById('bandsum');if(!b){out.textContent='';return}
  const ks=D.f.map((f,k)=>k).filter(k=>inBand(D.f[k],b));
  if(!ks.length){out.textContent='outside the simulated sweep';return}
  let w=-1e9,wf=0;for(const k of ks)if(D.s11[k]>w){w=D.s11[k];wf=D.f[k]}
  const ff=D.ff.filter(o=>inBand(o.f,b));
  out.innerHTML=`worst S11 at the feed (50 Ω, no matching) ${w.toFixed(1)} dB at ${(wf/1e6).toFixed(1)} MHz`+
   (ff.length?' · '+ff.map(o=>`${(o.f/1e6).toFixed(0)} MHz: η<sub>rad</sub> ${(100*o.eff_rad).toFixed(0)} %, D ${o.Dmax.toFixed(1)} dBi`).join(' · '):
    ' · no far-field frequency inside the band (set f_farfield in the setup)');
  try{localStorage.setItem('rfsim_band',bsel.value)}catch(e){}};
 bsel.onchange=apply;if(DBAND!==null){bsel.value=DBAND;apply()}else try{const b0=localStorage.getItem('rfsim_band');if(b0&&bsel.querySelector(`option[value="${b0}"]`)){bsel.value=b0;apply()}}catch(e){}}
sel.onchange=pattern;['onb','psz','pop','prng','qsel','csel','ssel','vsel','cutsel'].forEach(id=>{const e=$(id);e.oninput=pattern;e.onchange=pattern});
if((D.sheets||[]).length)$('sheets').innerHTML='Pattern sheets: '+D.sheets.map(n=>`<a href="${n}" target="_blank">${n}</a>`).join(', ');
if(!D.ff.some(o=>o.Dth)){$('csel').disabled=true;$('csel').title='polarisation split: results from version 0.25 on'}
pattern();
const g=D.geo,tr=[];const add=(k,c,name,op,vis)=>{const a=g[k];if(a[0].length)tr.push({type:'mesh3d',x:a[0],y:a[1],z:a[2],i:a[3],j:a[4],k:a[5],color:c,opacity:op,name,flatshading:true,showlegend:true,visible:vis})};
add('diel','#5a8f4f','dielectric',0.2,true);add('board','#8a8a80','board copper (click to show)',0.5,'legendonly');add('ant','#d0661c','antenna copper',1.0,true);(g.casing||[]).forEach(m=>tr.push(Object.assign({},m,{showlegend:true})));
Plotly.newPlot('p5',tr,{...base('Model geometry (global frame, mm)'),scene:{aspectmode:'data'}},cfg);
</script></body></html>
"""
