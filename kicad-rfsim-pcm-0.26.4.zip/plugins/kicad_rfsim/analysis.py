"""Quick layout checks for RF nets: impedance, reference plane, electrical length."""
from __future__ import annotations

from dataclasses import dataclass

from shapely.geometry import LineString
from shapely.ops import unary_union

from . import tline
from .board import Board


@dataclass
class SegmentCheck:
    net: str
    layer: str
    width: float
    length: float
    gap: float | None  # min clearance to same-layer ground, None if > limit
    ref_layer: str
    ref_coverage: float  # fraction of trace footprint backed by ground on ref layer
    h: float
    er: float
    z0: float
    eeff: float
    model: str


def adjacent_layer(board: Board, layer: str) -> str:
    order = board._ordered_copper()
    i = order.index(layer)
    return order[i + 1] if i == 0 else order[i - 1] if i == len(order) - 1 else order[i + 1]


def check_rf_tracks(board: Board, nets: list[str], ground: str = "GND", gap_limit: float = 1.0) -> list[SegmentCheck]:
    gnd_cache: dict[str, object] = {}

    def gnd(layer):
        if layer not in gnd_cache:
            gnd_cache[layer] = unary_union([g for _, g in board.copper(layer, ground)])
        return gnd_cache[layer]

    out: list[SegmentCheck] = []
    for t in board.tracks:
        if t.net not in nets or t.length < 1e-3:
            continue
        if t.layer not in ("F.Cu", "B.Cu"):
            continue
        ref = adjacent_layer(board, t.layer)
        diel = board.stackup.dielectric_between(t.layer, ref)
        h = sum(d.thickness for d in diel)
        er = sum(d.thickness * (d.epsilon_r or 4.5) for d in diel) / h
        cu_t = 0.0  # zero-thickness copper, same assumption as the FDTD model
        poly = t.polygon()
        cov = poly.intersection(gnd(ref)).area / poly.area if poly.area else 0.0
        # gap: sample along centreline, distance to same-layer ground minus half width
        line = LineString(t.points)
        g_same = gnd(t.layer)
        gaps = []
        for k in range(11):
            p = line.interpolate(k / 10, normalized=True)
            gaps.append(p.distance(g_same) - t.width / 2)
        gap = min(gaps)
        if gap > gap_limit or gap <= 0:
            z0, ee = tline.microstrip(t.width, h, er, cu_t)
            model, gap_v = "microstrip", (None if gap > gap_limit else gap)
        else:
            z0, ee = tline.cpwg(t.width, gap, h, er, cu_t)
            model, gap_v = "CPWG", gap
        out.append(SegmentCheck(t.net, t.layer, t.width, t.length, gap_v, ref, cov, h, er, z0, ee, model))
    return out


def summarize(checks: list[SegmentCheck], f_hz: float = 868e6) -> str:
    by_net: dict[str, list[SegmentCheck]] = {}
    for c in checks:
        by_net.setdefault(c.net, []).append(c)
    rows = [f"{'net':<24} {'layer':<5} {'w/mm':>5} {'len/mm':>7} {'gap/mm':>7} {'Z0/ohm':>11} {'model':<10} {'ref':<7} {'cover':>5} {'deg@' + str(round(f_hz/1e6)) + 'M':>9}"]
    for net, cs in by_net.items():
        L = sum(c.length for c in cs)
        zs = [c.z0 for c in cs]
        gaps = [c.gap for c in cs if c.gap is not None]
        cov = sum(c.ref_coverage * c.length for c in cs) / L
        ee = sum(c.eeff * c.length for c in cs) / L
        deg = tline.electrical_length_deg(L, ee, f_hz)
        widths = sorted({c.width for c in cs})
        models = sorted({c.model for c in cs})
        rows.append(f"{net[-24:]:<24} {cs[0].layer:<5} {'/'.join(f'{w:g}' for w in widths):>5} {L:7.2f} "
                    f"{(min(gaps) if gaps else float('nan')):7.3f} {min(zs):5.1f}-{max(zs):5.1f} {'/'.join(models):<10} "
                    f"{cs[0].ref_layer:<7} {cov*100:4.0f}% {deg:9.2f}")
    return "\n".join(rows)
