"""Casing / enclosure parts around the board for the antenna simulation.

Each body is a STEP (or STL) file, placed relative to the board like a joint in a CAD tool:
rotation about the body's own centre, then a shift. Bodies are dielectric (material preset
or own eps_r / tan d) or metal. In the antenna model they are openEMS polyhedra (the
tessellated shape, staircased by the FDTD mesh) or - the strongest simplification - a hollow
box with the body's outer dimensions and one wall thickness.

Frame: the antenna model's frame = KiCad's 3D / STEP export frame: x right, y up (= -y of
the PCB editor), z up, z = 0 on the top copper. The board lies between z = -thickness and 0.

Stored per project in ``rfsim/enclosure.json`` ({"type": "enclosure", "bodies": [...]}); every
antenna setup of the project uses the enabled bodies.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import math
import threading
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

# eps_r, tan d around 1 GHz. Sources: Curbell Plastics, "Plastics for high performance radomes"
# (2022), tables 1-4 (1 GHz values) where marked; otherwise typical datasheet values - check the
# grade's datasheet (fillers, colour and moisture change them).
MATERIALS: dict[str, dict] = {
    "ABS": {"er": 2.8, "tand": 0.010, "src": "Curbell, 1 GHz"},
    "PC (polycarbonate)": {"er": 2.86, "tand": 0.0066, "src": "Curbell, 1 GHz"},
    "PC/ABS": {"er": 2.85, "tand": 0.008, "src": "typical"},
    "ASA": {"er": 3.0, "tand": 0.010, "src": "typical"},
    "PA6 / PA66 (dry)": {"er": 3.1, "tand": 0.015, "src": "typical; moisture raises both clearly"},
    "PA66-GF30": {"er": 3.7, "tand": 0.015, "src": "typical"},
    "PBT": {"er": 3.1, "tand": 0.008, "src": "typical"},
    "PBT-GF30": {"er": 3.6, "tand": 0.010, "src": "typical"},
    "PP (polypropylene)": {"er": 2.25, "tand": 0.0005, "src": "typical"},
    "PE (HDPE)": {"er": 2.35, "tand": 0.002, "src": "Curbell"},
    "POM (acetal)": {"er": 3.0, "tand": 0.005, "src": "typical"},
    "PMMA (acrylic)": {"er": 2.65, "tand": 0.008, "src": "typical"},
    "PEEK": {"er": 3.11, "tand": 0.002, "src": "Curbell, 1 GHz"},
    "PTFE": {"er": 2.07, "tand": 0.0004, "src": "Curbell, 1 GHz"},
    "PLA (3D print, solid)": {"er": 2.7, "tand": 0.010, "src": "typical; lower the fill for infill"},
    "PETG (3D print, solid)": {"er": 2.7, "tand": 0.008, "src": "typical; lower the fill for infill"},
    "FR4": {"er": 4.6, "tand": 0.03, "src": "Curbell, 1 GHz"},
    "Glass (soda-lime)": {"er": 6.5, "tand": 0.010, "src": "typical"},
    "Silicone rubber": {"er": 3.0, "tand": 0.005, "src": "typical"},
    "Metal (aluminium, steel, zinc)": {"er": 1.0, "tand": 0.0, "pec": True, "src": "perfect conductor"},
    "Custom": {"er": 3.0, "tand": 0.01, "src": "own values"},
}

DETAIL = {"coarse": 4.0, "medium": 2.0, "fine": 1.0}  # tessellation size (mm)


@dataclass
class Body:
    name: str
    file: str  # STEP / STL, absolute or relative to the rfsim folder
    material: str = "ABS"
    er: float | None = None  # own values (material "Custom", or overriding the preset)
    tand: float | None = None
    fill: float = 1.0  # volume fraction (3D-print infill): eps_eff = 1 + fill (eps_r - 1)
    model: str = "shape"  # "shape" (tessellated) | "box" (hollow box from the outer size)
    wall: float = 2.0  # wall thickness for model "box" (mm)
    detail: str = "medium"
    pos: list = field(default_factory=lambda: [0.0, 0.0, 0.0])  # shift (mm)
    rot: list = field(default_factory=lambda: [0.0, 0.0, 0.0])  # degrees about x, then y, then z (body centre)
    enabled: bool = True

    @classmethod
    def from_dict(cls, d: dict) -> "Body":
        names = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in names})

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    def props(self) -> dict:
        """{er, tand, pec} after preset, own values and fill."""
        m = MATERIALS.get(self.material, MATERIALS["Custom"])
        er = self.er if self.er is not None else m["er"]
        tand = self.tand if self.tand is not None else m["tand"]
        fill = min(1.0, max(0.0, float(self.fill)))
        er_eff = 1 + fill * (er - 1)
        # loss scales with the material share of the stored energy (simple mixing)
        tand_eff = tand * fill * er / er_eff if er_eff > 0 else tand
        return {"er": float(er_eff), "tand": float(tand_eff), "pec": bool(m.get("pec"))}


# ---------------------------------------------------------------------------
def path_of(body: Body, rfsim_dir: Path) -> Path:
    p = Path(body.file)
    return p if p.is_absolute() else (Path(rfsim_dir) / p).resolve()


def load(rfsim_dir: Path) -> list[Body]:
    p = Path(rfsim_dir) / "enclosure.json"
    if not p.exists():
        return []
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return [Body.from_dict(b) for b in d.get("bodies", [])]


def save(rfsim_dir: Path, bodies: list[Body]) -> Path:
    p = Path(rfsim_dir) / "enclosure.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"type": "enclosure", "bodies": [b.to_dict() for b in bodies]}, indent=2),
                 encoding="utf-8")
    return p


def tessellate(body: Body, rfsim_dir: Path, detail: str | None = None) -> Path:
    """STL of the body in its own (STEP) frame, cached by file content and detail level.
    ``detail="view"``: fine, curvature-following surface for showing the part as imported."""
    src = path_of(body, rfsim_dir)
    if src.suffix.lower() == ".stl":
        return src
    detail = detail or body.detail
    h = hashlib.sha1(src.read_bytes()).hexdigest()[:16]
    cache = Path(rfsim_dir) / "results" / "enclosure_cache"
    cache.mkdir(parents=True, exist_ok=True)
    out = cache / f"{src.stem}_{h}_{detail}.stl"
    if not out.exists():
        with _LOCK:  # gmsh is not thread safe
            if not out.exists():
                if detail == "view":
                    _step_to_stl(src, out, 3.0, curvature=16)
                else:
                    _step_to_stl(src, out, DETAIL.get(detail, 2.0))
    return out


def _step_to_stl(step: Path, stl: Path, size: float, curvature: int = 0):
    """Coarse surface mesh with gmsh: sizes up to ``size``, no refinement at curvature - the FDTD
    mesh staircases the shape anyway, fewer triangles make openEMS' inside test faster."""
    try:
        import gmsh
    except ImportError as e:
        raise RuntimeError("reading STEP files needs the Python package gmsh (plugin requirements); "
                           "install it or export the part as STL") from e
    gmsh.initialize(interruptible=False)  # no SIGINT handler: works in worker threads
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("casing")
        gmsh.model.occ.importShapes(str(step))
        gmsh.model.occ.synchronize()
        gmsh.option.setNumber("Mesh.MeshSizeMax", size)
        gmsh.option.setNumber("Mesh.MeshSizeMin", size * 0.05 if curvature else size * 0.5)
        gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", curvature)
        gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 0)
        gmsh.model.mesh.generate(2)
        gmsh.option.setNumber("Mesh.Binary", 1)  # binary STL: 5x smaller, read without parsing text
        gmsh.write(str(stl))
    finally:
        gmsh.finalize()


from .cadview import _LOCK  # one lock for every gmsh use: gmsh is not thread safe
_TRI: dict = {}


def raw_triangles(body: Body, rfsim_dir: Path) -> np.ndarray:
    """Triangles of the body in its own frame (tessellated once, then kept in memory)."""
    from .antenna import read_stl
    with _LOCK:
        stl = tessellate(body, rfsim_dir)
        key = (str(stl), stl.stat().st_mtime)
        if key not in _TRI:
            if len(_TRI) > 32:
                _TRI.clear()
            _TRI[key] = read_stl(stl)
        return _TRI[key]


def view_triangles(body: Body, rfsim_dir: Path) -> np.ndarray:
    """The part as imported (fine tessellation), placed like the simulation shape."""
    raw = raw_triangles(body, rfsim_dir)
    with _LOCK:
        stl = tessellate(body, rfsim_dir, "view")
        key = (str(stl), stl.stat().st_mtime)
        if key not in _TRI:
            from .antenna import read_stl
            _TRI[key] = read_stl(stl)
        fine = _TRI[key]
    p = raw.reshape(-1, 3)
    return place(fine, body, centre=(p.min(0) + p.max(0)) / 2)


def placer(body: Body, rfsim_dir: Path):
    """points [n, 3] in the part's own frame -> model frame (same placement as the simulation shape)."""
    p = raw_triangles(body, rfsim_dir).reshape(-1, 3)
    c = (p.min(0) + p.max(0)) / 2
    R = rotation(body.rot)
    t = np.asarray(body.pos, float)
    return lambda q: (np.asarray(q, float) - c) @ R.T + c + t


def stl_mesh(tri: np.ndarray, angle: float = 30.0) -> dict:
    """cadview-style mesh of plain triangles: one grey face set, sharp edges (> ``angle``) as lines."""
    from .cadview import DEFAULT
    V = tri.reshape(-1, 3)
    T = np.arange(len(V)).reshape(-1, 3)
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    key = np.round(V, 4)
    edges: dict = {}
    for k in range(len(tri)):
        for a, b in ((0, 1), (1, 2), (2, 0)):
            e = tuple(sorted((tuple(key[3 * k + a]), tuple(key[3 * k + b]))))
            edges.setdefault(e, []).append(k)
    lines = []
    cs = np.cos(np.radians(angle))
    for e, ks in edges.items():
        if len(ks) == 1 or (len(ks) == 2 and float(n[ks[0]] @ n[ks[1]]) < cs):
            lines.append(np.array(e, float))
    return {"faces": {DEFAULT: (V, T)}, "edges": lines, "bbox": (V.min(0), V.max(0))}


def cad_mesh(body: Body, rfsim_dir: Path) -> dict:
    """The part as a CAD program shows it: STEP faces with their colours and B-rep edges."""
    src = path_of(body, rfsim_dir)
    if src.suffix.lower() == ".stl":
        return stl_mesh(raw_triangles(body, rfsim_dir))
    from .cadview import step_mesh
    return step_mesh(src, Path(rfsim_dir) / "results" / "enclosure_cache")


def rotation(rot) -> np.ndarray:
    ax, ay, az = (math.radians(float(a)) for a in rot)
    rx = np.array([[1, 0, 0], [0, math.cos(ax), -math.sin(ax)], [0, math.sin(ax), math.cos(ax)]])
    ry = np.array([[math.cos(ay), 0, math.sin(ay)], [0, 1, 0], [-math.sin(ay), 0, math.cos(ay)]])
    rz = np.array([[math.cos(az), -math.sin(az), 0], [math.sin(az), math.cos(az), 0], [0, 0, 1]])
    return rz @ ry @ rx


def place(tri: np.ndarray, body: Body, centre=None) -> np.ndarray:
    """Triangles [n, 3, 3] in the model frame: rotate about the body's centre, then shift."""
    pts = tri.reshape(-1, 3)
    c = (pts.min(0) + pts.max(0)) / 2 if centre is None else np.asarray(centre, float)
    out = (pts - c) @ rotation(body.rot).T + c + np.asarray(body.pos, float)
    return out.reshape(-1, 3, 3)


def bounds(tri: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    p = tri.reshape(-1, 3)
    return p.min(0), p.max(0)


def board_bounds(board) -> tuple[np.ndarray, np.ndarray]:
    """Board box in the model frame (outline, -thickness .. top copper)."""
    ol = board.outline()
    x0, y0, x1, y1 = ol.bounds
    return np.array([x0, -y1, -board.stackup.thickness]), np.array([x1, -y0, 0.0])


# ---------------------------------------------------------------------------
# joint-like placement
ALIGN = {
    "keep": "keep",
    "center": "centre on",
    "min": "align min faces",
    "max": "align max faces",
    "on": "stack on (min face to max face)",
    "under": "stack under (max face to min face)",
}


def align(body_lo, body_hi, ref_lo, ref_hi, axis: int, how: str, offset: float = 0.0) -> float:
    """Shift along ``axis`` that puts the body (current bounds) where ``how`` says relative to the
    reference bounds; ``offset`` is added (gap / overlap)."""
    if how == "center":
        d = (ref_lo[axis] + ref_hi[axis]) / 2 - (body_lo[axis] + body_hi[axis]) / 2
    elif how == "min":
        d = ref_lo[axis] - body_lo[axis]
    elif how == "max":
        d = ref_hi[axis] - body_hi[axis]
    elif how == "on":
        d = ref_hi[axis] - body_lo[axis]
    elif how == "under":
        d = ref_lo[axis] - body_hi[axis]
    else:
        return 0.0
    return float(d + offset)


# ---------------------------------------------------------------------------
def planar_faces(tri: np.ndarray, min_area: float = 4.0, limit: int = 40) -> list[list[float]]:
    """Coordinates of large axis-aligned faces per axis (walls, floors, lids): fixed mesh lines, so
    a 2 mm wall is resolved between its two faces instead of being smeared into one cell."""
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    n = np.cross(b - a, c - a)
    area = 0.5 * np.linalg.norm(n, axis=1)
    nn = n / np.maximum(2 * area[:, None], 1e-12)
    out = []
    for ax in range(3):
        m = np.abs(nn[:, ax]) > 0.999
        coord = np.round(a[m, ax] / 0.05) * 0.05
        acc: dict[float, float] = {}
        for v, ar in zip(coord, area[m]):
            acc[float(v)] = acc.get(float(v), 0.0) + float(ar)
        big = sorted((v for v, ar in acc.items() if ar >= min_area), key=lambda v: -acc[v])[:limit]
        out.append(sorted(big))
    return out


def box_walls(lo, hi, t: float) -> list[tuple[np.ndarray, np.ndarray]]:
    """Six wall boxes of a hollow box (outer lo..hi, wall t)."""
    lo, hi = np.asarray(lo, float), np.asarray(hi, float)
    t = max(0.1, min(t, float(np.min(hi - lo)) / 2))
    w = []
    for ax in range(3):
        a = lo.copy(); b = hi.copy()
        b[ax] = lo[ax] + t
        w.append((a.copy(), b.copy()))
        a = lo.copy(); b = hi.copy()
        a[ax] = hi[ax] - t
        w.append((a, b))
    return w


def prepare(bodies: list[Body], rfsim_dir: Path, workdir: Path) -> list[dict]:
    """Bodies for the antenna model: {name, er, tand, pec, stl | walls, lo, hi, faces, sig}."""
    from .antenna import write_stl
    out = []
    workdir = Path(workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    missing = [(b.name, b.file, path_of(b, rfsim_dir)) for b in bodies if b.enabled and not path_of(b, rfsim_dir).exists()]
    if missing:
        raise FileNotFoundError("Casing part file not found:\n" + "\n".join(
            f"  {n}: {f}" + (f" (looked for {p})" if str(p) != str(f) else "") for n, f, p in missing)
            + "\nSelect the file again on the Casing & 3D page, or switch the part off.")
    for i, b in enumerate(bodies):
        if not b.enabled:
            continue
        tri = place(raw_triangles(b, rfsim_dir), b)
        lo, hi = bounds(tri)
        pr = b.props()
        sig = hashlib.sha1(json.dumps(b.to_dict(), sort_keys=True).encode()
                           + path_of(b, rfsim_dir).read_bytes()[:1 << 20]).hexdigest()[:10]
        d = {"name": f"case{i}_{''.join(ch if ch.isalnum() else '_' for ch in b.name)}_{sig}",
             "lo": lo, "hi": hi, "sig": sig, **pr}
        if b.model == "box":
            d["walls"] = box_walls(lo, hi, b.wall)
            d["faces"] = [sorted({lo[ax], lo[ax] + b.wall, hi[ax] - b.wall, hi[ax]}) for ax in range(3)]
        else:
            p = workdir / f"case{i}.stl"
            write_stl(p, tri)
            d["stl"] = p
            d["faces"] = planar_faces(tri)
        out.append(d)
    return out


def sim_cell(rfsim_dir: Path, er: float, pec: bool = False) -> float:
    """Largest FDTD cell inside a casing part, as the antenna model meshes it (antenna._mesh)."""
    s = {}
    for c in sorted(Path(rfsim_dir).glob("*.json")):
        try:
            d = json.loads(c.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(d, dict) and d.get("type") == "antenna":
            s = d.get("settings", {})
            break
    lam_min = 299792458.0 / float(s.get("f_max", 1.5e9)) * 1e3
    max_air = s.get("max_air") or lam_min / 20
    if pec:
        return 2 * float(s.get("max_board", 2.0))
    return min(max_air, lam_min / (15 * math.sqrt(max(er, 1.0))))


def grid_lines(lo: float, hi: float, faces, h: float) -> np.ndarray:
    """Mesh lines over one body: its large planar faces fixed, uniform fill with cells <= h."""
    fixed = sorted({float(lo), float(hi)} | {float(v) for v in faces if lo <= v <= hi})
    out = [fixed[0]]
    for a, b in zip(fixed[:-1], fixed[1:]):
        n = max(1, int(math.ceil((b - a) / h - 1e-9)))
        out += [a + (b - a) * k / n for k in range(1, n + 1)]
    return np.array(out)


def voxelize(tri: np.ndarray, lines: list[np.ndarray]) -> np.ndarray:
    """Cells (between the grid lines) whose centre lies inside the closed surface ``tri``:
    rays along +z through every (x, y) cell centre, inside = odd number of crossings below."""
    xc = (lines[0][:-1] + lines[0][1:]) / 2 + 1.3e-6  # tiny offset: no ray through an edge
    yc = (lines[1][:-1] + lines[1][1:]) / 2 + 0.7e-6
    zc = (lines[2][:-1] + lines[2][1:]) / 2
    occ = np.zeros((len(xc), len(yc), len(zc)), bool)
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    tx0, tx1 = np.minimum(np.minimum(a[:, 0], b[:, 0]), c[:, 0]), np.maximum(np.maximum(a[:, 0], b[:, 0]), c[:, 0])
    ty0, ty1 = np.minimum(np.minimum(a[:, 1], b[:, 1]), c[:, 1]), np.maximum(np.maximum(a[:, 1], b[:, 1]), c[:, 1])
    det = (b[:, 1] - c[:, 1]) * (a[:, 0] - c[:, 0]) + (c[:, 0] - b[:, 0]) * (a[:, 1] - c[:, 1])
    ok = np.abs(det) > 1e-12
    for i, x in enumerate(xc):
        mx = ok & (tx0 <= x) & (tx1 >= x)
        if not mx.any():
            continue
        A, B, Cc, dd = a[mx], b[mx], c[mx], det[mx]
        y0, y1 = ty0[mx], ty1[mx]
        for j, y in enumerate(yc):
            m = (y0 <= y) & (y1 >= y)
            if not m.any():
                continue
            Am, Bm, Cm, dm = A[m], B[m], Cc[m], dd[m]
            l1 = ((Bm[:, 1] - Cm[:, 1]) * (x - Cm[:, 0]) + (Cm[:, 0] - Bm[:, 0]) * (y - Cm[:, 1])) / dm
            l2 = ((Cm[:, 1] - Am[:, 1]) * (x - Cm[:, 0]) + (Am[:, 0] - Cm[:, 0]) * (y - Cm[:, 1])) / dm
            l3 = 1 - l1 - l2
            hit = (l1 >= 0) & (l2 >= 0) & (l3 >= 0)
            if not hit.any():
                continue
            z = np.sort(l1[hit] * Am[hit, 2] + l2[hit] * Bm[hit, 2] + l3[hit] * Cm[hit, 2])
            occ[i, j] = (np.searchsorted(z, zc) % 2) == 1
    return occ


def voxel_surface(occ: np.ndarray, lines: list[np.ndarray]) -> np.ndarray:
    """Triangles of the outer faces of the occupied cells (the staircased surface)."""
    pad = np.pad(occ, 1).astype(np.int8)
    quads = []
    for ax in range(3):
        u, v = (ax + 1) % 3, (ax + 2) % 3
        d = np.diff(pad, axis=ax)  # index k along ax = grid line k; other axes: padded cell index
        idx = np.argwhere(d != 0)
        keep = np.ones(len(idx), bool)
        for q in (u, v):  # faces between two padding cells do not exist (d = 0 there)
            keep &= (idx[:, q] >= 1) & (idx[:, q] <= occ.shape[q])
        idx = idx[keep]
        for k in idx:
            p0 = [0.0, 0.0, 0.0]
            p0[ax] = lines[ax][k[ax]]
            p0[u], p0[v] = lines[u][k[u] - 1], lines[v][k[v] - 1]
            du, dv = lines[u][k[u]] - p0[u], lines[v][k[v]] - p0[v]
            p1, p2, p3 = list(p0), list(p0), list(p0)
            p1[u] += du
            p2[u] += du
            p2[v] += dv
            p3[v] += dv
            quads += [[p0, p1, p2], [p0, p2, p3]]
    return np.array(quads, float).reshape(-1, 3, 3)


_SIM: dict = {}


def sim_triangles(body: Body, rfsim_dir: Path) -> tuple[np.ndarray, float]:
    """What the FDTD sees of a part: the six walls of the hollow box, or the tessellated shape
    staircased on a mesh like the antenna model's (planar faces fixed, cells <= sim_cell).
    Returns (triangles, cell size)."""
    tri = place(raw_triangles(body, rfsim_dir), body)
    lo, hi = bounds(tri)
    pr = body.props()
    h = sim_cell(rfsim_dir, pr["er"] or 1.0, pr["pec"])
    if body.model == "box":
        out = [t for wl, wh in box_walls(lo, hi, body.wall) for t in _box_tris(wl, wh)]
        return np.array(out, float), h
    key = (hashlib.sha1(tri.tobytes()).hexdigest(), round(h, 4))
    with _LOCK:
        if key in _SIM:
            return _SIM[key], h
    faces = planar_faces(tri)
    lines = [grid_lines(lo[ax], hi[ax], faces[ax], h) for ax in range(3)]
    surf = voxel_surface(voxelize(tri, lines), lines)
    with _LOCK:
        if len(_SIM) > 16:
            _SIM.clear()
        _SIM[key] = surf
    return surf, h


def model_traces(model, opacity: float = 0.18, max_tri: int = 6000) -> list[dict]:
    """See-through mesh3d dicts of the casing parts inside an antenna model (model.bodies)."""
    from .fields import mesh3d
    out = []
    for bd in getattr(model, "bodies", None) or []:
        try:
            if "stl" in bd:
                from .antenna import read_stl
                ct = read_stl(bd["stl"])
                ct = ct[::max(1, len(ct) // max_tri)].tolist()
            elif "walls" in bd:
                ct = [t for wl, wh in bd["walls"] for t in _box_tris(wl, wh)]
            else:
                ct = _box_tris(bd["lo"], bd["hi"])
            nm = str(bd["name"]).split("_", 1)[-1].rsplit("_", 1)[0]
            out.append(mesh3d(ct, "#9aa7b8" if bd.get("pec") else "#c8a165", f"casing {nm}", opacity))
        except Exception:  # noqa: BLE001 - decoration only
            pass
    return out


SHOW = {"imported": "imported (as in CAD)", "both": "imported + simulation model", "sim": "simulation model"}


def preview(bodies: list[Body], rfsim_dir: Path, max_tri: int = 6000, show: str = "imported",
            selected: int | None = None) -> list[dict]:
    """Plotly traces of the placed bodies: as imported (CAD view: STEP colours, edges) and / or as
    simulated (staircase on the FDTD mesh / hollow box walls). Casing traces carry
    legendgroup "casing" (the page's see-through slider)."""
    from .cadview import mesh_traces
    from .fields import mesh3d
    colors = ["#c8a165", "#7fa7d9", "#a3c47f", "#d98fb0", "#b0a0d9", "#d9c27f"]
    out = []
    for i, b in enumerate(bodies):
        if not b.enabled:
            continue
        col = colors[i % len(colors)]
        sel = selected is not None and i == selected
        if show in ("both", "imported"):
            try:
                tr = mesh_traces(cad_mesh(b, rfsim_dir), placer(b, rfsim_dir), opacity=1.0 if show == "imported" else 0.3,
                                 name=b.name, edge_color="#2a6fdb" if sel else "#1d1d1b")
            except Exception:  # noqa: BLE001 - fall back to the simulation tessellation
                tri = place(raw_triangles(b, rfsim_dir), b)
                tr = [mesh3d(tri.tolist(), col, b.name, opacity=0.5)]
            for t in tr:
                t["legendgroup"] = "casing"
            out += tr
        if show in ("both", "sim"):
            tri, h = sim_triangles(b, rfsim_dir)
            step = max(1, len(tri) // (max_tri * 3))
            kind = "hollow box" if b.model == "box" else f"staircase, cells ≤ {h:.1f} mm"
            m = mesh3d(tri[::step].tolist(), "#e07b39" if show == "both" else col,
                       f"{b.name}: simulation ({kind})", opacity=(0.45 if show == "both" else 0.22) * (1.3 if sel else 1))
            m["legendgroup"] = "casing"  # the page's see-through slider acts on it too
            out.append(m)
    return out


def _box_tris(lo, hi):
    x0, y0, z0 = lo
    x1, y1, z1 = hi
    v = [(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0), (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]
    f = [(0, 1, 2), (0, 2, 3), (4, 5, 6), (4, 6, 7), (0, 1, 5), (0, 5, 4), (1, 2, 6), (1, 6, 5), (2, 3, 7), (2, 7, 6),
         (3, 0, 4), (3, 4, 7)]
    return [[v[a], v[b], v[c]] for a, b, c in f]


# ---------------------------------------------------------------------------
def scene(board, bodies: list[Body], rfsim_dir: Path, selected: int | None = None,
          show: str = "imported", extra: list[dict] | None = None, board_override: list[dict] | None = None) -> list[dict]:
    """Plotly traces: board (outline slab, top copper) and the placed casing parts."""
    key = (str(getattr(board, "path", id(board))), getattr(board, "path", None) and board.path.stat().st_mtime)
    with _LOCK:
        tr = list(_BOARD_SCENE.get(key) or [])
    if board_override is not None:  # the board with its components (KiCad's STEP export)
        tr = list(board_override)
    elif not tr:
        tr = _board_traces(board)
        with _LOCK:
            _BOARD_SCENE.clear()
            _BOARD_SCENE[key] = tr
    tr = [dict(t) for t in tr] + list(extra or [])
    return tr + preview(bodies, rfsim_dir, show=show, selected=selected)


_BOARD_SCENE: dict = {}


def board_3d_traces(board, rfsim_dir: Path, log=print) -> tuple[list[dict], str]:
    """The board with its components as KiCad exports it (kicad-cli), in the model frame."""
    from .cadview import board_step_transform, export_board_step, mesh_traces, step_mesh
    cache = Path(rfsim_dir) / "results" / "enclosure_cache"
    st = export_board_step(board.path, cache, log)
    m = step_mesh(st, cache, quality=0.6)
    tf, res = board_step_transform(board, m)
    tr = mesh_traces(m, tf, name="board (KiCad 3D)", edge_color="#3a3a38")
    for t in tr:
        t["legendgroup"] = "board3d"
        if t["type"] == "scatter3d":
            t["line"]["width"] = 1
    return tr, f"board with components from KiCad's STEP export (fits the outline within {res:.2f} mm)"


def _board_traces(board) -> list[dict]:
    """The main board as a KiCad STEP export looks (cached per board file)."""
    from .cadview import board_traces
    return board_traces(board, name="board")


_PREVIEW = r"""<!doctype html><html><head><meta charset="utf-8"><title>Casing preview</title>
<script src="plotly.min.js"></script><style>
body{margin:0;background:linear-gradient(#f4f5f7,#dfe2e6);font:12px system-ui;color:#333;height:100vh;overflow:hidden}
@media (prefers-color-scheme:dark){body{background:linear-gradient(#2b2d30,#1c1d1f);color:#ddd}}
#p{width:100vw;height:100vh}.vbar{position:absolute;left:8px;top:6px;z-index:3;display:flex;flex-wrap:wrap;gap:4px;align-items:center}
.vbar button{font:inherit;padding:3px 8px;border:1px solid #9aa0a6;border-radius:4px;background:rgba(255,255,255,.75);cursor:pointer;color:#222}
.vbar label{display:flex;gap:4px;align-items:center;margin-left:8px}#t{position:absolute;left:10px;bottom:8px;color:#777;z-index:2}
</style></head><body><div id="p"></div><div id="t">drag: rotate · right-drag: pan · scroll: zoom</div><script>
__VIEWJS__
const T=__TRACES__;let cam=__CAM__;try{const c=localStorage.getItem('cam');if(c)cam=JSON.parse(c)}catch(e){}
cam.projection=cam.projection||{type:'orthographic'};
const ax={visible:false,showbackground:false,title:''};
const L={margin:{l:0,r:0,t:0,b:0},paper_bgcolor:'rgba(0,0,0,0)',showlegend:false,
 scene:{aspectmode:'data',xaxis:Object.assign({},ax,{title:'x / mm'}),yaxis:Object.assign({},ax,{title:'y / mm'}),zaxis:Object.assign({},ax,{title:'z / mm'}),camera:cam,dragmode:'orbit'}};
Plotly.newPlot('p',T,L,{displaylogo:false,responsive:true,modeBarButtonsToRemove:['toImage']});
const save=c=>{try{localStorage.setItem('cam',JSON.stringify(c))}catch(x){}};
document.getElementById('p').on('plotly_relayout',e=>{if(e['scene.camera'])save(e['scene.camera'])});
const bar=viewBar('p',save);document.body.appendChild(bar);
const cs=T.map((t,i)=>t.legendgroup==='casing'?i:-1).filter(i=>i>=0);
if(cs.length){const l=document.createElement('label');l.innerHTML='casing <input type="range" id="op" min="10" max="100" value="100" style="width:90px">';
 bar.appendChild(l);let op0=1;try{op0=+(localStorage.getItem('op')||1)}catch(e){}document.getElementById('op').value=Math.round(op0*100);
 const setOp=v=>{Plotly.restyle('p',{opacity:cs.map(i=>T[i].type==='scatter3d'?Math.min(1,v+0.3):v*(T[i]._op0||1))},cs);try{localStorage.setItem('op',v)}catch(e){}};
 cs.forEach(i=>T[i]._op0=T[i].opacity);document.getElementById('op').oninput=e=>setOp(+e.target.value/100);if(op0<1)setOp(op0)}
document.getElementById('ortho').checked=(cam.projection||{}).type!=='perspective';
</script></body></html>"""


def write_preview(path: Path, board, bodies: list[Body], rfsim_dir: Path, selected: int | None = None,
                  camera: dict | None = None, show: str = "imported", extra: list[dict] | None = None,
                  board_override: list[dict] | None = None) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    from .pagepack import pack_page, plotly_tag
    html = _PREVIEW.replace('<script src="plotly.min.js"></script>', plotly_tag(path))
    html = pack_page(html, scene(board, bodies, rfsim_dir, selected, show, extra, board_override), "__TRACES__", "T")
    from .cadview import VIEW_JS
    html = html.replace("__VIEWJS__", VIEW_JS)
    html = html.replace("__CAM__", json.dumps(camera or {"eye": {"x": 1.2, "y": -1.4, "z": 0.9}}))
    path.write_text(html, encoding="utf-8")
    return path
