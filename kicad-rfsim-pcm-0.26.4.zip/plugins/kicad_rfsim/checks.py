"""Plausibility checks on every result (no reference needed).

A passive, linear, reciprocal layout must give
* reciprocity: S_ij = S_ji,
* passivity: for every excitation, the power leaving all ports is at most the power put in
  (sum_i |S_ij|^2 <= 1),
* antennas: |S11| <= 1, radiated power <= accepted power (efficiency <= 100 %), directivity >= 0 dBi.
Violations point at a numerical problem (not settled, unstable, mesh too coarse at a port).
Each check returns {"name", "ok", "value", "limit", "meaning"}.
"""
from __future__ import annotations

import numpy as np


def _c(name, ok, value, limit, meaning):
    return {"name": name, "ok": bool(ok), "value": value, "limit": limit, "meaning": meaning}


def circuit_checks(S: np.ndarray, f: np.ndarray, names: list[str] | None = None,
                   recip_tol: float = 0.05, pass_tol: float = 0.02) -> list[dict]:
    S = np.asarray(S)
    n = S.shape[1]
    have = [j for j in range(n) if not np.isnan(S[0, 0, j])]
    out = []
    worst, where = 0.0, ""
    for a in have:
        for b in have:
            if b <= a:
                continue
            d = float(np.nanmax(np.abs(S[:, a, b] - S[:, b, a])))
            if d > worst:
                lab = (f"{names[a]} / {names[b]}" if names else f"{a+1} / {b+1}")
                worst, where = d, lab
    if len(have) > 1:
        out.append(_c("Reciprocity", worst <= recip_tol, f"max |Sij - Sji| = {worst:.3f}" + (f" ({where})" if where else ""),
                      f"≤ {recip_tol}", "a passive layout transmits the same both ways"))
    # the Gaussian excitation spans the sweep and is 20 dB down at its ends: there the spectra are
    # 10x noisier, so the band edges (excitation more than 10 dB down) get a wider tolerance
    f = np.asarray(f, float)
    f0, fc = (f[0] + f[-1]) / 2, (f[-1] - f[0]) / 2
    core = np.abs(f - f0) <= fc / np.sqrt(2) if len(f) > 1 else np.ones(len(f), bool)
    best = {True: (0.0, 0, 0.0), False: (0.0, 0, 0.0)}
    for j in have:
        p = np.nansum(np.abs(S[:, :, j]) ** 2, axis=1)
        for region in (True, False):
            sel = core if region else ~core
            if not sel.any():
                continue
            k = int(np.argmax(np.where(sel, p, -1)))
            if p[k] > best[region][0]:
                best[region] = (float(p[k]), j, float(f[k]))
    if have:
        (pc, jc, fcr), (pe, je, fe) = best[True], best[False]
        edge_tol = 2.5 * pass_tol
        ok = pc <= 1 + pass_tol and pe <= 1 + edge_tol
        lab = (lambda j: names[j] if names else str(j + 1))
        txt = f"max power out / in = {pc:.3f} (port {lab(jc)}, {fcr/1e6:.0f} MHz)"
        if pe > 1 + pass_tol:
            txt += f"; band edge {pe:.3f} ({lab(je)}, {fe/1e6:.0f} MHz, excitation > 10 dB down)"
        out.append(_c("Passivity", ok, txt,
                      f"≤ {1 + pass_tol:.2f} ({f[core].min()/1e6:.0f}-{f[core].max()/1e6:.0f} MHz), "
                      f"≤ {1 + edge_tol:.2f} at the band edges",
                      "no port may get back more power than was put in"))
    return out


def antenna_checks(res, tol: float = 0.03) -> list[dict]:
    out = []
    m = float(np.max(np.abs(res.s11)))
    out.append(_c("Passivity", m <= 1 + tol, f"max |S11| = {m:.3f}", f"≤ {1 + tol:.2f}",
                  "the antenna cannot reflect more than it gets"))
    z = np.asarray(res.zin)
    rmax = float(np.max(np.abs(z.real))) if len(z) else 0.0
    smin = float(np.min(np.abs(res.s11))) if len(res.s11) else 1.0
    shorted = rmax < 2.0 and smin > 0.9
    out.append(_c("Feed not shorted", not shorted, f"max Re(Zin) = {rmax:.1f} ohm, best |S11| = {20*np.log10(max(smin, 1e-9)):.1f} dB",
                  "Re(Zin) > 2 ohm somewhere in the band",
                  "a port that sees only a few ohm of reactance everywhere is shorted at the feed - the antenna is not excited"))
    for fx, d in sorted(res.farfield.items()):
        eff = d.get("eff_rad")
        if eff is not None:
            out.append(_c(f"Energy balance {fx/1e6:.0f} MHz", -tol <= eff <= 1 + tol, f"radiation efficiency {100*eff:.0f} %",
                          f"0 … {100*(1+tol):.0f} %", "0 ≤ radiated power ≤ power accepted at the feed"))
        dm = d.get("Dmax")
        if dm:
            out.append(_c(f"Directivity {fx/1e6:.0f} MHz", dm >= 1 - tol, f"{10*np.log10(dm):.2f} dBi", "≥ 0 dBi",
                          "no antenna radiates less than an isotropic one in its best direction"))
    return out


def unused_primitives(logs) -> dict[str, dict[str, int]]:
    """{property: {primitive type: count}} of what openEMS reported as unused (not on the mesh)."""
    import re
    out: dict[str, dict[str, int]] = {}
    pat = re.compile(r"Unused primitive \(type: (\w+)\) detected in property: (.*)!")
    for lp in logs:
        try:
            text = open(lp, encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        seen: dict[str, dict[str, int]] = {}
        for m in pat.finditer(text):
            d = seen.setdefault(m.group(2), {})
            d[m.group(1)] = d.get(m.group(1), 0) + 1
        for k, d in seen.items():  # per property: the largest count of any run (runs share the model)
            o = out.setdefault(k, {})
            for t, n in d.items():
                o[t] = max(o.get(t, 0), n)
    return out


def geometry_check(logs, critical) -> list[dict]:
    """Copper that openEMS left out because it does not touch the mesh. ``critical(name)``: the
    property carries the RF copper / antenna -> failed check; other copper (small islands of the
    board copper, via cylinders with an axis line) is only listed."""
    un = unused_primitives(logs)
    crit = {k: v for k, v in un.items() if critical(k)}
    rest = {k: v for k, v in un.items() if not critical(k) and k != "vias_pins_solder" and k != "vias"}
    vias = sum(sum(v.values()) for k, v in un.items() if k in ("vias_pins_solder", "vias"))
    if crit:
        txt = "; ".join(f"{k}: {sum(v.values())} piece(s)" for k, v in crit.items())
        return [_c("Copper in the model", False, f"left out by openEMS (not on the mesh): {txt}",
                   "all RF / antenna copper used", "copper between mesh lines is dropped silently")]
    notes = []
    if rest:
        notes.append(f"{sum(sum(v.values()) for v in rest.values())} small board-copper pieces below the mesh "
                     f"resolution left out")
    if vias:
        notes.append(f"{vias} via cylinders thinner than the cells (connected through their axis line)")
    return [_c("Copper in the model", True, "; ".join(notes) or "all copper on the mesh",
               "all RF / antenna copper used", "copper between mesh lines is dropped silently")]


def connectivity_check(broken: list[dict], max_fine: float) -> list[dict]:
    """Ports of one net that the mesh separates (OpenEMSModel.broken_nets)."""
    if not broken:
        return [_c("RF path on the mesh", True, "all ports of each net connected", "connected",
                   "a trace thinner than the cells falls apart in the FDTD")]
    txt = "; ".join(f"{b['net']}: " + " | ".join(", ".join(g) for g in b["groups"]) for b in broken)
    return [_c("RF path on the mesh", False, f"separated by the mesh ({max_fine:g} mm cells): {txt}",
               "connected", "a trace thinner than the cells falls apart in the FDTD - lower mesh.max_fine "
               "below the narrowest diagonal / curved trace width, or use the Automatic settings")]


def short_check(board, region, nets, layers) -> list[dict]:
    """Copper of two different nets that overlaps inside the region: a short on the board itself
    (KiCad's DRC reports it too). The FDTD joins the copper, so the RF net is shorted in every result."""
    from shapely.geometry import box
    from shapely.ops import unary_union
    reg = box(*region)
    hits = []
    for layer in layers:
        by_net: dict = {}
        for net, g in board.copper(layer):
            if net and g is not None and not g.is_empty and g.intersects(reg):
                by_net.setdefault(net, []).append(g.intersection(reg))
        geo = {n: unary_union(gs) for n, gs in by_net.items()}
        for n in nets:
            if n not in geo:
                continue
            for m, gm in geo.items():
                if m == n or any({h[0], h[1]} == {n, m} and h[2] == layer for h in hits):
                    continue
                ov = geo[n].intersection(gm)
                if ov.area > 1e-4:
                    c = ov.centroid
                    hits.append((n, m, layer, c.x, c.y))
    if not hits:
        return [_c("No shorts on the board", True, "no overlapping copper of different nets", "none",
                   "copper of two nets that overlaps is one conductor in the simulation")]
    txt = "; ".join(f"{n} and {m} on {l} at ({x:.2f}, {y:.2f}) mm" for n, m, l, x, y in hits[:4])
    return [_c("No shorts on the board", False, f"copper overlaps: {txt}", "none",
               "copper of two nets that overlaps is one conductor in the simulation - check the layout (KiCad DRC)")]
