"""Compact result pages.

Two things made the pages big: every page carried its own copy of plotly.js (4.8 MB), and the data
was plain JSON text (the wave views hold ~10 MB of field frames, mostly zeros).

* ``plotly_tag(page)``: one shared ``plotly.min.js`` in the project's ``rfsim`` folder, loaded by a
  relative path; a page copied elsewhere falls back to the CDN. ``standalone(page)`` inlines it again
  (*Save as single file* on the Results page).
* ``pack_page(html, data, page)``: the page data deflate-compressed and base64-encoded in a data
  block; a small boot script unpacks it (DecompressionStream) and then runs the page's main script.
  The fields compress 50-100x, plain JSON 3-5x.

``page_data(html)`` reads the data back (tests, tools).
"""
from __future__ import annotations

import base64
import json
import re
import zlib
from pathlib import Path

PLOTLY_CDN = "https://cdnjs.cloudflare.com/ajax/libs/plotly.js/2.35.2/plotly.min.js"
_SHARED_RE = re.compile(r'<script src="([^"]*plotly\.min\.js)" data-rfsim="plotly"></script>'
                        r'<script>window\.Plotly\|\|document\.write\(.*?\)</script>')

BOOT = r"""(async()=>{const el=document.getElementById("rfsim-data");
try{if(!window.DecompressionStream)throw new Error("this browser cannot unpack the page data - use a current Chrome, Edge, Firefox or Safari");
const b=atob(el.textContent.trim());const u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);
const s=new Blob([u]).stream().pipeThrough(new DecompressionStream("deflate"));
window[el.dataset.var]=JSON.parse(await new Response(s).text());}
catch(e){document.body.insertAdjacentHTML("afterbegin",'<p style="padding:12px;color:#b00020;font:14px system-ui">Page data could not be loaded: '+e.message+'</p>');return}
const m=document.getElementById("rfsim-main");const sc=document.createElement("script");sc.textContent=m.textContent;
document.body.appendChild(sc);})();"""


def _plotly_js() -> Path | None:
    try:
        import plotly
    except ImportError:
        return None
    js = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
    return js if js.exists() else None


def _shared_dir(page: Path) -> Path:
    """The project's rfsim folder above the page (or the page's own folder)."""
    for p in page.resolve().parents:
        if p.name == "rfsim":
            return p
    return page.resolve().parent


def plotly_tag(page: str | Path | None = None) -> str:
    """Script tag for plotly.js. With ``page``: the shared copy next to the project's pages (copied
    there once), with a CDN fallback for a page opened elsewhere. Without: inlined (standalone)."""
    js = _plotly_js()
    if page is None:
        if js is None:
            return f'<script src="{PLOTLY_CDN}"></script>'
        return "<script>" + js.read_text(encoding="utf-8").replace("</script>", "<\\/script>") + "</script>"
    page = Path(page)
    d = _shared_dir(page)
    target = d / "plotly.min.js"
    if js is not None:
        try:
            if not target.exists() or target.stat().st_size != js.stat().st_size:
                d.mkdir(parents=True, exist_ok=True)
                target.write_bytes(js.read_bytes())
        except OSError:
            pass
    if not target.exists():
        return f'<script src="{PLOTLY_CDN}"></script>'
    rel = Path(*([".."] * len(page.resolve().parent.relative_to(d).parts)), "plotly.min.js").as_posix()
    return (f'<script src="{rel}" data-rfsim="plotly"></script>'
            f'<script>window.Plotly||document.write(\'<script src="{PLOTLY_CDN}"><\\/script>\')</script>')


def pack(obj) -> str:
    raw = json.dumps(obj, separators=(",", ":")).encode()
    return base64.b64encode(zlib.compress(raw, 9)).decode("ascii")


def unpack(s: str):
    return json.loads(zlib.decompress(base64.b64decode(s)))


def pack_page(html: str, data, placeholder: str = "__DATA__", var: str = "D") -> str:
    """Move ``const <var>=<placeholder>;`` out of the main script: the data goes compressed into a
    data block, the main script runs after the boot script has unpacked it."""
    decl = f"const {var}={placeholder};"
    i = html.index(decl)
    s0 = html.rindex("<script>", 0, i)
    s1 = html.index("</script>", i)
    main = html[s0 + len("<script>"):s1].replace(decl, f"const {var}=window.__rfsim_{var};")
    block = (f'<script type="application/x-rfsim-data" id="rfsim-data" data-var="__rfsim_{var}">{pack(data)}</script>'
             f'<script type="text/x-rfsim-main" id="rfsim-main">{main}</script><script>{BOOT}</script>')
    return html[:s0] + block + html[s1 + len("</script>"):]


def page_data(html: str):
    """The data of a page written with ``pack_page`` (or a plain ``const D=...;`` page)."""
    m = re.search(r'id="rfsim-data"[^>]*>([^<]+)</script>', html)
    if m:
        return unpack(m.group(1))
    i = html.index("const D=") + len("const D=")
    return json.JSONDecoder().raw_decode(html[i:])[0]


def main_script(html: str) -> str:
    """The page's main script (as it runs after the data is unpacked)."""
    m = re.search(r'id="rfsim-main">(.*?)</script>', html, re.S)
    return m.group(1) if m else ""


def standalone(page: str | Path) -> str:
    """The page with plotly.js inlined: one file that works offline anywhere."""
    html = Path(page).read_text(encoding="utf-8")
    return _SHARED_RE.sub(lambda _m: plotly_tag(None), html)
