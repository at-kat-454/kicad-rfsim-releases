"""Field recording for the wave view.

openEMS writes the E-field on one horizontal plane (HDF5 dump boxes):
* time domain (every Nyquist/oversampling timesteps): the pulse travelling along the
  RF chain or leaving the antenna,
* frequency domain at chosen frequencies: complex field -> steady-state phase animation.
The plane lies in the middle of the dielectric under the top copper, where the field of
microstrip / coplanar lines is strongest. ``read_fields`` turns the dumps into numpy
arrays; ``write_wave_view`` makes the animated page.
"""
from __future__ import annotations

import base64
import json
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np

TD_NAME, FD_NAME = "fld_td", "fld_fd"
TOP_NAME = "fld_top"  # circuit wave run: extra TD plane 0.5 mm above the top copper (overlay)
COMPACT_PX = 512  # compact recordings: finest line spacing kept = plane / 512 (pages show 170-240 px)


def add_dumps(prop, lo, hi, freqs, oversampling: int = 10, td_name: str = TD_NAME, fd_name: str = FD_NAME):
    """Add the two dump boxes through the model's ``prop(tag, name, **attrs)`` helper."""
    def box(prims):
        b = ET.SubElement(prims, "Box", Priority="0")
        ET.SubElement(b, "P1", X=f"{lo[0]:.6g}", Y=f"{lo[1]:.6g}", Z=f"{lo[2]:.6g}")
        ET.SubElement(b, "P2", X=f"{hi[0]:.6g}", Y=f"{hi[1]:.6g}", Z=f"{hi[2]:.6g}")
    e, prims = prop("DumpBox", td_name, DumpType="0", DumpMode="2", FileType="1", OverSampling=str(oversampling))
    box(prims)
    if freqs:
        e, prims = prop("DumpBox", fd_name, DumpType="10", DumpMode="2", FileType="1")
        box(prims)
        fs = ET.SubElement(e, "FD_Samples")
        fs.text = ",".join(f"{f:.10g}" for f in freqs)


def _h5(path: Path):
    import h5py
    return h5py.File(path, "r")


def read_fields(run_dir: Path, td_name: str = TD_NAME, fd_name: str | None = None, normal: int | None = 2) -> dict | None:
    """{"x", "y" (mm), "td": [n, ny, nx] E normal, "t" (s), "fd": {f: complex [ny, nx]}} or None.

    ``normal``: axis of the plane normal (2: horizontal plane, field Ez on x / y; 0 or 1: vertical
    plane, "x" / "y" are then the two in-plane axes in increasing order, e.g. y and z for normal 0;
    None: the axis the dump is flat along). A compact recording (``<td_name>.npz``, see
    ``compact_fields``) is read in place of the HDF5 dumps."""
    run_dir = Path(run_dir)
    if fd_name is None:
        fd_name = FD_NAME if td_name == TD_NAME else "_none_"
    cz = run_dir / f"{td_name}.npz"
    if cz.exists():
        return load_compact(cz)
    td, fd = run_dir / f"{td_name}.h5", run_dir / f"{fd_name}.h5"
    if not td.exists():
        return None
    out = {}
    with _h5(td) as h:
        mesh = h["Mesh"]
        ax = [np.array(mesh[k]) for k in ("x", "y", "z")]
        if normal is None:
            normal = int(np.argmin([len(a) for a in ax]))
        x, y = [ax[k] for k in range(3) if k != normal]
        scale = 1e3 if max(np.max(np.abs(a)) for a in ax) < 1.0 else 1.0  # dumps are in m (with DeltaUnit) or drawing units
        out["x"], out["y"] = x * scale, y * scale
        g = h["FieldData"]["TD"]
        keys = sorted(g.keys(), key=lambda k: float(g[k].attrs.get("time", [0])[0]) if "time" in g[k].attrs else int(k))
        frames, times = [], []
        for k in keys:
            a = np.array(g[k])
            frames.append(_ez(a, len(x), len(y), normal))
            t = g[k].attrs.get("time")
            times.append(float(t[0]) if t is not None else 0.0)
        out["td"], out["t"] = np.array(frames), np.array(times)
    if fd.exists():
        with _h5(fd) as h:
            g = h["FieldData"]["FD"]
            res = {}
            for k in sorted(g.keys()):
                if k.endswith("_imag"):
                    continue
                ds = g[k]
                a = np.array(ds)
                if a.dtype.names:  # compound complex
                    nm = a.dtype.names
                    a = a[nm[0]] + 1j * a[nm[1]]
                elif k.endswith("_real") and (k[:-5] + "_imag") in g:
                    a = a + 1j * np.array(g[k[:-5] + "_imag"])
                fr = ds.attrs.get("frequency")
                f = float(np.ravel(fr)[0]) if fr is not None else 0.0
                res[f] = _ez(a, len(out["x"]), len(out["y"]), normal)
            out["fd"] = res
    return out


def _q8(a: np.ndarray, axes) -> tuple[np.ndarray, np.ndarray]:
    """int8 with one scale per frame (``axes``: the axes reduced for the peak)."""
    pk = np.max(np.abs(a), axis=axes, keepdims=True).astype(np.float32)
    pk[pk == 0] = 1.0
    return np.clip(np.round(a / pk * 127), -127, 127).astype(np.int8), np.squeeze(pk, axis=axes)


def _thin(a: np.ndarray, step: float) -> np.ndarray:
    """Indices of mesh lines at least ``step`` apart (first and last kept)."""
    keep = [0]
    for i in range(1, len(a) - 1):
        if a[i] - a[keep[-1]] >= step * 0.999:
            keep.append(i)
    if len(a) > 1:
        keep.append(len(a) - 1)
    return np.array(keep, int)


def save_compact(path: Path, F: dict, n_long: int = COMPACT_PX) -> Path:
    """A recording as the wave views and the overlay use it: the normal field component on the
    mesh lines at least 1/``n_long`` of the plane apart (the pages show 200-240 px), 8 bit per
    value with a scale per frame, all frames, compressed.
    About 1 % of the HDF5 dumps (three components, every mesh line, 32 bit)."""
    x, y = np.asarray(F["x"], float), np.asarray(F["y"], float)
    step = max(x[-1] - x[0], y[-1] - y[0]) / n_long
    xi, yi = _thin(x, step), _thin(y, step)  # mesh lines kept: values there are exact
    td = np.asarray(F["td"], np.float32)[:, yi][:, :, xi]
    q, sc = _q8(td, (1, 2))
    d = {"x": x[xi], "y": y[yi], "t": np.asarray(F["t"], float), "td": q, "td_s": sc}
    fs = sorted(F.get("fd", {}))
    if fs:
        a = np.stack([np.asarray(F["fd"][f])[yi][:, xi] for f in fs])
        d["fd_f"] = np.array(fs, float)
        d["fd_re"], d["fd_rs"] = _q8(a.real.astype(np.float32), (1, 2))
        d["fd_im"], d["fd_is"] = _q8(a.imag.astype(np.float32), (1, 2))
    path = Path(path)
    np.savez_compressed(path, **d)
    return path


def load_compact(path: Path) -> dict:
    with np.load(path) as z:
        out = {"x": z["x"], "y": z["y"], "t": z["t"],
               "td": z["td"].astype(np.float32) * (z["td_s"][:, None, None] / 127.0)}
        if "fd_f" in z:
            re = z["fd_re"].astype(np.float32) * (z["fd_rs"][:, None, None] / 127.0)
            im = z["fd_im"].astype(np.float32) * (z["fd_is"][:, None, None] / 127.0)
            out["fd"] = {float(f): re[i] + 1j * im[i] for i, f in enumerate(z["fd_f"])}
        else:
            out["fd"] = {}
    return out


def recording_exists(run_dir: Path, td_name: str = TD_NAME) -> bool:
    run_dir = Path(run_dir)
    return (run_dir / f"{td_name}.h5").exists() or (run_dir / f"{td_name}.npz").exists()


def compact_fields(run_dir: Path) -> tuple[int, int]:
    """Replace the HDF5 field dumps of one run folder by compact recordings (``save_compact``).
    Returns (dumps compacted, bytes freed). A dump that cannot be read stays."""
    import h5py
    run_dir = Path(run_dir)
    n = freed = 0
    for td in sorted(run_dir.glob("fld_*.h5")):
        try:
            with h5py.File(td, "r") as h:
                if "TD" not in h.get("FieldData", {}):
                    continue
        except OSError:
            continue
        name = td.stem
        fd = run_dir / (f"{FD_NAME}.h5" if name == TD_NAME else f"{name}_fd.h5")
        try:
            F = read_fields(run_dir, name, fd.stem if fd.exists() else "_none_", normal=None)
            if F is None or not len(F["td"]):
                continue
            cz = save_compact(run_dir / f"{name}.npz", F)
            load_compact(cz)  # readable before the originals go
        except Exception:  # noqa: BLE001 - keep the original
            (run_dir / f"{name}.npz").unlink(missing_ok=True)
            continue
        for f in (td, fd):
            if f.exists():
                freed += f.stat().st_size
                f.unlink()
        freed -= cz.stat().st_size
        n += 1
    return n, freed


def _ez(a: np.ndarray, nx: int, ny: int, normal: int = 2) -> np.ndarray:
    """E component normal to the plane as [ny, nx] from an openEMS vector dump."""
    if normal != 2:  # vertical plane: dumps are [3, nx, ny, nz] (d_order NXYZ)
        a = np.asarray(a)
        c = a[normal] if a.shape[0] == 3 else a[..., normal]
        c = np.take(c, 0, axis=normal) if c.ndim == 3 else np.squeeze(c)
        return c.T if c.shape == (nx, ny) else c
    a = np.squeeze(a)
    # openEMS HDF5 vector dumps: [3, nz, ny, nx] or [3, ny, nx] after squeezing the flat z
    if a.shape[0] == 3:
        ez = a[2]
    elif a.shape[-1] == 3:
        ez = a[..., 2]
    else:
        ez = a
    ez = np.squeeze(ez)
    if ez.shape == (nx, ny):
        ez = ez.T
    return ez


def _resample(a: np.ndarray, x: np.ndarray, y: np.ndarray, n_long: int = 240):
    """Field on a non-uniform mesh -> uniform pixel grid (nearest cell)."""
    w, h = x[-1] - x[0], y[-1] - y[0]
    s = max(w, h) / n_long
    nx, ny = max(2, int(round(w / s))), max(2, int(round(h / s)))
    xi = np.clip(np.searchsorted(x, np.linspace(x[0], x[-1], nx)) , 0, len(x) - 1)
    yi = np.clip(np.searchsorted(y, np.linspace(y[0], y[-1], ny)), 0, len(y) - 1)
    if a.ndim == 3:
        return a[:, yi][:, :, xi], nx, ny
    return a[yi][:, xi], nx, ny


def triangulate(poly) -> list:
    """Triangles [(x, y) x3] of a shapely polygon (holes respected)."""
    import shapely
    out = []
    cdt = getattr(shapely, "constrained_delaunay_triangles", None)  # shapely >= 2.1
    for g in getattr(poly, "geoms", [poly]):
        if g.is_empty or g.geom_type != "Polygon":
            continue
        if cdt is not None:
            tris = getattr(cdt(g), "geoms", [])
        else:
            from shapely.ops import triangulate as _tri
            from shapely.prepared import prep
            gb = prep(g.buffer(1e-6))  # once per polygon (per triangle it took 30 s on a big board)
            tris = [t for t in _tri(g) if gb.contains(t)]
        out += [list(t.exterior.coords)[:3] for t in tris]
    return out


def mesh3d(tris3, color: str, name: str, opacity: float = 1.0) -> dict:
    """Plotly mesh3d dict from 3-D triangles [[(x, y, z) x3], ...]."""
    xs, ys, zs, i, j, k = [], [], [], [], [], []
    for t in tris3:
        n = len(xs)
        for x, y, z in t:
            xs.append(round(float(x), 3))
            ys.append(round(float(y), 3))
            zs.append(round(float(z), 4))
        i.append(n)
        j.append(n + 1)
        k.append(n + 2)
    return {"type": "mesh3d", "x": xs, "y": ys, "z": zs, "i": i, "j": j, "k": k, "color": color,
            "opacity": opacity, "name": name, "flatshading": True, "hoverinfo": "skip"}


def slab(poly, z0: float, z1: float) -> list:
    """Triangles of a board slab: top, bottom and side walls of ``poly`` between z0 and z1."""
    tris = []
    for a, b, c in triangulate(poly):
        tris.append([(*a, z1), (*b, z1), (*c, z1)])
        tris.append([(*a, z0), (*b, z0), (*c, z0)])
    for g in getattr(poly, "geoms", [poly]):
        for ring in [g.exterior] + list(g.interiors):
            c = list(ring.coords)
            for (xa, ya), (xb, yb) in zip(c, c[1:]):
                tris.append([(xa, ya, z0), (xb, yb, z0), (xb, yb, z1)])
                tris.append([(xa, ya, z0), (xb, yb, z1), (xa, ya, z1)])
    return tris


def _b64_i8(a: np.ndarray) -> str:
    return base64.b64encode(np.clip(np.round(a * 127), -127, 127).astype(np.int8).tobytes()).decode()


def write_wave_view(F: dict, outlines: list, path: Path, title: str = "Wave view", note: str = "",
                    max_frames: int = 140, y_up: bool = False, show: str = "signed",
                    scene: list | None = None, plane_z: float | None = None, plane_opacity: float = 0.85,
                    pic: dict | None = None, plane3d: dict | None = None, links: list | None = None,
                    comp_label: str = "E vertical (sign = direction)", where: str = "") -> Path:
    """``pic``: boardpic.picture() of the board (KiCad coordinates) drawn under the field.
    ``scene``: plotly mesh3d dicts (board, copper) for the 3D view, in the same x / y as the
    field (y already pointing up); ``plane_z``: height of the field plane in that scene."""
    """Animated page: pulse in time (TD frames) and steady state at each recorded frequency.
    ``outlines``: copper polygons [(net, [(x, y), ...])] in mm for the overlay."""
    from .boardpic import JS_DRAW
    x, y = F["x"], F["y"]
    td = F["td"]
    t = F["t"]
    if len(td) > max_frames:
        k = np.linspace(0, len(td) - 1, max_frames).astype(int)
        td, t = td[k], t[k]
    tdr, nx, ny = _resample(td, x, y)
    peak = float(np.max(np.abs(tdr))) or 1.0
    frame_peak = (np.max(np.abs(tdr), axis=(1, 2)) / peak).round(4).tolist()
    fds = []
    for f, a in sorted(F.get("fd", {}).items()):
        ar, _, _ = _resample(a, x, y)
        m = float(np.max(np.abs(ar))) or 1.0
        fds.append({"f": f, "re": _b64_i8(ar.real / m), "im": _b64_i8(ar.imag / m)})
    data = {"title": title, "note": note, "nx": nx, "ny": ny, "x0": float(x[0]), "x1": float(x[-1]),
            "y0": float(y[0]), "y1": float(y[-1]), "yup": y_up, "show": show, "td": _b64_i8(tdr / peak), "nt": int(len(tdr)),
            "t": (t * 1e9).round(5).tolist(), "fpeak": frame_peak, "fd": fds,
            "outlines": [[n, [[round(px, 3), round(py, 3)] for px, py in pts]] for n, pts in outlines],
            "scene": scene or [], "pz": plane_z, "sop": plane_opacity, "pic": pic, "p3": plane3d,
            "links": [[a, b] for a, b in (links or [])], "clab": comp_label, "where": where}
    path = Path(path)
    from .pagepack import pack_page, plotly_tag
    plotly = plotly_tag(path) if scene else ""
    html = pack_page(_TPL.replace("__TITLE__", title).replace("__PLOTLY__", plotly).replace("__BOARDJS__", JS_DRAW), data)
    path.write_text(html, encoding="utf-8")
    return path


_TPL = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>__PLOTLY__<style>
:root{--bg:#fafaf8;--fg:#1d1d1b;--mut:#6b6b66;--card:#fff;--line:#e3e2dc;--acc:#2a6fdb;--cu:#1d1d1b}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff;--cu:#f4f3ee}}
:root[data-theme="dark"]{--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff;--cu:#f4f3ee}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 system-ui,sans-serif}
header{padding:14px 16px;border-bottom:1px solid var(--line)}h1{font-size:17px;margin:0}.sub{color:var(--mut);font-size:12px}
main{padding:14px 16px;display:grid;grid-template-columns:300px 1fr;gap:14px}@media(max-width:820px){main{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px;min-width:0}
label{display:flex;gap:8px;align-items:center;margin:8px 0;font-size:13px}select,input[type=range]{flex:1;min-width:0;font:inherit}
button{background:var(--acc);color:#fff;border:0;border-radius:6px;padding:7px 14px;cursor:pointer;font:inherit}
canvas{width:100%;height:auto;image-rendering:auto;border-radius:6px;background:#000}
#cbar{height:10px;border-radius:5px;margin-top:6px}.row{display:flex;justify-content:space-between;font-size:12px;color:var(--mut)}
</style></head><body>
<header><span style="float:right;font-size:12px"><span id="links"></span><a href="solver_info.html" style="color:var(--acc)">How this was solved →</a></span>
<h1 id="t"></h1><div class="sub" id="note"></div></header>
<main><section class="card">
<label>View <select id="mode"></select></label>
<label id="v3row" style="display:none"><input type="checkbox" id="v3" style="flex:0"> 3D (field over the board; drag to rotate)</label>
<div><button id="play">Pause</button></div>
<label>Speed <input type="range" id="speed" min="2" max="60" value="20"></label>
<label>Time <input type="range" id="pos" min="0" max="100" value="0"></label>
<div class="row"><span id="tlab"></span><span id="flab"></span></div>
<label>Show <select id="comp"><option value="signed">E vertical (sign = direction)</option><option value="mag">|E| magnitude</option></select></label>
<label><input type="checkbox" id="auto" checked style="flex:0"> scale each frame (follow the pulse as it fades)</label>
<label>Contrast <input type="range" id="gain" min="1" max="30" value="3"></label>
<label>Background <select id="bg"><option value="board">realistic board</option><option value="outlines">copper outlines</option><option value="none">field only</option></select></label>
<label class="bgo">Field opacity <input type="range" id="op" min="10" max="100" value="80"></label>
<label class="bgo"><input type="checkbox" id="parts" checked style="flex:0"> part bodies</label>
<label class="bgo"><input type="checkbox" id="refs" style="flex:0"> part labels</label>
<div id="cbar"></div><div class="row"><span id="cb0"></span><span id="cb1"></span></div>
<p class="sub" id="where">E-field on one plane (see the line under the title) over the board (top side). Pulse: the broadband
excitation travelling through the layout. Steady state: the field at one frequency over one RF period.</p>
</section><section class="card"><canvas id="cv"></canvas><div id="p3" style="display:none;height:640px"></div></section></main>
<script>__BOARDJS__
const D=__DATA__;document.getElementById('t').textContent=D.title;document.getElementById('note').textContent=D.note;
(D.links||[]).forEach(([l,h])=>{const a=document.createElement('a');a.href=h;a.textContent=l;a.style.color='var(--acc)';a.style.marginRight='14px';document.getElementById('links').appendChild(a)});
if(D.clab)document.querySelector('#comp option[value=signed]').textContent=D.clab;if(D.where)document.getElementById('where').textContent=D.where;
const dec=b=>{const s=atob(b),a=new Int8Array(s.length);for(let i=0;i<s.length;i++){a[i]=(s.charCodeAt(i)<<24)>>24}return a};
const TD=dec(D.td),FD=D.fd.map(o=>({f:o.f,re:dec(o.re),im:dec(o.im)})),N=D.nx*D.ny;
const sel=document.getElementById('mode');sel.add(new Option('Pulse in time','td'));FD.forEach((o,i)=>sel.add(new Option('Steady state at '+(o.f/1e6).toFixed(0)+' MHz','fd'+i)));
const cv=document.getElementById('cv'),ctx=cv.getContext('2d');const S=1100/Math.max(D.nx,D.ny);
cv.width=Math.round(D.nx*S);cv.height=Math.round(D.ny*S);
const $=id=>document.getElementById(id);if(!D.pic){$('bg').value='outlines';$('bg').querySelector('[value=board]').disabled=true}
let bgc=null;function boardBg(){const c=document.createElement('canvas');c.width=cv.width;c.height=cv.height;const x=c.getContext('2d');
 x.fillStyle='#0d0d0c';x.fillRect(0,0,c.width,c.height);const sx=cv.width/(D.x1-D.x0),sy=cv.height/(D.y1-D.y0);
 drawBoard(x,D.pic,X=>(X-D.x0)*sx,Y=>D.yup?(D.y1+Y)*sy:(Y-D.y0)*sy,sx,{parts:$('parts').checked,refs:$('refs').checked});return c}
function bgOpts(){document.querySelectorAll('.bgo').forEach(e=>e.style.display=$('bg').value==='board'?'flex':'none');bgc=null}const img=ctx.createImageData(D.nx,D.ny);const off=document.createElement('canvas');off.width=D.nx;off.height=D.ny;
function col(v,mag){if(mag){const a=Math.min(1,Math.abs(v));const r=Math.round(255*Math.min(1,a*1.6)),g=Math.round(255*Math.max(0,a*1.6-0.6)),b=Math.round(80*(1-a));return[r,g,b]}
 v=Math.max(-1,Math.min(1,v));const a=Math.abs(v);if(v>=0)return[255,Math.round(255*(1-a)),Math.round(255*(1-a))];return[Math.round(255*(1-a)),Math.round(255*(1-a)),255]}
let frame=0,playing=true,last=0;const PH=48;
function nFrames(){return sel.value==='td'?D.nt:PH}
function values(k){const out=new Float32Array(N);if(sel.value==='td'){const o=k*N;for(let i=0;i<N;i++)out[i]=TD[o+i]/127}
 else{const F=FD[+sel.value.slice(2)],ph=2*Math.PI*k/PH,c=Math.cos(ph),s=Math.sin(ph);for(let i=0;i<N;i++)out[i]=(F.re[i]*c-F.im[i]*s)/127}return out}
function draw(){const k=frame%nFrames();const v=values(k),mag=document.getElementById('comp').value==='mag';
 let g=+document.getElementById('gain').value;if(document.getElementById('auto').checked&&sel.value==='td'){g=g/Math.max(1e-3,D.fpeak[k])}
 const bg=$('bg').value,brd=bg==='board',op=+$('op').value/100;
 if(brd){if(!bgc)bgc=boardBg();ctx.drawImage(bgc,0,0)}
 for(let j=0;j<D.ny;j++)for(let i=0;i<D.nx;i++){const val=v[(D.yup?(D.ny-1-j):j)*D.nx+i]*g;const [r,gg,b]=col(val,mag);const p=4*(j*D.nx+i);img.data[p]=r;img.data[p+1]=gg;img.data[p+2]=b;
  img.data[p+3]=brd?Math.round(255*op*Math.min(1,Math.abs(val)*1.5)):255}
 off.getContext('2d').putImageData(img,0,0);ctx.imageSmoothingEnabled=true;ctx.drawImage(off,0,0,cv.width,cv.height);
 const sx=cv.width/(D.x1-D.x0),sy=cv.height/(D.y1-D.y0);ctx.strokeStyle=mag?'#e8e8e8':'#1d1d1b';ctx.lineWidth=1.2;ctx.globalAlpha=bg==='outlines'?0.8:0;
 if(bg==='outlines')for(const [n,pts] of D.outlines){ctx.beginPath();pts.forEach(([x,y],i)=>{const X=(x-D.x0)*sx,Y=D.yup?(D.y1-y)*sy:(y-D.y0)*sy;i?ctx.lineTo(X,Y):ctx.moveTo(X,Y)});ctx.closePath();ctx.stroke()}ctx.globalAlpha=1;
 document.getElementById('pos').max=nFrames()-1;document.getElementById('pos').value=k;
 document.getElementById('tlab').textContent=sel.value==='td'?('t = '+D.t[k].toFixed(3)+' ns'):('phase '+Math.round(360*k/PH)+'°');
 document.getElementById('flab').textContent=sel.value==='td'?('frame '+(k+1)+' / '+D.nt):'one RF period'}
// ---- 3D view: board + copper (mesh3d) and the field plane as a coloured surface
const has3d=D.scene.length&&window.Plotly;let p3init=false;
if(has3d)document.getElementById('v3row').style.display='flex';
function surf3(){if(!D.p3){const [xs,ys]=grid();return{x:xs,y:ys,z:ys.map(()=>xs.map(()=>D.pz))}}
 const P=D.p3,X=[],Y=[],Z=[];for(let j=0;j<D.ny;j++){const xr=[],yr=[],zr=[],v=D.y0+(D.y1-D.y0)*j/(D.ny-1);
  for(let i=0;i<D.nx;i++){const u=D.x0+(D.x1-D.x0)*i/(D.nx-1),g=[0,0,0];g[P.n]=P.e;g[P.h]=P.s*u;g[2]=v;xr.push(g[0]);yr.push(g[1]);zr.push(g[2])}
  X.push(xr);Y.push(yr);Z.push(zr)}return{x:X,y:Y,z:Z}}
function grid(){const xs=[],ys=[];for(let i=0;i<D.nx;i++)xs.push(D.x0+(D.x1-D.x0)*i/(D.nx-1));
 for(let j=0;j<D.ny;j++){const yy=D.y0+(D.y1-D.y0)*j/(D.ny-1);ys.push(D.yup?yy:-yy)}return[xs,ys]}
function surfColor(k,g,mag){const v=values(k),z=[];for(let j=0;j<D.ny;j++){const r=[];for(let i=0;i<D.nx;i++){const x=v[j*D.nx+i]*g;r.push(mag?Math.min(1,Math.abs(x)):Math.max(-1,Math.min(1,x)))}z.push(r)}return z}
function draw3d(k){const mag=document.getElementById('comp').value==='mag';let g=+document.getElementById('gain').value;
 if(document.getElementById('auto').checked&&sel.value==='td')g=g/Math.max(1e-3,D.fpeak[k]);
 const sc=surfColor(k,g,mag);
 if(!p3init){const G3=surf3();
  const cs=mag?[[0,'#0b0040'],[0.5,'#c0392b'],[1,'#fff200']]:[[0,'#0000ff'],[0.5,'#ffffff'],[1,'#ff0000']];
  const tr=D.scene.map(m=>Object.assign({},m,{lighting:{ambient:0.7,diffuse:0.6}}));
  tr.push({type:'surface',x:G3.x,y:G3.y,z:G3.z,surfacecolor:sc,cmin:mag?0:-1,cmax:1,colorscale:cs,showscale:false,opacity:D.sop||0.85,hoverinfo:'skip'});
  Plotly.newPlot('p3',tr,{margin:{l:0,r:0,t:0,b:0},paper_bgcolor:'rgba(0,0,0,0)',showlegend:false,
   scene:{bgcolor:'rgba(0,0,0,0)',aspectmode:'data',xaxis:{visible:false},yaxis:{visible:false},zaxis:{visible:false},camera:{eye:{x:0.9,y:-1.3,z:0.9}}}},{displaylogo:false,responsive:true});p3init=true}
 else Plotly.restyle('p3',{surfacecolor:[sc],cmin:[mag?0:-1],colorscale:[mag?[[0,'#0b0040'],[0.5,'#c0392b'],[1,'#fff200']]:[[0,'#0000ff'],[0.5,'#ffffff'],[1,'#ff0000']]]},[D.scene.length])}
const on3d=()=>has3d&&document.getElementById('v3').checked;
document.getElementById('v3').onchange=()=>{document.getElementById('cv').style.display=on3d()?'none':'block';document.getElementById('p3').style.display=on3d()?'block':'none';
 document.getElementById('speed').value=on3d()?Math.min(8,+document.getElementById('speed').value):document.getElementById('speed').value;draw()};
const draw2d=draw;draw=function(){draw2d();if(on3d())draw3d(frame%nFrames())};
function tick(ts){if(playing&&ts-last>1000/+document.getElementById('speed').value){frame=(frame+1)%nFrames();last=ts;draw()}requestAnimationFrame(tick)}
document.getElementById('play').onclick=e=>{playing=!playing;e.target.textContent=playing?'Pause':'Play'};
document.getElementById('pos').oninput=e=>{frame=+e.target.value;playing=false;document.getElementById('play').textContent='Play';draw()};
['mode','comp','auto','gain','op'].forEach(id=>document.getElementById(id).oninput=()=>{if(id==='mode')frame=0;cbar();draw()});
['bg','parts','refs'].forEach(id=>$(id).onchange=()=>{bgOpts();draw()});bgOpts();
function cbar(){const mag=document.getElementById('comp').value==='mag';const st=[];for(let i=0;i<=10;i++){const v=mag?i/10:(i/5-1);const [r,g,b]=col(v,mag);st.push(`rgb(${r},${g},${b}) ${i*10}%`)}
 document.getElementById('cbar').style.background=`linear-gradient(90deg,${st.join(',')})`;document.getElementById('cb0').textContent=mag?'0':'− (down)';document.getElementById('cb1').textContent=mag?'max':'+ (up)'}
document.getElementById('comp').value=D.show||'signed';cbar();draw();requestAnimationFrame(tick);
</script></body></html>"""
