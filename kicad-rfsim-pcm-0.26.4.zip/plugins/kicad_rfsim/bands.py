"""Frequency band presets for the tuning viewer and the antenna report.

Each band: (group, name, [(lo, hi) MHz, ...]) - FDD bands with their uplink and downlink ranges.
Values: 3GPP TS 36.101 / 38.101 (LTE / NR), ETSI EN 300 220 and ERC/REC 70-03 annex 1 (SRD 868,
wireless M-Bus EN 13757-4), ITU-R radio regulations (ISM), GNSS interface documents, IEEE 802.15.4z
(UWB channels).
"""
from __future__ import annotations

import json

BANDS = [
    ("ISM / SRD", "SRD 868 MHz (863-870)", [(863.0, 870.0)]),
    ("ISM / SRD", "SRD 868 g1 868.0-868.6 (EnOcean, wM-Bus S, Sigfox)", [(868.0, 868.6)]),
    ("ISM / SRD", "SRD 868 g3 869.4-869.65 (500 mW)", [(869.4, 869.65)]),
    ("ISM / SRD", "wireless M-Bus T/C 868.95 (868.7-869.2)", [(868.7, 869.2)]),
    ("ISM / SRD", "wireless M-Bus N 169 MHz", [(169.4, 169.475)]),
    ("ISM / SRD", "ISM 433 MHz (433.05-434.79)", [(433.05, 434.79)]),
    ("ISM / SRD", "ISM 915 MHz (902-928)", [(902.0, 928.0)]),
    ("ISM / SRD", "ISM 2.4 GHz (2400-2483.5: BLE, Zigbee, Thread, Wi-Fi)", [(2400.0, 2483.5)]),
    ("ISM / SRD", "ISM 5.8 GHz (5725-5875)", [(5725.0, 5875.0)]),
    ("LoRa", "LoRaWAN EU868 (863-870)", [(863.0, 870.0)]),
    ("LoRa", "LoRaWAN US915 (902-928)", [(902.0, 928.0)]),
    ("LoRa", "LoRaWAN AS923 (915-928)", [(915.0, 928.0)]),
    ("LoRa", "LoRa 2.4 GHz", [(2400.0, 2483.5)]),
    ("LTE / NB-IoT / LTE-M", "LTE-M / NB-IoT Europe (B20 + B8)", [(791.0, 821.0), (832.0, 862.0), (880.0, 915.0), (925.0, 960.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B20 (800: UL 832-862, DL 791-821)", [(791.0, 821.0), (832.0, 862.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B8 (900: UL 880-915, DL 925-960)", [(880.0, 915.0), (925.0, 960.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B28 (700: UL 703-748, DL 758-803)", [(703.0, 748.0), (758.0, 803.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B3 (1800: UL 1710-1785, DL 1805-1880)", [(1710.0, 1785.0), (1805.0, 1880.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B1 (2100: UL 1920-1980, DL 2110-2170)", [(1920.0, 1980.0), (2110.0, 2170.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B7 (2600: UL 2500-2570, DL 2620-2690)", [(2500.0, 2570.0), (2620.0, 2690.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B5 (850: UL 824-849, DL 869-894)", [(824.0, 849.0), (869.0, 894.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B12 (700 a: UL 699-716, DL 729-746)", [(699.0, 716.0), (729.0, 746.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B13 (700 c: UL 777-787, DL 746-756)", [(746.0, 756.0), (777.0, 787.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B2 (1900: UL 1850-1910, DL 1930-1990)", [(1850.0, 1910.0), (1930.0, 1990.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE B4 / B66 (AWS: 1710-1780, 2110-2200)", [(1710.0, 1780.0), (2110.0, 2200.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE low band world (B12/13/20/28/5/8: 699-960)", [(699.0, 960.0)]),
    ("LTE / NB-IoT / LTE-M", "LTE mid band world (B1/2/3/4/66: 1710-2200)", [(1710.0, 2200.0)]),
    ("LTE / NB-IoT / LTE-M", "5G NR n78 (3300-3800)", [(3300.0, 3800.0)]),
    ("GSM", "GSM 900 (UL 880-915, DL 925-960)", [(880.0, 915.0), (925.0, 960.0)]),
    ("GSM", "GSM 1800 (UL 1710-1785, DL 1805-1880)", [(1710.0, 1785.0), (1805.0, 1880.0)]),
    ("GNSS", "GNSS L1 / E1 / B1 / G1 (1559-1610)", [(1559.0, 1610.0)]),
    ("GNSS", "GPS L1 C/A (1575.42 ± 1.023)", [(1574.397, 1576.443)]),
    ("GNSS", "GNSS L5 / E5a (1164-1189)", [(1164.0, 1189.0)]),
    ("GNSS", "GNSS L2 (1215-1240)", [(1215.0, 1240.0)]),
    ("Wi-Fi", "Wi-Fi 2.4 GHz (2400-2483.5)", [(2400.0, 2483.5)]),
    ("Wi-Fi", "Wi-Fi 5 GHz (5150-5850)", [(5150.0, 5850.0)]),
    ("Wi-Fi", "Wi-Fi 6E (5925-7125)", [(5925.0, 7125.0)]),
    ("UWB", "UWB channel 5 (6240-6739.2)", [(6240.0, 6739.2)]),
    ("UWB", "UWB channel 9 (7737.6-8236.8)", [(7737.6, 8236.8)]),
]


def payload() -> list[dict]:
    return [{"g": g, "n": n, "r": [[lo * 1e6, hi * 1e6] for lo, hi in r]} for g, n, r in BANDS]


# JS helpers shared by the pages: BANDS, fillBands(select), bandShapes(band, scale), inBand(f, band)
JS = r"""
const BANDS=__BANDS__;
function fillBands(sel,fmin,fmax){sel.innerHTML='<option value="">none</option>';const groups={};
 BANDS.forEach((b,i)=>{const lo=Math.min(...b.r.map(r=>r[0])),hi=Math.max(...b.r.map(r=>r[1]));
  if(hi<fmin||lo>fmax)return;(groups[b.g]=groups[b.g]||[]).push([i,b])});
 for(const [g,list] of Object.entries(groups)){const og=document.createElement('optgroup');og.label=g;
  list.forEach(([i,b])=>{const o=document.createElement('option');o.value=i;o.textContent=b.n;og.appendChild(o)});sel.appendChild(og)}}
function addDesignBand(sel,band){// the board's operating band (setup) as the first entry; returns its value or null
 if(!band||!band.length)return null;const i=BANDS.length;
 BANDS.push({g:'This board',n:'operating band ('+band.map(r=>r[0]===r[1]?`${+(r[0]/1e6).toFixed(1)}`:`${+(r[0]/1e6).toFixed(1)}-${+(r[1]/1e6).toFixed(1)}`).join(', ')+' MHz)',r:band});
 const og=document.createElement('optgroup');og.label='This board';const o=document.createElement('option');o.value=i;o.textContent=BANDS[i].n;
 og.appendChild(o);sel.insertBefore(og,sel.children[1]||null);return String(i)}
function bandOf(sel){return sel&&sel.value!==''?BANDS[+sel.value]:null}
function bandEdges(b){return[Math.min(...b.r.map(r=>r[0])),Math.max(...b.r.map(r=>r[1]))]}
function bandShapes(b,scale){if(!b)return[];return b.r.map(([lo,hi])=>({type:'rect',xref:'x',yref:'paper',x0:lo/scale,x1:hi/scale,y0:0,y1:1,
 fillcolor:'rgba(46,160,90,0.13)',line:{width:0},layer:'below'}))}
function inBand(f,b){return!!b&&b.r.some(([lo,hi])=>f>=lo-1&&f<=hi+1)}
"""


def js() -> str:
    return JS.replace("__BANDS__", json.dumps(payload()))


# ---------------------------------------------------------------------------
# operating band of a design: one definition for the antenna and the RF chain setups
# ---------------------------------------------------------------------------
OPERATING = [  # (label, [(lo, hi) MHz]) offered on the Setup and Solver Settings pages
    ("SRD 868 MHz (863-870)", [(863.0, 870.0)]),
    ("ISM 915 MHz (902-928)", [(902.0, 928.0)]),
    ("868 + 915 MHz (863-928)", [(863.0, 928.0)]),
    ("ISM 433 MHz (433.05-434.79)", [(433.05, 434.79)]),
    ("ISM 2.4 GHz (2400-2483.5)", [(2400.0, 2483.5)]),
    ("868 MHz + 2.4 GHz", [(863.0, 870.0), (2400.0, 2483.5)]),
    ("LTE-M / NB-IoT EU (791-960)", [(791.0, 960.0)]),
    ("LTE-M / NB-IoT low band (699-960)", [(699.0, 960.0)]),
    ("GNSS L1 (1559-1610)", [(1559.0, 1610.0)]),
    ("Wi-Fi 5 GHz (5150-5850)", [(5150.0, 5850.0)]),
]
DEFAULT_RANGES = [(863.0, 870.0)]


def parse_ranges(text: str) -> list[tuple[float, float]]:
    """'2400-2483.5, 863-870' or '868' (a single frequency) -> [(lo, hi) MHz], sorted."""
    out = []
    for part in str(text).replace(";", ",").split(","):
        p = part.strip().lower().replace("mhz", "").replace(" ", "")
        if not p:
            continue
        if "-" in p[1:]:
            i = p.index("-", 1)
            lo, hi = float(p[:i]), float(p[i + 1:])
        else:
            lo = hi = float(p)
        if lo <= 0 or hi <= 0:
            raise ValueError(f"'{part.strip()}': frequencies must be > 0 MHz")
        out.append((min(lo, hi), max(lo, hi)))
    if not out:
        raise ValueError("Enter the operating band in MHz, e.g. 2400-2483.5 or 863-870, 2400-2483.5")
    return sorted(out)


def format_ranges(ranges) -> str:
    return ", ".join(f"{lo:g}" if lo == hi else f"{lo:g}-{hi:g}" for lo, hi in ranges)


def label_of(ranges) -> str:
    r = [tuple(map(float, x)) for x in ranges]
    for lab, rr in OPERATING:
        if rr == r:
            return lab
    return "Custom"


def _groups(ranges):
    """Ranges closer than 15 % of their frequency form one band (e.g. LTE uplink + downlink)."""
    gs = []
    for lo, hi in sorted(ranges):
        if gs and lo - gs[-1][1] < 0.15 * lo:
            gs[-1][1] = max(gs[-1][1], hi)
        else:
            gs.append([lo, hi])
    return [(lo, hi) for lo, hi in gs]


def derive(ranges) -> dict:
    """Frequencies of the antenna and the RF chain setups from the operating band (MHz in, Hz out).

    Sweep 0.6 x the lowest to 1.5 x the highest band centre (both setups the same), a frequency step
    of a quarter of the narrowest band (at most 0.5 % of its centre; 201..1001 points), far field and
    markers at the band edges and centre (centres only for three or more bands), lumped-part Q
    referred to the geometric mean of the band centres."""
    gs = _groups(ranges)
    cs = [(lo + hi) / 2 for lo, hi in gs]
    f_min = float(round(0.6 * gs[0][0]))
    f_max = float(round(1.5 * cs[-1]))
    step = min(max(min((hi - lo) / 4, 0.005 * c), 0.05) for (lo, hi), c in zip(gs, cs))
    pts = int(min(1001, max(201, round((f_max - f_min) / step) + 1)))
    if len(gs) <= 2:
        ff = [x for (lo, hi), c in zip(gs, cs) for x in ((lo, c, hi) if hi - lo > 0.002 * c else (c,))]
    else:
        ff = cs[:6]
    marks = [x for (lo, hi), c in zip(gs, cs) for x in ((lo, c, hi) if hi - lo > 0.002 * c else (c,))]
    if len(marks) > 3:
        marks = cs[:3]
    gm = 1.0
    for c in cs:
        gm *= c
    gm **= 1 / len(cs)
    r = lambda x: round(x * 1e6, -3)  # noqa: E731  Hz, 1 kHz grid
    return {"ranges_mhz": [[lo, hi] for lo, hi in ranges],
            "antenna": {"f_min": r(f_min), "f_max": r(f_max), "f_points": pts, "f_farfield": [r(x) for x in ff],
                        "f_loss": r(gm)},
            "circuit": {"f_min": r(f_min), "f_max": r(f_max), "points": pts, "marks_hz": [r(x) for x in marks]},
            "f_q": r(gm)}
