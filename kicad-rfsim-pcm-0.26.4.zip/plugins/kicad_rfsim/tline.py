"""Closed-form transmission line models (quasi-static).

Used for fast plausibility checks before a full-wave run.
Formulas: Hammerstad-Jensen microstrip, Wadell/Ghione grounded CPW (CPWG).
Copper thickness is handled by the usual effective-width correction.
"""
from __future__ import annotations

import math

from scipy.special import ellipk

ETA0 = 376.730313668


def _K_ratio(k: float) -> float:
    """K(k)/K(k') using the parameter m = k^2."""
    k = min(max(k, 1e-12), 1 - 1e-12)
    return ellipk(k * k) / ellipk(1 - k * k)


def _w_eff(w: float, h: float, t: float) -> float:
    if t <= 0:
        return w
    if w / h >= 1 / (2 * math.pi):
        return w + t / math.pi * (1 + math.log(2 * h / t))
    return w + t / math.pi * (1 + math.log(4 * math.pi * w / t))


def microstrip(w: float, h: float, er: float, t: float = 0.0) -> tuple[float, float]:
    """Return (Z0 [ohm], eps_eff)."""
    we = _w_eff(w, h, t)
    u = we / h
    a = 1 + (1 / 49) * math.log((u**4 + (u / 52) ** 2) / (u**4 + 0.432)) + (1 / 18.7) * math.log(1 + (u / 18.1) ** 3)
    b = 0.564 * ((er - 0.9) / (er + 3)) ** 0.053
    eeff = (er + 1) / 2 + (er - 1) / 2 * (1 + 10 / u) ** (-a * b)
    f = 6 + (2 * math.pi - 6) * math.exp(-((30.666 / u) ** 0.7528))
    z0_air = ETA0 / (2 * math.pi) * math.log(f / u + math.sqrt(1 + (2 / u) ** 2))
    return z0_air / math.sqrt(eeff), eeff


def cpwg(w: float, s: float, h: float, er: float, t: float = 0.0) -> tuple[float, float]:
    """Grounded coplanar waveguide (infinite side grounds). Return (Z0, eps_eff)."""
    if t > 0:  # thickness: widen strip, narrow gap (Gupta)
        d = 1.25 * t / math.pi * (1 + math.log(4 * math.pi * w / t))
        w, s = w + d, max(s - d, 1e-6)
    a, b = w, w + 2 * s
    k = a / b
    k1 = math.tanh(math.pi * a / (4 * h)) / math.tanh(math.pi * b / (4 * h))
    r, r1 = _K_ratio(k), _K_ratio(k1)
    q = r1 / r  # K(k')K(k1) / (K(k)K(k1'))
    eeff = (1 + er * q) / (1 + q)
    z0 = 60 * math.pi / math.sqrt(eeff) / (r + r1)
    return z0, eeff


def width_for_z0(z0: float, h: float, er: float, t: float = 0.0, gap: float | None = None) -> float:
    """Bisection for the width that gives ``z0`` (microstrip if gap is None)."""
    lo, hi = 0.01 * h, 20 * h
    for _ in range(80):
        mid = math.sqrt(lo * hi)
        z = cpwg(mid, gap, h, er, t)[0] if gap else microstrip(mid, h, er, t)[0]
        if z > z0:
            lo = mid
        else:
            hi = mid
    return math.sqrt(lo * hi)


def electrical_length_deg(length_mm: float, eeff: float, f_hz: float) -> float:
    lam = 299792458.0 / f_hz / math.sqrt(eeff) * 1000.0
    return 360.0 * length_mm / lam
