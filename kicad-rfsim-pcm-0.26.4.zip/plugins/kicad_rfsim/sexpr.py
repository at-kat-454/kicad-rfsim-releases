"""Minimal, fast S-expression reader for KiCad files.

KiCad files are trees of lists like ``(segment (start 1 2) (end 3 4))``.
The reader returns ``Node`` objects. Atoms stay strings; callers convert.
"""
from __future__ import annotations

import re
from typing import Iterator

_TOKEN = re.compile(r'\(|\)|"(?:[^"\\]|\\.)*"|[^\s()"]+')


class Node:
    """One parenthesised list. ``name`` is the first atom, ``items`` the rest."""

    __slots__ = ("name", "items")

    def __init__(self, name: str, items: list):
        self.name = name
        self.items = items

    # --- navigation -------------------------------------------------------
    def find(self, name: str) -> "Node | None":
        for it in self.items:
            if isinstance(it, Node) and it.name == name:
                return it
        return None

    def findall(self, name: str) -> Iterator["Node"]:
        for it in self.items:
            if isinstance(it, Node) and it.name == name:
                yield it

    def nodes(self) -> Iterator["Node"]:
        for it in self.items:
            if isinstance(it, Node):
                yield it

    def atoms(self) -> list[str]:
        return [it for it in self.items if not isinstance(it, Node)]

    # --- value helpers ----------------------------------------------------
    def atom(self, i: int = 0, default=None):
        a = self.atoms()
        return a[i] if i < len(a) else default

    def floats(self) -> list[float]:
        out = []
        for a in self.atoms():
            try:
                out.append(float(a))
            except ValueError:
                pass
        return out

    def get(self, name: str, default=None):
        """Value of child ``(name value)``."""
        n = self.find(name)
        return n.atom(0, default) if n is not None else default

    def getf(self, name: str, default: float | None = None) -> float | None:
        v = self.get(name)
        return float(v) if v is not None else default

    def __repr__(self) -> str:
        return f"Node({self.name!r}, {len(self.items)} items)"


def _unquote(tok: str) -> str:
    if tok.startswith('"'):
        return tok[1:-1].replace('\\"', '"').replace("\\\\", "\\")
    return tok


def parse(text: str) -> Node:
    """Parse one top-level S-expression."""
    stack: list[list] = []
    root = None
    for m in _TOKEN.finditer(text):
        tok = m.group(0)
        if tok == "(":
            stack.append([])
        elif tok == ")":
            lst = stack.pop()
            name = lst[0] if lst and isinstance(lst[0], str) else ""
            node = Node(name, lst[1:] if name else lst)
            if stack:
                stack[-1].append(node)
            else:
                root = node
                break
        else:
            stack[-1].append(_unquote(tok))
    if root is None:
        raise ValueError("no complete S-expression found")
    return root


def load(path) -> Node:
    with open(path, encoding="utf-8") as f:
        return parse(f.read())
