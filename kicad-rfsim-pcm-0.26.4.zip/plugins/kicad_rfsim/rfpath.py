"""Find the RF cluster of a board: nets and parts that form the RF chain.

The board is treated as a bipartite graph (nets <-> footprints). Starting at
seed nets, the search crosses passives and RF parts. It stops at:
  * ground nets (they are the reference, not part of the chain),
  * boundary parts (large ICs such as the MCU, or explicitly listed refs),
  * resistors >= ``r_stop`` ohms (bias / control feeds).
Every pad of a boundary part that touches the cluster becomes a port candidate.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .board import Board, Footprint

_SI = {"f": 1e-15, "p": 1e-12, "n": 1e-9, "u": 1e-6, "µ": 1e-6, "m": 1e-3,
       "k": 1e3, "K": 1e3, "M": 1e6, "G": 1e9, "R": 1.0, "r": 1.0}


def parse_value(text: str) -> float | None:
    """Parse KiCad-style values: '6p8', '3n3', '100n', '2k2', '0R', '4.7u', '39pF'."""
    if not text:
        return None
    t = text.strip().replace(",", ".").replace("Ω", "").replace("F", "").replace("H", "")
    m = re.fullmatch(r"(\d*\.?\d*)([fpnuµmkKMGRr]?)(\d*)", t)
    if not m or not (m.group(1) or m.group(3)):
        return None
    a, unit, b = m.groups()
    mult = _SI.get(unit, 1.0)
    if b:  # 6p8 style
        num = float(f"{a or 0}.{b}")
    else:
        num = float(a)
    return num * mult


def part_kind(fp: Footprint) -> str:
    """Rough role from reference prefix and library id."""
    ref = re.match(r"[A-Za-z]+", fp.ref)
    p = ref.group(0).upper() if ref else ""
    lib = fp.lib_id.lower()
    if p in ("C",) or "capacitor" in lib:
        return "C"
    if p in ("L", "FB") or "inductor" in lib:
        return "L"
    if p == "R" or "resistor" in lib:
        return "R"
    if p in ("J", "P"):
        return "connector"
    return "ic"


@dataclass
class RFCluster:
    nets: list[str]
    parts: list[str]
    boundary_parts: list[str]
    port_candidates: list[tuple[str, str, str]]  # (ref, pad, net)
    ground: str
    notes: list[str] = field(default_factory=list)

    def describe(self, board: Board) -> str:
        lines = [f"RF nets ({len(self.nets)}):"]
        for n in self.nets:
            lines.append(f"  {n}")
        lines.append(f"Parts inside ({len(self.parts)}):")
        for r in self.parts:
            f = board.footprint(r)
            pads = ", ".join(f"{p.number}:{p.net or '-'}" for p in f.pads if p.number)
            lines.append(f"  {r:<5} {f.value:<16} {'DNP ' if f.dnp else ''}[{pads}]")
        lines.append("Port candidates (pads on boundary parts):")
        for ref, pad, net in self.port_candidates:
            pf = board.footprint(ref).pad(pad).pinfunction
            lines.append(f"  {ref}.{pad:<4} {pf:<12} -> {net}")
        if self.notes:
            lines.append("Notes:")
            lines += [f"  - {n}" for n in self.notes]
        return "\n".join(lines)


def find_rf_cluster(board: Board, seeds: list[str], boundary: list[str] | None = None,
                    ground: str = "GND", max_ic_pins: int = 12, r_stop: float = 10.0) -> RFCluster:
    boundary = set(boundary or [])
    by_net: dict[str, list[Footprint]] = {}
    for f in board.footprints:
        for n in f.nets:
            by_net.setdefault(n, []).append(f)

    def is_boundary(f: Footprint) -> bool:
        if f.ref in boundary:
            return True
        if part_kind(f) == "ic" and len([p for p in f.pads if p.number]) > max_ic_pins:
            return True
        if part_kind(f) == "R":
            v = parse_value(f.value)
            if v is not None and v >= r_stop:
                return True
        return False

    nets: list[str] = []
    parts: list[str] = []
    bparts: list[str] = []
    ports: list[tuple[str, str, str]] = []
    queue = [s for s in seeds]
    seen_nets: set[str] = set()
    seen_parts: set[str] = set()
    while queue:
        net = queue.pop(0)
        if net in seen_nets or net == ground or not net:
            continue
        seen_nets.add(net)
        nets.append(net)
        for f in by_net.get(net, []):
            if f.ref in seen_parts:
                if is_boundary(f):
                    for p in f.pads:
                        if p.net == net and (f.ref, p.number, net) not in ports:
                            ports.append((f.ref, p.number, net))
                continue
            seen_parts.add(f.ref)
            if is_boundary(f):
                bparts.append(f.ref)
                for p in f.pads:
                    if p.net == net:
                        ports.append((f.ref, p.number, net))
                continue
            parts.append(f.ref)
            for n in f.nets:
                if n not in seen_nets:
                    queue.append(n)
    notes = []
    for r in parts:
        f = board.footprint(r)
        if f.dnp:
            notes.append(f"{r} is DNP: treated as open in the circuit layer, its pads stay in the EM model.")
    pad_less = [n for n in nets if not by_net.get(n)]
    for n in pad_less:
        notes.append(f"net '{n}' has copper but no pads (e.g. a printed antenna).")
    # copper-only nets (antenna) are found via track/zone search from seeds
    return RFCluster(nets, parts, bparts, ports, ground, notes)
