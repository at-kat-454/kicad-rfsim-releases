"""CAD-like 3D view of STEP parts and boards (as a CAD program shows an imported STEP).

* ``step_mesh(step)``: the STEP tessellated per B-rep face with gmsh, keeping the face colours
  stored in the STEP (XCAF), and the B-rep edges (feature lines, without cylinder seams).
  Faces keep their own vertices, so the shading is smooth inside a face and crisp at its edges.
* ``board_traces(board, placement)``: a board as solder mask, exposed pads (gold), copper under
  the mask, silkscreen and holes - for the main board and soldered-in antenna boards.
* ``traces(...)``: plotly mesh3d / scatter3d dicts in the antenna model frame
  (x right, y up on the board, z up, z = 0 at the main board's top copper).
"""
from __future__ import annotations

import hashlib
import threading
from pathlib import Path

import numpy as np

_LOCK = threading.RLock()  # gmsh is not thread safe
_MEM: dict = {}
DEFAULT = (190, 192, 196)  # grey for faces without a colour in the STEP
LIGHT = {"ambient": 0.62, "diffuse": 0.55, "specular": 0.15, "roughness": 0.5, "fresnel": 0.1}


def _hex(c) -> str:
    return "#%02x%02x%02x" % tuple(int(max(0, min(255, v))) for v in c[:3])


def step_mesh(step: Path, cache_dir: Path | None = None, quality: float = 1.0) -> dict:
    """{"faces": {colour: (V [n, 3], T [m, 3])}, "edges": [polyline [k, 3], ...], "bbox": (lo, hi)}.
    Cached in memory and as .npz in ``cache_dir`` (by file content)."""
    step = Path(step)
    h = hashlib.sha1(step.read_bytes()).hexdigest()[:16]
    key = (h, quality)
    with _LOCK:
        if key in _MEM:
            return _MEM[key]
    cache = Path(cache_dir) / f"{step.stem}_{h}_cad{quality:g}.npz" if cache_dir else None
    if cache is not None and cache.exists():
        try:
            out = _load(cache)
            with _LOCK:
                _MEM[key] = out
            return out
        except Exception:  # noqa: BLE001 - rebuild a broken cache
            pass
    with _LOCK:
        out = _tessellate(step, quality)
        if len(_MEM) > 24:
            _MEM.clear()
        _MEM[key] = out
    if cache is not None:
        try:
            cache.parent.mkdir(parents=True, exist_ok=True)
            _save(cache, out)
        except OSError:
            pass
    return out


def _save(path: Path, m: dict):
    d = {"edges_n": np.array([len(e) for e in m["edges"]], np.int64),
         "edges": np.concatenate(m["edges"]).astype(np.float32) if m["edges"] else np.zeros((0, 3), np.float32),
         "colors": np.array([list(c) for c in m["faces"]], np.int64).reshape(-1, 3),
         "lo": m["bbox"][0], "hi": m["bbox"][1]}
    for i, (V, T) in enumerate(m["faces"].values()):
        d[f"V{i}"], d[f"T{i}"] = V.astype(np.float32), T.astype(np.int32)
    np.savez_compressed(path, **d)


def _load(path: Path) -> dict:
    z = np.load(path)
    faces = {}
    for i, c in enumerate(z["colors"]):
        faces[tuple(int(v) for v in c)] = (z[f"V{i}"].astype(float), z[f"T{i}"])
    edges, k = [], 0
    for n in z["edges_n"]:
        edges.append(z["edges"][k:k + n].astype(float))
        k += n
    return {"faces": faces, "edges": edges, "bbox": (z["lo"], z["hi"])}


def _tessellate(step: Path, quality: float) -> dict:
    try:
        import gmsh
    except ImportError as e:
        raise RuntimeError("showing STEP files needs the Python package gmsh (plugin requirements)") from e
    gmsh.initialize(interruptible=False)
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.option.setNumber("Geometry.OCCImportLabels", 1)  # colours and names from the STEP
        gmsh.model.add("view")
        gmsh.model.occ.importShapes(str(step))
        gmsh.model.occ.synchronize()
        x0, y0, z0, x1, y1, z1 = gmsh.model.getBoundingBox(-1, -1)
        diag = float(np.linalg.norm([x1 - x0, y1 - y0, z1 - z0])) or 1.0
        gmsh.option.setNumber("Mesh.MeshSizeMax", diag / (25 * quality))
        gmsh.option.setNumber("Mesh.MeshSizeMin", diag / 3000)
        gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", int(14 * quality))
        gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 1)
        gmsh.option.setNumber("Mesh.Algorithm", 6)
        gmsh.model.mesh.generate(2)
        faces: dict = {}
        for _d, tag in gmsh.model.getEntities(2):
            c = gmsh.model.getColor(2, tag)
            if c[3] == 0:  # no colour on the face: take its solid's, else grey
                c = DEFAULT
                up, _ = gmsh.model.getAdjacencies(2, tag)
                for v in up:
                    cv = gmsh.model.getColor(3, int(v))
                    if cv[3] != 0:
                        c = cv
                        break
            col = tuple(int(v) for v in c[:3])
            types, _et, enodes = gmsh.model.mesh.getElements(2, tag)
            tri = None
            for t, en in zip(types, enodes):
                if t == 2:
                    tri = np.asarray(en, np.int64).reshape(-1, 3)
            if tri is None or not len(tri):
                continue
            ntags, coords, _ = gmsh.model.mesh.getNodes(2, tag, includeBoundary=True)
            V = np.asarray(coords, float).reshape(-1, 3)
            loc = {int(n): i for i, n in enumerate(ntags)}
            T = np.vectorize(loc.get)(tri)
            Vs, Ts = faces.get(col, (np.zeros((0, 3)), np.zeros((0, 3), np.int64)))
            faces[col] = (np.vstack([Vs, V]), np.vstack([Ts, T + len(Vs)]))
        edges = []
        for _d, tag in gmsh.model.getEntities(1):
            up, _ = gmsh.model.getAdjacencies(1, tag)
            if len(set(int(u) for u in up)) < 2 and len(up) > 0:
                # a curve on one face only: the seam of a cylinder / cone / sphere (no CAD program draws it)
                if _is_seam(gmsh, tag, int(up[0])):
                    continue
            types, _et, enodes = gmsh.model.mesh.getElements(1, tag)
            seg = None
            for t, en in zip(types, enodes):
                if t == 1:
                    seg = np.asarray(en, np.int64).reshape(-1, 2)
            if seg is None or not len(seg):
                continue
            ntags, coords, _ = gmsh.model.mesh.getNodes(1, tag, includeBoundary=True)
            loc = {int(n): i for i, n in enumerate(ntags)}
            P = np.asarray(coords, float).reshape(-1, 3)
            order = [seg[0, 0]] + [s[1] for s in seg]
            edges.append(P[[loc[int(n)] for n in order]])
        return {"faces": faces, "edges": edges, "bbox": (np.array([x0, y0, z0]), np.array([x1, y1, z1]))}
    finally:
        gmsh.finalize()


def _is_seam(gmsh, curve: int, face: int) -> bool:
    """The curve bounds ``face`` twice (periodic surface)."""
    try:
        b = gmsh.model.getBoundary([(2, face)], combined=False, oriented=True, recursive=False)
    except Exception:  # noqa: BLE001
        return False
    n = sum(1 for d, t in b if d == 1 and abs(t) == curve)
    return n >= 2


# ---------------------------------------------------------------------------
def mesh_traces(m: dict, transform=None, opacity: float = 1.0, name: str = "", edges: bool = True,
                edge_color: str = "#1d1d1b") -> list[dict]:
    """Plotly traces of a ``step_mesh`` result; ``transform(points [n, 3]) -> points``."""
    tf = transform or (lambda p: p)
    out = []
    for col, (V, T) in m["faces"].items():
        P = np.round(tf(V), 4)
        out.append({"type": "mesh3d", "x": P[:, 0].tolist(), "y": P[:, 1].tolist(), "z": P[:, 2].tolist(),
                    "i": T[:, 0].tolist(), "j": T[:, 1].tolist(), "k": T[:, 2].tolist(), "color": _hex(col),
                    "opacity": opacity, "name": name, "flatshading": False, "lighting": LIGHT,
                    "lightposition": {"x": 2e4, "y": -1e4, "z": 3e4}, "hoverinfo": "name", "showlegend": False})
    if edges and m["edges"]:
        xs, ys, zs = [], [], []
        for e in m["edges"]:
            P = np.round(tf(e), 4)
            xs += P[:, 0].tolist() + [None]
            ys += P[:, 1].tolist() + [None]
            zs += P[:, 2].tolist() + [None]
        out.append({"type": "scatter3d", "mode": "lines", "x": xs, "y": ys, "z": zs, "name": name + " edges",
                    "line": {"color": edge_color, "width": 2}, "opacity": min(1.0, opacity + 0.3),
                    "hoverinfo": "skip", "showlegend": False})
    return out


# ---------------------------------------------------------------------------
def _tri_mesh(tris3, color, name, opacity=1.0, flat=True) -> dict:
    a = np.asarray(tris3, float).reshape(-1, 3)
    n = len(a) // 3
    idx = np.arange(n * 3).reshape(-1, 3)
    a = np.round(a, 4)
    return {"type": "mesh3d", "x": a[:, 0].tolist(), "y": a[:, 1].tolist(), "z": a[:, 2].tolist(),
            "i": idx[:, 0].tolist(), "j": idx[:, 1].tolist(), "k": idx[:, 2].tolist(), "color": color,
            "opacity": opacity, "name": name, "flatshading": flat, "lighting": LIGHT,
            "lightposition": {"x": 2e4, "y": -1e4, "z": 3e4}, "hoverinfo": "name", "showlegend": False}


def _flat(geom, z: float, pl) -> list:
    from .fields import triangulate
    out = []
    for t in triangulate(geom):
        p = np.array([[x, y, z] for x, y in t])
        out.append(pl.apply(p))
    return out


def _walls(poly, z0: float, z1: float, pl) -> list:
    out = []
    for ring in [poly.exterior] + list(poly.interiors):
        c = list(ring.coords)
        for (xa, ya), (xb, yb) in zip(c, c[1:]):
            q = np.array([[xa, ya, z0], [xb, yb, z0], [xb, yb, z1], [xa, ya, z1]])
            g = pl.apply(q)
            out += [g[[0, 1, 2]], g[[0, 2, 3]]]
    return out


def board_traces(board, pl=None, name: str = "board", opacity: float = 1.0, detail: bool = True) -> list[dict]:
    """Board as a CAD program shows a KiCad STEP export: green solder mask, gold pads, silkscreen."""
    from shapely.geometry import LineString
    from shapely.ops import unary_union

    from .geom3d import MAIN
    from . import sexpr
    pl = pl or MAIN
    ol = board.outline()
    if ol is None or ol.is_empty:
        return []
    T = board.stackup.thickness
    mask, mask_cu, gold, silk = "#1f6234", "#2e7d43", "#d7b04c", "#f4f4ef"
    tr = []
    slab = []
    for p in getattr(ol, "geoms", [ol]):
        slab += _walls(p, -T, 0.0, pl)
    tr.append(_tri_mesh(slab, "#c9c08a", name + " edge", opacity))
    tr.append(_tri_mesh(_flat(ol, -T - 0.002, pl) + _flat(ol, 0.002, pl), mask, name, opacity))
    if not detail:
        return tr
    clip = ol.buffer(0.01)
    for layer, z, s in (("F.Cu", 0.012, 1), ("B.Cu", -T - 0.012, -1)):
        try:
            cu = unary_union([g for _n, g in board.copper(layer)]).intersection(clip).simplify(0.03)
            pads = unary_union([pd.polygon() for f in board.footprints for pd in f.pads if pd.on_layer(layer)
                                and (any(m in pd.layers for m in ("F.Mask", "B.Mask", "*.Mask")) or pd.kind == "thru_hole")])
            pads = pads.intersection(clip).simplify(0.01)
            under = cu.difference(pads.buffer(0.01))
            if not under.is_empty:
                tr.append(_tri_mesh(_flat(under, z, pl), mask_cu, f"{name} copper {layer}", opacity))
            if not pads.is_empty:
                tr.append(_tri_mesh(_flat(pads, z + 0.004 * s, pl), gold, f"{name} pads {layer}", opacity))
        except Exception:  # noqa: BLE001 - decoration
            pass
    # silkscreen lines (top and bottom)
    try:
        from .boardpic import _graphic, _width
        from .board import rotate_local
        root = sexpr.load(board.path)
        lines = {"F.SilkS": [], "B.SilkS": []}
        ident = lambda x, y: (x, y)  # noqa: E731
        for node in root.nodes():
            lay = node.get("layer")
            if node.name.startswith("gr_") and lay in lines:
                r = _graphic(node, ident)
                if r:
                    lines[lay].append((r, _width(node)))
            if node.name == "footprint":
                at = node.find("at").floats()
                fx, fy, fa = at[0], at[1], at[2] if len(at) > 2 else 0.0

                def tf(lx, ly, fx=fx, fy=fy, fa=fa):
                    dx, dy = rotate_local(lx, ly, fa)
                    return fx + dx, fy + dy
                for g in node.nodes():
                    lg = g.get("layer")
                    if g.name.startswith("fp_") and g.name != "fp_text" and lg in lines:
                        r = _graphic(g, tf)
                        if r:
                            lines[lg].append((r, _width(g)))
        for lay, z in (("F.SilkS", 0.02), ("B.SilkS", -T - 0.02)):
            geo = []
            for (pts, closed), w in lines[lay]:
                if len(pts) < 2:
                    continue
                ls = LineString(list(pts) + ([pts[0]] if closed else []))
                geo.append(ls.buffer(max(w, 0.08) / 2, cap_style=1, resolution=2))
            if geo:
                g = unary_union(geo).intersection(clip).simplify(0.02)
                tr.append(_tri_mesh(_flat(g, z, pl), silk, f"{name} silkscreen", opacity))
    except Exception:  # noqa: BLE001
        pass
    # holes: dark discs on both faces
    try:
        from shapely.geometry import Point
        hs = [Point(v.x, v.y).buffer(v.drill / 2, resolution=4) for v in board.vias]
        hs += [Point(pd.x, pd.y).buffer(pd.drill / 2, resolution=6) for f in board.footprints for pd in f.pads if pd.drill]
        if hs:
            g = unary_union(hs)
            tr.append(_tri_mesh(_flat(g, 0.03, pl) + _flat(g, -T - 0.03, pl), "#1a1a18", f"{name} holes", opacity))
    except Exception:  # noqa: BLE001
        pass
    return tr


VIEW_JS = r"""
const VIEWS={iso:{eye:{x:1.25,y:-1.45,z:1.0},up:{x:0,y:0,z:1}},top:{eye:{x:0,y:0,z:2.3},up:{x:0,y:1,z:0}},
 bottom:{eye:{x:0,y:0,z:-2.3},up:{x:0,y:1,z:0}},front:{eye:{x:0,y:-2.3,z:0},up:{x:0,y:0,z:1}},
 back:{eye:{x:0,y:2.3,z:0},up:{x:0,y:0,z:1}},right:{eye:{x:2.3,y:0,z:0},up:{x:0,y:0,z:1}},left:{eye:{x:-2.3,y:0,z:0},up:{x:0,y:0,z:1}}};
function viewBar(div,onCam){const bar=document.createElement('div');bar.className='vbar';
 for(const [k,t] of [['iso','Home'],['top','Top'],['front','Front'],['right','Right'],['left','Left'],['back','Back'],['bottom','Bottom']]){
  const b=document.createElement('button');b.textContent=t;b.onclick=()=>{const c=Object.assign({},VIEWS[k],{center:{x:0,y:0,z:0}});
   c.projection={type:document.getElementById('ortho')&&document.getElementById('ortho').checked?'orthographic':'perspective'};Plotly.relayout(div,{'scene.camera':c});onCam&&onCam(c)};bar.appendChild(b)}
 const l=document.createElement('label');l.innerHTML='<input type="checkbox" id="ortho" checked> orthographic';
 l.querySelector('input').onchange=e=>{const c=Object.assign({},document.getElementById(div)._fullLayout.scene.camera);c.projection={type:e.target.checked?'orthographic':'perspective'};Plotly.relayout(div,{'scene.camera':c});onCam&&onCam(c)};
 bar.appendChild(l);
 const a=document.createElement('label');a.innerHTML='<input type="checkbox" id="axes"> axes';
 a.querySelector('input').onchange=e=>{const v=e.target.checked;Plotly.relayout(div,{'scene.xaxis.visible':v,'scene.yaxis.visible':v,'scene.zaxis.visible':v})};
 bar.appendChild(a);return bar}
"""


# ---------------------------------------------------------------------------
# the board with its components: KiCad's own STEP export (kicad-cli)
# ---------------------------------------------------------------------------
def find_kicad_cli() -> str | None:
    """kicad-cli of the running KiCad (next to its Python), on PATH, or a standard install."""
    import glob
    import os
    import shutil
    import sys
    env = os.environ.get("KICAD_CLI")
    if env and Path(env).exists():
        return env
    exe = "kicad-cli.exe" if sys.platform == "win32" else "kicad-cli"
    for d in (Path(sys.executable).parent, Path(sys.base_prefix), Path(sys.base_prefix) / "bin",
              Path(getattr(sys, "_base_executable", sys.executable)).parent):
        if (d / exe).exists():
            return str(d / exe)
    w = shutil.which("kicad-cli")
    if w:
        return w
    pats = ([r"C:\Program Files\KiCad\*\bin\kicad-cli.exe"] if sys.platform == "win32" else
            ["/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli", "/usr/bin/kicad-cli", "/usr/local/bin/kicad-cli"])
    hits = sorted(h for p in pats for h in glob.glob(p))
    return hits[-1] if hits else None


def export_board_step(board_path: Path, cache_dir: Path, log=print, timeout: float = 600.0) -> Path:
    """The board with its 3D models as STEP (kicad-cli pcb export step), cached by board content."""
    import subprocess
    board_path = Path(board_path)
    cli = find_kicad_cli()
    if not cli:
        raise RuntimeError("kicad-cli not found (it comes with KiCad; set KICAD_CLI to its path)")
    h = hashlib.sha1(board_path.read_bytes()).hexdigest()[:16]
    out = Path(cache_dir) / f"{board_path.stem}_{h}_board.step"
    if out.exists() and out.stat().st_size > 0:
        return out
    out.parent.mkdir(parents=True, exist_ok=True)
    base = [cli, "pcb", "export", "step", "--subst-models", "--force", "--no-dnp", "-o", str(out)]
    tries = [base + ["--include-pads", "--include-silkscreen", "--include-soldermask"], base]
    err = ""
    for cmd in tries:  # newer options first; older KiCad versions reject them
        log(f"board 3D: {Path(cli).name} pcb export step ...")
        kw = {}
        import sys
        if sys.platform == "win32":
            kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
        r = subprocess.run(cmd + [str(board_path)], capture_output=True, text=True, timeout=timeout, **kw)
        if r.returncode == 0 and out.exists() and out.stat().st_size > 0:
            return out
        err = (r.stderr or r.stdout or "").strip()[-400:]
    raise RuntimeError(f"kicad-cli STEP export failed: {err}")


def board_step_transform(board, m: dict):
    """Map the exported board STEP into the model frame: fit its board corners (KiCad exports
    (x, -y) about some origin, board bottom or top at z = 0). Returns (transform, residual mm)."""
    from .geom3d import step_frame_fit
    pts = np.vstack([V for V, _ in m["faces"].values()] + list(m["edges"]))
    fr = step_frame_fit(board, pts)
    if not fr:
        raise RuntimeError("the exported STEP does not show the board outline")
    res, oname, zref = fr[0]
    from .geom3d import _origins
    ox, oy = _origins(board)[oname]
    T = board.stackup.thickness
    zoff = T if zref == "bottom" else 0.0
    return (lambda P, ox=ox, oy=oy, zoff=zoff: np.asarray(P) + np.array([ox, -oy, -zoff])), res
