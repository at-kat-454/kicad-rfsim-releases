"""Mesh convergence check: the same setup on two or three meshes (Fast / Automatic / Accurate),
the key results side by side, how much they still move, and an extrapolation to zero cell size.

The FDTD error shrinks with the cell size h (about h^1 ... h^2 for staircased copper edges). When
the results of the finest two meshes agree within the tolerances below, the mesh is fine enough
for this layout; otherwise the Accurate result is the better one and the remaining change shows
how far it may still be off.

    run_convergence(config_path, [("fast", cfg_fast, 1.8), ("auto", cfg, 1.0), ("accurate", cfg_acc, 0.65)])

writes ``<result>/convergence/convergence.html`` and ``convergence.json``; each level runs into
``<result>/convergence/<level>/`` (the Automatic level can reuse the setup's own result).
"""
from __future__ import annotations

import json
import math
import time
from pathlib import Path

import numpy as np

LABELS = {"fast": "Fast", "auto": "Automatic", "accurate": "Accurate", "custom": "Custom"}

# metric tolerances between the two finest meshes: (kind, limit)
#   "rel": relative change, "abs": absolute change in the metric's unit
TOL = {
    "S11 minimum at": ("rel", 0.01),
    "resonance (X = 0) at": ("rel", 0.01),
    "S11 minimum": ("abs", 1.0),
    "R at": ("zin", 0.05),
    "X at": ("zin", 0.05),
    "radiation efficiency": ("abs", 3.0),
    "directivity": ("abs", 0.3),
    "EM N-port, max |ΔS|": ("abs", 0.05),
}


def _interp_min(f, y):
    """Location and value of the minimum of y(f), parabola through the three samples around it."""
    k = int(np.argmin(y))
    if 0 < k < len(y) - 1:
        a, b, c = y[k - 1], y[k], y[k + 1]
        den = a - 2 * b + c
        if den > 0:
            d = 0.5 * (a - c) / den
            df = f[k + 1] - f[k]
            return float(f[k] + d * df), float(b - 0.25 * (a - c) * d)
    return float(f[k]), float(y[k])


def antenna_metrics(out: Path, f_ref: float, f_ff: float | None = None, bands=None) -> tuple[dict, dict]:
    """(metrics, curves) of an antenna result. ``bands``: operating band (MHz ranges); every band gets its own
    metrics (S11 minimum inside the band +-15 %, impedance at the centre, efficiency and directivity at the
    far-field frequency nearest the centre). Without a band: one set around f_ref."""
    from .antenna import load_result
    from .bands import _groups
    r = load_result(Path(out) / "antenna_result.npz")
    f, z = np.asarray(r.f, float), np.asarray(r.zin, complex)
    s11 = (z - 50) / (z + 50)
    db = 20 * np.log10(np.abs(s11) + 1e-12)
    x = z.imag
    cr = [f[i] - x[i] * (f[i + 1] - f[i]) / (x[i + 1] - x[i]) for i in range(len(f) - 1)
          if np.sign(x[i]) != np.sign(x[i + 1]) and x[i + 1] != x[i]]
    ff = r.farfield or {}
    groups = _groups([tuple(b) for b in bands]) if bands else []
    m = {}
    if not groups:
        groups = [(f_ref / 1e6, f_ref / 1e6)]
    for lo, hi in groups:
        c = 0.5 * (lo + hi) * 1e6
        tag = "" if len(groups) == 1 else f" ({lo:g}-{hi:g} MHz)"
        sel = (f >= 0.85 * lo * 1e6) & (f <= 1.15 * hi * 1e6) if bands else np.ones(len(f), bool)
        if sel.sum() >= 3:
            fm, dm = _interp_min(f[sel], db[sel])
            m[f"S11 minimum at{tag}"], m[f"S11 minimum{tag}"] = fm / 1e6, dm
        if cr:
            m[f"resonance (X = 0) at{tag}"] = float(min(cr, key=lambda v: abs(v - c))) / 1e6
        zr = complex(np.interp(c, f, z.real), np.interp(c, f, z.imag))
        m[f"R at {c / 1e6:g} MHz"], m[f"X at {c / 1e6:g} MHz"] = zr.real, zr.imag
        if ff:
            k = min(ff, key=lambda q: abs(q - (c if bands else (f_ff or f_ref))))
            m[f"radiation efficiency{tag}"] = 100 * float(ff[k]["eff_rad"])
            m[f"directivity{tag}"] = 10 * math.log10(max(float(ff[k]["Dmax"]), 1e-9))
    return m, {"f": (f / 1e6).round(4).tolist(), "S11": db.round(3).tolist(),
               "R": z.real.round(3).tolist(), "X": z.imag.round(3).tolist()}


def circuit_metrics(out: Path, board, external: list[str], marks: list[float],
                    f_q: float | None = None) -> tuple[dict, dict, np.ndarray]:
    """(metrics, curves, EM S-matrix) of an RF chain result with the parts at their board values."""
    from .tune import auto_circuit, load_em
    f, S, names = load_em(Path(out) / "result.npz")
    c, _ = auto_circuit(board, f, S, names, f_q=f_q)
    S2 = c.solve(external)
    m, curves = {}, {"f": (np.asarray(f) / 1e6).round(4).tolist()}
    n = S2.shape[1]
    for i in range(n):
        for j in range(n):
            if j > i or (i != j and n == 1):
                continue
            nm = f"S{i + 1}{j + 1}"
            db = 20 * np.log10(np.abs(S2[:, i, j]) + 1e-12)
            curves[nm] = db.round(3).tolist()
            for fx in marks:
                if f[0] <= fx <= f[-1]:
                    m[f"|{nm}| at {fx / 1e6:g} MHz"] = float(np.interp(fx, f, db))
    return m, curves, np.nan_to_num(np.asarray(S))


def richardson(h: list[float], v: list[float]) -> dict | None:
    """v(h) = v0 + C h^p through three (cell factor, value) points: v0 and p, or None when the
    values do not converge monotonically (then no extrapolation is meaningful)."""
    if len(h) != 3 or any(x is None for x in v):
        return None
    (h1, h2, h3), (v1, v2, v3) = h, v  # coarse -> fine
    d12, d23 = v1 - v2, v2 - v3
    if d23 == 0 or d12 == 0 or np.sign(d12) != np.sign(d23) or abs(d23) >= abs(d12):
        return None
    r = d12 / d23

    def g(p):
        return (h1 ** p - h2 ** p) / (h2 ** p - h3 ** p) - r
    lo, hi = 0.3, 6.0
    if g(lo) * g(hi) > 0:
        return None
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if g(lo) * g(mid) <= 0:
            hi = mid
        else:
            lo = mid
    p = 0.5 * (lo + hi)
    v0 = v3 - d23 * h3 ** p / (h2 ** p - h3 ** p)
    return {"order": p, "extrapolated": v0}


def _check(name: str, a: float, b: float, ref_scale: float = 0.0) -> tuple[bool | None, str]:
    """Is the change a -> b (coarser -> finest) within the tolerance? (ok, text)."""
    key = next((k for k in TOL if name.startswith(k)), None)
    if name.startswith("|S"):
        kind, lim = ("sdb", 0.5)
    elif key is None:
        return None, ""
    else:
        kind, lim = TOL[key]
    d = b - a
    if kind == "rel":
        rel = abs(d) / max(abs(b), 1e-12)
        return rel <= lim, f"{100 * d / max(abs(b), 1e-12):+.2f} %"
    if kind == "zin":
        ok = abs(d) <= max(lim * ref_scale, 2.0)
        return ok, f"{d:+.2f} Ω"
    if kind == "sdb":
        # deep dips: compare linear |S| (a 30 vs 35 dB dip is the same match in practice)
        la, lb = 10 ** (a / 20), 10 ** (b / 20)
        ok = abs(d) <= lim or abs(la - lb) <= 0.03
        return ok, f"{d:+.2f} dB"
    return abs(d) <= lim, f"{d:+.3g}"


def run_convergence(config_path, variants: list[tuple[str, dict, float]], board_path=None, threads: int = 0,
                    progress=print, openems_bin: str | None = None, force: bool = False,
                    main_out: Path | None = None, auto_in_main: bool = False) -> dict:
    """Run the variants (level, setup dict, cell factor) coarse -> fine and compare them.
    ``main_out``: result folder of the setup itself (the check goes to its ``convergence``
    subfolder); ``auto_in_main``: the "auto" level is the setup's own run (reused when unchanged)."""
    from .board import Board
    from .pipeline import simulate
    config_path = Path(config_path)
    cfg0 = variants[0][1]
    base = config_path.parent
    root = Path(main_out) if main_out else base / cfg0.get("output", "rfsim") / cfg0["name"]
    croot = root / "convergence"
    croot.mkdir(parents=True, exist_ok=True)
    kind = "antenna" if cfg0.get("type") == "antenna" else "circuit"
    rows, curves, nports = [], [], []
    for k, (level, cfg, h) in enumerate(variants, 1):
        out = root if (level == "auto" and auto_in_main) else croot / level
        progress(f"convergence {k}/{len(variants)}: {LABELS.get(level, level)} mesh (cells x{h:g})")
        t0 = time.time()
        simulate(config_path, board_path, threads, progress, force=force, openems_bin=openems_bin,
                 cfg_override=cfg, out_dir=out)
        info = json.loads((out / "run_info.json").read_text()) if (out / "run_info.json").exists() else {}
        runs = info.get("runs", [])
        row = {"level": level, "label": LABELS.get(level, level), "h": h, "dir": str(out),
               "cells": max([r.get("cells", 0) for r in runs] or [0]),
               "dt_fs": 1e15 * min([r.get("dt_s") or 1 for r in runs] or [0]),
               "solver_s": sum(r.get("wall_s", 0) for r in runs), "wall_s": time.time() - t0,
               "reused": bool(info.get("reused"))}
        if kind == "antenna":
            s = cfg.get("settings", {})
            f_ref = float(s.get("f_loss") or 0) or 0.5 * (float(s.get("f_min", 0.5e9)) + float(s.get("f_max", 1.5e9)))
            ffl = s.get("f_farfield") or [f_ref]
            m, cv = antenna_metrics(out, f_ref, float(ffl[len(ffl) // 2]), cfg.get("band"))
            row["f_ref"] = f_ref
        else:
            bp = Path(board_path) if board_path else base / cfg["board"]
            m, cv, S = circuit_metrics(out, Board(bp), cfg["external"], cfg.get("marks_hz", [868e6])[:3],
                                          cfg.get("f_q"))
            nports.append(S)
        row["metrics"] = m
        rows.append(row)
        curves.append(cv)
    if kind == "circuit" and len(nports) > 1:
        ref = nports[-1]
        for row, S in zip(rows, nports):
            if S.shape == ref.shape:
                row["metrics"]["EM N-port, max |ΔS|"] = float(np.max(np.abs(S - ref)))
    res = compare(rows)
    res.update({"setup": cfg0["name"], "kind": kind, "rows": rows, "curves": curves,
                "when": time.strftime("%Y-%m-%d %H:%M")})
    (croot / "convergence.json").write_text(json.dumps(res, indent=1))
    page = write_page(res, croot / "convergence.html")
    progress(f"convergence: {res['verdict']} - {page}")
    res["page"] = str(page)
    return res


def compare(rows: list[dict]) -> dict:
    """Changes of every metric towards the finest mesh, the verdict and the extrapolation."""
    fin = rows[-1]["metrics"]
    prev = rows[-2]["metrics"] if len(rows) > 1 else fin
    table, bad = [], []
    for name in fin:
        sfx = name[4:] if name[:5] in ("R at ", "X at ") else None
        scale = abs(complex(fin.get("R at " + sfx, 0), fin.get("X at " + sfx, 0))) if sfx else 0.0
        vals = [r["metrics"].get(name) for r in rows]
        ok, txt = (None, "")
        if len(rows) > 1 and prev.get(name) is not None:
            ok, txt = _check(name, prev[name], fin[name], scale)
        ex = None
        if len(rows) == 3 and (name.startswith("S11 minimum at") or name.startswith("resonance")):
            ex = richardson([r["h"] for r in rows], vals)
        table.append({"name": name, "values": vals, "change": txt, "ok": ok, "richardson": ex})
        if ok is False:
            bad.append(name)
    if len(rows) < 2:
        verdict = "one mesh only"
    elif bad:
        verdict = f"not converged: {', '.join(bad)} still move between {rows[-2]['label']} and {rows[-1]['label']}"
    else:
        verdict = f"converged: {rows[-2]['label']} and {rows[-1]['label']} agree within the tolerances"
    return {"table": table, "verdict": verdict, "converged": len(rows) > 1 and not bad}


def _unit(name: str) -> str:
    if name.startswith("S11 minimum at") or name.startswith("resonance"):
        return "MHz"
    if name.startswith("directivity"):
        return "dBi"
    if name.startswith("|S") or name.startswith("S11 minimum"):
        return "dB"
    if name[:5] in ("R at ", "X at "):
        return "Ω"
    if name.startswith("radiation efficiency"):
        return "%"
    return ""


def write_page(res: dict, path: Path) -> Path:
    from .pagepack import pack_page, plotly_tag
    path = Path(path)
    html = _PAGE.replace("__PLOTLY__", plotly_tag(path)).replace("__TITLE__", f"Mesh convergence – {res['setup']}")
    data = dict(res)
    data["units"] = {t["name"]: _unit(t["name"]) for t in res["table"]}
    path.write_text(pack_page(html, data), encoding="utf-8")
    return path


_PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>__PLOTLY__<style>
:root{--bg:#fafaf8;--fg:#1d1d1b;--mut:#6b6b66;--card:#fff;--line:#e3e2dc;--acc:#2a6fdb;--ok:#1a7f37;--bad:#b3261e}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff;--ok:#56c26b;--bad:#ff8a80}}
:root[data-theme="dark"]{--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff;--ok:#56c26b;--bad:#ff8a80}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 system-ui,sans-serif}
header{padding:14px 16px;border-bottom:1px solid var(--line)}h1{font-size:17px;margin:0}.sub{color:var(--mut);font-size:12px}
main{padding:14px 16px;display:grid;gap:14px;max-width:1200px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px;overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:4px 8px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}
td:first-child,th:first-child{text-align:left}.ok{color:var(--ok)}.bad{color:var(--bad)}
#verdict{font-weight:600;font-size:15px}#plot{height:380px}
</style></head><body>
<header><span style="float:right;font-size:12px"><a href="../solver_info.html" style="color:var(--acc)">How this was solved →</a></span>
<h1 id="t"></h1><div class="sub" id="sub"></div></header>
<main>
<section class="card"><div id="verdict"></div><div class="sub" id="how"></div></section>
<section class="card"><table id="tab"></table></section>
<section class="card"><div id="plot"></div></section>
<section class="card sub">The finest mesh is the reference; "change" is the step from the second finest to the finest.
Tolerances: frequencies 1 %, S-parameters 0.5 dB (or 0.03 in |S| for deep dips), impedance 5 % of |Z| (at least 2 Ω),
efficiency 3 points, directivity 0.3 dB, EM N-port 0.05 in |S|. With three meshes the frequencies are extrapolated to
zero cell size (Richardson: v(h) = v₀ + C·hᵖ): the extrapolated value and the order p show how far the finest mesh
still is from the converged answer. A non-monotonic sequence gets no extrapolation.</section>
</main>
<script>
const D=__DATA__;
const $=id=>document.getElementById(id);
$("t").textContent="Mesh convergence – "+D.setup;
$("sub").textContent=(D.kind==="antenna"?"Antenna":"RF chain (parts at their board values)")+" · "+D.rows.length+" meshes · "+D.when;
$("verdict").textContent=D.verdict;$("verdict").className=D.converged?"ok":"bad";
$("how").textContent=D.rows.map(r=>`${r.label}: cells ×${r.h} → ${(r.cells/1e6).toFixed(2)} M cells, timestep ${r.dt_fs.toFixed(1)} fs, solver ${(r.solver_s/60).toFixed(1)} min${r.reused?" (reused)":""}`).join(" · ");
const fmt=(v,u)=>v==null?"–":(u==="MHz"?v.toFixed(1):Math.abs(v)>=100?v.toFixed(1):v.toFixed(2));
let h=`<tr><th>Result</th>${D.rows.map(r=>`<th>${r.label}</th>`).join("")}<th>change</th><th>extrapolated (order)</th></tr>`;
h+=`<tr><td>cells</td>${D.rows.map(r=>`<td>${(r.cells/1e6).toFixed(2)} M</td>`).join("")}<td></td><td></td></tr>`;
for(const t of D.table){const u=D.units[t.name]||"";
 h+=`<tr><td>${t.name}${u?" ("+u+")":""}</td>${t.values.map(v=>`<td>${fmt(v,u)}</td>`).join("")}<td class="${t.ok===false?"bad":t.ok?"ok":""}">${t.change}${t.ok===false?" ✗":t.ok?" ✓":""}</td><td>${t.richardson?fmt(t.richardson.extrapolated,u)+" (p "+t.richardson.order.toFixed(1)+")":""}</td></tr>`}
$("tab").innerHTML=h;
const dark=matchMedia("(prefers-color-scheme: dark)").matches;const col=["#9aa0a6","#2a6fdb","#d9480f"];
const tr=[];D.curves.forEach((c,i)=>{const keys=Object.keys(c).filter(k=>k.startsWith("S"));
 for(const k of keys)tr.push({x:c.f,y:c[k],name:`${D.rows[i].label} ${k}`,mode:"lines",line:{color:col[(i+3-D.curves.length)%3]||col[i],dash:k==="S11"?"solid":"dot",width:i===D.curves.length-1?2.4:1.5}})});
if(window.Plotly)Plotly.newPlot("plot",tr,{margin:{l:50,r:10,t:10,b:40},xaxis:{title:"MHz"},yaxis:{title:"dB"},
 paper_bgcolor:"rgba(0,0,0,0)",plot_bgcolor:"rgba(0,0,0,0)",font:{color:dark?"#ecebe6":"#1d1d1b"},legend:{orientation:"h"}},{displaylogo:false,responsive:true});
</script></body></html>"""
