"""Board model built from a ``.kicad_pcb`` file (KiCad 9/10 format).

All lengths are millimetres in KiCad's coordinate system (x right, y down).
Geometry is returned as shapely objects so regions can be clipped and merged.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path

from shapely import affinity
from shapely.geometry import LineString, Point, Polygon, box
from shapely.ops import polygonize, unary_union

from . import sexpr

ARC_SEGMENTS_PER_CIRCLE = 32


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def rotate_local(lx: float, ly: float, deg: float) -> tuple[float, float]:
    """Rotate a local offset by a KiCad angle (CCW on screen, y down)."""
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    return lx * c + ly * s, -lx * s + ly * c


def arc_points(start, mid, end, n_per_circle: int = ARC_SEGMENTS_PER_CIRCLE):
    """Polyline through a three-point arc."""
    (x1, y1), (x2, y2), (x3, y3) = start, mid, end
    d = 2 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))
    if abs(d) < 1e-12:
        return [start, end]
    ux = ((x1**2 + y1**2) * (y2 - y3) + (x2**2 + y2**2) * (y3 - y1) + (x3**2 + y3**2) * (y1 - y2)) / d
    uy = ((x1**2 + y1**2) * (x3 - x2) + (x2**2 + y2**2) * (x1 - x3) + (x3**2 + y3**2) * (x2 - x1)) / d
    r = math.hypot(x1 - ux, y1 - uy)
    a1 = math.atan2(y1 - uy, x1 - ux)
    a2 = math.atan2(y2 - uy, x2 - ux)
    a3 = math.atan2(y3 - uy, x3 - ux)

    def ccw(a, b):  # positive sweep from a to b
        return (b - a) % (2 * math.pi)

    sweep = ccw(a1, a3)
    if ccw(a1, a2) > sweep:  # mid not on the ccw path -> go clockwise
        sweep -= 2 * math.pi
    n = max(2, int(abs(sweep) / (2 * math.pi) * n_per_circle) + 1)
    return [(ux + r * math.cos(a1 + sweep * i / n), uy + r * math.sin(a1 + sweep * i / n)) for i in range(n + 1)]


def _xy(node) -> tuple[float, float]:
    f = node.floats()
    return f[0], f[1]


# ---------------------------------------------------------------------------
# data classes
# ---------------------------------------------------------------------------
@dataclass
class StackupLayer:
    name: str
    kind: str  # "copper" | "dielectric" | "mask" | "other"
    thickness: float = 0.0
    epsilon_r: float | None = None
    loss_tangent: float | None = None
    material: str | None = None
    z_top: float = 0.0  # z of upper surface, board top = 0, downwards negative
    z_bottom: float = 0.0


@dataclass
class Stackup:
    layers: list[StackupLayer]

    @property
    def copper(self) -> list[StackupLayer]:
        return [l for l in self.layers if l.kind == "copper"]

    @property
    def dielectrics(self) -> list[StackupLayer]:
        return [l for l in self.layers if l.kind == "dielectric"]

    @property
    def thickness(self) -> float:
        return sum(l.thickness for l in self.layers if l.kind in ("copper", "dielectric"))

    def layer(self, name: str) -> StackupLayer:
        for l in self.layers:
            if l.name == name:
                return l
        raise KeyError(name)

    def dielectric_between(self, cu_a: str, cu_b: str) -> list[StackupLayer]:
        names = [l.name for l in self.layers]
        i, j = sorted((names.index(cu_a), names.index(cu_b)))
        return [l for l in self.layers[i + 1 : j] if l.kind == "dielectric"]


@dataclass
class Pad:
    ref: str
    number: str
    net: str
    kind: str  # smd | thru_hole | np_thru_hole | connect
    shape: str  # rect | roundrect | circle | oval | trapezoid | custom
    x: float
    y: float
    angle: float  # absolute orientation
    size: tuple[float, float]
    layers: list[str]
    rratio: float = 0.0
    drill: float = 0.0
    pinfunction: str = ""

    def polygon(self) -> Polygon:
        w, h = self.size
        if self.shape == "circle":
            g = Point(0, 0).buffer(w / 2, quad_segs=8)
        elif self.shape == "oval":
            r = min(w, h) / 2
            if w >= h:
                g = LineString([(-(w / 2 - r), 0), (w / 2 - r, 0)]).buffer(r, quad_segs=8)
            else:
                g = LineString([(0, -(h / 2 - r)), (0, h / 2 - r)]).buffer(r, quad_segs=8)
        elif self.shape == "roundrect" and self.rratio > 0:
            r = min(w, h) * self.rratio
            g = box(-w / 2 + r, -h / 2 + r, w / 2 - r, h / 2 - r).buffer(r, quad_segs=4)
        else:  # rect, trapezoid (approx.), custom (anchor only)
            g = box(-w / 2, -h / 2, w / 2, h / 2)
        # KiCad angle is CCW on screen with y down -> shapely rotate by -angle
        g = affinity.rotate(g, -self.angle, origin=(0, 0))
        return affinity.translate(g, self.x, self.y)

    def on_layer(self, layer: str) -> bool:
        if layer in self.layers:
            return True
        if layer.endswith(".Cu") and "*.Cu" in self.layers:
            return True
        return False


@dataclass
class Footprint:
    ref: str
    value: str
    lib_id: str
    x: float
    y: float
    angle: float
    side: str  # F | B
    properties: dict[str, str]
    attrs: list[str]
    pads: list[Pad] = field(default_factory=list)
    models: list[dict] = field(default_factory=list)  # {"path", "offset", "scale", "rotate"} (mm / deg)

    @property
    def dnp(self) -> bool:
        return "dnp" in self.attrs

    def pad(self, number: str) -> Pad:
        for p in self.pads:
            if p.number == number:
                return p
        raise KeyError(f"{self.ref} pad {number}")

    @property
    def nets(self) -> set[str]:
        return {p.net for p in self.pads if p.net}


@dataclass
class Track:
    net: str
    layer: str
    width: float
    points: list[tuple[float, float]]  # polyline (2 points for segment, more for arc)
    is_arc: bool = False

    def polygon(self):
        return LineString(self.points).buffer(self.width / 2, quad_segs=8)

    @property
    def length(self) -> float:
        return LineString(self.points).length


@dataclass
class Via:
    net: str
    x: float
    y: float
    size: float
    drill: float
    layers: tuple[str, str]  # start / end copper layer

    def polygon(self):
        return Point(self.x, self.y).buffer(self.size / 2, quad_segs=8)


@dataclass
class Shape:
    """Copper drawn as a graphic (gr_rect / gr_poly / gr_line ... on a copper layer, or a footprint's
    fp_ shape on copper): KiCad treats it as copper of its net."""
    net: str
    layer: str
    geom: object

    def polygon(self):
        return self.geom


def _copper_shape(g, tf):
    """Shapely geometry of one gr_ / fp_ graphic on a copper layer (``tf``: local -> board)."""
    kind = g.name[3:]
    st = g.find("stroke")
    w = st.getf("width") if st is not None else None
    w = w if w is not None else (g.getf("width") or 0.0)
    fl = g.find("fill")
    filled = fl is not None and (fl.atom(0, "") in ("yes", "solid") or
                                 (fl.find("type") is not None and fl.find("type").atom(0) == "solid"))
    try:
        if kind == "line":
            pts = [tf(*g.find("start").floats()[:2]), tf(*g.find("end").floats()[:2])]
            return LineString(pts).buffer(max(w, 1e-3) / 2, quad_segs=8)
        if kind == "arc":
            pts = arc_points(tuple(g.find("start").floats()[:2]), tuple(g.find("mid").floats()[:2]),
                             tuple(g.find("end").floats()[:2]))
            return LineString([tf(x, y) for x, y in pts]).buffer(max(w, 1e-3) / 2, quad_segs=8)
        if kind == "rect":
            (x0, y0), (x1, y1) = g.find("start").floats()[:2], g.find("end").floats()[:2]
            pts = [tf(x0, y0), tf(x1, y0), tf(x1, y1), tf(x0, y1)]
        elif kind == "circle":
            cx, cy = g.find("center").floats()[:2]
            ex, ey = g.find("end").floats()[:2]
            r = math.hypot(ex - cx, ey - cy)
            k = max(24, int(r * 24))
            pts = [tf(cx + r * math.cos(2 * math.pi * i / k), cy + r * math.sin(2 * math.pi * i / k)) for i in range(k)]
        elif kind == "poly":
            pts = [tf(*xy.floats()[:2]) for xy in g.find("pts").findall("xy")]
        else:
            return None
    except (AttributeError, TypeError, IndexError):
        return None
    if len(pts) < 3:
        return None
    ring = Polygon(pts).buffer(0)
    if filled:
        return ring.buffer(w / 2, quad_segs=8) if w > 0 else ring
    return LineString(pts + [pts[0]]).buffer(max(w, 1e-3) / 2, quad_segs=8)


@dataclass
class Zone:
    net: str
    layers: list[str]
    keepout: bool
    outline: Polygon | None
    filled: dict[str, list[Polygon]]  # layer -> filled polygons


# ---------------------------------------------------------------------------
# board
# ---------------------------------------------------------------------------
class Board:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        root = sexpr.load(self.path)
        if root.name != "kicad_pcb":
            raise ValueError(f"{path} is not a kicad_pcb file")
        self.version = root.get("version")
        self.generator_version = root.get("generator_version")
        self.copper_layers: list[str] = []
        self.footprints: list[Footprint] = []
        self.tracks: list[Track] = []
        self.vias: list[Via] = []
        self.zones: list[Zone] = []
        self.shapes: list[Shape] = []  # copper drawn as graphics
        self._edge_items: list = []
        self._parse_layers(root)
        self.stackup = self._parse_stackup(root)
        setup = root.find("setup")
        def _origin(name):
            n = setup.find(name) if setup is not None else None
            return tuple(n.floats()[:2]) if n is not None else (0.0, 0.0)
        self.aux_origin = _origin("aux_axis_origin")
        self.grid_origin = _origin("grid_origin")
        for node in root.nodes():
            n = node.name
            if n == "footprint":
                self._parse_footprint(node)
            elif n == "segment":
                self.tracks.append(Track(node.get("net", ""), node.get("layer"), node.getf("width"),
                                         [_xy(node.find("start")), _xy(node.find("end"))]))
            elif n == "arc":
                pts = arc_points(_xy(node.find("start")), _xy(node.find("mid")), _xy(node.find("end")))
                self.tracks.append(Track(node.get("net", ""), node.get("layer"), node.getf("width"), pts, True))
            elif n == "via":
                lay = node.find("layers").atoms()
                f = node.find("at").floats()
                self.vias.append(Via(node.get("net", ""), f[0], f[1], node.getf("size"),
                                     node.getf("drill"), (lay[0], lay[-1])))
            elif n == "zone":
                self._parse_zone(node)
            elif n.startswith("gr_") and node.get("layer") == "Edge.Cuts":
                self._edge_items.append(node)
            elif n.startswith("gr_") and (node.get("layer") or "").endswith(".Cu"):
                g = _copper_shape(node, lambda x, y: (x, y))
                if g is not None and not g.is_empty:
                    self.shapes.append(Shape(node.get("net", "") or "", node.get("layer"), g))
        self._outline = None
        self.ground_alias = self._alias_ground()

    # --- ground net -------------------------------------------------------
    _GND_NAMES = ("GND", "/GND", "AGND", "GNDA", "GND_RF", "RF_GND", "GNDRF", "PGND", "DGND", "GNDD", "VSS",
                  "0V", "GROUND", "/0V", "/AGND")

    def _alias_ground(self) -> str | None:
        """The simulation treats the net "GND" as ground. A board whose ground is called e.g. "/GND"
        or "AGND" gets that net renamed to "GND" in this in-memory copy (the board file is untouched).
        Returns the original name, or None."""
        nets = self.nets
        if "GND" in nets:
            return None
        cands = [n for n in self._GND_NAMES if n in nets]
        cands += sorted(n for n in nets if n.upper().lstrip("/").startswith("GND") and n not in cands)
        if not cands:
            return None

        def weight(n):  # the ground plane: most zone area + pads
            a = sum(sum(g.area for g in gs) for z in self.zones if z.net == n for gs in z.filled.values())
            return a + sum(1 for f in self.footprints for p in f.pads if p.net == n)
        g = max(cands, key=weight)
        for f in self.footprints:
            for p in f.pads:
                if p.net == g:
                    p.net = "GND"
        for t in self.tracks:
            if t.net == g:
                t.net = "GND"
        for v in self.vias:
            if v.net == g:
                v.net = "GND"
        for z in self.zones:
            if z.net == g:
                z.net = "GND"
        for sh in self.shapes:
            if sh.net == g:
                sh.net = "GND"
        return g

    # --- layers / stackup -------------------------------------------------
    def _parse_layers(self, root):
        lay = root.find("layers")
        for l in lay.nodes():
            # (0 "F.Cu" signal) -> name is "0"
            a = l.atoms()
            if a and a[0].endswith(".Cu"):
                self.copper_layers.append(a[0])

    def _parse_stackup(self, root) -> Stackup:
        setup = root.find("setup")
        st = setup.find("stackup") if setup else None
        layers: list[StackupLayer] = []
        if st is None:
            # KiCad default: 1.6 mm FR4, 35 um copper
            n = len(self.copper_layers)
            diel = (1.6 - n * 0.035) / max(n - 1, 1)
            order = self._ordered_copper()
            for i, cu in enumerate(order):
                layers.append(StackupLayer(cu, "copper", 0.035))
                if i < n - 1:
                    layers.append(StackupLayer(f"dielectric {i+1}", "dielectric", diel, 4.5, 0.02, "FR4"))
        else:
            for l in st.findall("layer"):
                name = l.atom(0)
                typ = (l.get("type") or "").lower()
                if typ == "copper":
                    kind = "copper"
                elif typ in ("core", "prepreg"):
                    kind = "dielectric"
                elif "mask" in typ:
                    kind = "mask"
                else:
                    kind = "other"
                layers.append(StackupLayer(name, kind, l.getf("thickness", 0.0) or 0.0,
                                           l.getf("epsilon_r"), l.getf("loss_tangent"), l.get("material")))
        z = 0.0
        for l in layers:
            if l.kind in ("copper", "dielectric"):
                l.z_top = z
                z -= l.thickness
                l.z_bottom = z
        return Stackup(layers)

    def _ordered_copper(self) -> list[str]:
        inner = sorted([c for c in self.copper_layers if c.startswith("In")], key=lambda s: int(s[2:-3]))
        return ["F.Cu", *inner, "B.Cu"]

    # --- footprints -------------------------------------------------------
    def _parse_footprint(self, node):
        at = node.find("at").floats()
        fx, fy = at[0], at[1]
        fa = at[2] if len(at) > 2 else 0.0
        props = {p.atom(0): p.atom(1, "") for p in node.findall("property")}
        attr = node.find("attr")
        fp = Footprint(
            ref=props.get("Reference", "?"),
            value=props.get("Value", ""),
            lib_id=node.atom(0, ""),
            x=fx, y=fy, angle=fa,
            side="B" if node.get("layer") == "B.Cu" else "F",
            properties=props,
            attrs=attr.atoms() if attr else [],
        )
        for p in node.findall("pad"):
            a = p.atoms()
            pat = p.find("at").floats()
            lx, ly = pat[0], pat[1]
            pang = pat[2] if len(pat) > 2 else 0.0
            dx, dy = rotate_local(lx, ly, fa)
            size = p.find("size").floats()
            drill_n = p.find("drill")
            drill = drill_n.floats()[0] if drill_n is not None and drill_n.floats() else 0.0
            fp.pads.append(Pad(
                ref=fp.ref, number=a[0] if a else "", net=p.get("net", "") or "",
                kind=a[1] if len(a) > 1 else "", shape=a[2] if len(a) > 2 else "rect",
                x=fx + dx, y=fy + dy, angle=pang, size=(size[0], size[1] if len(size) > 1 else size[0]),
                layers=p.find("layers").atoms() if p.find("layers") else [],
                rratio=p.getf("roundrect_rratio", 0.0) or 0.0, drill=drill,
                pinfunction=p.get("pinfunction", "") or "",
            ))
        for m in node.findall("model"):
            def xyz(name, default):
                n = m.find(name)
                x = n.find("xyz") if n is not None else None
                return tuple(x.floats()) if x is not None else default
            hide = m.get("hide") in ("yes",) or "hide" in m.atoms()
            fp.models.append({"path": m.atom(0, ""), "offset": xyz("offset", (0.0, 0.0, 0.0)),
                              "scale": xyz("scale", (1.0, 1.0, 1.0)), "rotate": xyz("rotate", (0.0, 0.0, 0.0)),
                              "hide": hide})
        def tf(lx, ly):
            dx, dy = rotate_local(lx, ly, fa)
            return fx + dx, fy + dy
        for g in node.nodes():
            if g.name.startswith("fp_") and g.get("layer") == "Edge.Cuts":
                self._edge_items.append(("fp", fx, fy, fa, g))
            elif g.name.startswith("fp_") and (g.get("layer") or "").endswith(".Cu"):
                geom = _copper_shape(g, tf)
                if geom is None or geom.is_empty:
                    continue
                net = g.get("net", "") or ""
                if not net:  # footprint copper has no net of its own: the net of the one pad it touches
                    lay = g.get("layer")
                    touch = {p.net for p in fp.pads if p.net and p.on_layer(lay) and p.polygon().intersects(geom)}
                    net = touch.pop() if len(touch) == 1 else ""
                self.shapes.append(Shape(net, g.get("layer"), geom))
        self.footprints.append(fp)

    # --- zones ------------------------------------------------------------
    def _parse_zone(self, node):
        if node.find("layers") is not None:
            layers = node.find("layers").atoms()
        else:
            layers = [node.get("layer")]
        poly = node.find("polygon")
        outline = None
        if poly is not None:
            pts = [_xy(xy) for xy in poly.find("pts").findall("xy")]
            if len(pts) >= 3:
                outline = Polygon(pts)
        filled: dict[str, list[Polygon]] = {}
        for fpoly in node.findall("filled_polygon"):
            lay = fpoly.get("layer")
            pts = [_xy(xy) for xy in fpoly.find("pts").findall("xy")]
            if len(pts) >= 3:
                g = Polygon(pts)
                if not g.is_valid:
                    g = g.buffer(0)  # fractured polygons with zero-width slits
                filled.setdefault(lay, []).append(g)
        self.zones.append(Zone(node.get("net", "") or "", layers, node.find("keepout") is not None, outline, filled))

    # --- queries ----------------------------------------------------------
    def footprint(self, ref: str) -> Footprint:
        for f in self.footprints:
            if f.ref == ref:
                return f
        raise KeyError(ref)

    @property
    def nets(self) -> set[str]:
        s = {t.net for t in self.tracks} | {v.net for v in self.vias} | {g.net for g in self.shapes}
        for f in self.footprints:
            s |= f.nets
        s.discard("")
        return s

    def outline(self) -> Polygon:
        """Board outline from Edge.Cuts graphics."""
        if self._outline is not None:
            return self._outline
        lines = []
        for it in self._edge_items:
            if isinstance(it, tuple):
                _, fx, fy, fa, g = it
                tf = lambda p: (fx + rotate_local(p[0], p[1], fa)[0], fy + rotate_local(p[0], p[1], fa)[1])
            else:
                g = it
                tf = lambda p: p
            n = g.name.split("_", 1)[1]
            if n == "line":
                lines.append(LineString([tf(_xy(g.find("start"))), tf(_xy(g.find("end")))]))
            elif n == "arc":
                lines.append(LineString([tf(p) for p in arc_points(_xy(g.find("start")), _xy(g.find("mid")), _xy(g.find("end")))]))
            elif n == "rect":
                (x1, y1), (x2, y2) = _xy(g.find("start")), _xy(g.find("end"))
                lines.append(LineString([tf(p) for p in [(x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1)]]))
            elif n == "circle":
                c, e = _xy(g.find("center")), _xy(g.find("end"))
                r = math.hypot(e[0] - c[0], e[1] - c[1])
                lines.append(Point(tf(c)).buffer(r, quad_segs=16).exterior)
            elif n == "poly":
                pts = [tf(_xy(xy)) for xy in g.find("pts").findall("xy")]
                lines.append(LineString(pts + [pts[0]]))
        # snap coordinates so endpoints that differ by ~1e-6 mm meet
        def snap(ls):
            return LineString([(round(x, 3), round(y, 3)) for x, y in ls.coords])
        lines = [snap(l) for l in lines if l.length > 0.05]  # drop tiny marker circles
        merged = unary_union([l.buffer(0.001) for l in lines]) if lines else None
        polys = list(polygonize(unary_union(lines))) if lines else []
        if not polys and merged is not None:
            polys = [Polygon(merged.envelope.exterior)]
        out = max(polys, key=lambda p: p.area) if polys else None
        # holes: other polygons inside the main one
        if out is not None:
            holes = [p for p in polys if p is not out and out.contains(p.representative_point())]
            for h in holes:
                out = out.difference(h)
        self._outline = out
        return out

    def copper(self, layer: str, net: str | None = None, region=None) -> "list[tuple[str, object]]":
        """List of (net, geometry) for all copper on ``layer`` (optionally one net / clipped)."""
        items = []
        for t in self.tracks:
            if t.layer == layer and (net is None or t.net == net):
                items.append((t.net, t.polygon()))
        for v in self.vias:
            if self.via_on_layer(v, layer) and (net is None or v.net == net):
                items.append((v.net, v.polygon()))
        for f in self.footprints:
            for p in f.pads:
                if p.on_layer(layer) and (net is None or p.net == net):
                    items.append((p.net, p.polygon()))
        for z in self.zones:
            if z.keepout:
                continue
            for g in z.filled.get(layer, []):
                if net is None or z.net == net:
                    items.append((z.net, g))
        for sh in self.shapes:
            if sh.layer == layer and (net is None or sh.net == net):
                items.append((sh.net, sh.geom))
        if region is not None:
            items = [(n, g.intersection(region)) for n, g in items if g.intersects(region)]
            items = [(n, g) for n, g in items if not g.is_empty]
        return items

    def via_on_layer(self, v: Via, layer: str) -> bool:
        order = self._ordered_copper()
        try:
            i0, i1 = sorted((order.index(v.layers[0]), order.index(v.layers[1])))
            return i0 <= order.index(layer) <= i1
        except ValueError:
            return False

    def summary(self) -> str:
        st = self.stackup
        lines = [f"Board: {self.path.name}  (format {self.version}, KiCad {self.generator_version})",
                 f"Copper layers: {', '.join(self._ordered_copper())}",
                 f"Footprints: {len(self.footprints)}, tracks: {len(self.tracks)}, vias: {len(self.vias)}, zones: {len(self.zones)}",
                 f"Total thickness (Cu+dielectric): {st.thickness:.4f} mm"]
        ol = self.outline()
        if ol is not None:
            x0, y0, x1, y1 = ol.bounds
            lines.append(f"Outline: {x1-x0:.2f} x {y1-y0:.2f} mm")
        lines.append("Stackup:")
        for l in st.layers:
            if l.kind in ("copper", "dielectric"):
                extra = f"  er={l.epsilon_r} tand={l.loss_tangent} {l.material or ''}" if l.kind == "dielectric" else ""
                lines.append(f"  {l.name:<14} {l.kind:<10} t={l.thickness*1000:7.1f} um  z={l.z_top:+.4f}..{l.z_bottom:+.4f}{extra}")
        return "\n".join(lines)
