"""Top view of the board for the field views: solder mask, copper, exposed pads, silkscreen,
part bodies (from F.Fab) and reference labels.

``picture(board)`` returns plain lists in KiCad coordinates (mm, y down); ``JS_DRAW`` is the
canvas painter the wave views embed (``drawBoard(ctx, P, X, Y, scale, opts)``).
"""
from __future__ import annotations

import math

from . import sexpr
from .board import arc_points, rotate_local

MASK, MASK_CU, PAD, SILK = "#1e5a2e", "#2f7a40", "#d4a547", "#f2f2ee"


def _r(v: float) -> float:
    return round(float(v), 3)


def _ring(coords) -> list:
    return [[_r(x), _r(y)] for x, y in coords]


def _polys(g, tol: float = 0.02) -> list:
    """Shapely (multi)polygon -> [[exterior, hole, ...], ...]."""
    if g is None or g.is_empty:
        return []
    g = g.simplify(tol, preserve_topology=True)
    out = []
    for p in getattr(g, "geoms", [g]):
        if p.geom_type != "Polygon" or p.is_empty:
            continue
        out.append([_ring(p.exterior.coords)] + [_ring(i.coords) for i in p.interiors])
    return out


def _width(node) -> float:
    s = node.find("stroke")
    w = s.getf("width") if s is not None else None
    return w if w is not None else (node.getf("width") or 0.12)


def _hidden(node) -> bool:
    h = node.find("hide")
    if h is not None:
        return h.atom(0, "yes") != "no"
    return "hide" in node.atoms()


def _graphic(g, tf) -> tuple[list, bool] | None:
    """(points, closed) of one gr_/fp_ graphic; ``tf`` maps local to board coordinates."""
    n = g.name[3:]
    try:
        if n == "line":
            return [tf(*g.find("start").floats()[:2]), tf(*g.find("end").floats()[:2])], False
        if n == "rect":
            (x0, y0), (x1, y1) = g.find("start").floats()[:2], g.find("end").floats()[:2]
            return [tf(x0, y0), tf(x1, y0), tf(x1, y1), tf(x0, y1)], True
        if n == "circle":
            cx, cy = g.find("center").floats()[:2]
            ex, ey = g.find("end").floats()[:2]
            r = math.hypot(ex - cx, ey - cy)
            k = max(12, int(r * 12))
            return [tf(cx + r * math.cos(2 * math.pi * i / k), cy + r * math.sin(2 * math.pi * i / k))
                    for i in range(k)], True
        if n == "arc":
            pts = arc_points(tuple(g.find("start").floats()[:2]), tuple(g.find("mid").floats()[:2]),
                             tuple(g.find("end").floats()[:2]))
            return [tf(x, y) for x, y in pts], False
        if n == "poly":
            pts = g.find("pts")
            return [tf(*xy.floats()[:2]) for xy in pts.findall("xy")], True
    except (AttributeError, TypeError, IndexError):
        return None
    return None


def _filled(g) -> bool:
    f = g.find("fill")
    if f is None:
        return False
    a = f.atom(0, "")
    return a in ("solid", "yes") or (f.find("type") is not None and f.find("type").atom(0) == "solid")


def _text(node, tf, fa: float, label: str):
    at = node.find("at")
    if at is None:
        return None
    f = at.floats()
    x, y = tf(f[0], f[1])
    ang = f[2] if len(f) > 2 else 0.0
    eff = node.find("effects")
    size = 1.0
    if eff is not None and eff.find("font") is not None and eff.find("font").find("size") is not None:
        size = eff.find("font").find("size").floats()[1]
    ang = ang % 360
    if 90 < ang <= 270:  # KiCad keeps text readable
        ang -= 180
    return [label, _r(x), _r(y), _r(size), _r(ang)]


def picture(board, region=None) -> dict:
    """Top-side picture data of ``board`` (optionally only what lies in the shapely ``region``)."""
    from shapely.geometry import Point, Polygon, box
    from shapely.ops import unary_union

    ol = board.outline()
    clip = region if region is not None else (ol.buffer(0.5) if ol is not None else None)

    def keep(g):
        return clip is None or g.intersects(clip)

    cu = [g for n, g in board.copper("F.Cu") if g is not None and not g.is_empty and keep(g)]
    pads, vias = [], []
    for fp in board.footprints:
        for p in fp.pads:
            if p.on_layer("F.Cu") and ("F.Mask" in p.layers or "*.Mask" in p.layers or p.kind == "thru_hole"):
                g = p.polygon()
                if keep(g):
                    pads.append(g)
    for v in board.vias:
        if board.via_on_layer(v, "F.Cu") and keep(Point(v.x, v.y)):
            vias.append([_r(v.x), _r(v.y), _r(v.size / 2), _r(v.drill / 2)])
    cu_u = unary_union(cu) if cu else None
    if cu_u is not None and ol is not None:
        cu_u = cu_u.intersection(ol.buffer(0.01))
    pad_u = unary_union(pads) if pads else None
    holes = []
    for fp in board.footprints:
        for p in fp.pads:
            if p.drill and keep(Point(p.x, p.y)):
                holes.append([_r(p.x), _r(p.y), _r(p.drill / 2)])

    silk, silk_fill, bodies, texts, refs = [], [], [], [], []
    root = sexpr.load(board.path)
    ident = lambda x, y: (x, y)  # noqa: E731
    for node in root.nodes():
        if node.name.startswith("gr_") and node.get("layer") == "F.SilkS":
            r = _graphic(node, ident)
            if r:
                (silk_fill if _filled(node) and r[1] else silk).append([_r(_width(node)), _ring(r[0]), r[1]])
        elif node.name == "gr_text" and node.get("layer") == "F.SilkS" and not _hidden(node):
            t = _text(node, ident, 0.0, node.atom(0, ""))
            if t:
                texts.append(t)
    for node in root.findall("footprint"):
        if node.get("layer") != "F.Cu":
            continue
        at = node.find("at").floats()
        fx, fy = at[0], at[1]
        fa = at[2] if len(at) > 2 else 0.0

        def tf(lx, ly, fx=fx, fy=fy, fa=fa):
            dx, dy = rotate_local(lx, ly, fa)
            return fx + dx, fy + dy
        if clip is not None and not clip.contains(Point(fx, fy)):
            continue
        fab = []
        ref = "?"
        for g in node.nodes():
            lay = g.get("layer")
            if g.name.startswith("fp_") and g.name != "fp_text":
                r = _graphic(g, tf)
                if not r:
                    continue
                if lay == "F.SilkS":
                    (silk_fill if _filled(g) and r[1] else silk).append([_r(_width(g)), _ring(r[0]), r[1]])
                elif lay == "F.Fab":
                    fab.extend(r[0])
            elif g.name == "property" and g.atom(0) == "Reference":
                ref = g.atom(1, "?")
                if lay == "F.SilkS" and not _hidden(g):
                    t = _text(g, tf, fa, ref)
                    if t:
                        texts.append(t)
            elif g.name == "fp_text" and lay == "F.SilkS" and not _hidden(g):
                lab = g.atom(1, "")
                if g.atom(0) == "reference":
                    ref = lab
                t = _text(g, tf, fa, ref if lab == "${REFERENCE}" else lab)
                if t:
                    texts.append(t)
            elif g.name == "fp_text" and g.atom(0) == "reference":
                ref = g.atom(1, "?")
        kind = (ref.rstrip("0123456789") or "?")[:2]
        if len(fab) >= 3:
            hull = Polygon(fab).convex_hull if len(fab) > 2 else None
            if hull is not None and hull.area > 0.05:
                # large outlines (modules, connectors, plug-in boards) only as a frame: they would hide the board
                bodies.append([kind, _ring(hull.exterior.coords), 1 if hull.area <= 80 else 0])
        if ref and not ref.startswith(("REF", "#", "?")):
            refs.append([ref, _r(fx), _r(fy)])

    bb = (ol if ol is not None else box(0, 0, 1, 1)).bounds
    return {"outline": _polys(ol, 0.005) if ol is not None else [], "copper": _polys(cu_u),
            "pads": _polys(pad_u, 0.005), "vias": vias, "holes": holes, "silk": silk, "silkfill": silk_fill,
            "text": texts, "bodies": bodies, "refs": refs, "bbox": [_r(v) for v in bb]}


# Canvas painter shared by the wave views. X(x), Y(y) map board mm to canvas pixels, s = px per mm.
JS_DRAW = r"""
function drawBoard(ctx,P,X,Y,s,o){o=o||{};const path=(rings)=>{ctx.beginPath();for(const r of rings){r.forEach(([x,y],i)=>i?ctx.lineTo(X(x),Y(y)):ctx.moveTo(X(x),Y(y)));ctx.closePath()}};
 ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
 for(const p of P.outline){path(p);ctx.fillStyle='#1e5a2e';ctx.fill('evenodd');ctx.strokeStyle='#c9c38a';ctx.lineWidth=Math.max(1,0.15*s);ctx.stroke()}
 for(const p of P.copper){path(p);ctx.fillStyle='#2f7a40';ctx.fill('evenodd')}
 for(const p of P.pads){path(p);ctx.fillStyle='#d4a547';ctx.fill('evenodd')}
 for(const [x,y,r,d] of P.vias){ctx.beginPath();ctx.arc(X(x),Y(y),r*s,0,7);ctx.fillStyle='#3a8a4a';ctx.fill();ctx.beginPath();ctx.arc(X(x),Y(y),Math.max(0.5,d*s),0,7);ctx.fillStyle='#111';ctx.fill()}
 for(const [x,y,r] of P.holes){ctx.beginPath();ctx.arc(X(x),Y(y),Math.max(0.5,r*s),0,7);ctx.fillStyle='#111';ctx.fill()}
 if(o.silk!==false){ctx.strokeStyle='#f2f2ee';ctx.fillStyle='#f2f2ee';
  for(const [w,pts,cl] of P.silk){ctx.lineWidth=Math.max(0.6,w*s);ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(X(x),Y(y)):ctx.moveTo(X(x),Y(y)));if(cl)ctx.closePath();ctx.stroke()}
  for(const [w,pts] of P.silkfill){path([pts]);ctx.fill()}
  ctx.textAlign='center';ctx.textBaseline='middle';
  for(const [t,x,y,h,a] of P.text){ctx.save();ctx.translate(X(x),Y(y));ctx.rotate(-a*Math.PI/180);ctx.font=`${Math.max(6,h*s)}px sans-serif`;ctx.fillText(t,0,0);ctx.restore()}}
 if(o.parts!==false){const C={C:'#c9a878',L:'#4a4a4a',R:'#1c1c1c',FB:'#3a3a3a'};
  for(const [k,pts,fill] of P.bodies){path([pts]);if(fill){ctx.globalAlpha=0.88;ctx.fillStyle=C[k]||'#262626';ctx.fill();ctx.globalAlpha=1;ctx.strokeStyle='rgba(0,0,0,.6)';ctx.lineWidth=1;ctx.stroke()}
   else{ctx.setLineDash([5,4]);ctx.strokeStyle='rgba(220,220,210,.55)';ctx.lineWidth=1.2;ctx.stroke();ctx.setLineDash([])}}}
 if(o.refs){ctx.font='bold 11px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
  for(const [t,x,y] of P.refs){ctx.lineWidth=3;ctx.strokeStyle='rgba(0,0,0,.75)';ctx.strokeText(t,X(x),Y(y));ctx.fillStyle='#fff';ctx.fillText(t,X(x),Y(y))}}
 ctx.restore()}
"""


def transform(pic: dict, fn) -> dict:
    """The same picture with every point mapped by ``fn(x, y) -> (x', y')`` (e.g. a standing antenna
    board drawn in the plane of its wave view). Text angles follow the mapping."""
    def pt(p):
        a, b = fn(p[0], p[1])
        return [_r(a), _r(b)]

    def ring(r):
        return [pt(p) for p in r]

    def ang(x, y, a):
        d = math.radians(a)
        p0, p1 = fn(x, y), fn(x + math.cos(d), y - math.sin(d))
        return math.degrees(math.atan2(-(p1[1] - p0[1]), p1[0] - p0[0]))
    out = dict(pic)
    for k in ("outline", "copper", "pads"):
        out[k] = [[ring(r) for r in poly] for poly in pic.get(k, [])]
    out["vias"] = [pt(v[:2]) + list(v[2:]) for v in pic.get("vias", [])]
    out["holes"] = [pt(v[:2]) + list(v[2:]) for v in pic.get("holes", [])]
    out["silk"] = [[e[0], ring(e[1]), *e[2:]] for e in pic.get("silk", [])]
    out["silkfill"] = [[e[0], ring(e[1]), *e[2:]] for e in pic.get("silkfill", [])]
    out["text"] = [[t, *pt((x, y)), h, _r(ang(x, y, a))] for t, x, y, h, a in pic.get("text", [])]
    out["bodies"] = [[k, ring(r), f] for k, r, f in pic.get("bodies", [])]
    out["refs"] = [[t, *pt((x, y))] for t, x, y in pic.get("refs", [])]
    pts = [p for poly in out["outline"] for r in poly for p in r]
    if pts:
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        out["bbox"] = [min(xs), min(ys), max(xs), max(ys)]
    return out
