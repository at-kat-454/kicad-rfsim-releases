"""Whole-board wave view without an extra simulation.

The RF path and the antenna are simulated separately anyway. Both runs record the E-field
in time on a plane 0.5 mm above the top copper, and both record the port voltage and current.
Because the structure is linear, the two can be joined after the runs:

* field per incident wave: ``H(f) = E(f) / a(f)`` for every pixel of each run
  (``a`` = wave launched by that run's source, from its port probes),
* RF path (2-port, parts at board values inside the FDTD): S21, S22 from two wave runs
  (input excited, output excited),
* antenna: reflection ``G_A`` at the feed from its own run,
* a new pulse ``P(f)`` into the RF path input gives the wave into the antenna
  ``x = S21 P / (1 - S22 G_A)`` and the wave reflected back ``y = G_A x``.

Path field = ``H1 P + H2 y``, antenna field = ``H_A x``. Transformed back to time, both share
one clock (t = 0 at the RF path input), so the overlay is time-synchronized and includes
every reflection between the matching network and the antenna. Not included: direct EM
coupling between the two models other than through the feed.
"""
from __future__ import annotations

import base64
import json
from pathlib import Path

import numpy as np

META = "overlay_meta.json"


def ft(t: np.ndarray, v: np.ndarray, f: np.ndarray) -> np.ndarray:
    """Fourier integral of a sampled signal (non-uniform steps allowed), ``v``: [n_t] or [n_t, P]."""
    w = np.gradient(t)
    k = np.exp(-2j * np.pi * np.outer(f, t)) * w
    return k @ v


def port_waves(run_dir: Path, number: int, R: float, f: np.ndarray):
    """(a, b) volt waves at a port: a into the structure, b out of it."""
    from .openems_export import _read_probe
    t, u = _read_probe(Path(run_dir) / f"port_ut_{number}")
    ti, i = _read_probe(Path(run_dir) / f"port_it_{number}")
    U, I = ft(t, u, f), ft(ti, i, f)
    a = 0.5 * (U + I * R)
    return a, U - a


def write_meta(run_dir: Path, **kw):
    Path(run_dir).mkdir(parents=True, exist_ok=True)
    (Path(run_dir) / META).write_text(json.dumps(kw))


def read_meta(run_dir: Path) -> dict | None:
    p = Path(run_dir) / META
    return json.loads(p.read_text()) if p.exists() else None


def _layer(run_dir: Path, td_name: str, flip_y: bool, n_long: int):
    """Frames on a uniform pixel grid in board coordinates (y down): (frames [n_t, ny, nx], t, box)."""
    from .fields import _resample, read_fields
    F = read_fields(run_dir, td_name)
    if F is None:
        return None
    a, nx, ny = _resample(F["td"], F["x"], F["y"], n_long)
    x0, x1, y0, y1 = float(F["x"][0]), float(F["x"][-1]), float(F["y"][0]), float(F["y"][-1])
    if flip_y:  # antenna model: global y = -board y
        a = a[:, ::-1, :]
        y0, y1 = -y1, -y0
    return a.astype(np.float32), np.asarray(F["t"], float), (x0, y0, x1, y1), nx, ny


def _band(spectra: list[np.ndarray], f: np.ndarray, floor_db: float = -20.0):
    """Frequency range where every excitation is within ``floor_db`` of its own peak."""
    ok = np.ones(len(f), bool)
    for s in spectra:
        m = np.abs(s)
        ok &= m > m.max() * 10 ** (floor_db / 20)
    if not ok.any():
        return None
    idx = np.where(ok)[0]
    # largest contiguous run
    runs = np.split(idx, np.where(np.diff(idx) > 1)[0] + 1)
    r = max(runs, key=len)
    return float(f[r[0]]), float(f[r[-1]])


def build_overlay(path_dirs: tuple[Path, Path], ant_dir: Path, path_meta: dict, ant_meta: dict,
                  f_ref: float | None = None, marks: list[float] | None = None, max_frames: int = 240,
                  floor_db: float = -40.0) -> dict:
    """Synthesize the joint field. ``path_dirs``: wave run with the input excited / output excited."""
    d1, d2 = map(Path, path_dirs)
    p_in, p_out = path_meta["port_in"], path_meta["port_out"]
    Rp, Ra = path_meta["R"], ant_meta["R"]
    # 1) usable band, from the three excitations on a fine grid
    fmin = max(path_meta["f_min"], ant_meta["f_min"])
    fmax = min(path_meta["f_max"], ant_meta["f_max"])
    fg = np.linspace(fmin, fmax, 400)
    a1, _ = port_waves(d1, p_in, Rp, fg)
    a2, _ = port_waves(d2, p_out, Rp, fg)
    aA, _ = port_waves(ant_dir, 1, Ra, fg)
    band = _band([a1, a2, aA], fg)
    if band is None:
        raise ValueError("the RF path and antenna runs share no excited frequency band")
    lo, hi = band
    fc = f_ref if (f_ref and lo < f_ref < hi) else (lo + hi) / 2
    half = min(fc - lo, hi - fc)
    sigma = half / np.sqrt(np.log(10 ** (-floor_db / 20)))  # pulse spectrum -40 dB at the band edge
    t0 = 3.2 / (np.pi * sigma)  # pulse starts ~ e^-10 below its peak
    # 2) layers (frames) and the analysis grid
    LP = _layer(d1, path_meta["td_name"], False, 170)
    LP2 = _layer(d2, path_meta["td_name"], False, 170)
    LA = _layer(ant_dir, ant_meta["td_name"], True, 200)
    if LP is None or LP2 is None or LA is None:
        raise ValueError("field recordings missing - run the RF path and the antenna with the wave view on")
    T = max(LP[1][-1], LP2[1][-1], LA[1][-1])
    df = 1.0 / (2.0 * (T + t0))
    f = np.arange(fc - 3 * sigma, fc + 3 * sigma + df, df)
    f = f[(f > 0)]
    marks = [m for m in (marks or []) if lo <= m <= hi]
    fa = np.concatenate([f, marks]) if marks else f
    # 3) network quantities on the analysis grid
    a1, b2_1 = port_waves(d1, p_in, Rp, fa)
    _, b1_1 = port_waves(d1, p_in, Rp, fa)
    a2, b2_2 = port_waves(d2, p_out, Rp, fa)
    _, b2_from1 = port_waves(d1, p_out, Rp, fa)
    _, b1_2 = port_waves(d2, p_in, Rp, fa)
    aA, bA = port_waves(ant_dir, 1, Ra, fa)
    S11, S21 = b1_1 / a1, b2_from1 / a1
    S12, S22 = b1_2 / a2, b2_2 / a2
    GA = bA / aA
    P = np.exp(-((fa - fc) / sigma) ** 2) * np.exp(-2j * np.pi * fa * t0)
    x = S21 / (1 - S22 * GA)  # wave into the antenna per unit incident wave at the input
    y = GA * x
    s11_in = S11 + S12 * y

    def transfer(L, a):
        fr, t = L[0], L[1]
        n, ny, nx = fr.shape
        E = ft(t, fr.reshape(n, -1), fa)
        return E / a[:, None], ny, nx

    H1, ny_p, nx_p = transfer(LP, a1)
    H2, _, _ = transfer(LP2, a2)
    HA, ny_a, nx_a = transfer(LA, aA)
    spec_p = H1 * P[:, None] + H2 * (y * P)[:, None]
    spec_a = HA * (x * P)[:, None]
    nf = len(f)
    # 4) back to time on a shared clock
    t_out = np.arange(0, T + t0, 1.0 / (8 * fc))
    W = np.exp(2j * np.pi * np.outer(t_out, fa[:nf])) * (2 * df)
    fp = np.real(W @ spec_p[:nf])
    fa_ = np.real(W @ spec_a[:nf])
    e = (fp ** 2).sum(1) + (fa_ ** 2).sum(1)
    k_pk = int(np.argmax(e))
    above = np.where(e > e[k_pk] * 1e-3)[0]
    k_end = int(above[-1]) + 1 if len(above) else len(t_out)
    k0 = int(np.where(e > e[k_pk] * 1e-4)[0][0])
    sel = np.arange(max(0, k0 - 4), min(len(t_out), k_end + 4))
    if len(sel) > max_frames:
        sel = sel[np.linspace(0, len(sel) - 1, max_frames).astype(int)]
    fp, fa_, t_out = fp[sel], fa_[sel], t_out[sel]
    # 5) steady state at the markers: unit incident wave at the input
    ss = []
    for j, m in enumerate(marks):
        k = nf + j
        ss.append({"f": m, "path": H1[k] + H2[k] * y[k], "ant": HA[k] * x[k],
                   "s11": complex(s11_in[k]), "x": complex(x[k]), "GA": complex(GA[k])})
    return {"t": t_out, "path": fp.reshape(len(t_out), ny_p, nx_p), "ant": fa_.reshape(len(t_out), ny_a, nx_a),
            "box_p": LP[2], "box_a": LA[2], "fc": fc, "band": (lo, hi), "t0": t0, "ss": ss,
            "shape_p": (ny_p, nx_p), "shape_a": (ny_a, nx_a)}


def _i8(a: np.ndarray, peak: float) -> str:
    return base64.b64encode(np.clip(np.round(a / (peak or 1.0) * 127), -127, 127).astype(np.int8).tobytes()).decode()


def write_overlay_view(R: dict, outlines: list, path: Path, title: str, note: str, board_outline=None,
                       region_label: str = "RF path model", pic: dict | None = None) -> Path:
    """Page with the two layers on one board picture (board coordinates, mm, y down)."""
    fp, fa = R["path"], R["ant"]
    pk = float(max(np.abs(fp).max(), np.abs(fa).max())) or 1.0
    pk_p, pk_a = float(np.abs(fp).max()) or 1.0, float(np.abs(fa).max()) or 1.0
    layers = []
    for key, arr, box, lp in (("ant", fa, R["box_a"], pk_a), ("path", fp, R["box_p"], pk_p)):
        n, ny, nx = arr.shape
        fpk = (np.abs(arr).reshape(n, -1).max(1) / lp).round(4).tolist()
        ss = []
        for s in R["ss"]:
            c = s[key].reshape(ny, nx)
            m = float(np.abs(c).max()) or 1.0
            ss.append({"re": _i8(c.real, m), "im": _i8(c.imag, m), "m": m})
        layers.append({"key": key, "nx": nx, "ny": ny, "box": [round(v, 3) for v in box], "td": _i8(arr, lp),
                       "peak": lp / pk, "fpeak": fpk, "ss": ss})
    # steady-state relative scale between the layers
    for j, s in enumerate(R["ss"]):
        m = max(layers[0]["ss"][j]["m"], layers[1]["ss"][j]["m"]) or 1.0
        for L in layers:
            L["ss"][j]["rel"] = L["ss"][j]["m"] / m
    gp = (np.maximum(np.abs(fp).reshape(len(fp), -1).max(1), np.abs(fa).reshape(len(fa), -1).max(1)) / pk)
    xs = [L["box"][0] for L in layers] + [L["box"][2] for L in layers]
    ys = [L["box"][1] for L in layers] + [L["box"][3] for L in layers]
    data = {"title": title, "note": note, "layers": layers, "nt": int(len(R["t"])),
            "t": (np.asarray(R["t"]) * 1e9).round(4).tolist(), "gpeak": gp.round(4).tolist(),
            "x0": min(xs), "x1": max(xs), "y0": min(ys), "y1": max(ys),
            "marks": [{"f": s["f"], "s11": 20 * np.log10(max(abs(s["s11"]), 1e-9)),
                       "pacc": (abs(s["x"]) ** 2) * (1 - abs(s["GA"]) ** 2)} for s in R["ss"]],
            "outlines": [[n, [[round(px, 3), round(py, 3)] for px, py in pts]] for n, pts in outlines],
            "board": [[round(px, 3), round(py, 3)] for px, py in (board_outline or [])],
            "rlabel": region_label, "pic": pic}
    from .boardpic import JS_DRAW
    from .pagepack import pack_page
    html = pack_page(_TPL.replace("__TITLE__", title).replace("__BOARDJS__", JS_DRAW), data)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(html, encoding="utf-8")
    return path


_TPL = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title><style>
:root{--bg:#fafaf8;--fg:#1d1d1b;--mut:#6b6b66;--card:#fff;--line:#e3e2dc;--acc:#2a6fdb}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff}}
:root[data-theme="dark"]{--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 system-ui,sans-serif}
header{padding:14px 16px;border-bottom:1px solid var(--line)}h1{font-size:17px;margin:0}.sub{color:var(--mut);font-size:12px}
main{padding:14px 16px;display:grid;grid-template-columns:300px 1fr;gap:14px}@media(max-width:820px){main{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px;min-width:0}
label{display:flex;gap:8px;align-items:center;margin:8px 0;font-size:13px}select,input[type=range]{flex:1;min-width:0;font:inherit}
button{background:var(--acc);color:#fff;border:0;border-radius:6px;padding:7px 14px;cursor:pointer;font:inherit}
canvas{width:100%;height:auto;border-radius:6px;background:#000}
#cbar{height:10px;border-radius:5px;margin-top:6px}.row{display:flex;justify-content:space-between;font-size:12px;color:var(--mut)}
table{border-collapse:collapse;font-size:12px;width:100%;margin-top:8px}td,th{border-bottom:1px solid var(--line);padding:3px 4px;text-align:left}
</style></head><body>
<header><h1 id="t"></h1><div class="sub" id="note"></div></header>
<main><section class="card">
<label>View <select id="mode"></select></label>
<div><button id="play">Pause</button></div>
<label>Speed <input type="range" id="speed" min="2" max="60" value="20"></label>
<label>Time <input type="range" id="pos" min="0" max="100" value="0"></label>
<div class="row"><span id="tlab"></span><span id="flab"></span></div>
<label>Show <select id="comp"><option value="mag">|E| magnitude</option><option value="signed">E vertical (sign = direction)</option></select></label>
<label><input type="checkbox" id="auto" checked style="flex:0"> scale each frame (follow the pulse as it fades)</label>
<label><input type="checkbox" id="sep" style="flex:0"> scale RF path and antenna separately</label>
<label>Contrast <input type="range" id="gain" min="1" max="30" value="3"></label>
<label><input type="checkbox" id="box" checked style="flex:0"> show the RF path model's area</label>
<label>Background <select id="bg"><option value="board">realistic board</option><option value="outlines">copper outlines</option><option value="none">field only</option></select></label>
<label class="bgo">Field opacity <input type="range" id="op" min="10" max="100" value="80"></label>
<label class="bgo"><input type="checkbox" id="parts" checked style="flex:0"> part bodies</label>
<label class="bgo"><input type="checkbox" id="refs" style="flex:0"> part labels</label>
<div id="cbar"></div><div class="row"><span id="cb0"></span><span id="cb1"></span></div>
<table id="mk"></table>
<p class="sub">Two separate simulations joined after the runs: the RF path (parts at their board values) and the
antenna. The antenna is driven by the wave the RF path really delivers, including the reflections between
matching network and antenna, on one shared clock (t = 0 at the RF input). Not included: direct coupling
between path and antenna other than through the feed. E-field 0.5 mm above the top copper, drawn over the board.</p>
</section><section class="card"><canvas id="cv"></canvas></section></main>
<script>__BOARDJS__
const D=__DATA__;document.getElementById('t').textContent=D.title;document.getElementById('note').textContent=D.note;
const dec=b=>{const s=atob(b),a=new Int8Array(s.length);for(let i=0;i<s.length;i++){a[i]=(s.charCodeAt(i)<<24)>>24}return a};
const L=D.layers.map(l=>Object.assign({},l,{TD:dec(l.td),SS:l.ss.map(o=>({re:dec(o.re),im:dec(o.im),rel:o.rel})),
 off:Object.assign(document.createElement('canvas'),{width:l.nx,height:l.ny})}));
L.forEach(l=>{l.img=l.off.getContext('2d').createImageData(l.nx,l.ny)});
const sel=document.getElementById('mode');sel.add(new Option('Pulse in time','td'));
D.marks.forEach((m,i)=>sel.add(new Option('Steady state at '+(m.f/1e6).toFixed(0)+' MHz','fd'+i)));
const mk=document.getElementById('mk');if(D.marks.length){mk.innerHTML='<tr><th>f</th><th>input match</th><th>power into antenna</th></tr>'+
 D.marks.map(m=>`<tr><td>${(m.f/1e6).toFixed(0)} MHz</td><td>${m.s11.toFixed(1)} dB</td><td>${(100*m.pacc).toFixed(0)} %</td></tr>`).join('')}
const W=D.x1-D.x0,H=D.y1-D.y0,cv=document.getElementById('cv'),ctx=cv.getContext('2d');const S=1100/Math.max(W,H);
cv.width=Math.round(W*S);cv.height=Math.round(H*S);
const X=x=>(x-D.x0)*S,Y=y=>(y-D.y0)*S;
const $=id=>document.getElementById(id);if(!D.pic){$('bg').value='outlines';$('bg').querySelector('[value=board]').disabled=true}
let bgc=null;function boardBg(){const c=document.createElement('canvas');c.width=cv.width;c.height=cv.height;const x=c.getContext('2d');
 x.fillStyle='#0d0d0c';x.fillRect(0,0,c.width,c.height);drawBoard(x,D.pic,X,Y,S,{parts:$('parts').checked,refs:$('refs').checked});return c}
function bgOpts(){document.querySelectorAll('.bgo').forEach(e=>e.style.display=$('bg').value==='board'?'flex':'none');bgc=null}
function col(v,mag){if(mag){const a=Math.min(1,Math.abs(v));return[Math.round(255*Math.min(1,a*1.6)),Math.round(255*Math.max(0,a*1.6-0.6)),Math.round(80*(1-a))]}
 v=Math.max(-1,Math.min(1,v));const a=Math.abs(v);if(v>=0)return[255,Math.round(255*(1-a)),Math.round(255*(1-a))];return[Math.round(255*(1-a)),Math.round(255*(1-a)),255]}
let frame=0,playing=true,last=0;const PH=48;
const nFrames=()=>sel.value==='td'?D.nt:PH;
function paint(l,k,g,mag,al){const N=l.nx*l.ny,d=l.img.data;const td=sel.value==='td';let F,c,s;
 if(!td){F=l.SS[+sel.value.slice(2)];const ph=2*Math.PI*k/PH;c=Math.cos(ph);s=Math.sin(ph)}
 for(let i=0;i<N;i++){const v=td?l.TD[k*N+i]/127:(F.re[i]*c-F.im[i]*s)/127;const [r,gg,b]=col(v*g,mag);const p=4*i;d[p]=r;d[p+1]=gg;d[p+2]=b;d[p+3]=al?Math.round(255*al*Math.min(1,Math.abs(v*g)*1.5)):255}
 l.off.getContext('2d').putImageData(l.img,0,0)}
function draw(){const k=frame%nFrames(),mag=document.getElementById('comp').value==='mag',sep=document.getElementById('sep').checked,
 auto=document.getElementById('auto').checked,td=sel.value==='td';const g0=+document.getElementById('gain').value;
 const bg=$('bg').value,brd=bg==='board',al=brd?+$('op').value/100:0;
 ctx.fillStyle='#000';ctx.fillRect(0,0,cv.width,cv.height);if(brd){if(!bgc)bgc=boardBg();ctx.drawImage(bgc,0,0)}ctx.imageSmoothingEnabled=true;
 for(const l of L){let g=g0;
  if(td){const lp=sep?1:l.peak;g=g0*lp;if(auto)g=g/Math.max(1e-3,sep?l.fpeak[k]:D.gpeak[k])}
  else{g=g0/3*(sep?1:l.SS[+sel.value.slice(2)].rel)}
  paint(l,k,g,mag,al);const [x0,y0,x1,y1]=l.box;
  if(brd&&l.key==='path'){const a=X(x0),b=Y(y0),w=X(x1)-a,h=Y(y1)-b;ctx.drawImage(bgc,a,b,w,h,a,b,w,h)}
  ctx.drawImage(l.off,X(x0),Y(y0),X(x1)-X(x0),Y(y1)-Y(y0))}
 ctx.lineWidth=1.2;ctx.strokeStyle=mag?'#e8e8e8':'#1d1d1b';ctx.globalAlpha=0.8;
 if(bg==='outlines')for(const [n,pts] of D.outlines){ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(X(x),Y(y)):ctx.moveTo(X(x),Y(y)));ctx.closePath();ctx.stroke()}
 if(bg==='outlines'&&D.board.length){ctx.strokeStyle='#7fbf7f';ctx.lineWidth=2;ctx.beginPath();D.board.forEach(([x,y],i)=>i?ctx.lineTo(X(x),Y(y)):ctx.moveTo(X(x),Y(y)));ctx.closePath();ctx.stroke()}
 if(document.getElementById('box').checked){const [x0,y0,x1,y1]=L[1].box;ctx.setLineDash([6,4]);ctx.strokeStyle='#6aa3ff';ctx.lineWidth=1.5;
  ctx.strokeRect(X(x0),Y(y0),X(x1)-X(x0),Y(y1)-Y(y0));ctx.setLineDash([]);ctx.globalAlpha=1;ctx.fillStyle='#6aa3ff';ctx.font='13px system-ui';ctx.fillText(D.rlabel,X(x0)+3,Y(y0)-5)}
 ctx.globalAlpha=1;
 document.getElementById('pos').max=nFrames()-1;document.getElementById('pos').value=k;
 document.getElementById('tlab').textContent=td?('t = '+D.t[k].toFixed(2)+' ns'):('phase '+Math.round(360*k/PH)+'°');
 document.getElementById('flab').textContent=td?('frame '+(k+1)+' / '+D.nt):'one RF period'}
function tick(ts){if(playing&&ts-last>1000/+document.getElementById('speed').value){frame=(frame+1)%nFrames();last=ts;draw()}requestAnimationFrame(tick)}
document.getElementById('play').onclick=e=>{playing=!playing;e.target.textContent=playing?'Pause':'Play'};
document.getElementById('pos').oninput=e=>{frame=+e.target.value;playing=false;document.getElementById('play').textContent='Play';draw()};
['mode','comp','auto','gain','sep','box','op'].forEach(id=>document.getElementById(id).oninput=()=>{if(id==='mode')frame=0;cbar();draw()});
['bg','parts','refs'].forEach(id=>$(id).onchange=()=>{bgOpts();draw()});bgOpts();
function cbar(){const mag=document.getElementById('comp').value==='mag';const st=[];for(let i=0;i<=10;i++){const v=mag?i/10:(i/5-1);const [r,g,b]=col(v,mag);st.push(`rgb(${r},${g},${b}) ${i*10}%`)}
 document.getElementById('cbar').style.background=`linear-gradient(90deg,${st.join(',')})`;document.getElementById('cb0').textContent=mag?'0':'− (down)';document.getElementById('cb1').textContent=mag?'max':'+ (up)'}
cbar();draw();requestAnimationFrame(tick);
</script></body></html>"""
