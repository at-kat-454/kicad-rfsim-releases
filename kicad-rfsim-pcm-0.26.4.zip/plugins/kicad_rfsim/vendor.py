"""Vendor part libraries (Touchstone files of real capacitors / inductors).

The tuning viewer can use the measured impedance of real parts instead of the ideal
value + Q model. Supported now: Murata S-parameter libraries (GJM / GRM MLCC, LQW / LQG
inductors) as downloaded from murata.com, in any folder layout below the library folder.

Murata measures every part in series-through mode on a de-embedded fixture, so
S21 = 2 Z0 / (2 Z0 + Z) and the part impedance is ``Z = 2 Z0 (1 / S21 - 1)``. That
impedance is valid in any position (series or shunt) on the board.

``load_index(folder)`` scans the folder once (a few seconds for ~2000 relevant files) and
keeps a cache in the app folder. ``series_for(kind, size)`` lists the series with their
parts; ``z_at(part, f)`` interpolates a part's impedance onto the simulation frequencies.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

GRID = np.geomspace(50e6, 10e9, 360)  # index frequency grid (Hz)
TOL_ORDER = "WABCDFGHJKM"  # tightest first

# series (by part-number prefix) -> (kind, size, label)
SERIES = {
    "GJM155": ("C", "0402", "GJM15 (high Q, C0G)"),
    "GRM155": ("C", "0402", "GRM155 (C0G)"),
    "GJM033": ("C", "0201", "GJM03 (high Q, C0G)"),
    "GRM033": ("C", "0201", "GRM033 (C0G)"),
    "GJM188": ("C", "0603", "GJM18 (high Q, C0G)"),
    "GRM188": ("C", "0603", "GRM188 (C0G)"),
    "LQW15AN": ("L", "0402", "LQW15AN (wire-wound)"),
    "LQG15HS": ("L", "0402", "LQG15HS (multilayer)"),
    "LQG15HN": ("L", "0402", "LQG15HN (multilayer)"),
    "LQP03TN": ("L", "0201", "LQP03TN (thin film)"),
    "LQW18AN": ("L", "0603", "LQW18AN (wire-wound)"),
}

_RE_MLCC = re.compile(r"^(G[RJ]M)(\d\d)(\w)(\w\w)(\w\w)(\w{3})(\w)(\w+)$")  # GJM 15 5 5C 1H 100 F B01
_RE_IND = re.compile(r"^(LQ[WGP]\d\d[A-Z]{2})(\w{3})(\w)(\w{2})\w?$")


@dataclass
class VPart:
    pn: str
    series: str  # e.g. "LQW15AN_80", "GJM15"
    label: str
    kind: str  # C / L
    size: str  # 0402 ...
    value: float  # nominal F / H
    tol: str
    z: np.ndarray  # complex impedance on GRID
    q868: float = 0.0
    srf: float = 0.0  # Hz (first X = 0 crossing), 0 = above the data


def parse_pn(pn: str):
    """(series key, kind, size, label, nominal value, tolerance letter) or None."""
    m = _RE_MLCC.match(pn)
    if m:
        fam, size_code = m.group(1), pn[3:6]
        key = fam + size_code
        tc = m.group(4)  # temperature characteristic, "5C" = C0G
        if key not in SERIES or tc != "5C":
            return None
        code = m.group(6)
        try:
            if "R" in code:
                v = float(code.replace("R", ".")) * 1e-12
            else:
                v = int(code[:2]) * 10 ** int(code[2]) * 1e-12
        except ValueError:
            return None
        kind, size, label = SERIES[key]
        short = {"GJM155": "GJM15", "GRM155": "GRM155", "GJM033": "GJM03", "GRM033": "GRM033",
                 "GJM188": "GJM18", "GRM188": "GRM188"}[key]
        return short, kind, size, label, v, m.group(7)
    m = _RE_IND.match(pn)
    if m:
        key, code, tol, suf = m.group(1), m.group(2), m.group(3), m.group(4)
        if key not in SERIES:
            return None
        try:
            if "N" in code:
                v = float(code.replace("N", ".")) * 1e-9
            elif code.startswith("R"):
                v = float("0." + code[1:]) * 1e-6
            else:
                return None
        except ValueError:
            return None
        kind, size, label = SERIES[key]
        return f"{key}_{suf}", kind, size, label.replace(key, f"{key}…{suf}"), v, tol
    return None


def read_series_s2p(path: Path, text: str | None = None) -> tuple[np.ndarray, np.ndarray]:
    """(f, Z) of a part measured in series-through mode (Murata). The numbers are converted in
    one numpy call (a Python loop per value was the slow part of reading a library)."""
    unit, fmt, z0 = 1.0, "RI", 50.0
    if text is None:
        with open(path, encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    nums = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s[0] == "!":
            continue
        if s[0] == "#":
            t = s[1:].upper().split()
            unit = {"HZ": 1.0, "KHZ": 1e3, "MHZ": 1e6, "GHZ": 1e9}.get(t[0], 1.0) if t else 1.0
            fmt = next((x for x in t if x in ("RI", "MA", "DB")), "RI")
            if "R" in t:
                z0 = float(t[t.index("R") + 1])
            continue
        nums.append(s.split("!", 1)[0])
    a = np.array(" ".join(nums).split(), dtype=float).reshape(-1, 9)
    f = a[:, 0] * unit
    if fmt == "RI":
        s21 = a[:, 3] + 1j * a[:, 4]
    elif fmt == "MA":
        s21 = a[:, 3] * np.exp(1j * np.deg2rad(a[:, 4]))
    else:
        s21 = 10 ** (a[:, 3] / 20) * np.exp(1j * np.deg2rad(a[:, 4]))
    return f, 2 * z0 * (1 / s21 - 1)


def _interp(f, z, fg):
    lf, lg = np.log(f), np.log(fg)
    zr = np.interp(lg, lf, z.real, left=np.nan, right=np.nan)
    zi = np.interp(lg, lf, z.imag, left=np.nan, right=np.nan)
    return zr + 1j * zi


def _figures(kind, z):
    k = int(np.argmin(abs(GRID - 868e6)))
    x, r = z.imag[k], z.real[k]
    q = abs(x) / r if r > 0 else 0.0
    sgn = np.sign(z.imag)
    want = 1 if kind == "C" else -1  # C: X < 0 then crosses to > 0 ; L: X > 0 then < 0
    srf = 0.0
    for i in range(1, len(GRID)):
        if np.isfinite(z.imag[i]) and sgn[i - 1] == -want and sgn[i] == want:
            srf = float(GRID[i - 1] - z.imag[i - 1] * (GRID[i] - GRID[i - 1]) / (z.imag[i] - z.imag[i - 1]))
            break
    return float(q), srf


def _one(p: Path, text: str | None = None):
    info = parse_pn(p.stem.upper())
    if info is None:
        return None
    series, kind, size, label, v, tol = info
    try:
        f, z = read_series_s2p(p, text)
    except (OSError, ValueError, IndexError):
        return None
    zg = _interp(f, z, GRID)
    q, srf = _figures(kind, zg)
    return VPart(p.stem.upper(), series, label, kind, size, v, tol, zg.astype(np.complex64), q, srf)


def _read_text(p: Path) -> str | None:
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def scan(folder: Path, progress=None) -> list[VPart]:
    """Read every usable file below ``folder``. Files are read by 8 threads (opening many small
    files is slow on synced / network folders and with virus scanners); parsing stays in this
    thread, where it is fastest."""
    from concurrent.futures import ThreadPoolExecutor
    files = [p for p in sorted(Path(folder).rglob("*.s2p")) if parse_pn(p.stem.upper())]
    parts = []
    with ThreadPoolExecutor(8) as ex:
        for i0 in range(0, len(files), 256):
            chunk = files[i0:i0 + 256]
            for p, text in zip(chunk, ex.map(_read_text, chunk)):
                if text is not None:
                    r = _one(p, text)
                    if r is not None:
                        parts.append(r)
            if progress:
                progress(f"part library: {min(i0 + 256, len(files))}/{len(files)} files")
    return parts


def _stamp(folder: Path) -> str:
    n, mt = 0, 0.0
    for root, _d, fs in os.walk(folder):
        for f in fs:
            if f.lower().endswith(".s2p"):
                n += 1
        try:
            mt = max(mt, os.path.getmtime(root))
        except OSError:
            pass
    return f"{Path(folder).resolve()}|{n}|{mt:.0f}"


_CACHE: dict[str, list[VPart]] = {}


def load_index(folder, cache_dir=None, progress=None) -> list[VPart]:
    """All usable parts below ``folder`` (cached in ``cache_dir``/vendor_index.npz)."""
    if not folder or not Path(folder).is_dir():
        return []
    stamp = _stamp(Path(folder))
    if stamp in _CACHE:
        return _CACHE[stamp]
    cf = Path(cache_dir) / "vendor_index.npz" if cache_dir else None
    if cf and cf.exists():
        try:
            d = np.load(cf, allow_pickle=False)
            if str(d["stamp"]) == stamp:
                meta = json.loads(str(d["meta"]))
                zz = d["z"]  # read once: every d["z"] access decompresses the whole array again
                parts = [VPart(**m, z=zz[i].copy()) for i, m in enumerate(meta)]
                _CACHE[stamp] = parts
                return parts
        except Exception:
            pass
    parts = scan(Path(folder), progress)
    if cf:
        try:
            cf.parent.mkdir(parents=True, exist_ok=True)
            meta = [{k: getattr(p, k) for k in ("pn", "series", "label", "kind", "size", "value", "tol", "q868", "srf")}
                    for p in parts]
            np.savez_compressed(cf, stamp=np.array(stamp), meta=np.array(json.dumps(meta)),
                                z=np.array([p.z for p in parts]) if parts else np.zeros((0, len(GRID)), np.complex64))
        except OSError:
            pass
    _CACHE[stamp] = parts
    return parts


def series_for(parts: list[VPart], kind: str, size: str, vmin: float = 0.0, vmax: float = 1.0) -> dict[str, list[VPart]]:
    """{series: parts sorted by value, one per nominal value (tightest tolerance)}."""
    out: dict[str, dict[float, VPart]] = {}
    for p in parts:
        if p.kind != kind or p.size != size or not (vmin <= p.value <= vmax):
            continue
        d = out.setdefault(p.series, {})
        key = round(p.value, 15)
        o = d.get(key)
        if o is None or TOL_ORDER.find(p.tol) < TOL_ORDER.find(o.tol):
            d[key] = p
    return {s: [d[k] for k in sorted(d)] for s, d in sorted(out.items())}


def z_at(part: VPart, f) -> np.ndarray:
    """Impedance at the frequencies ``f`` (NaN outside the measured range)."""
    return _interp(GRID, part.z.astype(complex), np.asarray(f, float))


def footprint_size(lib_id: str) -> str | None:
    """Imperial size code from a KiCad footprint name (C_0402_1005Metric -> 0402)."""
    s = lib_id.upper()
    for imp, met in (("01005", "0402M"), ("0201", "0603M"), ("0402", "1005M"), ("0603", "1608M"), ("0805", "2012M")):
        if f"_{imp}_" in s or s.endswith(f"_{imp}") or f"{met}ETRIC" in s:
            return imp
    for imp in ("0201", "0402", "0603", "0805"):
        if imp in s:
            return imp
    return None


def viewer_payload(parts: list[VPart], f, kinds_sizes: set[tuple[str, str]]) -> dict:
    """Data for the tuning viewer: {kind: {size: [{series, label, parts: [pn, value, tol, q, srf, zr, zi]}]}}"""
    out: dict = {}
    for kind, size in sorted(kinds_sizes):
        lim = (0.1e-12, 1e-9) if kind == "C" else (0.5e-9, 470e-9)
        ss = series_for(parts, kind, size, *lim)
        lst = []
        for name, ps in ss.items():
            rows = []
            for p in ps:
                z = z_at(p, f)
                if not np.all(np.isfinite(z)):
                    continue
                rows.append({"pn": p.pn, "v": p.value, "tol": p.tol, "q": round(p.q868, 1),
                             "srf": round(p.srf / 1e6, 0), "zr": np.round(z.real, 4).tolist(),
                             "zi": np.round(z.imag, 3).tolist()})
            if rows:
                lst.append({"series": name, "label": ps[0].label, "parts": rows})
        if lst:
            out.setdefault(kind, {})[size] = lst
    return out
