"""Circuit layer: connect component models to the EM N-port of the layout.

The EM model has one port per component pad (pad -> ground plane). Every
port is a node. Components are stamped into the nodal admittance matrix:

  * two-terminal part between nodes a and b:  Y[a,a]+=y, Y[b,b]+=y, Y[a,b]-=y, Y[b,a]-=y
  * shunt part (other pad on ground):          Y[a,a]+=y
  * any N-port model (Touchstone, ground-referenced): its Y-matrix is added
    on the node set it connects to.

Nodes that are not external ports are removed by Kron reduction (no current
is injected there). The result is the S-matrix between the external ports.
Re-solving after a value change costs only a matrix inversion per frequency,
so sliders and optimizers run without a new EM simulation.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from .rfpath import parse_value

TWO_PI = 2 * math.pi


# ---------------------------------------------------------------------------
# component models
# ---------------------------------------------------------------------------
@dataclass
class Element:
    """A two-terminal lumped element. ``kind``: C, L, R, short, open."""
    kind: str
    value: float = 0.0
    q: float | None = None  # quality factor at f_q (constant-Q loss model)
    f_q: float = 868e6
    esl: float = 0.0  # series parasitic inductance (C, R, short)
    esr: float = 0.0
    srf_c: float = 0.0  # parallel parasitic capacitance (L)

    def z(self, f: np.ndarray) -> np.ndarray:
        w = TWO_PI * f
        if self.kind == "C":
            r = self.esr
            if self.q:
                r += 1 / (TWO_PI * self.f_q * self.value * self.q)
            return r + 1 / (1j * w * self.value) + 1j * w * self.esl
        if self.kind == "L":
            r = self.esr
            if self.q:
                r += TWO_PI * self.f_q * self.value / self.q
            zl = r + 1j * w * self.value
            if self.srf_c > 0:
                zl = 1 / (1 / zl + 1j * w * self.srf_c)
            return zl
        if self.kind == "R":
            return self.value + 1j * w * self.esl + 0 * f
        if self.kind == "short":
            return self.esr + 1j * w * self.esl + 0 * f
        raise ValueError(self.kind)

    def y(self, f):
        if self.kind == "open":
            return np.zeros_like(f, dtype=complex)
        return 1 / self.z(f)

    def label(self) -> str:
        if self.kind == "C":
            return f"{self.value*1e12:.3g} pF"
        if self.kind == "L":
            return f"{self.value*1e9:.3g} nH"
        if self.kind == "R":
            return f"{self.value:.3g} ohm"
        return self.kind


# Defaults roughly typical for 0402 parts around 1 GHz (override per part with RF.Q / RF.Model).
DEFAULT_Q = {"C": 150.0, "L": 30.0}
DEFAULT_ESL = {"C": 0.3e-9, "short": 0.3e-9}


def element_from_value(kind_hint: str, value_text: str, dnp: bool = False, q: float | None = None,
                       f_q: float | None = None) -> Element:
    """A part from its value text. ``q``: quality factor at ``f_q`` (default Q, 868 MHz when not given)."""
    if dnp:
        return Element("open")
    v = parse_value(value_text)
    if v is None:
        return Element("open")
    jumper = value_text.strip().upper().rstrip("Ω").rstrip() in ("0", "0R", "0OHM", "0 OHM")
    if v == 0 and (kind_hint in ("R", "L") or jumper):  # also a 0R fitted on a capacitor footprint
        return Element("short", esl=DEFAULT_ESL["short"], esr=0.02)
    if kind_hint == "C":
        return Element("C", v, q or DEFAULT_Q["C"], f_q or 868e6, esl=DEFAULT_ESL["C"])
    if kind_hint == "L":
        return Element("L", v, q or DEFAULT_Q["L"], f_q or 868e6)
    return Element("R", v)


# ---------------------------------------------------------------------------
# network algebra
# ---------------------------------------------------------------------------
def s2y(S: np.ndarray, z0: float = 50.0) -> np.ndarray:
    I = np.eye(S.shape[-1])
    return np.linalg.solve(I + S, I - S) / z0


def y2s(Y: np.ndarray, z0: float = 50.0) -> np.ndarray:
    n = Y.shape[-1]
    I = np.eye(n)
    Yn = Y * z0
    return (I - Yn) @ np.linalg.inv(I + Yn)


@dataclass
class Circuit:
    """EM N-port + lumped parts -> reduced network."""
    freq: np.ndarray
    S_em: np.ndarray  # [f, n, n] with 50 ohm port reference
    port_names: list[str]  # node names, e.g. "C34.1"
    z0: float = 50.0
    parts: dict[str, tuple[str, str | None, Element]] = field(default_factory=dict)
    nports: dict[str, tuple[list[str], np.ndarray]] = field(default_factory=dict)

    def __post_init__(self):
        self.Y_em = s2y(self.S_em, self.z0)
        self.idx = {n: i for i, n in enumerate(self.port_names)}

    def set_part(self, ref: str, node_a: str, node_b: str | None, el: Element):
        """``node_b`` None means the second terminal is ground."""
        self.parts[ref] = (node_a, node_b, el)

    def set_nport(self, ref: str, nodes: list[str], Y: np.ndarray):
        """Ground-referenced N-port model given as Y[f, n, n] (siemens)."""
        self.nports[ref] = (nodes, Y)

    def solve(self, external: list[str], z_ref: float | list[float] = 50.0) -> np.ndarray:
        Y = self.Y_em.copy()
        for ref, (a, b, el) in self.parts.items():
            y = el.y(self.freq)
            ia = self.idx[a]
            Y[:, ia, ia] += y
            if b is not None:
                ib = self.idx[b]
                Y[:, ib, ib] += y
                Y[:, ia, ib] -= y
                Y[:, ib, ia] -= y
        for ref, (nodes, Yn) in self.nports.items():
            ii = [self.idx[n] for n in nodes]
            for r, a in enumerate(ii):
                for c, b in enumerate(ii):
                    Y[:, a, b] += Yn[:, r, c]
        # Y_em is the bare layout seen at the pads (port resistors are not part of it)
        e = [self.idx[n] for n in external]
        i = [k for k in range(len(self.port_names)) if k not in e]
        Yee = Y[:, e][:, :, e]
        if i:
            Yei = Y[:, e][:, :, i]
            Yie = Y[:, i][:, :, e]
            Yii = Y[:, i][:, :, i]
            Yred = Yee - Yei @ np.linalg.solve(Yii, Yie)
        else:
            Yred = Yee
        zr = np.broadcast_to(np.asarray(z_ref, dtype=float), (len(e),))
        F = np.diag(np.sqrt(zr))
        I = np.eye(len(e))
        A = F @ Yred @ F
        return np.linalg.solve((I + A).transpose(0, 2, 1), (I - A).transpose(0, 2, 1)).transpose(0, 2, 1)

    def input_impedance(self, node: str) -> np.ndarray:
        """Impedance seen at ``node`` with all other nodes internal (open)."""
        S = self.solve([node])
        return self.z0 * (1 + S[:, 0, 0]) / (1 - S[:, 0, 0])
