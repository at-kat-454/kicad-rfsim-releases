"""Radiating openEMS model for PCB antennas.

Contents of the model (global right-handed frame, see geom3d):
  * the whole main board: dielectric slabs from the stackup, all copper
    (antenna nets kept separate, everything else merged per layer),
  * optional sub-boards (e.g. a vertical antenna PCB from its own KiCad file)
    placed with a ``geom3d.Placement`` and soldered to their footprint pads,
  * optional metal parts from STEP/STL (wire, stamped or chip antennas),
  * one lumped feed port, PML boundaries, and an NF2FF box.

Results: Zin(f), S11, accepted / radiated power, radiation efficiency,
directivity, realised gain and the 3D far-field pattern.
"""
from __future__ import annotations

import math
import os
import shutil
import struct
import subprocess
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import unary_union

from . import mesh as meshmod
from .board import Board
from .geom3d import MAIN, Placement
from .openems_export import CU_SIGMA, EPS0, _dft, _read_probe, find_openems, split_holes

C0 = 299792458.0


# ---------------------------------------------------------------------------
@dataclass
class AntennaSettings:
    f_min: float = 0.5e9
    f_max: float = 1.5e9
    f_points: int = 201
    f_farfield: list[float] = field(default_factory=lambda: [868e6])
    f_loss: float = 868e6
    margin: float | None = None  # air margin to the PML in mm (default lambda/4 at the first far-field freq)
    max_antenna: float = 0.4  # mm, mesh inside the antenna zone
    max_board: float = 2.0  # mm, mesh on the rest of the board
    max_air: float | None = None  # mm, default lambda_min/20
    min_cell: float = 0.08  # mm
    ratio: float = 1.4
    zone_margin: float = 2.0  # mm around antenna copper
    fill_holes_below: float = 1.5  # mm^2: small holes in merged copper (via antipads) are filled
    merge_gap: float = 0.3  # mm: board copper (not antenna / RF) with gaps below this becomes one plane; 0 = off
    plane_gap: float = 1.0  # mm: outside the RF / antenna area board copper gaps up to this are closed (one plane)
    plane_hole: float = 2500.0  # mm^2: ... and enclosed non-copper areas up to this are filled (not antenna windows)
    rf_margin: float = 1.5  # mm: the RF / antenna area = antenna and RF path copper + this margin (kept exact)
    rf_path_mesh: bool = True  # fine mesh over the RF chain region(s), so the RF traces are on the mesh
    rf_cell: float | None = None  # mm, cell in the RF chain region; None = narrowest RF trace / 2 (0.1 ... max_antenna)
    feed_fill: float = 0.6  # mm: feed on a trace - the RF chain behind it is filled into ground with this margin
    feed_clear: float = 0.3  # mm: ... but never closer than this to the antenna copper
    end_criteria: float = 1e-4
    max_time_ns: float = 150.0  # run limit as simulated time (enough for Q up to ~80 at 868 MHz)
    max_timesteps: int | None = None  # explicit limit (overrides max_time_ns)
    pml_cells: int = 8
    edge_rule: str = "thirds"  # mesh at antenna copper edges: "thirds" (1/3 in, 2/3 out) or "edge"
    theta_step: float = 5.0
    phi_step: float = 5.0


@dataclass
class Feed:
    ref: str
    pad: str
    ground: str = "auto"  # "below" (vertical port to ref layer), "side" (to nearest same-layer ground), "auto"
    ref_layer: str = "In1.Cu"
    R: float = 50.0
    # feed on the antenna trace (pipeline.trace_feed): {x, y, layer, net, dir, width, gap} in KiCad mm.
    # ref / pad then name the last matching pad; everything behind the feed point becomes ground.
    trace: dict | None = None


@dataclass
class SubBoard:
    board: Board
    placement: Placement
    name: str = "sub"
    solder_to: str | None = None  # main footprint ref whose pads are soldered to this board
    input_pad: str | None = None  # "REF.PAD" on this board joined to the antenna feed pad of the main board
    feed_pad: str | None = None  # number of the main footprint's feed pad (set by the model from the Feed)


@dataclass
class MetalPart:
    stl: Path  # already in global frame (mm)
    name: str = "part"


# ---------------------------------------------------------------------------
def side_port(board, layer: str, pd, ground: str, hs: float, reach: float = 3.0, near: float = 4.0):
    """Place a horizontal feed port from the feed net copper to ``ground`` (KiCad coordinates).

    The port is a straight strip of width 2*hs (narrowed down to 0.1 mm if needed). It starts on the
    edge of the feed pad or of the trace connected to it (within ``near`` mm of the pad) and ends on
    ground copper. The strip must not overlap any copper on its way: a port drawn across the feed
    trace itself would short the antenna. Best = shortest gap plus distance from the pad.
    Returns (axis, start(x, y), end(x, y), gap, distance from pad, width) or None.
    """
    from shapely.geometry import LineString, box
    from shapely.prepared import prep

    padg = pd.polygon()
    region = padg.buffer(near + reach)
    items = [(n, g) for n, g in board.copper(layer) if g is not None and not g.is_empty and g.intersects(region)]
    gnd = unary_union([g for n, g in items if n == ground]) if any(n == ground for n, _ in items) else None
    if gnd is None or gnd.is_empty:
        return None
    net = unary_union([g for n, g in items if pd.net and n == pd.net] + [padg]).buffer(0)
    if net.geom_type == "MultiPolygon":  # only the copper connected to the pad
        net = unary_union([p for p in net.geoms if p.intersects(padg.buffer(1e-3))])
    others = unary_union([g for n, g in items if n != ground and n != pd.net] or [Polygon()])
    obst = unary_union([net, others])
    p_net, p_gnd = prep(net.buffer(1e-4)), prep(gnd.buffer(5e-3))
    zone = net.intersection(padg.buffer(near))
    pts = []
    for poly in getattr(zone, "geoms", [zone]):
        if poly.geom_type != "Polygon":
            continue
        for ring in [poly.exterior, *poly.interiors]:
            pts.extend(ring.segmentize(0.05).coords)
    best = None
    for px, py in pts:
        for axis in (0, 1):
            for d in (-1.0, 1.0):
                for w in (2 * hs, hs, 0.1):
                    if w > 2 * hs + 1e-9 or w < 0.1 - 1e-9:
                        continue

                    def at(a, o, px=px, py=py, axis=axis):  # a along the port axis, o across it
                        return Point(px + a, py + o) if axis == 0 else Point(px + o, py + a)
                    eps = 0.01
                    if not all(p_net.contains(at(-d * eps, o)) for o in (0.0, -0.45 * w, 0.45 * w)):
                        continue
                    if p_net.contains(at(d * eps, 0.0)):
                        continue  # not an outward edge
                    hits = []  # first ground hit of the centre and both edges of the strip
                    for o in (0.0, -0.45 * w, 0.45 * w):
                        ray = LineString([at(0, o).coords[0], at(d * reach, o).coords[0]])
                        inter = ray.intersection(gnd)
                        if inter.is_empty:
                            break
                        hits.append(at(0, o).distance(inter))
                    if len(hits) < 3:
                        continue
                    gap = max(hits)  # the port reaches ground over its full width (may end inside it)
                    if min(hits) < 0.02:
                        continue
                    a0, a1 = sorted((d * 0.005, d * (gap - 0.005)))
                    if axis == 0:
                        strip = box(px + a0, py - w / 2, px + a1, py + w / 2)
                    else:
                        strip = box(px - w / 2, py + a0, px + w / 2, py + a1)
                    if strip.intersection(obst).area > 1e-5:
                        continue  # crosses the feed trace or other copper
                    if not all(p_gnd.contains(at(d * (gap + eps), o)) for o in (-0.45 * w, 0.45 * w)):
                        continue
                    dist = Point(px, py).distance(padg)
                    score = gap + dist + (0.0 if w >= hs - 1e-9 else 0.4) + (0.0 if w >= 0.2 else 0.4)  # narrow ports: tiny cells
                    if best is None or score < best[0] - 1e-9:
                        end = at(d * gap, 0)
                        best = (score, (axis, (px, py), (end.x, end.y), gap, dist, w))
                    break
    return best[1] if best else None


def merge_gaps(geom, gap: float, keep=None):
    """Board copper outside the RF / antenna copper: close gaps narrower than ``gap`` (clearances
    around non-RF traces, slivers) so the rest of the board becomes a plain plane. Nothing is added
    within ``gap`` of ``keep`` (antenna / RF copper), so RF clearances stay exactly as drawn."""
    if geom.is_empty:
        return geom
    from shapely.geometry import JOIN_STYLE
    closed = geom.buffer(gap / 2, join_style=JOIN_STYLE.mitre).buffer(-gap / 2, join_style=JOIN_STYLE.mitre)
    added = closed.difference(geom)
    if keep is not None and not keep.is_empty:
        added = added.difference(keep.buffer(gap))
    return unary_union([geom, added]).buffer(0).simplify(0.01)


def plane_outside(geom, area, gap: float, hole: float, small: float = 25.0):
    """Board copper outside the RF / antenna ``area`` as plain planes: gaps up to ``gap`` closed
    (traces, pads and their clearances inside a copper pour become pour) and enclosed non-copper
    areas up to ``hole`` mm^2 filled (antipads, mounting holes, cut-outs under switching converters,
    plane splits). A hole that reaches into ``area`` (the ground-free window of a printed antenna)
    stays, unless it is a small antipad (< ``small`` mm^2), which is filled outside ``area`` only.
    Copper is only added where it pours already: an area without a copper fill keeps its traces.
    Inside ``area`` the copper stays exactly as drawn."""
    if geom.is_empty:
        return geom
    from shapely.geometry import JOIN_STYLE
    closed = geom.buffer(gap / 2, join_style=JOIN_STYLE.mitre).buffer(-gap / 2, join_style=JOIN_STYLE.mitre)
    closed = _fill_small_holes(closed, small)
    closed = _fill_small_holes(closed, max(hole, small), keep=area)
    added = closed.difference(geom).difference(area)
    if added.is_empty:
        return geom
    out = unary_union([geom, added]).buffer(1e-4, join_style=JOIN_STYLE.mitre).buffer(-1e-4, join_style=JOIN_STYLE.mitre)
    return _fill_small_holes(out, 1e-3).simplify(0.01)  # seams of the union: zero-area slits


def _fill_small_holes(geom, max_area: float, keep=None):
    out = []
    for p in getattr(geom, "geoms", [geom]):
        if not isinstance(p, Polygon):
            continue
        holes = []
        for r in p.interiors:
            h = Polygon(r)
            if h.area >= max_area or (keep is not None and h.intersects(keep)):
                holes.append(r)
        out.append(Polygon(p.exterior, holes))
    return unary_union(out)


class AntennaModel:
    def __init__(self, main: Board, feed: Feed, antenna_nets: list[str], settings: AntennaSettings | None = None,
                 subboards: list[SubBoard] | None = None, metal_parts: list[MetalPart] | None = None,
                 ground: str = "GND", lumped: dict | None = None, zones: list | None = None,
                 bodies: list[dict] | None = None, rf_nets: list[str] | None = None):
        """``lumped``: ref -> {kind, value, esr, esl}: parts on the main board as lumped elements (whole-board
        wave run); ``zones``: extra fine-mesh areas (x0, y0, x1, y1) in board coordinates (e.g. the RF chain)."""
        self.main = main
        self.feed = feed
        self.antenna_nets = list(antenna_nets)
        self.rf_nets = [n for n in (rf_nets or []) if n not in self.antenna_nets]  # RF chain: kept exact
        self.s = settings or AntennaSettings()
        self.subs = subboards or []
        self.parts = metal_parts or []
        self.bodies = bodies or []  # casing parts (enclosure.prepare): dielectric / metal volumes
        self.ground = ground
        self.sheets: list[dict] = []  # {name, axis, elev, poly(2D in plane axes), thickness}
        self.slabs: list[dict] = []  # dielectric LinPoly
        self.cyls: list[tuple] = []  # (name, p0, p1, r)
        self.boxes: list[tuple] = []  # metal boxes (solder joints): (name, lo, hi)
        self.zones: list[tuple[np.ndarray, np.ndarray]] = []  # fine mesh zones (lo, hi)
        self.fixed: list[set] = [set(), set(), set()]
        self.planes: list[set] = [set(), set(), set()]  # plate surfaces that must stay on distinct mesh lines
        self.bridge: list[set] = [set(), set(), set()]  # clearance lines against mesh shorts: never dropped
        self.notes: list[str] = []
        self._build_plate(main, MAIN, "main", self.antenna_nets)
        for sb in self.subs:
            self._build_plate(sb.board, sb.placement, sb.name, None)
            if sb.solder_to:
                if sb.solder_to == feed.ref:
                    sb.feed_pad = feed.pad
                elif feed.trace:  # fed on the trace before the antenna board: its pad on the antenna net
                    try:
                        sb.feed_pad = next(pd.number for pd in main.footprint(sb.solder_to).pads
                                           if pd.net == feed.trace.get("net"))
                    except (KeyError, StopIteration):
                        pass
                self._solder(sb)
        for mp in self.parts:
            lo, hi = _stl_bounds(mp.stl)
            self.zones.append((lo, hi))
        for bd in self.bodies:  # wall faces as fixed mesh lines
            for ax in range(3):
                self.fixed[ax] |= {round(float(v), 4) for v in bd["faces"][ax]}
        from .openems_export import lumped_geometry
        self.lumped = lumped_geometry(main, lumped or {}, self._cu_z(main))
        for lm in self.lumped:
            x0, y0, x1, y1 = lm["box"]
            self.fixed[0] |= {round(x0, 4), round(x1, 4)}
            self.fixed[1] |= {round(-y1, 4), round(-y0, 4)}
            self.zones.append((np.array([x0 - 0.5, -y1 - 0.5, lm["z"] - 0.5]), np.array([x1 + 0.5, -y0 + 0.5, lm["z"] + 0.5])))
        for z in zones or []:  # (x0, y0, x1, y1[, cell]) in board coordinates
            x0, y0, x1, y1 = z[:4]
            zz = (np.array([x0, -y1, -main.stackup.thickness]), np.array([x1, -y0, 0.0]))
            self.zones.append(zz + ((float(z[4]), "xy") if len(z) > 4 and z[4] else ()))  # cell given: in x, y only
        self._feed()
        self._mesh()
        self._fix_mesh_bridges()
        self._check_mesh()

    # ------------------------------------------------------------------ mesh check
    def mesh_problems(self) -> list[str]:
        """What openEMS would drop silently: a copper plane of the main board or a feed port end that
        lies on no mesh line. A plane without its line is snapped into the dielectric, a port without
        its lines is not excited at all (the run then computes nothing for hours)."""
        tol = 1e-4  # mm; fixed lines are rounded to 1e-5 mm, every cell is far larger
        L = [np.asarray(l) for l in self.lines]

        def on(ax, v):
            return bool(len(L[ax]) and np.min(np.abs(L[ax] - v)) < tol)
        out = []
        for ax in range(3):
            d = np.diff(L[ax])
            if len(d) and float(d.min()) <= 1e-6:
                k = int(np.argmin(d))
                out.append(f"zero-width cell on {'xyz'[ax]} at {L[ax][k]:.4f} mm")
        for layer, z in self._cu_z(self.main).items():
            if not on(2, z):
                out.append(f"copper layer {layer} (z = {z:.4f} mm) has no mesh line")
        st, sp, ax = self.port["start"], self.port["stop"], self.port["axis"]
        for nm, p in (("ground", st), ("feed", sp)):
            if not on(ax, p[ax]):
                out.append(f"port {nm} end ({'xyz'[ax]} = {p[ax]:.4f} mm) has no mesh line")
        for k in range(3):
            if k == ax:
                continue
            a, b = sorted((st[k], sp[k]))
            if b - a < tol:
                if not on(k, a):
                    out.append(f"port plane ({'xyz'[k]} = {a:.4f} mm) has no mesh line")
            elif not np.any((L[k] >= a - tol) & (L[k] <= b + tol)):
                out.append(f"no mesh line across the port width ({'xyz'[k]} {a:.3f} .. {b:.3f} mm)")
        return out

    def _check_mesh(self):
        bad = self.mesh_problems()
        if bad:
            raise ValueError("the mesh would drop parts of the model - " + "; ".join(bad)
                             + ". Change min_cell a little (e.g. 0.1 mm) and report this case.")

    # ------------------------------------------------------------------ mesh bridges
    def _mesh_bridges(self):
        """Places where the FDTD mesh joins the feed copper to other copper that is separate on the board.

        openEMS makes a mesh edge metal when its midpoint lies in the copper. An edge that spans a
        narrow clearance (feed trace or matching pad next to the ground pour) therefore bridges it, and
        the port is shorted although the drawing is fine. The main-board copper planes are rasterised that
        way around the feed copper; vias join the planes. Returns [(axis, coordinate)] of the copper
        boundaries that need a mesh line, and the bridged points."""
        import shapely
        from shapely.geometry import box as sbox
        xs, ys, zs = (np.asarray(l) for l in self.lines)
        planes: dict[float, list] = {}
        groups: dict[tuple, list] = {}
        for sh in self.sheets:
            if sh["name"].startswith("main:") and sh["axis"] == 2:
                planes.setdefault(round(sh["elev"], 6), []).append(sh["poly"])
                # antenna copper and board copper are separate pieces even where they touch (the short of
                # an inverted F lies on the ground): a DC-grounded antenna is checked too
                groups.setdefault((round(sh["elev"], 6), sh["name"]), []).append(sh["poly"])
        pieces = []  # (plane elevation, polygon)
        for (e, _nm), ps in groups.items():
            u = unary_union(ps).buffer(0)
            pieces += [(e, p) for p in getattr(u, "geoms", [u]) if p.geom_type == "Polygon" and not p.is_empty]
        if not pieces:
            return [], []
        parent = list(range(len(pieces)))

        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a
        vias = [(n, p0, p1, r) for n, p0, p1, r in self.cyls if n.startswith("main:")
                and abs(p0[0] - p1[0]) < 1e-9 and abs(p0[1] - p1[1]) < 1e-9]
        via_piece = []
        for n, p0, p1, r in vias:
            z0, z1 = sorted((p0[2], p1[2]))
            c = Point(p0[0], p0[1]).buffer(max(r, 1e-3))
            hit = [k for k, (e, p) in enumerate(pieces) if z0 - 1e-6 <= e <= z1 + 1e-6 and p.intersects(c)]
            for a, b in zip(hit, hit[1:]):
                parent[find(a)] = find(b)
            via_piece.append(hit[0] if hit else None)
        st, sp = self.port["start"], self.port["stop"]

        def piece_at(pt, z):
            q = Point(pt[0], pt[1]).buffer(0.01)
            return next((k for k, (e, p) in enumerate(pieces) if abs(e - z) < 1e-6 and p.intersects(q)), None)
        ax_p = self.port["axis"]
        mid = (st + sp) / 2  # the port's centre line: its ends lie on the feed and on the ground copper
        pf, pg = mid.copy(), mid.copy()
        pf[ax_p], pg[ax_p] = sp[ax_p], st[ax_p]
        kf = piece_at(pf, pf[2])
        kg = piece_at(pg, pg[2])
        if kf is None or kg is None or find(kf) == find(kg):
            return [], []  # nothing to check
        gnd = find(kg)
        # Copper that must stay separate from the ground on the mesh: the feed copper, the antenna copper
        # and the copper at both ends of the lumped parts (a 0R or a matching part between the feed
        # trace and the antenna makes the antenna part of the feed path).
        prot = {find(kf)}
        ant_polys = [sh["poly"] for sh in self.sheets if sh["name"].startswith("main:") and sh.get("antenna")]
        if ant_polys:
            ua = unary_union(ant_polys).buffer(-1e-4)
            prot |= {find(k) for k, (e, p) in enumerate(pieces) if p.intersects(ua)}
        for lm in self.lumped:
            x0, y0, x1, y1 = lm["box"]
            ends = ([(x0, -(y0 + y1) / 2), (x1, -(y0 + y1) / 2)] if lm["axis"] == 0
                    else [((x0 + x1) / 2, -y0), ((x0 + x1) / 2, -y1)])
            for pt in ends:
                k = piece_at(pt, lm["z"])
                if k is not None:
                    prot.add(find(k))
        prot.discard(gnd)
        if not prot:
            return [], []
        fb = unary_union([p for k, (e, p) in enumerate(pieces) if find(k) in prot]).bounds
        roi = sbox(fb[0] - 1.0, fb[1] - 1.0, fb[2] + 1.0, fb[3] + 1.0)
        i0, i1 = np.searchsorted(xs, [roi.bounds[0], roi.bounds[2]])
        j0, j1 = np.searchsorted(ys, [roi.bounds[1], roi.bounds[3]])
        X, Y = xs[max(0, i0 - 1):i1 + 1], ys[max(0, j0 - 1):j1 + 1]
        if len(X) < 2 or len(Y) < 2:
            return [], []
        mx, my = (X[:-1] + X[1:]) / 2, (Y[:-1] + Y[1:]) / 2
        node: dict[tuple, set] = {}  # node -> pieces whose metal edges end there
        edges: dict[tuple, list] = {}  # node -> [(axis, a, b, fixed coordinate, piece)]
        near = [k for k, (e, p) in enumerate(pieces) if p.intersects(roi)]
        touch = {}  # copper that really touches (the short of an inverted F): where it touches
        for a in near:
            for b in near:
                if a < b and pieces[a][0] == pieces[b][0] and pieces[a][1].distance(pieces[b][1]) < 1e-6:
                    touch[(a, b)] = pieces[a][1].buffer(1e-4).intersection(pieces[b][1].buffer(1e-4))
        for k, (e, p) in enumerate(pieces):
            if not p.intersects(roi):
                continue
            c = k
            g = p.buffer(1e-6)
            ex = shapely.contains_xy(g, *np.meshgrid(mx, Y, indexing="ij"))
            ey = shapely.contains_xy(g, *np.meshgrid(X, my, indexing="ij"))
            for i, j in zip(*np.nonzero(ex)):
                for nd in ((e, i, j), (e, i + 1, j)):
                    node.setdefault(nd, set()).add(c)
                    edges.setdefault(nd, []).append((0, X[i], X[i + 1], Y[j], k))
            for i, j in zip(*np.nonzero(ey)):
                for nd in ((e, i, j), (e, i, j + 1)):
                    node.setdefault(nd, set()).add(c)
                    edges.setdefault(nd, []).append((1, Y[j], Y[j + 1], X[i], k))
        for (n, p0, p1, r), kp in zip(vias, via_piece):  # via axes on their mesh nodes
            if kp is None:
                continue
            q0, _q1 = self._axis_on_mesh(n, p0, p1)
            if q0 is None:
                continue
            i, j = int(np.argmin(abs(X - q0[0]))), int(np.argmin(abs(Y - q0[1])))
            if abs(X[i] - q0[0]) > 1e-6 or abs(Y[j] - q0[1]) > 1e-6:
                continue
            z0, z1 = sorted((p0[2], p1[2]))
            for e in planes:
                if z0 - 1e-6 <= e <= z1 + 1e-6:
                    node.setdefault((e, i, j), set()).add(kp)

        def joins(nd, ks):  # two copper pieces that are separate on the board meet at this node
            ks = sorted(ks)
            i, j = nd[1], nd[2]
            cell = max(abs(X[min(i + 1, len(X) - 1)] - X[max(i - 1, 0)]), abs(Y[min(j + 1, len(Y) - 1)] - Y[max(j - 1, 0)]))
            for n_, a in enumerate(ks):
                for b in ks[n_ + 1:]:
                    if find(a) == find(b) or not (find(a) in prot or find(b) in prot):
                        continue
                    t = touch.get((a, b))
                    if t is not None and t.distance(Point(X[i], Y[j])) <= cell:
                        continue  # where the copper really touches
                    return True
            return False
        need, spots = set(), []
        for nd, cs in node.items():
            if len(cs) > 1 and joins(nd, cs):
                spots.append((float(X[nd[1]]), float(-Y[nd[2]]), nd[0]))
                for ax, a, b, o, k in edges.get(nd, []):
                    seg = LineString([(a, o), (b, o)]) if ax == 0 else LineString([(o, a), (o, b)])
                    cut = seg.intersection(pieces[k][1].boundary)
                    for q in getattr(cut, "geoms", [cut]):
                        if q.is_empty:
                            continue
                        for cx, cy in q.coords:
                            v = cx if ax == 0 else cy
                            if min(a, b) + 1e-6 < v < max(a, b) - 1e-6:
                                need.add((ax, round(float(v), 4)))
        return sorted(need), spots

    def _fix_mesh_bridges(self, rounds: int = 6):
        """Mesh lines on the copper boundaries where the mesh bridges the feed copper (see _mesh_bridges)."""
        added = 0
        for _ in range(rounds):
            need, spots = self._mesh_bridges()
            if not spots:
                break
            new = 0
            # first only where no mesh line is near (few extra cells); if that adds nothing and the mesh
            # still joins the copper, also next to a nearby line: on a narrow clearance a line 0.03 mm
            # off the copper edge still lets the mesh join the copper
            for near in (self.fixed, self.bridge):
                for ax, v in need:
                    if any(abs(v - w) < (0.04 if near is self.fixed else 0.03) for w in near[ax]):
                        continue
                    self.fixed[ax].add(v)
                    self.bridge[ax].add(v)  # never dropped when merging (but they do not set the merge distance)
                    new += 1
                if new:
                    break
            if not new:
                break
            added += new
            self._mesh()
        else:
            need, spots = self._mesh_bridges()
        if added:
            self.notes.append(f"mesh: {added} lines added at clearances where the mesh joined the feed or antenna copper to "
                              f"other copper")
        if spots:
            where = ", ".join(f"({x:.2f}, {y:.2f})" for x, y, _z in spots[:3])
            self.notes.append(f"WARNING mesh: feed or antenna copper still touches other copper on the mesh near {where} "
                              f"(board mm) - the feed may be shorted; lower min_cell or max_antenna")

    # ------------------------------------------------------------------ plates
    def _cu_z(self, b: Board) -> dict[str, float]:
        z, out = 0.0, {}
        for l in b.stackup.layers:
            if l.kind == "copper":
                out[l.name] = z
            elif l.kind == "dielectric":
                z -= l.thickness
        return out

    def _to_plane(self, pl: Placement, poly: Polygon, z_local: float):
        """Map a local planar polygon to (axis, elevation, polygon in the plane's 2 axes)."""
        n = pl.normal_axis()
        a1, a2 = (n + 1) % 3, (n + 2) % 3
        pts = np.array([[x, y, z_local] for x, y in poly.exterior.coords])
        g = pl.apply(pts)
        elev = float(g[0, n])
        return n, elev, Polygon(list(zip(g[:, a1], g[:, a2])))

    def _build_plate(self, b: Board, pl: Placement, name: str, antenna_nets):
        czs = self._cu_z(b)
        outline = b.outline()
        whole = antenna_nets is None  # sub-board: everything counts as antenna (fine mesh)
        keep = None
        ant_geoms = []
        rf_area = None
        if not whole:
            # RF / antenna area: antenna copper, RF chain copper and the feed pad on any layer, plus a
            # margin - kept as drawn. Outside it the board copper becomes plain planes (below).
            prot = [g for lay in czs for n, g in b.copper(lay) if n in (antenna_nets or []) or n in self.rf_nets]
            try:
                fp = b.footprint(self.feed.ref)
                prot += [Polygon([(pd.x - pd.size[0] / 2, pd.y - pd.size[1] / 2), (pd.x + pd.size[0] / 2, pd.y - pd.size[1] / 2),
                                  (pd.x + pd.size[0] / 2, pd.y + pd.size[1] / 2), (pd.x - pd.size[0] / 2, pd.y + pd.size[1] / 2)])
                         for pd in fp.pads]
            except KeyError:
                pass
            if prot:
                keep_all = unary_union(prot).buffer(0)
                rf_area = keep_all.buffer(self.s.rf_margin)
        cut = self._trace_cut(b, czs) if (not whole and self.feed.trace) else None
        for layer, zl in czs.items():
            items = b.copper(layer)
            if cut is not None:
                items = self._apply_trace_cut(items, layer, cut)
            groups: dict[str, list] = {}
            for net, g in items:
                key = net if (whole or net in (antenna_nets or [])) else "__board__"
                groups.setdefault(key, []).append(g)
            if not whole and antenna_nets:
                keep = unary_union([g for k, gs in groups.items() if k != "__board__" for g in gs]) if len(groups) > 1 else None
                rf = [g for n, g in items if n in self.rf_nets]
                if rf:  # RF chain traces: their clearances are never merged into the plane
                    keep = unary_union(([keep] if keep is not None else []) + rf)
            for key, gs in groups.items():
                u = unary_union(gs).buffer(0)
                if key == "__board__" and self.s.fill_holes_below > 0:
                    u = _fill_small_holes(u, self.s.fill_holes_below, keep)
                if key == "__board__" and self.s.merge_gap > 0:
                    u = merge_gaps(u, self.s.merge_gap, keep)
                if key == "__board__" and rf_area is not None and self.s.plane_gap > 0:
                    u = plane_outside(u, rf_area, self.s.plane_gap, self.s.plane_hole)
                if outline is not None:
                    u = u.intersection(outline.buffer(0.01))
                tag = f"{name}:{layer}:{'board' if key == '__board__' else key}"
                for p in split_holes(u):
                    axis, elev, pp = self._to_plane(pl, p, zl)
                    self.sheets.append({"name": tag, "axis": axis, "elev": elev, "poly": pp,
                                        "t": b.stackup.layer(layer).thickness, "antenna": key != "__board__"})
                    if key != "__board__":
                        ant_geoms.append(p)
                        self._edges(pp, axis)
                zg = round(float(pl.apply(np.array([[0, 0, zl]]))[0, pl.normal_axis()]), 6)
                self.fixed[pl.normal_axis()].add(zg)
                self.planes[pl.normal_axis()].add(zg)
        # dielectric slabs
        if outline is not None:
            z = 0.0
            for l in b.stackup.layers:
                if l.kind != "dielectric":
                    continue
                zt, zb = z, z - l.thickness
                z = zb
                for part in split_holes(outline):
                    n, e1, pp = self._to_plane(pl, part, zt)
                    _, e2, _ = self._to_plane(pl, part, zb)
                    self.slabs.append({"name": f"{name}:{l.name}", "axis": n, "elev": min(e1, e2),
                                       "len": abs(e1 - e2), "poly": pp, "er": l.epsilon_r or 4.5,
                                       "tand": l.loss_tangent or 0.0})
                    self.fixed[n] |= {round(e1, 6), round(e2, 6)}
                    self.planes[n] |= {round(e1, 6), round(e2, 6)}
        # vias (plated barrel as metal cylinder through the full span)
        order = b._ordered_copper()
        for v in b.vias:
            z0, z1 = czs[v.layers[0]], czs[v.layers[1]]
            p = pl.apply(np.array([[v.x, v.y, z0], [v.x, v.y, z1]]))
            is_ant = whole or v.net in (antenna_nets or [])
            self.cyls.append((f"{name}:via{'_ant' if is_ant else ''}", p[0], p[1], v.drill / 2))
            if is_ant:
                n = pl.normal_axis()
                for ax in range(3):
                    if ax != n:
                        self.fixed[ax].add(round(float(p[0, ax]), 6))
        # through-hole pads: barrels too (pins of vertical boards, connectors)
        for f in b.footprints:
            for pd in f.pads:
                if pd.kind == "thru_hole" and pd.drill > 0:
                    p = pl.apply(np.array([[pd.x, pd.y, 0.0], [pd.x, pd.y, czs[order[-1]]]]))
                    self.cyls.append((f"{name}:pth", p[0], p[1], pd.drill / 2))
        if ant_geoms:
            g = unary_union(ant_geoms)
            x0, y0, x1, y1 = g.bounds
            corners = []
            for (x, y) in ((x0, y0), (x1, y1), (x0, y1), (x1, y0)):
                for zl in czs.values():
                    corners.append(pl.apply(np.array([[x, y, zl]]))[0])
            c = np.array(corners)
            self.zones.append((c.min(0), c.max(0)))

    def _edges(self, poly: Polygon, axis: int):
        """Fixed mesh lines at axis-aligned antenna copper edges (1/3-2/3 rule by default)."""
        from .openems_export import _metal_side, edge_lines
        a1, a2 = (axis + 1) % 3, (axis + 2) % 3
        h = self.s.max_antenna
        c = list(poly.exterior.coords)
        for (u0, v0), (u1, v1) in zip(c, c[1:]):
            if abs(u0 - u1) < 1e-4 and abs(v0 - v1) > 0.3:
                side = _metal_side(poly, u0, (v0 + v1) / 2, 0)
                for x in edge_lines([(u0, side)], self.s.edge_rule, h):
                    self.fixed[a1].add(round(x, 4))
            if abs(v0 - v1) < 1e-4 and abs(u0 - u1) > 0.3:
                side = _metal_side(poly, (u0 + u1) / 2, v0, 1)
                for x in edge_lines([(v0, side)], self.s.edge_rule, h):
                    self.fixed[a2].add(round(x, 4))

    def _solder(self, sb: SubBoard):
        """Solder joints between the main footprint's pads and the sub-board copper standing on them.

        Each joint is a metal block that fills the corner between the main pad and the sub-board face
        like the solder fillet does: across the pad, from the pad to the board face, and up the face
        until it overlaps the sub-board copper (at least 0.5 mm into it) - so the two coppers are one
        conductor on any mesh. With ``input_pad`` the main feed pad is joined to exactly that pad of the
        sub-board, over the whole pad (direct connection, also across a placement error up to 5 mm);
        the other pads (numbered or mechanical) join the nearest copper not on the input pad's net."""
        fp = self.main.footprint(sb.solder_to)
        sub_sheets = [s for s in self.sheets if s["name"].startswith(sb.name + ":")]
        in_net, in_poly = None, None
        if sb.input_pad:
            r, _, num = sb.input_pad.partition(".")
            ip = sb.board.footprint(r).pad(num)
            in_net = ip.net or None
            in_poly = ip.polygon()
        from shapely.geometry import Polygon as _P
        from shapely.geometry import box as _box
        for k, pd in enumerate(fp.pads):
            if not (pd.on_layer("F.Cu") or pd.kind == "thru_hole"):
                continue
            px, py = pd.x, -pd.y
            x0, y0, x1, y1 = pd.polygon().bounds
            lo = np.array([x0, -y1, 0.0])
            hi = np.array([x1, -y0, 0.0])
            is_feed = sb.input_pad is not None and bool(pd.number) and pd.number == sb.feed_pad
            limit = 5.0 if is_feed else 1.0
            best = None
            for s in sub_sheets:
                n = s["axis"]
                if n == 2:
                    continue  # horizontal sub-board copper does not stand on the pad
                net = s["name"].split(":", 2)[2]
                if in_net is not None and (net == in_net) != is_feed:
                    continue  # feed pad only to the input pad's copper, other pads never to it
                a1, a2 = (n + 1) % 3, (n + 2) % 3
                pt = {0: px, 1: py, 2: 0.0}
                d_plane = max(0.0, lo[n] - s["elev"], s["elev"] - hi[n])  # pad edge to the board face
                if is_feed and in_poly is not None:  # the input pad itself on this sheet
                    loc = sb.placement.apply(np.array([[c[0], c[1], 0.0] for c in in_poly.exterior.coords]))
                    region = _P(list(zip(loc[:, a1], loc[:, a2]))).buffer(0.05).intersection(s["poly"].buffer(0.05))
                else:  # sheet copper next to the pad: within the pad's width, up to 5 mm above / below
                    lo_ab = [lo[a1] - 0.3, lo[a2] - 0.3]
                    hi_ab = [hi[a1] + 0.3, hi[a2] + 0.3]
                    for q, ax in enumerate((a1, a2)):
                        if ax == 2:
                            lo_ab[q], hi_ab[q] = -5.0, 5.0
                    region = s["poly"].intersection(_box(lo_ab[0], lo_ab[1], hi_ab[0], hi_ab[1]))
                if region.is_empty:
                    continue
                d = d_plane + region.distance(Point(pt[a1], pt[a2]))
                if best is None or d < best[0]:
                    best = (d, s, region)
            name = pd.number or f"m{k}"
            if best is None or best[0] > limit:
                if pd.number:
                    what = f"input pad {sb.input_pad}" if is_feed else "sub-board copper"
                    self.notes.append(f"{sb.name}: no {what} within {limit:g} mm of {fp.ref}.{pd.number}")
                continue
            s, region = best[1], best[2]
            n = s["axis"]
            a1, a2 = (n + 1) % 3, (n + 2) % 3
            zq = 0 if a1 == 2 else 1  # which plane coordinate is z
            hq = 1 - zq
            hax = (a1, a2)[hq]  # horizontal axis in the sheet plane
            rb = region.bounds  # (u0, v0, u1, v1) in (a1, a2)
            cz0, cz1 = rb[zq], rb[zq + 2]
            ch0, ch1 = rb[hq], rb[hq + 2]
            lo2, hi2 = lo.copy(), hi.copy()
            lo2[n] = min(lo[n], s["elev"])
            hi2[n] = max(hi[n], s["elev"])
            if is_feed:  # the whole input pad and the gap to it: one piece of copper
                lo2[hax] = min(lo2[hax], ch0)
                hi2[hax] = max(hi2[hax], ch1)
                lo2[2] = min(0.0, cz0)
                hi2[2] = max(0.5, cz1)
            else:  # fillet: up the face until 0.5 mm into the copper there
                lo2[2] = min(0.0, cz0)
                hi2[2] = max(0.5, min(cz0 + 0.6, cz1))
            for ax in range(3):  # mesh lines on the faces: the joint is never thinner than one cell
                self.fixed[ax] |= {round(float(lo2[ax]), 4), round(float(hi2[ax]), 4)}
            if is_feed:
                gap = best[0]
                self.notes.append(f"{sb.name}: feed {fp.ref}.{pd.number} and input pad {sb.input_pad} joined as one "
                                  f"copper piece ({hi2[2] - lo2[2]:.1f} mm high)"
                                  + (f" across {gap:.1f} mm - check the antenna board placement" if gap > 1.0 else ""))
            self.boxes.append((f"{sb.name}:solder_{name}", lo2, hi2))

    # ------------------------------------------------------------------ feed on a trace
    def _trace_cut(self, b: Board, czs: dict) -> dict:
        """Geometry of a feed on the antenna trace: the port gap (axis-aligned box across the trace),
        the antenna side of the cut net and the area behind the feed that becomes ground: the cut-off
        stub, the RF chain copper and the pads of the parts on it, with their clearances."""
        from shapely.geometry import box as sbox
        tr = self.feed.trace
        net, lay = tr["net"], tr["layer"]
        ux, uy = tr["dir"]
        axis = 0 if abs(ux) >= abs(uy) else 1
        g, w = float(tr["gap"]), float(tr["width"])
        x, y = float(tr["x"]), float(tr["y"])
        half = [g / 2, w + g] if axis == 0 else [w + g, g / 2]
        gapbox = sbox(x - half[0], y - half[1], x + half[0], y + half[1])
        cu = unary_union([gg for n, gg in b.copper(lay) if n == net]).buffer(0)
        rest = cu.difference(gapbox)
        probe = Point(x + ux * (g / 2 + 0.05), y + uy * (g / 2 + 0.05))
        pieces = [p for p in getattr(rest, "geoms", [rest]) if not p.is_empty]
        ant = next((p for p in pieces if p.buffer(1e-3).contains(probe)), None)
        if ant is None:
            raise ValueError(f"feed point ({x:.2f}, {y:.2f}): the antenna trace of {net} is not found behind it")
        # behind the feed: only the piece the selected segment starts in (stub + last matching pad and
        # what is connected to it on this layer). Other pieces of the net (meander parts joined through
        # vias on another layer) stay antenna.
        seg = tr.get("segment")
        start = Point(*seg[0]) if seg else Point(x - ux * (g / 2 + 0.05), y - uy * (g / 2 + 0.05))
        behind = unary_union([p for p in pieces if p is not ant and p.distance(start) < max(w, 0.1)]) \
            if len(pieces) > 1 else Polygon()
        self._trace_ant_pieces = [p for p in pieces if p is ant or p.distance(start) >= max(w, 0.1)]
        # parts whose pads sit on the cut-off stub or on the RF chain: their pads become ground too
        rfn = set(self.rf_nets)
        part_pads = []
        for f in b.footprints:
            on = [pd for pd in f.pads if pd.net in rfn or (pd.net == net and pd.on_layer(lay)
                                                         and pd.polygon().intersects(behind.buffer(1e-3)))]
            if on:
                part_pads += [(pd, pd.polygon()) for pd in f.pads]
        # the filled ground never comes closer to the antenna than the board's own ground did
        gnd_now = [gg for n, gg in b.copper(lay) if n == self.ground]
        d_real = min((ant.distance(gg) for gg in gnd_now), default=1.0)
        self._trace_clear = max(self.s.feed_clear, min(d_real, 1.0))
        fill = {}
        for layer in czs:
            src = [gg for n, gg in b.copper(layer) if n in rfn]
            src += [pg for pd, pg in part_pads if pd.on_layer(layer)]
            if layer == lay and not behind.is_empty:
                src.append(behind)
            if src:
                fill[layer] = unary_union(src).buffer(self.s.feed_fill, join_style=2)
        self.notes.append(f"feed: on the {net} trace at ({x:.2f}, {y:.2f}) mm, port gap {g:.2f} mm along "
                          f"{'xy'[axis]}; the RF chain behind the feed is ground in this model")
        antu = unary_union(self._trace_ant_pieces)
        return {"net": net, "layer": lay, "gapbox": gapbox, "ant": antu, "fill": fill, "axis": axis,
                "x": x, "y": y, "g": g, "w": w, "dir": (ux, uy), "clear": self._trace_clear, "behind": behind}

    def _apply_trace_cut(self, items, layer: str, cut: dict):
        """Copper of one layer with the trace feed applied: the antenna net keeps only the antenna side
        on the feed layer, the RF chain behind the feed is merged into the ground (net of the plane)."""
        net = cut["net"]
        gnd = self.ground
        keep_off = cut["ant"].buffer(max(cut["clear"], cut["g"] / 2)).union(cut["gapbox"])
        out = []
        for n, g in items:
            if n in self.rf_nets:
                out.append((gnd, g))
            elif n == net and layer == cut["layer"]:
                g2 = g.difference(cut["gapbox"])
                b = g2.intersection(cut["behind"]) if not cut["behind"].is_empty else Polygon()
                a = g2.difference(cut["behind"]) if not b.is_empty else g2
                if not a.is_empty:
                    out.append((n, a))
                if not b.is_empty:
                    out.append((gnd, b))
            else:
                out.append((n, g))
        f = cut["fill"].get(layer)
        if f is not None:
            add = f.difference(keep_off) if layer == cut["layer"] else f.difference(cut["ant"].buffer(cut["clear"]))
            if not add.is_empty:
                out.append((gnd, add))
        return out

    def _feed_trace(self):
        """Lumped port across the gap cut into the antenna trace: ``start`` on the ground side (the
        filled RF chain), ``stop`` on the antenna side."""
        tr = self.feed.trace
        czs = self._cu_z(self.main)
        z = czs[tr["layer"]]
        ux, uy = tr["dir"]
        axis = 0 if abs(ux) >= abs(uy) else 1
        g, w = float(tr["gap"]), float(tr["width"])
        c = np.array([float(tr["x"]), -float(tr["y"])])  # model frame: y up
        d = np.array([ux, -uy])
        sgn = 1.0 if d[axis] >= 0 else -1.0
        start, stop = np.zeros(3), np.zeros(3)
        start[axis], stop[axis] = c[axis] - sgn * g / 2, c[axis] + sgn * g / 2
        o = 1 - axis
        hw = max(w / 2 * 0.8, 0.05)
        start[o], stop[o] = c[o] - hw, c[o] + hw
        start[2] = stop[2] = z
        return start, stop, axis

    # ------------------------------------------------------------------ feed
    def _feed(self):
        """Lumped feed port. ``start`` is on the ground side, ``stop`` on the pad side."""
        f = self.feed
        if f.trace:
            start, stop, axis = self._feed_trace()
            self.port = {"start": start, "stop": stop, "axis": axis, "R": f.R,
                         "dir": float(np.sign(stop[axis] - start[axis]))}
            for ax in range(3):
                self.fixed[ax] |= {round(float(start[ax]), 5), round(float(stop[ax]), 5)}
                if ax == axis:
                    self.planes[ax] |= {round(float(start[ax]), 5), round(float(stop[ax]), 5)}
            cc = (start + stop) / 2
            self.zones.append((cc - 1.0, cc + 1.0))
            return
        pd = self.main.footprint(f.ref).pad(f.pad)
        czs = self._cu_z(self.main)
        layer = "F.Cu" if pd.on_layer("F.Cu") else "B.Cu"
        zs = czs[layer]
        hs = max(min(pd.size) * 0.3, 0.1)
        x, y = pd.x, -pd.y
        mode = f.ground
        ref_has_gnd = f.ref_layer in czs and any(
            g.contains(Point(pd.x, pd.y)) for _, g in self.main.copper(f.ref_layer, self.ground))
        if mode == "auto":
            mode = "below" if ref_has_gnd else "side"
        if mode == "below":
            if not ref_has_gnd:
                raise ValueError(f"feed {f.ref}.{f.pad} is set to a port to the ground plane below, but there is no "
                                 f"{self.ground} copper on {f.ref_layer} under the pad. Set the feed's ground to "
                                 f"'auto' or 'side' on the Setup page, or choose the layer that has the ground plane.")
            zr = czs[f.ref_layer]
            start = np.array([x - hs, y - hs, zr])
            stop = np.array([x + hs, y + hs, zs])
            axis = 2
        else:
            hit = side_port(self.main, layer, pd, self.ground, hs)
            if hit is None:
                raise ValueError(f"feed {f.ref}.{f.pad}: no {self.ground} copper on {layer} within reach of the "
                                 f"pad that a port can bridge without crossing other copper - set the ground "
                                 f"reference layer or place the feed on a pad next to {self.ground}")
            axis, (sx, sy), (ex, ey), gap, dist, w = hit
            other = 1 - axis
            hs = w / 2
            start = np.zeros(3)
            stop = np.zeros(3)
            ga = np.array([sx, -sy])  # net copper edge (global x, y)
            gb = np.array([ex, -ey])  # ground edge
            start[axis], stop[axis] = gb[axis], ga[axis]
            start[other], stop[other] = ga[other] - hs, ga[other] + hs
            start[2] = stop[2] = zs
            where = f"at {f.ref}.{f.pad}" if dist < 0.05 else f"on the {f.ref}.{f.pad} trace {dist:.2f} mm from the pad"
            self.notes.append(f"feed: horizontal port along {'xy'[axis]}, gap {gap:.2f} mm, {where}, to {self.ground}")
            if gap > 1.5:
                self.notes.append(f"WARNING feed: the port spans {gap:.1f} mm to ground. Its inductance (about 1 nH/mm) "
                                  "is part of the result, and the copper behind the feed counts as ground. Feed at "
                                  "the connector with the matching parts as lumped parts, or use ground 'below'.")
        if abs(stop[axis] - start[axis]) < 1e-6:
            raise ValueError("feed port has zero length")
        self.port = {"start": start, "stop": stop, "axis": axis, "R": f.R,
                     "dir": float(np.sign(stop[axis] - start[axis]))}
        for ax in range(3):
            self.fixed[ax] |= {round(float(start[ax]), 5), round(float(stop[ax]), 5)}
            if ax == axis:  # both port ends must stay on their own mesh lines (never merged)
                self.planes[ax] |= {round(float(start[ax]), 5), round(float(stop[ax]), 5)}
        c = (start + stop) / 2
        self.zones.append((c - 1.0, c + 1.0))

    # ------------------------------------------------------------------ mesh
    def _mesh(self):
        s = self.s
        lam_max = C0 / s.f_min * 1e3
        lam_min = C0 / s.f_max * 1e3
        f0 = s.f_farfield[0] if s.f_farfield else (s.f_min + s.f_max) / 2
        margin = s.margin or max(C0 / f0 * 1e3 / 4, 30.0)
        max_air = s.max_air or lam_min / 20
        allpts = [sh_pts for sh_pts in self._all_points()]
        P = np.vstack(allpts)
        glo, ghi = P.min(0), P.max(0)
        # zones: antenna (fine), board (medium)
        ol = self.main.outline()
        bx0, by0, bx1, by1 = ol.bounds
        board_lo = np.array([bx0, -by1, -self.main.stackup.thickness])
        board_hi = np.array([bx1, -by0, 0.0])
        self.domain = (glo - margin, ghi + margin)
        self.lines = []
        for ax in range(3):
            zl = [(z[0][ax] - s.zone_margin, z[1][ax] + s.zone_margin, z[2] if len(z) > 2 else s.max_antenna)
                  for z in self.zones if not (ax == 2 and len(z) > 3 and z[3] == "xy")]
            zl.append((board_lo[ax], board_hi[ax], s.max_board))
            zl.append((glo[ax], ghi[ax], s.max_board * 2))
            for bd in self.bodies:  # inside a dielectric the wavelength is shorter by sqrt(eps_r)
                cell = s.max_board * 2 if bd.get("pec") else min(max_air, lam_min / (15 * math.sqrt(bd["er"])))
                zl.append((bd["lo"][ax], bd["hi"][ax], cell))
            lines = self._axis(sorted(self.fixed[ax]), self.domain[0][ax], self.domain[1][ax], zl, max_air, self.planes[ax],
                               self.bridge[ax])
            # PML needs some extra cells outside the margin: add 8 equal cells
            self.lines.append(lines)
        self.nf2ff_box = self._nf2ff_box(glo, ghi)

    def _nf2ff_box(self, glo, ghi, gap: float = 3.0):
        """Near-to-far-field surface: in air, at least ``gap`` mm (and one mesh cell) outside every
        part of the model - board, antenna boards and casing - and at least 10 lines inside the domain
        (8 PML cells + 2). A surface that touches the casing wall samples the field in the dielectric."""
        lo, hi = [], []
        for ax, l in enumerate(self.lines):
            l = np.asarray(l)
            i = int(np.searchsorted(l, glo[ax] - gap, side="right")) - 1
            i = min(i, int(np.searchsorted(l, glo[ax], side="left")) - 2)
            j = int(np.searchsorted(l, ghi[ax] + gap, side="left"))
            j = max(j, int(np.searchsorted(l, ghi[ax], side="right")) + 1)
            i = max(10, min(i, len(l) - 12))
            j = min(len(l) - 11, max(j, i + 1))
            lo.append(float(l[i]))
            hi.append(float(l[j]))
        return np.array(lo), np.array(hi)

    def _axis(self, fixed, lo, hi, zones, max_air, planes=(), bridge=()):
        s = self.s
        pl = sorted(planes)
        gaps_pl = [b - a for a, b in zip(pl, pl[1:]) if b - a > 1e-6]
        mc = min([s.min_cell] + [0.45 * g for g in gaps_pl])  # never merge two plate surfaces
        core = sorted(set([lo, hi] + [v for v in fixed if lo < v < hi] +
                          [b for z in zones for b in (z[0], z[1]) if lo < b < hi]))
        # never move plate surfaces or metal-edge lines (1/3-2/3 rule) when merging close lines
        prio = set(round(p, 6) for p in pl) | set(round(v, 6) for v in bridge)  # never dropped
        keep = prio | set(round(v, 6) for v in fixed)
        core = self._merge_keep(core, mc, keep, prio)

        def cap(a, b):
            m = (a + b) / 2
            c = max_air
            for z0, z1, mc in zones:
                if z0 <= m <= z1:
                    c = min(c, mc)
            return c

        gaps = [b - a for a, b in zip(core, core[1:])]
        caps = [cap(a, b) for a, b in zip(core, core[1:])]
        out = [core[0]]
        for i, (a, b) in enumerate(zip(core, core[1:])):
            nl = min(gaps[i - 1], caps[i - 1]) if i > 0 else caps[i]
            nr = min(gaps[i + 1], caps[i + 1]) if i + 1 < len(gaps) else caps[i]
            sl = min(max(nl * s.ratio, s.min_cell), caps[i])
            sr = min(max(nr * s.ratio, s.min_cell), caps[i])
            out += meshmod.graded_fill(a, b, max(sl, mc), max(sr, mc), caps[i], s.ratio) + [b]
        merged = self._merge_keep(out, mc * 0.5, keep, prio)
        return [meshmod._clean(v) for v in meshmod.smooth(merged, 3.0)]

    def _axis_on_mesh(self, name, p0, p1):
        """Via axis snapped to a mesh line that does not lie in antenna copper (a ground via next
        to the feed must not short the antenna). Antenna vias themselves may."""
        from shapely.geometry import Point
        ax = next(k for k in range(3) if abs(p0[k] - p1[k]) > 1e-9)
        a1, a2 = (ax + 1) % 3, (ax + 2) % 3
        l1, l2 = np.asarray(self.lines[a1]), np.asarray(self.lines[a2])
        i, j = int(np.argmin(abs(l1 - p0[a1]))), int(np.argmin(abs(l2 - p0[a2])))
        ant = [] if "_ant" in name else [sh["poly"] for sh in self.sheets if sh.get("antenna") and sh["axis"] == ax
                                         and min(p0[ax], p1[ax]) - 1e-6 <= sh["elev"] <= max(p0[ax], p1[ax]) + 1e-6]
        cands = sorted(((float(l1[a]), float(l2[b])) for a in range(max(0, i - 1), min(len(l1), i + 2))
                        for b in range(max(0, j - 1), min(len(l2), j + 2))),
                       key=lambda q: (q[0] - p0[a1]) ** 2 + (q[1] - p0[a2]) ** 2)
        for u, v in cands:
            if not any(g.intersects(Point(u, v).buffer(1e-4)) for g in ant):
                q0, q1 = np.array(p0, float), np.array(p1, float)
                q0[a1] = q1[a1] = u
                q0[a2] = q1[a2] = v
                return q0, q1
        return None, None

    @staticmethod
    def _merge_keep(lines, min_cell, keep, prio=frozenset()):
        """Merge lines closer than min_cell, but never move a line listed in ``keep``.

        Of two close lines the one with the higher rank stays: ``prio`` (copper planes, dielectric faces,
        port ends) > ``keep`` (metal edges, joint faces) > the rest. A copper plane must never give way
        to a helper line next to it: without its mesh line the plane and a port on it drop out of the
        model (openEMS: "Unused primitive"). Two ``prio`` lines never collide (min_cell is below their
        smallest spacing)."""
        def rank(v):
            r = round(v, 6)
            return 2 if r in prio else (1 if r in keep else 0)
        out = []
        for v in sorted(lines):
            if out and v - out[-1] < min_cell:
                if rank(v) > rank(out[-1]):
                    out[-1] = v
                elif rank(v) == 2 and rank(out[-1]) == 2 and v - out[-1] > 1e-6:
                    out.append(v)  # both must stay (closer than min_cell only by rounding)
                continue
            out.append(v)
        return out

    def _all_points(self):
        for sh in self.sheets:
            n = sh["axis"]
            a1, a2 = (n + 1) % 3, (n + 2) % 3
            c = np.array(sh["poly"].exterior.coords)
            p = np.zeros((len(c), 3))
            p[:, a1], p[:, a2], p[:, n] = c[:, 0], c[:, 1], sh["elev"]
            yield p
        for sl in self.slabs:
            n = sl["axis"]
            a1, a2 = (n + 1) % 3, (n + 2) % 3
            c = np.array(sl["poly"].exterior.coords)
            p = np.zeros((len(c), 3))
            p[:, a1], p[:, a2], p[:, n] = c[:, 0], c[:, 1], sl["elev"]
            yield p
            p2 = p.copy()
            p2[:, n] += sl["len"]
            yield p2
        for mp in self.parts:
            lo, hi = _stl_bounds(mp.stl)
            yield np.array([lo, hi])
        for bd in self.bodies:
            yield np.array([bd["lo"], bd["hi"]])

    @property
    def max_timesteps(self) -> int:
        """Run limit in timesteps: the explicit setting, else max_time_ns / dt of this mesh."""
        from .openems_export import courant_dt, limit_timesteps
        return limit_timesteps(self.s.max_timesteps, self.s.max_time_ns,
                               getattr(self, "dt_exact", None) or courant_dt(self.lines))

    @property
    def n_cells(self):
        return int(np.prod([len(l) - 1 for l in self.lines]))

    def describe(self) -> str:
        d = [np.diff(l) for l in self.lines]
        lo, hi = self.domain
        txt = [f"Domain {hi[0]-lo[0]:.0f} x {hi[1]-lo[1]:.0f} x {hi[2]-lo[2]:.0f} mm, mesh "
               f"{len(self.lines[0])} x {len(self.lines[1])} x {len(self.lines[2])} = {self.n_cells/1e6:.2f} M cells",
               f"Cells min {d[0].min():.3f}/{d[1].min():.3f}/{d[2].min():.3f} mm, max {d[0].max():.1f}/{d[1].max():.1f}/{d[2].max():.1f} mm",
               f"Sheets {len(self.sheets)} (antenna {sum(s['antenna'] for s in self.sheets)}), slabs {len(self.slabs)}, "
               f"vias/pins {len(self.cyls)}, solder joints {len(self.boxes)}, metal parts {len(self.parts)}",
               (f"Feed on the antenna trace at ({self.feed.trace['x']:.2f}, {self.feed.trace['y']:.2f}) mm after "
                f"{self.feed.trace.get('after') or self.feed.ref + '.' + self.feed.pad} (gap port, {self.feed.R:g} ohm)"
                if self.feed.trace else
                f"Feed {self.feed.ref}.{self.feed.pad} ({'vertical' if self.port['axis'] == 2 else 'horizontal'} lumped port, {self.feed.R:g} ohm)")]
        if self.lumped:
            txt.append(f"Lumped parts: {', '.join(lm['ref'] for lm in self.lumped)}")
        for bd in self.bodies:
            sz = bd["hi"] - bd["lo"]
            mat = "metal" if bd.get("pec") else f"eps_r {bd['er']:.2f}, tan d {bd['tand']:.4f}"
            txt.append(f"Casing {bd['name'].split('_', 1)[1].rsplit('_', 1)[0]}: {mat}, "
                       f"{sz[0]:.0f} x {sz[1]:.0f} x {sz[2]:.0f} mm, {'hollow box' if bd.get('walls') else 'shape'}")
        txt += [f"Note: {n}" for n in self.notes]
        return "\n".join(txt)

    # ------------------------------------------------------------------ XML
    def field_plane(self):
        """Recording plane: the main board's area (+10 mm), 0.5 mm above the top copper, where the
        antenna's near field is seen over both the ground plane and the ground-free area."""
        czs = self._cu_z(self.main)
        zt = czs.get("F.Cu", max(czs.values()))
        z = zt + 0.5
        ol = self.main.outline()
        lo, hi = self.domain
        if ol is not None:
            x0, y0, x1, y1 = ol.bounds  # KiCad coords; global y = -y
            a = [max(lo[0], x0 - 10), max(lo[1], -y1 - 10), z]
            b = [min(hi[0], x1 + 10), min(hi[1], -y0 + 10), z]
        else:
            a, b = [lo[0], lo[1], z], [hi[0], hi[1], z]
        return a, b

    def sub_field_planes(self, offset: float = 1.0, margin: float = 4.0) -> list[dict]:
        """Recording planes for standing (vertical) antenna boards: parallel to the board, ``offset`` mm
        in front of its top copper, over the board (+``margin``). The horizontal plane above the main
        board only cuts such an antenna at its foot.
        Each: {name, sub, n (normal axis), e (elevation), h (in-plane horizontal axis), s (+-1: the
        page's x axis is s * global axis h, so the board is seen from the front), lo, hi}."""
        out = []
        lo_d, hi_d = self.domain
        for sb in self.subs:
            pl = sb.placement
            n = pl.normal_axis()
            if n == 2:
                continue
            nv = pl.R[:, 2] / np.linalg.norm(pl.R[:, 2])  # top-copper normal (local +z), points away from the board
            ol = sb.board.outline()
            if ol is None:
                continue
            x0, y0, x1, y1 = ol.bounds
            t = sb.board.stackup.thickness
            c = pl.apply(np.array([[x, y, z] for x in (x0, x1) for y in (y0, y1) for z in (0.0, -t)]))
            e = float(pl.apply(np.array([[x0, y0, 0.0]]))[0, n] + offset * np.sign(nv[n]))
            h = 1 - n  # the horizontal axis in the board plane (n is 0 or 1)
            r = np.cross(-nv, np.array([0.0, 0.0, 1.0]))  # viewer in front of the copper, z up: right-hand direction
            sgn = 1.0 if r[h] >= 0 else -1.0
            lo, hi = c.min(0) - margin, c.max(0) + margin
            lo, hi = np.maximum(lo, lo_d), np.minimum(hi, hi_d)
            lo[n] = hi[n] = e
            out.append({"name": f"fld_{sb.name}", "sub": sb, "n": n, "e": e, "h": h, "s": sgn, "lo": lo, "hi": hi})
        return out

    def write_xml(self, path: Path, fields: dict | None = None) -> Path:
        s = self.s
        f0 = (s.f_min + s.f_max) / 2
        fc = (s.f_max - s.f_min) / 2
        root = ET.Element("openEMS")
        fd = ET.SubElement(root, "FDTD", NumberOfTimesteps=str(self.max_timesteps), endCriteria=f"{s.end_criteria:g}",
                           OverSampling="4", TimeStepMethod="3", f_max=f"{s.f_max:g}")
        w = 2 * math.pi * fc
        t0 = 9.0 / w
        ET.SubElement(fd, "Excitation", Type="10", f0=f"{s.f_max:g}",
                      Function=f"sin(2*pi*{f0:.6g}*(t-{t0:.6g}))*exp(-(({w:.6g}*t/3-3)^2))")
        pml = f"PML_{s.pml_cells}"
        ET.SubElement(fd, "BoundaryCond", xmin=pml, xmax=pml, ymin=pml, ymax=pml, zmin=pml, zmax=pml)
        csx = ET.SubElement(root, "ContinuousStructure", CoordSystem="0")
        grid = ET.SubElement(csx, "RectilinearGrid", DeltaUnit="0.001", CoordSystem="0")
        for tag, arr in zip(("XLines", "YLines", "ZLines"), self.lines):
            e = ET.SubElement(grid, tag, Qty=str(len(arr)))
            e.text = ",".join(f"{v:.6g}" for v in arr)
        ET.SubElement(csx, "BackgroundMaterial", Epsilon="1", Mue="1", Kappa="0", Sigma="0")
        ET.SubElement(csx, "ParameterSet")
        props = ET.SubElement(csx, "Properties")
        pid = [0]

        def prop(tag, name, **a):
            e = ET.SubElement(props, tag, ID=str(pid[0]), Name=name, **a)
            pid[0] += 1
            return e, ET.SubElement(e, "Primitives")

        def verts(parent, poly):
            for u, v in list(poly.exterior.coords)[:-1]:
                ET.SubElement(parent, "Vertex", X1=f"{u:.6g}", X2=f"{v:.6g}")

        def bx(prims, lo, hi, prio):
            b = ET.SubElement(prims, "Box", Priority=str(prio))
            ET.SubElement(b, "P1", X=f"{lo[0]:.6g}", Y=f"{lo[1]:.6g}", Z=f"{lo[2]:.6g}")
            ET.SubElement(b, "P2", X=f"{hi[0]:.6g}", Y=f"{hi[1]:.6g}", Z=f"{hi[2]:.6g}")

        groups: dict[str, list] = {}
        for sl in self.slabs:
            groups.setdefault((sl["name"], sl["er"], sl["tand"]), []).append(sl)
        for (name, er, tand), sls in groups.items():
            kappa = 2 * math.pi * s.f_loss * EPS0 * er * tand
            e, prims = prop("Material", name, Isotropy="1")
            for sl in sls:
                lp = ET.SubElement(prims, "LinPoly", Priority="1", Elevation=f"{sl['elev']:.6g}", NormDir=str(sl["axis"]),
                                   QtyVertices=str(len(sl["poly"].exterior.coords) - 1), Length=f"{sl['len']:.6g}")
                verts(lp, sl["poly"])
            ET.SubElement(e, "Property", Epsilon=f"{er:g},{er:g},{er:g}", Mue="1,1,1",
                          Kappa=f"{kappa:g},{kappa:g},{kappa:g}", Sigma="0,0,0", Density="0")
        sg: dict[str, list] = {}
        for sh in self.sheets:
            sg.setdefault(sh["name"], []).append(sh)
        for name, shs in sg.items():
            e, prims = prop("ConductingSheet", name, Conductivity=f"{CU_SIGMA:g}", Thickness=f"{shs[0]['t']*1e-3:g}")
            for sh in shs:
                pe = ET.SubElement(prims, "Polygon", Priority="10", Elevation=f"{sh['elev']:.6g}", NormDir=str(sh["axis"]),
                                   QtyVertices=str(len(sh["poly"].exterior.coords) - 1))
                verts(pe, sh["poly"])
        if self.cyls or self.boxes:
            e, prims = prop("Metal", "vias_pins_solder")
            for name, p0, p1, r in self.cyls:
                c = ET.SubElement(prims, "Cylinder", Priority="10", Radius=f"{r:g}")
                ET.SubElement(c, "P1", X=f"{p0[0]:.6g}", Y=f"{p0[1]:.6g}", Z=f"{p0[2]:.6g}")
                ET.SubElement(c, "P2", X=f"{p1[0]:.6g}", Y=f"{p1[1]:.6g}", Z=f"{p1[2]:.6g}")
            for name, lo, hi in self.boxes:
                bx(prims, lo, hi, 10)
            # axis line of every straight via / pin: a via thinner than the local cell hits no
            # mesh node and openEMS drops the cylinder ("Unused primitive"); the line snaps to the
            # nearest mesh line, so the layers stay connected
            axes = [(n, p0, p1) for n, p0, p1, _r in self.cyls
                    if sum(abs(p0[k] - p1[k]) > 1e-9 for k in range(3)) == 1]
            if axes:
                e, prims = prop("Metal", "via_axes")
                for n, p0, p1 in axes:
                    q0, q1 = self._axis_on_mesh(n, p0, p1)
                    if q0 is not None:
                        bx(prims, q0, q1, 10)
        for mp in self.parts:
            e, prims = prop("Metal", mp.name)
            ET.SubElement(prims, "PolyhedronReader", FileName=str(Path(mp.stl).resolve()), FileType="STL", Priority="10")
        # casing: below the board in priority (where they touch, the board wins)
        for bd in self.bodies:
            if bd.get("pec"):
                e, prims = prop("Metal", bd["name"])
            else:
                kappa = 2 * math.pi * s.f_loss * EPS0 * bd["er"] * bd["tand"]
                e, prims = prop("Material", bd["name"], Isotropy="1")
            if bd.get("stl"):
                ET.SubElement(prims, "PolyhedronReader", FileName=str(Path(bd["stl"]).resolve()), FileType="STL",
                              Priority="0")
            for lo, hi in bd.get("walls", []):
                bx(prims, lo, hi, 0)
            if not bd.get("pec"):
                ET.SubElement(e, "Property", Epsilon=f"{bd['er']:g},{bd['er']:g},{bd['er']:g}", Mue="1,1,1",
                              Kappa=f"{kappa:g},{kappa:g},{kappa:g}", Sigma="0,0,0", Density="0")
        # feed: lumped port (P1 = ground side, P2 = pad side; same convention as openems_export)
        P = self.port
        ax, st, sp, dr = P["axis"], P["start"], P["stop"], P["dir"]
        e, prims = prop("LumpedElement", "port_resist_1", Direction=str(ax), Caps="1", R=f"{P['R']:g}", LEtype="0")
        bx(prims, st, sp, 5)
        exc = ["0", "0", "0"]
        exc[ax] = f"{-dr:g}"
        e, prims = prop("Excitation", "port_excite_1", Number="0", Enabled="1", Frequency="0", Delay="0", Type="0",
                        Excite=",".join(exc), PropDir="0,0,0")
        bx(prims, st, sp, 5)
        ET.SubElement(e, "Weight", X="1", Y="1", Z="1")
        mid = (st + sp) / 2
        u0, u1 = mid.copy(), mid.copy()
        u0[ax], u1[ax] = st[ax], sp[ax]
        e, prims = prop("ProbeBox", "port_ut_1", Number="0", Type="0", Weight="-1", NormDir="-1", StartTime="0", StopTime="0")
        bx(prims, u0, u1, 0)
        i0, i1 = st.copy(), sp.copy()
        i0[ax] = i1[ax] = mid[ax]
        e, prims = prop("ProbeBox", "port_it_1", Number="0", Type="1", Weight=f"{dr:g}", NormDir=str(ax),
                        StartTime="0", StopTime="0")
        bx(prims, i0, i1, 0)
        # NF2FF recording box (frequency-domain E/H on six faces)
        nlo, nhi = self.nf2ff_box
        for tag, dt in (("nf2ff_E", "10"), ("nf2ff_H", "11")):
            e, prims = prop("DumpBox", tag, Visible="0", Number="0", Type="0", Weight="1", NormDir="-1", StartTime="0",
                            StopTime="0", DumpType=dt, DumpMode="1", FileType="1", MultiGridLevel="0")
            for k in range(3):
                for side in (0, 1):
                    a, b = nlo.copy(), nhi.copy()
                    if side == 0:
                        b[k] = a[k]
                    else:
                        a[k] = b[k]
                    bx(prims, a, b, 0)
            fs = ET.SubElement(e, "FD_Samples")
            fs.text = ",".join(f"{f:.10g}" for f in self.s.f_farfield)
        if self.lumped:
            from .openems_export import add_lumped_xml
            add_lumped_xml(prop, self.lumped, y_sign=-1.0, f_max=self.s.f_max)
        if fields:
            from .fields import add_dumps
            a, b = self.field_plane()
            add_dumps(prop, a, b, fields.get("freqs", []), fields.get("oversampling", 10))
            for fp in self.sub_field_planes():  # standing antenna boards: a plane in front of each
                add_dumps(prop, fp["lo"], fp["hi"], fields.get("freqs", []), fields.get("oversampling", 10),
                          td_name=fp["name"], fd_name=fp["name"] + "_fd")
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        ET.indent(root)
        ET.ElementTree(root).write(path, encoding="UTF-8", xml_declaration=True)
        return path


# ---------------------------------------------------------------------------
def _stl_bounds(path) -> tuple[np.ndarray, np.ndarray]:
    tri = read_stl(path)
    p = tri.reshape(-1, 3)
    return p.min(0), p.max(0)


def read_stl(path) -> np.ndarray:
    """Triangles (n, 3, 3) from ASCII or binary STL."""
    data = Path(path).read_bytes()
    if data[:5] == b"solid" and b"facet" in data[:400]:
        import re
        v = re.findall(rb"vertex\s+(\S+)\s+(\S+)\s+(\S+)", data)  # ~20x faster than splitting lines
        return np.array(v, dtype=float).reshape(-1, 3, 3)
    n = struct.unpack("<I", data[80:84])[0]
    arr = np.frombuffer(data, dtype=np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), count=n, offset=84)
    return arr["v"].astype(float)


def write_stl(path, tri: np.ndarray):
    tri = np.asarray(tri, dtype=np.float32).reshape(-1, 3, 3)
    nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    ln = np.linalg.norm(nrm, axis=1, keepdims=True)
    nrm = np.where(ln > 0, nrm / np.where(ln > 0, ln, 1), nrm)
    rec = np.zeros(len(tri), dtype=np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]))
    rec["n"], rec["v"] = nrm, tri
    with open(path, "wb") as f:
        f.write(b"kicad-rfsim".ljust(80, b" "))
        f.write(struct.pack("<I", len(tri)))
        f.write(rec.tobytes())


def step_to_stl(step: Path, stl: Path, size: float = 0.5) -> Path:
    """Tessellate a STEP file with gmsh (OpenCASCADE). Units stay mm."""
    from .cadview import _LOCK
    with _LOCK:  # gmsh is not thread safe
        return _step_to_stl(step, stl, size)


def _step_to_stl(step: Path, stl: Path, size: float) -> Path:
    import gmsh

    gmsh.initialize(interruptible=False)  # no SIGINT handler: works in worker threads
    try:
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.model.add("part")
        gmsh.model.occ.importShapes(str(step))
        gmsh.model.occ.synchronize()
        gmsh.option.setNumber("Mesh.MeshSizeMax", size)
        gmsh.model.mesh.generate(2)
        gmsh.option.setNumber("Mesh.Binary", 1)  # binary STL: 5x smaller, read without parsing text
        gmsh.write(str(stl))
    finally:
        gmsh.finalize()
    return stl


def transform_stl(src: Path, dst: Path, pl: Placement, local_frame: str = "step") -> Path:
    """Move an STL given in the footprint's model frame into the global frame."""
    tri = read_stl(src)
    g = pl.apply(tri.reshape(-1, 3)).reshape(-1, 3, 3)
    write_stl(dst, g)
    return dst


# ---------------------------------------------------------------------------
@dataclass
class AntennaResult:
    f: np.ndarray
    zin: np.ndarray
    s11: np.ndarray
    p_acc: np.ndarray  # accepted power per unit incident excitation (W)
    farfield: dict  # per far-field frequency: Prad, Dmax, eff, gain_realised, theta, phi, D (theta, phi)


def find_nf2ff(openems_exe: str | None) -> str | None:
    cands = [os.environ.get("NF2FF_BIN")]
    if openems_exe:
        d = Path(openems_exe).parent
        cands += [str(d / "nf2ff.exe"), str(d / "nf2ff"), str(d / "nf2ff" / "nf2ff.exe")]
    cands += [shutil.which("nf2ff"), "/opt/openEMS/bin/nf2ff"]
    for c in cands:
        if c and Path(c).exists():
            return c
    return None


def run_antenna(model: AntennaModel, workdir: Path, threads: int = 0, openems_bin: str | None = None,
                log=print, engine: str = "auto", stats: list | None = None, label: str = "antenna",
                fields: dict | None = None, f_ref: float | None = None) -> AntennaResult:
    import h5py

    from .solver import openems_cmd, run_openems, set_stage

    s = model.s
    exe = openems_bin or find_openems()
    if exe is None:
        raise FileNotFoundError("openEMS not found")
    workdir = Path(workdir)
    d = workdir / "antenna_run"
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    xml = model.write_xml(d / "antenna.xml", fields=fields)
    if s.max_timesteps is None and not getattr(model, "dt_exact", None):
        from .openems_export import exact_dt
        model.dt_exact = exact_dt(exe, xml, workdir)
        if model.dt_exact:
            log(f"[openEMS] timestep {model.dt_exact*1e15:.1f} fs -> limit {s.max_time_ns:g} ns = "
                f"{model.max_timesteps:,} timesteps")
            xml = model.write_xml(d / "antenna.xml", fields=fields)  # with the exact limit
    cmd = openems_cmd(exe, xml.name, threads, engine)
    log(f"[openEMS] antenna: {model.n_cells/1e6:.2f} M cells ...")
    set_stage(label, 1, 1)
    f_ref = f_ref or (float(s.f_farfield[0]) if s.f_farfield else (s.f_min + s.f_max) / 2)
    st = run_openems(cmd, d, d / "openEMS.log", model.max_timesteps, s.end_criteria, label, log, f_ref=f_ref,
                     limit_key="max_time_ns" if s.max_timesteps is None else "max_timesteps")
    if stats is not None:
        stats.append(st)
    f = np.linspace(s.f_min, s.f_max, s.f_points)
    t, u = _read_probe(d / "port_ut_1")
    ti, i = _read_probe(d / "port_it_1")
    U, I = _dft(t, u, f), _dft(ti, i, f)
    R = model.port["R"]
    zin = U / I
    s11 = (zin - R) / (zin + R)
    # far field
    ff = {}
    nf = find_nf2ff(exe)
    if nf is None:
        log("nf2ff not found - far field skipped")
    elif s.f_farfield:
        theta = np.deg2rad(np.arange(0, 180 + 1e-9, s.theta_step))
        phi = np.deg2rad(np.arange(0, 360, s.phi_step))
        lo, hi = model.nf2ff_box
        center = ((lo + hi) / 2) * 1e-3
        root = ET.Element("nf2ff", freq=",".join(f"{x:.10g}" for x in s.f_farfield), Outfile="nf2ff.h5",
                          Center=",".join(f"{c:.6g}" for c in center), Radius="1", NumThreads=str(threads or 0))
        ET.SubElement(root, "theta").text = ",".join(f"{x:.8g}" for x in theta)
        ET.SubElement(root, "phi").text = ",".join(f"{x:.8g}" for x in phi)
        for n in range(6):
            fe, fh = d / f"nf2ff_E_{n}.h5", d / f"nf2ff_H_{n}.h5"
            if fe.exists() and fh.exists():
                ET.SubElement(root, "Planes", E_Field=fe.name, H_Field=fh.name)
        ET.ElementTree(root).write(d / "nf2ff.xml", encoding="UTF-8", xml_declaration=True)
        log("[nf2ff] far field ...")
        set_stage(f"{label}: far field", 1, 1)
        from .solver import busy, run_tool
        busy("near-field to far-field transform")
        rc = run_tool([nf, "nf2ff.xml"], d, d / "nf2ff.log")  # stoppable like openEMS
        if rc != 0:
            raise subprocess.CalledProcessError(rc, [nf, "nf2ff.xml"], output=f"see {d / 'nf2ff.log'}")
        with h5py.File(d / "nf2ff.h5", "r") as h:
            th = np.array(h["Mesh"]["theta"])
            ph = np.array(h["Mesh"]["phi"])
            freqs = np.array(h["nf2ff"].attrs["Frequency"])
            Prad = np.array(h["nf2ff"].attrs["Prad"])
            Dmax = np.array(h["nf2ff"].attrs["Dmax"])
            legacy = "f0_real" in h["/nf2ff/E_theta/FD"]
            for k, fx in enumerate(freqs):
                def rd(name):
                    g = h[f"/nf2ff/{name}/FD"]
                    if not legacy:
                        return np.array(g[f"f{k}"])
                    if f"f{k}_real" in g:
                        return np.swapaxes(np.array(g[f"f{k}_real"]) + 1j * np.array(g[f"f{k}_imag"]), 0, 1)
                    return np.swapaxes(np.array(g[f"f{k}"]), 0, 1)
                Pr = np.real(rd("P_rad"))
                Et, Ep = rd("E_theta"), rd("E_phi")
                Ui, Ii = _dft(t, u, [fx])[0], _dft(ti, i, [fx])[0]
                p_acc = 0.5 * np.real(Ui * np.conj(Ii))
                a = 0.5 * (Ui + Ii * R)
                p_inc = 0.5 * abs(a) ** 2 / R
                D = 4 * np.pi * Pr / Prad[k]  # directivity pattern (linear)
                Dth, Dph = pol_split(D, Et, Ep)
                ff[float(fx)] = {"Prad": float(Prad[k]), "Pacc": float(p_acc), "Pinc": float(p_inc),
                                 "eff_rad": float(Prad[k] / p_acc), "Dmax": float(Dmax[k]),
                                 "D": D, "Dth": Dth, "Dph": Dph, "theta": np.rad2deg(th), "phi": np.rad2deg(ph),
                                 "Etheta": Et, "Ephi": Ep}
    res = AntennaResult(f, zin, s11, None, ff)
    np.savez(workdir / "antenna_result.npz", f=f, zin=zin, s11=s11,
             ff_freqs=np.array(list(ff.keys())),
             **{f"ff{k}_{key}": v[key] for k, v in enumerate(ff.values()) for key in _FF_KEYS})
    return res


_FF_KEYS = ("D", "Dth", "Dph", "theta", "phi", "Prad", "Pacc", "Pinc", "eff_rad", "Dmax")


def pol_split(D, Et, Ep):
    """Directivity split into the theta and phi polarised parts (D = Dth + Dph)."""
    a, b = np.abs(np.asarray(Et)) ** 2, np.abs(np.asarray(Ep)) ** 2
    w = a / np.maximum(a + b, 1e-300)
    return D * w, D * (1 - w)


def load_result(path) -> AntennaResult:
    d = np.load(path)
    ff = {}
    for k, fx in enumerate(d["ff_freqs"]):
        ff[float(fx)] = {key: (d[f"ff{k}_{key}"] if d[f"ff{k}_{key}"].ndim else float(d[f"ff{k}_{key}"]))
                         for key in _FF_KEYS if f"ff{k}_{key}" in d}  # Dth/Dph: results from 0.25 on
    if ff and any("Dth" not in v for v in ff.values()):
        _backfill_pol(ff, Path(path).parent / "antenna_run" / "nf2ff.h5")
    return AntennaResult(d["f"], d["zin"], d["s11"], None, ff)


def _backfill_pol(ff: dict, h5path: Path):
    """Older results: take the polarisation split from the kept nf2ff.h5 (if it is there)."""
    if not h5path.exists():
        return
    try:
        import h5py
        with h5py.File(h5path, "r") as h:
            freqs = np.array(h["nf2ff"].attrs["Frequency"])
            legacy = "f0_real" in h["/nf2ff/E_theta/FD"]
            for k, fx in enumerate(freqs):
                key = min(ff, key=lambda x: abs(x - fx))
                v = ff[key]
                if abs(key - fx) > 1e-6 * fx or "Dth" in v:
                    continue

                def rd(name):
                    g = h[f"/nf2ff/{name}/FD"]
                    if not legacy:
                        return np.array(g[f"f{k}"])
                    if f"f{k}_real" in g:
                        return np.swapaxes(np.array(g[f"f{k}_real"]) + 1j * np.array(g[f"f{k}_imag"]), 0, 1)
                    return np.swapaxes(np.array(g[f"f{k}"]), 0, 1)
                Et, Ep = rd("E_theta"), rd("E_phi")
                if Et.shape == np.shape(v["D"]):
                    v["Dth"], v["Dph"] = pol_split(v["D"], Et, Ep)
    except Exception:  # noqa: BLE001 - the split is optional
        return
