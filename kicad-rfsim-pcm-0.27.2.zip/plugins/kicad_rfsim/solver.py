"""Running openEMS with live progress, user solver settings and a record of how
each result was solved.

* ``run_openems`` streams the openEMS console output, parses timestep, speed and
  energy decay and reports a progress state (fraction, remaining time) to the
  active meter (``with meter(fn): ...``).
* ``solver_options`` reads the optional ``"solver"`` block of a config
  (engine, threads) - the expert settings that are not part of the model.
* ``RunRecord`` collects what was run (method, settings, mesh, timesteps, final
  energy, runtime) and writes ``run_info.json`` + ``solver_info.html``.
"""
from __future__ import annotations

import atexit
import contextlib
import dataclasses
import html
import json
import math
import os
import re
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

# ---------------------------------------------------------------------------
# progress meter (one active callback; the plugin status page or the CLI)
# ---------------------------------------------------------------------------
_METER = None
_STAGE = {"label": "", "job": 1, "jobs": 1}
_CANCEL = None  # threading.Event set by the GUI to stop the running simulation


class Cancelled(Exception):
    """The user stopped the simulation."""


class NumericalInstability(RuntimeError):
    """openEMS energy grew again after the excitation (FDTD instability)."""

    def __init__(self, msg, stats=None):
        super().__init__(msg)
        self.stats = stats


class NoExcitation(RuntimeError):
    """The excitation never reached the FDTD grid (port not on the mesh): the run would compute nothing."""

    def __init__(self, msg, stats=None):
        super().__init__(msg)
        self.stats = stats


def set_cancel_event(ev):
    global _CANCEL
    _CANCEL = ev


# every solver process started by this program: killed on Stop, on closing the window and at exit,
# so no openEMS keeps running on all cores after RF Sim is gone (Windows does not end child processes)
_PROCS: set = set()
_PROCS_LOCK = threading.Lock()


def _register(p):
    with _PROCS_LOCK:
        _PROCS.add(p)


def _unregister(p):
    with _PROCS_LOCK:
        _PROCS.discard(p)


def kill_all() -> int:
    """Kill every running solver process (openEMS, nf2ff); returns how many were running."""
    with _PROCS_LOCK:
        procs = list(_PROCS)
    n = 0
    for p in procs:
        try:
            if p.poll() is None:
                p.kill()
                n += 1
        except Exception:  # noqa: BLE001
            pass
    for p in procs:
        try:
            p.wait(timeout=5)
        except Exception:  # noqa: BLE001
            pass
    return n


atexit.register(kill_all)


def run_tool(cmd: list[str], cwd: Path, logfile: Path, poll: float = 0.5) -> int:
    """Run a helper program (nf2ff) that can be stopped like openEMS; returns its exit code."""
    check_cancel()
    kw = {"creationflags": 0x08000000} if os.name == "nt" else {}  # no console window
    with open(logfile, "w", encoding="utf-8", errors="replace") as lf:
        p = subprocess.Popen(cmd, cwd=cwd, stdout=lf, stderr=subprocess.STDOUT, **kw)
        _register(p)
        try:
            while True:
                try:
                    return p.wait(timeout=poll)
                except subprocess.TimeoutExpired:
                    if _CANCEL is not None and _CANCEL.is_set():
                        p.kill()
                        p.wait()
                        raise Cancelled("simulation stopped by the user") from None
        finally:
            if p.poll() is None:
                p.kill()
            _unregister(p)


def check_cancel():
    if _CANCEL is not None and _CANCEL.is_set():
        raise Cancelled("simulation stopped by the user")


@contextlib.contextmanager
def meter(fn):
    """Route progress states of all openEMS runs inside the block to ``fn(state: dict)``."""
    global _METER
    old, _METER = _METER, fn
    try:
        yield
    finally:
        _METER = old


def set_stage(label: str, job: int = 1, jobs: int = 1):
    """Name of the current simulation (shown above the bar), e.g. 'rf: port 3 of 7'."""
    _STAGE.update(label=label, job=job, jobs=jobs)


def busy(text: str):
    """A step without a known duration (far-field transform, viewer) - indeterminate bar."""
    _emit({"phase": "busy", "frac": None, "eta_s": None, "text": text})


def _emit(state: dict):
    if _METER is not None:
        try:
            _METER(dict(_STAGE, **state))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# openEMS console parsing
# ---------------------------------------------------------------------------
_RE_STEP = re.compile(r"Timestep:\s*(\d+).*?Speed:\s*([\d.]+)\s*MC/s.*?Energy:\s*~?\s*([\d.eE+-]+)\s*\(\s*-?\s*([\d.]+)\s*dB\)")
_RE_VERSION = re.compile(r"openEMS\s+(\S+)\s*--\s*version\s+(\S+)")
_RE_ENGINE = re.compile(r"Create FDTD engine\s*\(([^)]+)\)", re.I)
_RE_THREADS = re.compile(r"(?:number of threads:\s*(\d+)|using\s*(\d+)\s*threads)", re.I)
_RE_SIZE = re.compile(r"FDTD simulation size:\s*(\d+)x(\d+)x(\d+)\s*-->\s*([\d.e+]+)\s*FDTD cells", re.I)
_RE_DT = re.compile(r"FDTD timestep is:\s*([\d.]+e[-+]?\d+)", re.I)
_RE_EXC = re.compile(r"Excitation signal length is:\s*(\d+)\s*timesteps", re.I)


@dataclass
class RunStats:
    """What one openEMS run did (filled from its console output)."""
    label: str = ""
    cells: int = 0
    timesteps: int = 0
    max_timesteps: int = 0
    end_criteria: float = 1e-4
    final_db: float = 0.0  # energy decay reached, dB below the maximum
    speed_mcs: float = 0.0  # mega cells per second (mean)
    wall_s: float = 0.0
    engine: str = ""
    threads: int = 0
    version: str = ""
    dt_s: float = 0.0
    excitation_ts: int = 0
    stop_reason: str = ""  # "energy decayed" | "max timesteps" | "error"
    sim_time_ns: float = 0.0  # simulated time reached
    decay_db_per_ns: float = 0.0  # energy decay rate at the end of the run
    q_est: float = 0.0  # loaded Q from the decay rate at f_ref (0 = unknown)
    f_ref: float = 0.0
    time_needed_ns: float = 0.0  # simulated time to reach the target (only when stopped at the limit)
    limit_key: str = "max_time_ns"
    unused: str = ""  # openEMS' "Unused primitive" line of the excitation (no excitation)

    @property
    def target_db(self) -> float:
        return -10 * math.log10(self.end_criteria) if self.end_criteria > 0 else 0.0

    @property
    def converged(self) -> bool:
        return self.stop_reason == "energy decayed"


class _Estimator:
    """Fraction done and remaining time from timestep and energy-decay history.

    openEMS energy is noisy while the pulse is still in the structure (it jumps
    between 0 and a few dB), so the decay is tracked as its running maximum and a
    decay-based estimate is only made once that envelope passed 10 dB. Before that
    the only bound is max timesteps (an upper limit, flagged as such).
    """

    def __init__(self, max_ts: int, target_db: float):
        self.max_ts, self.target_db = max(1, max_ts), max(1e-6, target_db)
        self.hist: list[tuple[float, int, float]] = []  # (wall s, timestep, decay envelope dB)
        self.env = 0.0
        self.frac = 0.0

    def update(self, t: float, ts: int, db: float) -> tuple[float, float | None, bool]:
        """Returns (fraction, remaining s or None, remaining is only an upper bound)."""
        self.env = max(self.env, db)
        self.hist.append((t, ts, self.env))
        f_db = self.env / self.target_db if self.env >= 10.0 else 0.0  # early spikes are noise
        self.frac = min(1.0, max(self.frac, ts / self.max_ts, f_db))
        eta_ts = None
        if len(self.hist) >= 2:
            t0, ts0, _ = self.hist[max(0, len(self.hist) - 20)]
            if t > t0 and ts > ts0:
                eta_ts = (self.max_ts - ts) * (t - t0) / (ts - ts0)
        rec = [h for h in self.hist if h[2] >= 10.0][-8:]
        if len(rec) >= 3 and rec[-1][0] > rec[0][0]:
            rate = (rec[-1][2] - rec[0][2]) / (rec[-1][0] - rec[0][0])
            if rate > 1e-6:
                eta = max(0.0, (self.target_db - self.env) / rate)
                return self.frac, (min(eta, eta_ts) if eta_ts is not None else eta), False
        return self.frac, eta_ts, True


def openems_cmd(exe: str, xml_name: str, threads: int = 0, engine: str = "auto") -> list[str]:
    cmd = [exe, xml_name]
    if engine and engine != "auto":
        cmd.append(f"--engine={engine}")
    if threads:
        cmd.append(f"--numThreads={threads}")
    return cmd


def decay_analysis(hist, dt: float, f_ref: float, final_db: float, target_db: float) -> dict:
    """Energy decay rate (dB/ns), loaded Q and the simulated time needed to reach ``target_db``
    from the (wall, timestep, decay envelope dB) history of a run. Energy of a resonance falls as
    exp(-w t / Q): rate in dB/s = 10 log10(e) w / Q."""
    rec = [h for h in hist if h[2] >= 10.0]
    out = {"decay_db_per_ns": 0.0, "q_est": 0.0, "time_needed_ns": 0.0}
    if len(rec) < 3 or dt <= 0:
        return out
    rec = rec[len(rec) // 2:] if len(rec) >= 6 else rec
    ts = np.array([h[1] for h in rec], float) * dt * 1e9  # ns
    db = np.array([h[2] for h in rec], float)
    if ts[-1] <= ts[0]:
        return out
    rate = float(np.polyfit(ts, db, 1)[0])  # dB per ns
    if rate <= 1e-6:
        return out
    out["decay_db_per_ns"] = rate
    if f_ref > 0:
        out["q_est"] = 10 * math.log10(math.e) * 2 * math.pi * f_ref * 1e-9 / rate
    t_now = hist[-1][1] * dt * 1e9
    out["time_needed_ns"] = t_now + max(0.0, target_db - final_db) / rate
    return out


def run_openems(cmd: list[str], cwd: Path, logfile: Path, max_timesteps: int, end_criteria: float,
                label: str = "", log=None, emit=None, f_ref: float = 0.0,
                limit_key: str = "max_time_ns") -> RunStats:
    """Run openEMS, stream its output to ``logfile`` and the meter, return the stats.
    ``emit``: own progress callback (parallel runs), else the global meter."""
    _emit = emit or globals()["_emit"]
    check_cancel()
    st = RunStats(label=label, max_timesteps=max_timesteps, end_criteria=end_criteria)
    est = _Estimator(max_timesteps, st.target_db)
    t0 = time.time()
    speeds = []
    _emit({"phase": "start", "frac": 0.0, "eta_s": None, "timestep": 0, "max_timesteps": max_timesteps,
           "db": 0.0, "target_db": st.target_db, "speed": 0.0, "elapsed_s": 0.0})
    env = dict(os.environ)
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
    with open(logfile, "w", encoding="utf-8", errors="replace") as lf:
        p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                             errors="replace", bufsize=1, env=env, **kw)
        _register(p)
        try:
            rc = _stream(p, lf, st, est, speeds, t0, max_timesteps, _emit)
        finally:  # any error in here (also KeyboardInterrupt): never leave openEMS running
            if p.poll() is None:
                p.kill()
                p.wait()
            _unregister(p)
    return _finish(st, est, speeds, t0, rc, label, log, max_timesteps, _emit, cmd, logfile, f_ref, limit_key)


def _stream(p, lf, st, est, speeds, t0, max_timesteps, _emit):
    """Read openEMS' output line by line: log, progress, cancel, instability guard. Returns the exit code."""
    last_emit = -1.0
    penv = 0.0
    if True:  # noqa: SIM108 (keeps the original indentation of the loop)
        assert p.stdout is not None
        e_max = 0.0
        for line in p.stdout:
            lf.write(line)
            if "Unused primitive" in line and "port_excite" in line:
                # the excited port lies on no mesh edge: the field stays zero for the whole run
                st.stop_reason = "no excitation"
                st.unused = line.strip()
                p.kill()
                p.wait()
                break
            if _CANCEL is not None and _CANCEL.is_set():
                p.kill()
                p.wait()
                raise Cancelled("simulation stopped by the user")
            if "Energy" in line and "nan" in line.lower():
                # the fields overflowed (energy NaN): the run can never recover - stop at once
                mts = re.search(r"Timestep:\s*(\d+)", line)
                st.timesteps = int(mts.group(1)) if mts else st.timesteps
                st.stop_reason = "unstable"
                p.kill()
                p.wait()
                break
            m = _RE_STEP.search(line)
            if m:
                ts, sp, db = int(m.group(1)), float(m.group(2)), float(m.group(4))
                st.timesteps, st.final_db = ts, db
                try:
                    e_max = max(e_max, float(m.group(3)))
                except ValueError:
                    pass
                if ts >= 3000 and e_max == 0.0:
                    # thousands of timesteps and not a trace of energy: nothing is excited
                    st.stop_reason = "no excitation"
                    p.kill()
                    p.wait()
                    break
                speeds.append(sp)
                now = time.time() - t0
                frac, eta, upper = est.update(now, ts, db)
                after_pulse = ts > 1.1 * st.excitation_ts if st.excitation_ts else ts > 20000
                if after_pulse:
                    penv = max(penv, db)  # decay envelope counted from the end of the pulse only
                if after_pulse and penv >= 15.0 and db < penv - 12.0:
                    # after the pulse a passive structure cannot gain energy: numerical instability.
                    # While the source still feeds energy in, the energy may dip and rise again
                    # (a port on a pad shorted by a via): no verdict before the pulse has ended.
                    st.stop_reason = "unstable"
                    p.kill()
                    p.wait()
                    break
                if now - last_emit > 0.5:
                    last_emit = now
                    _emit({"phase": "running", "frac": frac, "eta_s": eta, "eta_upper": upper, "timestep": ts,
                           "max_timesteps": max_timesteps, "db": db, "target_db": st.target_db,
                           "speed": sp, "elapsed_s": now})
                continue
            for rx, key in ((_RE_VERSION, "version"), (_RE_ENGINE, "engine"), (_RE_THREADS, "threads"),
                            (_RE_EXC, "excitation_ts")):
                mm = rx.search(line)
                if mm and not getattr(st, key):
                    v = mm.group(2) if key == "version" else next(g for g in mm.groups() if g)
                    setattr(st, key, int(v) if key in ("threads", "excitation_ts") else v)
            mm = _RE_SIZE.search(line)
            if mm:
                st.cells = int(float(mm.group(4)))
            md = _RE_DT.search(line)
            if md and not st.dt_s:
                st.dt_s = float(md.group(1))
        rc = p.wait()
        if _CANCEL is not None and _CANCEL.is_set():  # killed by Stop (kill_all) while waiting for output
            raise Cancelled("simulation stopped by the user")
        return rc


def _finish(st, est, speeds, t0, rc, label, log, max_timesteps, _emit, cmd, logfile, f_ref, limit_key):
    """Stats, decay analysis and the end-of-run checks (instability, solver error, limit hit)."""
    st.wall_s = time.time() - t0
    if st.stop_reason == "no excitation":
        st.speed_mcs = float(np.mean(speeds)) if speeds else 0.0
        why = ("openEMS dropped the excited port (it lies on no mesh line)" if getattr(st, "unused", "")
               else f"the field energy is still exactly 0 after {st.timesteps:,} timesteps")
        msg = (f"{label}: the excitation never entered the simulation - {why}. Stopped; nothing was computed. "
               "Usually the copper plane or the port lost its mesh line; check the mesh settings "
               "(min_cell) or report this model.")
        if log:
            log("ERROR " + msg)
        _emit({"phase": "done", "frac": 1.0, "eta_s": 0.0, "timestep": st.timesteps, "max_timesteps": max_timesteps,
               "db": 0.0, "target_db": st.target_db, "speed": st.speed_mcs, "elapsed_s": st.wall_s})
        raise NoExcitation(msg, st)
    if st.stop_reason == "unstable":
        st.speed_mcs = float(np.mean(speeds)) if speeds else 0.0
        st.sim_time_ns = st.timesteps * st.dt_s * 1e9 if st.dt_s else 0.0
        st.final_db = est.env
        msg = (f"{label}: numerically unstable - the energy fell to -{est.env:.0f} dB and then grew again "
               f"or overflowed (after {st.sim_time_ns:.1f} ns). Stopped. Usually caused by a lumped element "
               "model; the result of this run is not used.")
        if log:
            log("WARNING " + msg)
        _emit({"phase": "done", "frac": 1.0, "eta_s": 0.0, "timestep": st.timesteps, "max_timesteps": max_timesteps,
               "db": est.env, "target_db": st.target_db, "speed": st.speed_mcs, "elapsed_s": st.wall_s})
        raise NumericalInstability(msg, st)
    st.speed_mcs = float(np.mean(speeds)) if speeds else 0.0
    if rc != 0:
        st.stop_reason = "error"
        _emit({"phase": "error", "frac": 1.0, "eta_s": None, "timestep": st.timesteps, "max_timesteps": max_timesteps,
               "db": st.final_db, "target_db": st.target_db, "speed": st.speed_mcs, "elapsed_s": st.wall_s})
        raise subprocess.CalledProcessError(rc, cmd, output=f"see {logfile}")
    st.stop_reason = "energy decayed" if st.final_db >= st.target_db - 0.5 else "max timesteps"
    st.f_ref, st.limit_key = f_ref, limit_key
    st.sim_time_ns = st.timesteps * st.dt_s * 1e9 if st.dt_s else 0.0
    if st.dt_s:
        da = decay_analysis(est.hist, st.dt_s, f_ref, st.final_db, st.target_db)
        st.decay_db_per_ns, st.q_est = da["decay_db_per_ns"], da["q_est"]
        if st.stop_reason == "max timesteps":
            st.time_needed_ns = da["time_needed_ns"]
    _emit({"phase": "done", "frac": 1.0, "eta_s": 0.0, "timestep": st.timesteps, "max_timesteps": max_timesteps,
           "db": st.final_db, "target_db": st.target_db, "speed": st.speed_mcs, "elapsed_s": st.wall_s})
    if log and st.stop_reason == "max timesteps":
        log(f"WARNING {label}: {limit_advice(st)}")
    return st


def limit_advice(st) -> str:
    """Text for a run that stopped at its time limit, with the estimated Q and the time needed."""
    g = st if isinstance(st, dict) else dataclasses.asdict(st)
    tgt = g.get("target_db") or (-10 * math.log10(g["end_criteria"]) if g.get("end_criteria") else 40)
    t = g.get("sim_time_ns", 0.0)
    head = (f"stopped at the time limit ({t:.0f} ns simulated, {g['timesteps']:,} timesteps) with the energy only "
            f"{g['final_db']:.1f} of {tgt:.0f} dB down - the spectrum may ripple")
    if g.get("time_needed_ns"):
        need = g["time_needed_ns"]
        sug = int(math.ceil(need * 1.2 / 10.0) * 10)
        q = (f", loaded Q ≈ {g['q_est']:.0f} at {g['f_ref']/1e6:.0f} MHz" if g.get("q_est") and g.get("f_ref") else "")
        key = g.get("limit_key", "max_time_ns")
        fix = (f"set max_time_ns to {sug}" if key == "max_time_ns" else
               f"remove max_timesteps (then max_time_ns = {sug} is used) or raise it accordingly")
        return (f"{head}. Energy falls {g['decay_db_per_ns']:.2f} dB/ns{q}; reaching {tgt:.0f} dB needs about "
                f"{need:.0f} ns: {fix}.")
    if t:
        return f"{head}. The energy has not started to decay yet - raise max_time_ns a lot (e.g. x3, {int(t*3)} ns)."
    return head + "."


class ParallelMeter:
    """Combines the progress of several openEMS runs running at the same time into one state."""

    def __init__(self, label: str, jobs: int):
        import threading
        self.label, self.jobs = label, jobs
        self.lock = threading.Lock()
        self.state: dict[int, dict] = {}
        self.done = 0
        self.t0 = time.time()

    def emitter(self, key: int):
        def fn(st: dict):
            with self.lock:
                if st.get("phase") == "done":
                    self.done += 1
                    self.state.pop(key, None)
                else:
                    self.state[key] = st
                running = list(self.state.values())
                frac = (self.done + sum(float(r.get("frac") or 0) for r in running)) / max(1, self.jobs)
                etas = [r.get("eta_s") for r in running if r.get("eta_s") is not None]
                agg = {"phase": "done" if self.done == self.jobs else "running", "frac": min(1.0, frac),
                       "eta_s": max(etas) if etas else None,
                       "eta_upper": any(r.get("eta_upper") for r in running),
                       "timestep": max([int(r.get("timestep", 0)) for r in running] or [0]),
                       "max_timesteps": max([int(r.get("max_timesteps", 0)) for r in running] or [0]),
                       "db": min([float(r.get("db", 0)) for r in running] or [st.get("db", 0)]),
                       "target_db": st.get("target_db", 40), "speed": sum(float(r.get("speed", 0)) for r in running),
                       "elapsed_s": time.time() - self.t0}
            if _METER is not None:
                try:
                    _METER(dict(label=f"{self.label}: {len(running)} runs in parallel" if len(running) > 1 else
                                (running[0].get("_name", self.label) if running else self.label),
                                job=min(self.jobs, self.done + 1), jobs=self.jobs, **agg))
                except Exception:
                    pass
        return fn


def physical_cores() -> int:
    """Physical CPU cores (FDTD does not gain from hyper-threads)."""
    try:
        import psutil
        n = psutil.cpu_count(logical=False)
        if n:
            return int(n)
    except Exception:
        pass
    return max(1, (os.cpu_count() or 2) // 2)


def useful_threads(cells: int, cores: int = 0) -> int:
    """Threads that still speed up one openEMS run of ``cells``. Measured: 94 k cells run at
    104 MC/s on 1 thread and 61 MC/s on 2; 630 k cells 49 -> 66 MC/s from 1 to 2 threads."""
    cores = cores or physical_cores()
    cap = 1 if cells < 200_000 else 2 if cells < 450_000 else 4 if cells < 1_500_000 else cores
    return max(1, min(cores, cap))


def plan_parallel(n_runs: int, cells: int, threads: int = 0, parallel: int = 0) -> tuple[int, int]:
    """(runs at the same time, threads per run). Small models scale badly with threads, so
    several runs share the cores; big models get more threads each. A single small run gets
    one thread, not all cores (more threads made it slower)."""
    cores = threads or physical_cores()
    per = useful_threads(cells, cores)
    if parallel <= 0:
        parallel = max(1, min(n_runs, cores // per))
    parallel = max(1, min(parallel, n_runs))
    return parallel, max(1, min(per, cores // parallel))


# ---------------------------------------------------------------------------
# solver options (expert block of a config)
# ---------------------------------------------------------------------------
ENGINES = ("auto", "multithreaded", "sse-compressed", "sse", "basic")


@dataclass
class SolverOptions:
    mode: str = "auto"  # "auto": settings from the setup; "custom": the user's own (GUI)
    engine: str = "auto"  # openEMS engine: auto (openEMS default), multithreaded, sse-compressed, sse, basic
    threads: int = 0  # 0: all physical cores
    parallel: int = 0  # runs at the same time (RF chain excitations); 0 = automatic


def solver_options(cfg: dict, threads: int = 0) -> SolverOptions:
    so = check_keys(SolverOptions, cfg.get("solver", {}), "solver")
    if so.engine not in ENGINES:
        raise ValueError(f'solver.engine "{so.engine}" unknown, use one of {", ".join(ENGINES)}')
    if not so.threads:
        so.threads = threads
    return so


def check_keys(cls, values: dict, where: str):
    """Build dataclass ``cls`` from user values; unknown keys give a clear error."""
    names = {f.name for f in dataclasses.fields(cls)}
    bad = [k for k in values if k not in names]
    if bad:
        raise ValueError(f'unknown setting(s) {", ".join(bad)} in "{where}". Valid: {", ".join(sorted(names))}')
    return cls(**values)


# meaning of every user setting (shown on the solver info page)
SETTING_DOCS = {
    # circuit model ("model" / "mesh")
    "f_min": "lowest frequency of the excitation and result (Hz)",
    "f_max": "highest frequency (Hz); also sets the finest wavelength for the mesh",
    "f_loss": "frequency where the dielectric loss tangent is converted to a conductivity (Hz)",
    "air_above": "air above the board inside the model (mm)",
    "air_side": "air beside the region (mm)",
    "air_below": "air below the board (mm)",
    "truncate_at": "copper layer used as a perfect conductor bottom wall (model ends there); null = full stack",
    "end_criteria": "stop when the field energy fell to this fraction of its maximum (1e-4 = 40 dB; RF chain "
                    "default 1e-6 = 60 dB, antenna 1e-4)",
    "max_time_ns": "run limit as simulated time (ns); converted to timesteps from the timestep of the mesh, so a finer "
                   "mesh gets more timesteps automatically. The run usually stops earlier, when the energy has decayed "
                   "(end criteria). High-Q antennas need more: ~ 9.2 * Q / (2 pi f) for 40 dB",
    "max_timesteps": "explicit limit in timesteps; empty = automatic from max_time_ns (recommended)",
    "copper_thickness": "outer copper with its real thickness: auto (on when the copper is >= 1/10 of the dielectric "
                        "under it, e.g. 35 um on 0.2 mm prepreg), on, off. Zero-thickness sheets read Z0 too high on thin "
                        "dielectrics (+6 % microstrip, +21 % coplanar line); thick copper needs a smaller timestep (~1.8x slower)",
    "boundary": "outer boundary: MUR (absorbing, 1st order), PML_8 (better absorbing, slower), PEC (metal wall)",
    "excitation": "dc_free (sine-modulated Gaussian, no DC) or gauss (classic Gaussian)",
    "deembed_port": "feed port to the ground plane below: remove the inductance of the port column through the board "
                    "from the feed impedance (on by default; the board has no conductor there)",
    "pulse": "short (default): wide-band pulse, 0 to 3 x f_max (antenna: 2 x), so the run is shorter - the result "
             "band stays f_min to f_max; band: pulse limited to f_min ... f_max (longer runs, as before v0.27)",
    "max_fine": "largest cell inside the region of interest (mm)",
    "max_coarse": "largest cell in the air margin (mm)",
    "min_cell": "mesh lines closer than this are merged (mm); smaller = more accurate, smaller timestep",
    "z_cells_per_dielectric": "mesh cells across each dielectric layer",
    "ratio": "maximum growth of neighbouring cells (mesh grading)",
    "edge_min_len": "only metal edges longer than this get their own mesh lines (mm)",
    "edge_rule": "mesh at copper edges: thirds (one line 1/3 cell inside, one 2/3 outside the metal - accurate, "
                 "recommended) or edge (one line on the edge, Z0 a few % low)",
    # antenna
    "f_points": "frequency points of the result",
    "f_farfield": "frequencies of the radiation pattern / efficiency (Hz)",
    "margin": "air from the board to the absorbing boundary (mm); null = lambda/4",
    "max_antenna": "largest cell on the antenna copper (mm)",
    "max_board": "largest cell on the rest of the board (mm)",
    "max_air": "largest cell in the air (mm); null = lambda/20 at f_max",
    "zone_margin": "fine-mesh zone around the antenna copper (mm)",
    "fill_holes_below": "small holes in merged copper (via antipads) below this area are filled (mm²)",
    "merge_gap": "antenna / whole-board model: copper that is not antenna or RF chain and has gaps narrower than this "
                 "(mm) is merged into one plane - fewer polygons, no slivers; RF clearances are kept exactly. 0 = off",
    "plane_gap": "antenna model: outside the RF / antenna area, board copper gaps up to this (mm) are closed - traces, "
                 "pads and clearances inside a copper pour become one plane. Areas without a pour keep their traces. 0 = off",
    "plane_hole": "antenna model: enclosed non-copper areas in the board copper up to this area (mm²) are filled - antipads, "
                  "mounting holes, cut-outs under switching converters, plane splits. Holes that reach the RF / antenna "
                  "area (a printed antenna's ground-free window) stay",
    "rf_margin": "antenna model: the RF / antenna area (kept exactly as drawn) is the antenna copper, the RF chain copper "
                 "and the feed footprint plus this margin (mm)",
    "rf_path_mesh": "antenna model: fine mesh over the RF chain setups' regions, so the RF traces next to the antenna "
                    "are on the mesh (true); false = board mesh there (faster, the RF traces may fall apart)",
    "rf_cell": "antenna model: cell size in the RF chain region (mm); empty = narrowest RF trace / 2",
    "pml_cells": "thickness of the perfectly matched layer (cells)",
    "theta_step": "far-field resolution in theta (deg)",
    "phi_step": "far-field resolution in phi (deg)",
    # solver
    "engine": "openEMS engine: auto, multithreaded, sse-compressed, sse, basic",
    "threads": "solver threads in total (0 = all physical cores)",
    "parallel": "RF chain: excitations run at the same time, sharing the threads (0 = automatic: small models "
                "run several at once, which is faster than one run with many threads)",
}

METHOD_TEXT = {
    "common": [
        ("Method", "Finite-difference time-domain (FDTD), openEMS (EC-FDTD on a rectilinear mesh). "
                   "Maxwell's equations are stepped in time; a short pulse covers the whole band at once and "
                   "the frequency response is the Fourier transform of port voltage and current."),
        ("Mesh", "Rectilinear (axis-aligned) grid. Lines are placed on metal edges, dielectric interfaces and "
                 "ports, refined near metal and graded outwards. Curved copper is staircased."),
        ("Stop", "The run ends when the field energy fell by the target (end criteria) or at max timesteps. "
                 "A run stopped at max timesteps has not settled; its spectra may ripple."),
        ("Copper", "Conducting sheets (copper conductivity); in the RF circuit model the outer copper gets "
                   "its real thickness when it is ≥ 1/10 of the dielectric below it (copper_thickness auto). "
                   "Vias as metal cylinders plus a line on their axis. Solder mask is not modelled."),
        ("Dielectric", "Stackup thickness and εr from the board file; loss tangent converted to a "
                       "conductivity at f_loss."),
    ],
    "circuit": [
        ("Ports", "Each pad of a tuned part is a lumped port (50 Ω) to the reference plane below - also the "
                  "GND pad of a shunt part, so its pad, trace and via are in the result. One run per excited "
                  "port gives one column of the S-matrix; the parts (R/L/C, vendor Touchstone) are added "
                  "afterwards by circuit math, so values can be tuned without new runs."),
        ("Boundary", "Absorbing boundary (MUR) around a cut-out region of the board; optionally a metal "
                     "wall at the truncation layer."),
    ],
    "antenna": [
        ("Port", "One lumped port (50 Ω) at the feed; input impedance Z = U/I, S11 against 50 Ω."),
        ("Boundary", "Perfectly matched layer (PML) a quarter wavelength away; the whole board is modelled."),
        ("Far field", "Near-field to far-field transform (nf2ff) on a box around the board gives pattern, "
                      "directivity and radiated power; efficiency = radiated / accepted power."),
        ("Sub-boards", "Soldered-in antenna boards are placed from their own KiCad board in 90° steps."),
    ],
}


# ---------------------------------------------------------------------------
# record of a run
# ---------------------------------------------------------------------------
@dataclass
class RunRecord:
    kind: str  # "circuit" | "antenna"
    name: str
    settings: dict
    solver: dict
    model_text: str
    mesh: dict = field(default_factory=dict)
    runs: list = field(default_factory=list)  # RunStats as dicts
    reused: bool = False
    when: str = ""
    notes: list = field(default_factory=list)  # model warnings (region cuts, model ranges ...)
    checks: list = field(default_factory=list)  # plausibility checks (checks.py)

    def add(self, st: RunStats):
        self.runs.append(dataclasses.asdict(st) | {"target_db": st.target_db, "converged": st.converged})

    def save(self, out: Path) -> Path:
        self.when = self.when or time.strftime("%Y-%m-%d %H:%M")
        (out / "run_info.json").write_text(json.dumps(dataclasses.asdict(self), indent=2, default=_jsonable))
        return write_solver_page(out, self)


def _jsonable(o):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)


def mesh_stats(lines, f_max: float, er_max: float = 4.5) -> dict:
    """Cell statistics. Resolution = free-space wavelength at f_max / largest cell (the
    largest cells sit in air); the wavelength in the densest dielectric is listed too."""
    d = [np.diff(np.asarray(l, float)) for l in lines]
    lam0 = 299792458.0 / f_max * 1e3  # mm
    cmax = max(float(x.max()) for x in d)
    return {"lines": [len(l) for l in lines], "cells": int(np.prod([len(l) - 1 for l in lines])),
            "min_cell_mm": [round(float(x.min()), 4) for x in d], "max_cell_mm": [round(float(x.max()), 3) for x in d],
            "lambda0_mm": round(lam0, 1), "lambda_diel_mm": round(lam0 / math.sqrt(er_max), 1),
            "cells_per_lambda": round(lam0 / cmax, 1) if cmax else None}


def load_record(out: Path) -> dict | None:
    p = Path(out) / "run_info.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return None


def _fmt_s(s: float) -> str:
    s = float(s)
    if s < 90:
        return f"{s:.0f} s"
    if s < 5400:
        return f"{s/60:.1f} min"
    return f"{s/3600:.1f} h"


_CSS = """:root{--bg:#fafaf8;--fg:#1d1d1b;--mut:#6b6a64;--line:#dcdad3;--card:#fff;--ok:#2f7d4f;--warn:#b26b00;--err:#c4521b}
@media (prefers-color-scheme:dark){:root{--bg:#181816;--fg:#ecebe6;--mut:#a3a19a;--line:#3a3934;--card:#22221f;--ok:#6cc48f;--warn:#e0a548;--err:#f08a5d}}
body{font:14px/1.5 system-ui,sans-serif;margin:0;background:var(--bg);color:var(--fg)}
main{max-width:920px;margin:0 auto;padding:20px 16px}h1{font-size:20px;margin:0 0 4px}h2{font-size:16px;margin:24px 0 8px}
.mut{color:var(--mut)}table{border-collapse:collapse;width:100%;margin:4px 0}td,th{padding:5px 8px;border-bottom:1px solid var(--line);
text-align:left;vertical-align:top}th{font-weight:600;color:var(--mut);font-size:12px}code{font-size:12px}
.ok{color:var(--ok)}.warn{color:var(--warn)}.err{color:var(--err)}pre{white-space:pre-wrap;font-size:12px;background:var(--card);
border:1px solid var(--line);padding:10px;border-radius:6px}dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 16px;margin:0}
dt{font-weight:600}dd{margin:0}.wrap{overflow-x:auto}"""


def write_solver_page(out: Path, rec: RunRecord) -> Path:
    """``solver_info.html``: how the result was solved, with all settings used."""
    e = html.escape
    parts = [f"<h1>How this was solved – {e(rec.name)}</h1>",
             f"<p class='mut'>{'Antenna model' if rec.kind == 'antenna' else 'RF circuit model'} · {e(rec.when)}"
             + (" · result reused (geometry and settings unchanged)" if rec.reused else "") + "</p>"]
    # verdict
    warn = []
    for r in rec.runs:
        if r.get("stop_reason") == "max timesteps":
            warn.append(f"{e(r['label'])}: {e(limit_advice(r))}")
    warn += [e(n) for n in rec.notes]
    cpl = rec.mesh.get("cells_per_lambda")
    if cpl is not None and cpl < 15:
        warn.append(f"Coarsest cell gives only {cpl} cells per wavelength at f_max (≥ 15 recommended): "
                    "lower max_air / max_coarse.")
    warn += [f"Plausibility check failed - {e(c['name'])}: {e(c['value'])} (expected {e(c['limit'])}; {e(c['meaning'])})"
             for c in rec.checks if not c["ok"]]
    if rec.runs or warn:
        parts.append("<p class='warn'>" + "<br>".join(warn) + "</p>" if warn else
                     "<p class='ok'>All runs settled (energy reached the end criteria).</p>")
    # method
    parts.append("<h2>Method</h2><dl>")
    for k, v in METHOD_TEXT["common"] + METHOD_TEXT[rec.kind]:
        parts.append(f"<dt>{e(k)}</dt><dd>{e(v)}</dd>")
    parts.append("</dl>")
    # runs
    if rec.runs:
        parts.append("<h2>Runs</h2><div class='wrap'><table><tr><th>Run</th><th>Timesteps</th><th>Simulated</th>"
                     "<th>Energy decay</th><th>Q (est.)</th><th>Stop</th><th>Speed</th><th>Time</th></tr>")
        for r in rec.runs:
            cls = "ok" if r.get("converged") else "warn"
            stop = "time limit" if r.get("stop_reason") == "max timesteps" else r.get("stop_reason", "")
            sim = f"{r['sim_time_ns']:.1f} ns" if r.get("sim_time_ns") else "-"
            qe = f"{r['q_est']:.0f}" if r.get("q_est") else "-"
            parts.append(f"<tr><td>{e(r['label'])}</td><td>{r['timesteps']:,} / {r['max_timesteps']:,}</td>"
                         f"<td>{sim}</td><td>{r['final_db']:.1f} / {r['target_db']:.0f} dB</td><td>{qe}</td>"
                         f"<td class='{cls}'>{e(stop)}</td>"
                         f"<td>{r['speed_mcs']:.0f} MC/s</td><td>{_fmt_s(r['wall_s'])}</td></tr>")
        r0 = rec.runs[0]
        parts.append("</table></div><p class='mut'>"
                     + e(" · ".join(x for x in (f"openEMS {r0.get('version')}" if r0.get("version") else "",
                                                f"engine {r0.get('engine')}" if r0.get("engine") else "",
                                                f"{r0.get('threads')} threads" if r0.get("threads") else "",
                                                f"Δt {r0['dt_s']:.3g} s" if r0.get("dt_s") else "") if x))
                     + f" · total {_fmt_s(sum(r['wall_s'] for r in rec.runs))}</p>")
    # plausibility
    if rec.checks:
        parts.append("<h2>Plausibility checks</h2><p class='mut'>Physics every correct result must obey; a failed "
                     "check points at a numerical problem (run not settled, unstable, mesh too coarse at a port).</p>"
                     "<table><tr><th>Check</th><th>Result</th><th>Expected</th><th>Why</th></tr>")
        for c in rec.checks:
            cls = "ok" if c["ok"] else "err"
            parts.append(f"<tr><td>{e(c['name'])}</td><td class='{cls}'>{'passed' if c['ok'] else 'FAILED'} · "
                         f"{e(c['value'])}</td><td>{e(c['limit'])}</td><td class='mut'>{e(c['meaning'])}</td></tr>")
        parts.append("</table>")
    # mesh
    if rec.mesh:
        m = rec.mesh
        parts.append("<h2>Mesh</h2><table>"
                     f"<tr><td>Lines x / y / z</td><td>{' / '.join(map(str, m['lines']))} → {m['cells']/1e6:.2f} M cells</td></tr>"
                     f"<tr><td>Smallest cell</td><td>{' / '.join(f'{v:g}' for v in m['min_cell_mm'])} mm</td></tr>"
                     f"<tr><td>Largest cell</td><td>{' / '.join(f'{v:g}' for v in m['max_cell_mm'])} mm</td></tr>"
                     f"<tr><td>Resolution</td><td>{m.get('cells_per_lambda')} cells per wavelength at f_max in the coarsest "
                     f"(air) cell · λ = {m.get('lambda0_mm')} mm in air, {m.get('lambda_diel_mm')} mm in the dielectric</td></tr></table>")
    # settings
    parts.append("<h2>Settings used</h2><p class='mut'>Change them in the config file "
                 "(<code>rfsim/*.json</code>, keys below) and press Simulate again. Missing keys use the defaults; "
                 "<b>bold</b> values differ from the default.</p>"
                 "<div class='wrap'><table><tr><th>Key</th><th>Value</th><th>Default</th><th>Meaning</th></tr>")
    for grp, vals in list(rec.settings.items()) + [("solver", rec.solver)]:
        for k, v in vals.items():
            if isinstance(v, dict) and "value" in v:
                val, default = v["value"], v["default"]
            else:
                val, default = v, None
            changed = default is not None and _short(val) != _short(default)
            vtxt = f"<b>{e(_short(val))}</b>" if changed else e(_short(val))
            parts.append(f"<tr><td><code>{e(grp)}.{e(k)}</code></td><td>{vtxt}</td>"
                         f"<td class='mut'>{e(_short(default))}</td><td>{e(SETTING_DOCS.get(k, ''))}</td></tr>")
    parts.append("</table></div>")
    parts.append(f"<h2>Model</h2><pre>{e(rec.model_text)}</pre>")
    parts.append("<p class='mut'>Raw files in this folder: <code>run_info.json</code>, openEMS input "
                 "<code>*/model.xml</code> / <code>antenna_run/antenna.xml</code>, logs <code>*/openEMS.log</code>.</p>")
    path = out / "solver_info.html"
    path.write_text(f"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                    f"<title>Solver info</title><style>{_CSS}</style></head><body><main>{''.join(parts)}</main></body></html>",
                    encoding="utf-8")
    return path


def _short(v) -> str:
    if v is None:
        return "auto"
    if isinstance(v, float):
        return f"{v:.4g}"
    if isinstance(v, (list, tuple)):
        return ", ".join(_short(x) for x in v)
    return str(v)


def settings_table(groups: dict[str, object]) -> dict:
    """{group: dataclass instance} -> {group: {key: {value, default}}} for the record."""
    out = {}
    for g, obj in groups.items():
        d = {}
        for f in dataclasses.fields(obj):
            v = getattr(obj, f.name)
            if dataclasses.is_dataclass(v):
                continue
            default = f.default if f.default is not dataclasses.MISSING else (
                f.default_factory() if f.default_factory is not dataclasses.MISSING else None)
            d[f.name] = {"value": v, "default": default}
        out[g] = d
    return out


def console_meter(every: float = 10.0):
    """Simple meter for the CLI: one line every ``every`` seconds."""
    last = [0.0]

    def fn(s):
        if s["phase"] == "running" and time.time() - last[0] < every:
            return
        last[0] = time.time()
        eta = (f", {'at most ' if s.get('eta_upper') else ''}~{_fmt_s(s['eta_s'])} left") if s.get("eta_s") else ""
        print(f"  [{s['label']}] {100*s['frac']:5.1f} %  ts {s['timestep']}  {s['db']:.1f}/{s['target_db']:.0f} dB{eta}",
              flush=True)
    return fn
