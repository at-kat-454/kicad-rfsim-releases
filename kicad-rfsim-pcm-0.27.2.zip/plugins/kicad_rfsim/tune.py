"""Tie an EM result to the board's parts and solve / optimise component values.

Workflow
  1. EM run gives S[f, n, n] for the pad ports (termination ports dropped:
     they were loaded with 50 ohm during the run, so the sub-matrix of the
     driven ports is exact for that loading).
  2. ``auto_circuit`` stamps every part whose pads are all ports (or ground)
     using its Value field (``RF.Q`` / ``RF.Model`` fields override).
  3. ``Circuit.solve`` reduces to the external ports; ``optimise`` searches
     E-series values for the chosen parts.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass

import numpy as np

from .board import Board
from .circuit import Circuit, Element, element_from_value
from .rfpath import part_kind, value_kind

E12 = [1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2]
E24 = [1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0, 3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1]


def series_values(series=E24, decades=(1e-12, 1e-11, 1e-10)) -> list[float]:
    return sorted(v * d for d in decades for v in series)


def load_em(npz_path, drop_terminations: bool = True, deembed: bool = True):
    """S-matrix of an RF chain run: (f, S, port names). ``deembed``: remove the inductance of the pad
    port columns stored with the result (see openems_export.port_inductance)."""
    d = np.load(npz_path, allow_pickle=False)
    f, S, names = d["f"], d["S"], [str(n) for n in d["names"]]
    keep = [i for i in range(len(names)) if not np.isnan(S[0, :, i]).all()] if drop_terminations else list(range(len(names)))
    S = S[:, keep][:, :, keep]
    if deembed and "port_L" in d.files and not np.isnan(S).any():
        from .openems_export import deembed_ports
        S = deembed_ports(S, f, np.asarray(d["port_L"])[keep])
    return f, S, [names[i] for i in keep]


def auto_circuit(board: Board, f: np.ndarray, S: np.ndarray, names: list[str], ground: str = "GND",
                 skip: set[str] | None = None, f_q: float | None = None) -> tuple[Circuit, list[str]]:
    """Stamp all two-terminal parts whose pads are ports (or ground). ``f_q``: Q reference frequency."""
    c = Circuit(f, S, names)
    have = set(names)
    stamped = []
    for fp in board.footprints:
        if skip and fp.ref in skip:
            continue
        pads = [p for p in fp.pads if p.number]
        if len(pads) != 2 or part_kind(fp) not in ("C", "L", "R"):
            continue
        q = fp.properties.get("RF.Q")
        gname = f"{fp.ref}.{'-'.join(sorted(p.number for p in pads))}"
        if gname in have:  # one port across the part: the part closes that port
            el = element_from_value(value_kind(part_kind(fp), fp.value), fp.value, fp.dnp, float(q) if q else None, f_q)
            c.set_part(fp.ref, gname, None, el)
            stamped.append(fp.ref)
            continue
        nodes = []
        for p in pads:
            if f"{fp.ref}.{p.number}" in have:  # a port on a GND pad: its path to the plane is in S
                nodes.append(f"{fp.ref}.{p.number}")
            elif p.net == ground:
                nodes.append(None)
            else:
                nodes = []
                break
        if not nodes or all(n is None for n in nodes):
            continue
        el = element_from_value(value_kind(part_kind(fp), fp.value), fp.value, fp.dnp, float(q) if q else None, f_q)
        a, b = nodes if nodes[0] is not None else (nodes[1], None)
        c.set_part(fp.ref, a, b, el)
        stamped.append(fp.ref)
    return c, stamped


@dataclass
class OptResult:
    values: dict[str, float]
    cost: float
    S: np.ndarray


def band_mask(f, f_lo, f_hi):
    return (f >= f_lo) & (f <= f_hi)


def optimise(c: Circuit, parts: dict[str, tuple[str, list[float]]], external: list[str], f_lo: float, f_hi: float,
             cost=None, z_ref=50.0, max_combinations: int = 200000) -> OptResult:
    """Exhaustive search over discrete values. ``parts``: ref -> (kind "C"/"L", values)."""
    m = band_mask(c.freq, f_lo, f_hi)
    if cost is None:
        def cost(S):  # worst-case return loss at port 1 in band (linear |S11|)
            return float(np.max(np.abs(S[m, 0, 0])))
    keys = list(parts)
    n = int(np.prod([len(parts[k][1]) for k in keys]))
    if n > max_combinations:
        raise ValueError(f"{n} combinations, reduce the value lists")
    orig = {k: c.parts[k] for k in keys}
    best = None
    for combo in itertools.product(*[parts[k][1] for k in keys]):
        for k, v in zip(keys, combo):
            a, b, el = orig[k]
            kind = parts[k][0]
            ref_el = element_from_value(kind, "1", False)
            c.parts[k] = (a, b, Element(kind, v, ref_el.q, ref_el.f_q, ref_el.esl, ref_el.esr))
        S = c.solve(external, z_ref)
        val = cost(S)
        if best is None or val < best.cost:
            best = OptResult(dict(zip(keys, combo)), val, S)
    for k in keys:
        c.parts[k] = orig[k]
    return best

