"""Matplotlib rendering of a board region: copper per layer, RF nets, ports."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import PathPatch
from matplotlib.path import Path as MplPath
from shapely.geometry import MultiPolygon, Polygon, box
from shapely.ops import unary_union

from .board import Board

PALETTE = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#46a0b0", "#f032e6", "#9a7d0a",
           "#008080", "#9a6324", "#800000", "#2f6f2f", "#808000", "#000075", "#b8860b", "#c71585"]


def _patch(geom, **kw):
    polys = [geom] if isinstance(geom, Polygon) else list(getattr(geom, "geoms", []))
    verts, codes = [], []
    for p in polys:
        if not isinstance(p, Polygon) or p.is_empty:
            continue
        for ring in [p.exterior, *p.interiors]:
            xs = list(ring.coords)
            verts += xs
            codes += [MplPath.MOVETO] + [MplPath.LINETO] * (len(xs) - 2) + [MplPath.CLOSEPOLY]
    if not verts:
        return None
    return PathPatch(MplPath(verts, codes), **kw)


def render_region(board: Board, region, rf_nets: list[str], ports=None, title: str = "",
                  layers=("F.Cu", "In1.Cu"), out: str = "region.png", ground: str = "GND",
                  label_parts: bool = True, dpi: int = 160):
    if not isinstance(region, (Polygon, MultiPolygon)):
        region = box(*region)
    x0, y0, x1, y1 = region.bounds
    n = len(layers)
    fig, axes = plt.subplots(1, n, figsize=(6.2 * n, 6.2 * (y1 - y0) / (x1 - x0) + 0.8), squeeze=False)
    colors = {net: PALETTE[i % len(PALETTE)] for i, net in enumerate(rf_nets)}
    for ax, layer in zip(axes[0], layers):
        items = board.copper(layer, region=region)
        by_net: dict[str, list] = {}
        for net, g in items:
            by_net.setdefault(net, []).append(g)
        for net, gs in by_net.items():
            geom = unary_union(gs)
            if net == ground:
                kw = dict(facecolor="#c8c8c8", edgecolor="#9a9a9a", lw=0.3)
            elif net in colors:
                kw = dict(facecolor=colors[net], edgecolor="black", lw=0.3, alpha=0.9)
            else:
                kw = dict(facecolor="#f2d39b", edgecolor="#b08a3a", lw=0.3)
            p = _patch(geom, **kw)
            if p is not None:
                ax.add_patch(p)
        # vias
        for v in board.vias:
            if region.contains(box(v.x - 1e-3, v.y - 1e-3, v.x + 1e-3, v.y + 1e-3)) and board.via_on_layer(v, layer):
                ax.add_patch(plt.Circle((v.x, v.y), v.drill / 2, color="white", ec="black", lw=0.3, zorder=3))
        if label_parts and layer in ("F.Cu", "B.Cu"):
            side = "F" if layer == "F.Cu" else "B"
            for f in board.footprints:
                if f.side == side and x0 < f.x < x1 and y0 < f.y < y1 and f.ref[0] != "T":
                    ax.text(f.x, f.y, f.ref + (" DNP" if f.dnp else ""), fontsize=6, ha="center", va="center",
                            color="black", zorder=5,
                            bbox=dict(boxstyle="round,pad=0.1", fc="white", ec="none", alpha=0.75))
        if ports and layer == "F.Cu":
            for i, (ref, pad, _net) in enumerate(ports, 1):
                p = board.footprint(ref).pad(pad)
                ax.plot(p.x, p.y, marker="o", ms=7, mfc="none", mec="red", mew=1.4, zorder=6)
                ax.text(p.x, p.y - 0.35, f"P{i}", color="red", fontsize=7, ha="center", zorder=6, weight="bold")
        ax.set_xlim(x0, x1)
        ax.set_ylim(y1, y0)  # KiCad y down
        ax.set_aspect("equal")
        ax.set_title(f"{layer}", fontsize=10)
        ax.set_xlabel("x / mm")
        ax.set_ylabel("y / mm")
        ax.grid(True, lw=0.2, alpha=0.5)
    handles = [plt.Line2D([], [], color=c, lw=6, label=n.split("/")[-1]) for n, c in colors.items()
               if any(n == net for net, _ in board.copper(layers[0], region=region))]
    handles.append(plt.Line2D([], [], color="#c8c8c8", lw=6, label=ground))
    fig.legend(handles=handles, loc="lower center", ncol=min(6, len(handles)), fontsize=7, frameon=False)
    fig.suptitle(title, fontsize=11)
    fig.tight_layout(rect=(0, 0.08, 1, 0.96))
    fig.savefig(out, dpi=dpi)
    plt.close(fig)
    return out


def render_model(model, out: str = "model.png", layer: str = "F.Cu", show_mesh: bool = True, dpi: int = 160,
                 external: list[str] | None = None):
    """Top view of an OpenEMSModel: copper sheets on ``layer``, vias, ports, mesh."""
    fig, ax = plt.subplots(figsize=(8, 8 * (model.y[-1] - model.y[0]) / (model.x[-1] - model.x[0]) + 0.5))
    nets = sorted({n for n, _ in model.sheets.get(layer, [])})
    cols = {n: PALETTE[i % len(PALETTE)] for i, n in enumerate(nets)}
    for n, p in model.sheets.get(layer, []):
        kw = dict(facecolor="#c8c8c8", edgecolor="#777", lw=0.4) if n == model.ground else \
             dict(facecolor=cols[n], edgecolor="black", lw=0.4, alpha=0.85)
        pa = _patch(p, **kw)
        if pa is not None:
            ax.add_patch(pa)
    rx, ry = model.region.exterior.xy if isinstance(model.region, Polygon) else model.region.envelope.exterior.xy
    ax.plot(rx, ry, color="tab:green", lw=1.0, ls="--", label="region / dielectric")
    for _, vx, vy, r, *_ in model.vias:
        ax.add_patch(plt.Circle((vx, vy), r, color="white", ec="black", lw=0.4, zorder=3))
    for lm in getattr(model, "lumped", []):
        x0, y0, x1, y1 = lm["box"]
        ax.add_patch(plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fc="#f2a900", ec="#8a5f00", lw=1.0, alpha=0.8, zorder=6))
        ax.text(x1 + 0.1, y1, f"{lm['ref']} (in EM)", color="#8a5f00", fontsize=7, zorder=6)
    ext = list(external or [])
    EXT_STYLE = [("IN", "#1a9e3f"), ("OUT", "#1a6fdb")]
    for p in model.ports:
        if p.name in ext:
            tag, col = EXT_STYLE[min(ext.index(p.name), 1)]
            ax.add_patch(plt.Rectangle((p.x0, p.y0), p.x1 - p.x0, p.y1 - p.y0, fc=col, ec=col, lw=2.0, alpha=0.35, zorder=6))
            ax.add_patch(plt.Rectangle((p.x0, p.y0), p.x1 - p.x0, p.y1 - p.y0, fc="none", ec=col, lw=2.0, zorder=6))
            ax.text(p.x1 + 0.1, p.y0, f"{tag} {p.name}", color=col, fontsize=9, zorder=7, weight="bold",
                    bbox=dict(fc="white", ec=col, lw=0.8, pad=1.5, alpha=0.9))
        elif p.termination:
            ax.add_patch(plt.Rectangle((p.x0, p.y0), p.x1 - p.x0, p.y1 - p.y0, fc="none", ec="#888", lw=1.0, ls="--", zorder=5))
            ax.text(p.x1 + 0.1, p.y0, f"term. {p.name}", color="#777", fontsize=7, zorder=5)
        elif getattr(p, "gap", False):  # port across a part: the gap between its pads
            e = 0.06
            ax.add_patch(plt.Rectangle((p.x0 - e, p.y0 - e), p.x1 - p.x0 + 2 * e, p.y1 - p.y0 + 2 * e, fc="red",
                                       ec="red", lw=1.2, alpha=0.35, zorder=5))
            ax.text(max(p.x1, p.x0) + 0.25, p.y0, f"P{p.number} {p.ref}", color="red", fontsize=8, zorder=5, weight="bold")
        else:
            ax.add_patch(plt.Rectangle((p.x0, p.y0), p.x1 - p.x0, p.y1 - p.y0, fc="none", ec="red", lw=1.2, zorder=5))
            ax.text(p.x1 + 0.1, p.y0, f"P{p.number} {p.name}", color="red", fontsize=8, zorder=5, weight="bold")
    if show_mesh:
        for x in model.x:
            ax.axvline(x, color="tab:blue", lw=0.15, alpha=0.6)
        for y in model.y:
            ax.axhline(y, color="tab:blue", lw=0.15, alpha=0.6)
    ax.set_xlim(model.x[0], model.x[-1])
    ax.set_ylim(model.y[-1], model.y[0])
    ax.set_aspect("equal")
    ax.set_xlabel("x / mm")
    ax.set_ylabel("y / mm")
    handles = [plt.Line2D([], [], color=c, lw=6, label=n.split("/")[-1]) for n, c in cols.items() if n != model.ground]
    if ext:
        handles += [plt.Line2D([], [], color=c, marker="s", lw=0, ms=8, label=lab) for (t, c), lab in
                    zip(EXT_STYLE, ("input port", "output port"))][:len(ext)]
        handles.append(plt.Line2D([], [], color="red", marker="s", mfc="none", lw=0, ms=8, label="part port"))
    ax.legend(handles=handles, fontsize=7, loc="upper right")
    ax.set_title(f"openEMS model, {layer}: {len(model.x)}x{len(model.y)}x{len(model.z)} mesh lines", fontsize=10)
    fig.tight_layout()
    fig.savefig(out, dpi=dpi)
    plt.close(fig)
    return out
