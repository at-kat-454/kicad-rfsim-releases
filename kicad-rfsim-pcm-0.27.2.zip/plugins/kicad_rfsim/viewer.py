"""Self-contained HTML tuning viewer.

The EM layout admittance matrix and the part stamps are embedded as JSON.
JavaScript repeats the circuit-layer math (stamp, Kron reduction, Y->S), so
sliders update instantly without Python running. "Export values" downloads
a JSON file that the KiCad plugin applies to the footprints.
"""
from __future__ import annotations

import json
from pathlib import Path


from .circuit import DEFAULT_ESL, DEFAULT_Q, Circuit
from .tune import E24

PLOTLY = "https://cdnjs.cloudflare.com/ajax/libs/plotly.js/2.35.2/plotly.min.js"


def _series(kind: str) -> list[float]:
    dec = [1e-13, 1e-12, 1e-11, 1e-10] if kind == "C" else [1e-10, 1e-9, 1e-8, 1e-7]
    vals = sorted(v * d for d in dec for v in E24)
    lo, hi = (0.1e-12, 100e-12) if kind == "C" else (0.5e-9, 100e-9)
    return [float(f"{v:.3g}") for v in vals if lo <= v <= hi]


def _plotly_tag(page=None) -> str:
    """plotly.js: shared next to the project's pages (``page``), or inlined (no page)."""
    from .pagepack import plotly_tag
    return plotly_tag(page)


# value offered when a part that is not fitted (DNP / no value) is switched to "fitted"
_DEFAULT_FIT = {"C": 1.0e-12, "L": 2.2e-9}


def write_viewer(c: Circuit, external: list[str], path: str | Path, title: str = "RF tuning",
                 tunable: list[str] | None = None, marks_hz=(868e6, 1736e6, 2604e6), board_name: str = "",
                 load: dict | None = None, kind_hints: dict[str, str] | None = None,
                 sizes: dict[str, str] | None = None, vendor: dict | None = None,
                 source: tuple[float, float] | None = None, band=None):
    """``band``: the board's operating band [[lo, hi], ...] in MHz (preselected in the page).
    ``kind_hints``: ref -> "C" / "L" / "R" from the footprint. Every C / L place (fitted, not fitted or
    0 ohm) can be switched between a capacitor and an inductor in the viewer; a value whose kind differs
    from the footprint is exported with its unit ("5.6nH"), which the next run reads back.
    ``sizes``: ref -> footprint size ("0402"); ``vendor``: vendor.viewer_payload() - real part
    impedances on the simulation frequencies, selectable instead of the ideal part model.
    ``source``: (R, X) the chip wants to see at port 1 (datasheet "optimum load impedance");
    the match is then judged against it instead of 50 ohm (editable in the page)."""
    from .circuit import DEFAULT_ESL as _ESL
    from .circuit import DEFAULT_Q as _Q
    Y = c.Y_em.copy()
    for _ref, (nodes, Yn) in c.nports.items():  # vendor N-port models: fixed, part of the layout network
        ii = [c.idx[n] for n in nodes]
        for r, a in enumerate(ii):
            for q, b in enumerate(ii):
                Y[:, a, b] += Yn[:, r, q]
    hints = kind_hints or {}
    parts = []
    for ref, (a, b, el) in c.parts.items():
        kind, value, q, esl, esr, mode = el.kind, el.value, el.q, el.esl, el.esr, "fit"
        alt = []
        if el.kind in ("open", "short"):
            # not fitted / 0 ohm bridge in the design: the place can take a C or an L - offered as both,
            # starting with the footprint's own kind (a C footprint as C, else L for an R / jumper footprint
            # only if the footprint says L)
            mode = el.kind
            h = hints.get(ref)
            k0 = h if h in ("C", "L") else "C"
            kind, value, q = k0, _DEFAULT_FIT[k0], _Q[k0]
            esl, esr = _ESL.get(k0, 0.0), 0.0
            alt = ["C", "L"]
        tun = kind in ("C", "L")
        if tun and ((tunable is None) or ref in tunable):  # a fitted C can be tried as an L and the reverse
            alt = ["C", "L"]
        parts.append({
            "ref": ref, "a": a, "b": b, "kind": kind, "value": value, "q": q, "fq": el.f_q,
            "esl": esl, "esr": esr, "mode": mode,
            "series": _series(kind) if kind in ("C", "L") else [],
            "tunable": (tunable is None and tun) or (tunable is not None and ref in tunable),
            "label": el.label(), "size": (sizes or {}).get(ref), "alt": alt, "hint": hints.get(ref),
        })
    data = {
        "title": title, "board": board_name,
        "f": c.freq.tolist(), "nodes": c.port_names, "external": external,
        "Yre": Y.real.round(12).tolist(), "Yim": Y.imag.round(12).tolist(),
        "parts": parts, "marks": list(marks_hz),
        "defaults": {"Q": DEFAULT_Q, "ESL": DEFAULT_ESL, "fit": _DEFAULT_FIT},
        "series": {"C": _series("C"), "L": _series("L")},
        "load": load, "vendor": vendor or {},
        "source": list(source) if source else None,
        "band": [[lo * 1e6, hi * 1e6] for lo, hi in band] if band else None,
    }
    from .bands import js as _bands_js
    from .pagepack import pack_page
    html = _TEMPLATE.replace("__TITLE__", title).replace("__BANDSJS__", _bands_js())
    html = pack_page(html.replace('<script src="__PLOTLY__"></script>', _plotly_tag(path)), data)
    Path(path).write_text(html, encoding="utf-8")
    return path


_TEMPLATE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<script src="__PLOTLY__"></script>
<style>
:root{--bg:#fafaf8;--fg:#1d1d1b;--mut:#6b6b66;--card:#fff;--line:#e3e2dc;--acc:#2a6fdb;--warn:#c4521b}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff;--warn:#ff8a50}}
:root[data-theme="dark"]{--bg:#181816;--fg:#ecebe6;--mut:#a3a29b;--card:#22221f;--line:#3a3934;--acc:#6aa3ff;--warn:#ff8a50}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 system-ui,sans-serif}
header{padding:14px 16px;border-bottom:1px solid var(--line)}h1{font-size:17px;margin:0}
.sub{color:var(--mut);font-size:12px}
main{display:grid;grid-template-columns:340px 1fr;gap:14px;padding:14px 16px}
@media(max-width:860px){main{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px}
.part{display:grid;grid-template-columns:18px 40px 1fr 66px 92px;align-items:center;gap:6px;margin:6px 0}
.part .lk{margin:0;accent-color:var(--warn)}
.part select{font:inherit;font-size:12px;width:100%}.part.off b,.part.off .val{opacity:.55}
.part b{font-variant-numeric:tabular-nums}.part input{width:100%}
.val{text-align:right;font-variant-numeric:tabular-nums}.chg{color:var(--warn)}
table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;font-size:13px}
td,th{padding:3px 6px;border-bottom:1px solid var(--line);text-align:right}th:first-child,td:first-child{text-align:left}
button{background:var(--acc);color:#fff;border:0;border-radius:6px;padding:7px 12px;cursor:pointer;margin:4px 6px 0 0}
button.sec{background:transparent;color:var(--acc);border:1px solid var(--acc)}
.plots{display:grid;grid-template-columns:1fr 1fr;gap:14px}@media(max-width:1100px){.plots{grid-template-columns:1fr}}
.plot{height:340px}.wide{grid-column:1/-1}
.viewbar{display:flex;flex-wrap:wrap;gap:6px 16px;align-items:center;margin-bottom:14px;font-size:12px;color:var(--mut)}
.viewbar label{display:flex;gap:6px;align-items:center}.viewbar select,.viewbar input{font:inherit;font-size:12px}
.cols{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:12px;color:var(--mut);margin:6px 0}.cols label{display:flex;gap:4px;align-items:center}
td.bad{color:var(--warn)}td.good{color:#2f8f4e}
label.opt{display:flex;gap:6px;align-items:center;font-size:12px;color:var(--mut);margin-top:6px}
</style></head><body>
<header><a class="sinfo" href="solver_info.html" style="float:right;font-size:12px;color:var(--acc)">How this was solved →</a><h1 id="t"></h1><div class="sub" id="s"></div></header>
<main>
<section class="card"><div style="font-weight:600">Components</div>
<details class="sub"><summary>How the parts work</summary>Ideal parts snap to the E24 series, vendor parts to the
values of the selected series. Layout parasitics come from the EM run. Per part: <i>fitted as C</i> (capacitor), <i>fitted as L</i> (inductor),
<i>not fitted</i> (removed, open) or <i>0 Ω</i> (bridged). A place can change between C and L: the value starts at
1 pF / 2.2 nH and the board gets the value with its unit (e.g. 5.6nH). The box in front locks a part: autotune does not change it.</details>
<div id="vbox" style="display:none;margin:8px 0;padding:8px;border:1px solid var(--line);border-radius:6px">
<label class="opt" style="margin-top:0">Part models <select id="pmodel" style="flex:1;min-width:0"><option value="ideal">ideal (value, Q, ESL)</option>
<option value="vendor">vendor parts (measured S-parameters)</option></select></label>
<label class="opt" id="vsCrow">C series <select id="vsC" style="flex:1;min-width:0"></select></label>
<label class="opt" id="vsLrow">L series <select id="vsL" style="flex:1;min-width:0"></select></label>
<div class="sub" id="vinfo"></div></div>
<div id="parts"></div>
<label class="opt"><input type="checkbox" id="showref" checked> show initial values as reference</label>
<div id="srcbox" style="margin-top:10px"><div style="font-weight:600">Target at port 1</div>
<div class="sub">the impedance the chip wants to see at its RF pin (datasheet: optimum load impedance); the match is judged against it</div>
<label class="opt"><input type="radio" name="sr" id="sr50" checked> 50 Ω</label>
<label class="opt"><input type="radio" name="sr" id="src"> R <input id="sr" type="number" value="50" step="0.5" style="width:70px"> Ω &nbsp; X <input id="sx" type="number" value="0" step="0.5" style="width:70px"> Ω</label></div>
<div id="loadbox" style="margin-top:10px"><div style="font-weight:600">Load at port 2</div>
<div class="sub">e.g. antenna impedance (measured or simulated) at the design frequency</div>
<label class="opt" id="simrow" style="display:none"><input type="radio" name="ld" id="ldsim" checked> simulated antenna <span id="simname"></span></label>
<label class="opt"><input type="radio" name="ld" id="ldc"> R <input id="lr" type="number" value="50" step="0.5" style="width:70px"> Ω &nbsp; X <input id="lx" type="number" value="0" step="0.5" style="width:70px"> Ω</label></div>
<div id="atbox" style="margin-top:12px;border-top:1px solid var(--line);padding-top:10px">
<div style="font-weight:600">Autotune</div>
<div class="sub">Searches the values of the tunable parts - E24 or the real vendor parts, as selected above (and optionally removing / bridging parts).</div>
<label class="opt">Band <input id="atlo" type="number" step="0.5" style="width:72px"> – <input id="athi" type="number" step="0.5" style="width:72px"> MHz</label>
<label class="opt">Goal <select id="atgoal" style="flex:1;min-width:0"><option value="match">best match (worst S11 in band)</option>
<option value="power">most power into the load</option>
<option value="robust">robust (antenna detuned ±3 %)</option></select></label>
<label class="opt">C / L <select id="atkind" style="flex:1;min-width:0"><option value="keep">keep each part as set (change by hand)</option>
<option value="free">autotune chooses C or L per part</option></select></label>
<label class="opt"><input type="checkbox" id="attopo"> also try "not fitted" and "0 Ω" for each part</label>
<div style="margin-top:6px"><button id="atrun">Autotune</button><span class="sub" id="atmsg" style="margin-left:8px"></span></div></div>
<div style="margin-top:8px"><button id="exp">Export values</button><button class="sec" id="reset">Reset</button></div>
</section>
<section>
<div class="card viewbar">
<label>Band <select id="band" style="max-width:240px"></select></label>
<label>Frequency <select id="span"><option value="full">full sweep</option><option value="5">marker ±5 %</option>
<option value="20" selected>marker ±20 %</option><option value="band">band ±15 %</option><option value="custom">custom</option></select></label>
<label id="custrow" style="display:none"><input id="flo" type="number" step="1" style="width:70px"> – <input id="fhi" type="number" step="1" style="width:70px"> MHz</label>
<label>Show <select id="qty"><option value="db">|S| in dB</option><option value="lin">|S| linear</option>
<option value="vswr">VSWR</option><option value="rl">return loss (dB)</option><option value="ml">mismatch loss (dB)</option></select></label>
<label>Y axis <select id="yr"><option value="auto">auto</option><option value="10">0 … −10 dB</option><option value="20">0 … −20 dB</option>
<option value="40">0 … −40 dB</option><option value="60" selected>0 … −60 dB</option></select></label>
<label>Markers <input id="mk" style="width:150px" title="frequencies in MHz, separated by commas"> MHz</label>
<label title="Touchstone file of a VNA measurement (s1p: S11; s2p: S11, S21, S22), drawn over the simulation">Measurement <input type="file" id="meas" accept=".s1p,.s2p,.S1P,.S2P,.txt" style="max-width:190px"></label><span id="measinfo"></span>
</div>
<div class="plots"><div class="card"><div id="p1" class="plot"></div></div><div class="card"><div id="p3" class="plot"></div></div>
<div class="card"><div id="p2" class="plot"></div></div>
<div class="card"><div style="font-weight:600">At the markers</div><div class="cols" id="cols"></div><table id="tab"></table>
<div class="sub" id="bandsum" style="margin:6px 0"></div>
<div><button class="sec" id="copy">Copy table</button><button class="sec" id="csv">Download sweep (CSV)</button><button class="sec" id="ts" title="S-parameters of the matching network with the current values, ports as in the title, 50 Ω">Touchstone (current values)</button><button class="sec" id="tsin" title="Reflection at port 1 with the load at port 2 (antenna or R + jX), 50 Ω">Input with load (.s1p)</button><span class="sub" id="cpmsg"></span></div></div></div>
</section>
</main>
<script>__BANDSJS__
const D=__DATA__;
document.getElementById('t').textContent=D.title;
document.getElementById('s').textContent=(D.board?D.board+' · ':'')+'ports '+D.external.join(' → ')+' · '+D.nodes.length+' EM nodes';
const nF=D.f.length,N=D.nodes.length,idx={};const ALLK=[...Array(D.f.length).keys()];D.nodes.forEach((n,i)=>idx[n]=i);
const ext=D.external.map(n=>idx[n]),int=[...Array(N).keys()].filter(i=>!ext.includes(i));
const init={};D.parts.forEach(p=>init[p.ref]=p.value);const cur={...init};
const mode0={};D.parts.forEach(p=>mode0[p.ref]=p.mode||'fit');const mode={...mode0};
// ---- part models: ideal (value, Q, ESL) or vendor parts (measured impedance per frequency)
let VM='ideal';const VSEL={C:null,L:null};
function vgroups(p){const g=D.vendor&&D.vendor[p.kind]&&p.size&&D.vendor[p.kind][p.size];return g&&g.length?g:null}
function vgroup(p){const g=vgroups(p);if(!g)return null;return g.find(x=>x.series===VSEL[p.kind])||g[0]}
function vlist(p){if(VM!=='vendor')return null;const g=vgroup(p);return g?g.parts:null}
function seriesOf(p){const l=vlist(p);return l?l.map(x=>x.v):p.series}
function vpart(p,v){const l=vlist(p);if(!l||!v)return null;for(const x of l)if(Math.abs(x.v/v-1)<1e-6)return x;return null}
function zEl(p,v,f,m,k){const w=2*Math.PI*f;let re=0,im=0;
 if(m==='open')return null;
 if(m==='short')return[0.02,w*0.3e-9];// 0 ohm bridge (0402 jumper)
 if(VM==='vendor'&&k!==undefined&&(p.kind==='C'||p.kind==='L')){const x=vpart(p,v);if(x)return[x.zr[k],x.zi[k]]}
 if(p.kind==='C'){re=p.esr+(p.q?1/(2*Math.PI*p.fq*v*p.q):0);im=-1/(w*v)+w*p.esl}
 else if(p.kind==='L'){re=p.esr+(p.q?2*Math.PI*p.fq*v/p.q:0);im=w*v}
 else if(p.kind==='R'){re=v;im=w*p.esl}else if(p.kind==='short'){re=p.esr;im=w*p.esl}else return null;return[re,im]}
function inv(z){const d=z[0]*z[0]+z[1]*z[1];return[z[0]/d,-z[1]/d]}
function cmul(a,b){return[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]]}
function solveC(Are,Aim,Bre,Bim,n,m){// Gaussian elimination, A n×n, B n×m (in place)
 for(let k=0;k<n;k++){let piv=k,best=-1;for(let r=k;r<n;r++){const a=Are[r*n+k]**2+Aim[r*n+k]**2;if(a>best){best=a;piv=r}}
  if(piv!==k){for(let c=0;c<n;c++){[Are[k*n+c],Are[piv*n+c]]=[Are[piv*n+c],Are[k*n+c]];[Aim[k*n+c],Aim[piv*n+c]]=[Aim[piv*n+c],Aim[k*n+c]]}
   for(let c=0;c<m;c++){[Bre[k*m+c],Bre[piv*m+c]]=[Bre[piv*m+c],Bre[k*m+c]];[Bim[k*m+c],Bim[piv*m+c]]=[Bim[piv*m+c],Bim[k*m+c]]}}
  const ip=inv([Are[k*n+k],Aim[k*n+k]]);
  for(let r=0;r<n;r++){if(r===k)continue;const fct=cmul([Are[r*n+k],Aim[r*n+k]],ip);if(fct[0]===0&&fct[1]===0)continue;
   for(let c=k;c<n;c++){const t=cmul(fct,[Are[k*n+c],Aim[k*n+c]]);Are[r*n+c]-=t[0];Aim[r*n+c]-=t[1]}
   for(let c=0;c<m;c++){const t=cmul(fct,[Bre[k*m+c],Bim[k*m+c]]);Bre[r*m+c]-=t[0];Bim[r*m+c]-=t[1]}}}
 for(let r=0;r<n;r++){const ip=inv([Are[r*n+r],Aim[r*n+r]]);for(let c=0;c<m;c++){const t=cmul([Bre[r*m+c],Bim[r*m+c]],ip);Bre[r*m+c]=t[0];Bim[r*m+c]=t[1]}}}
function compute(vals,modes,ks){modes=modes||mode;const E=ext.length,I=int.length,out=[];
 for(const k of (ks||ALLK)){const f=D.f[k];const Yr=D.Yre[k].map(r=>r.slice()),Yi=D.Yim[k].map(r=>r.slice());
  for(const p of D.parts){const z=zEl(p,vals[p.ref],f,modes[p.ref],k);if(!z)continue;const y=inv(z);const a=idx[p.a];
   Yr[a][a]+=y[0];Yi[a][a]+=y[1];if(p.b!==null){const b=idx[p.b];Yr[b][b]+=y[0];Yi[b][b]+=y[1];Yr[a][b]-=y[0];Yi[a][b]-=y[1];Yr[b][a]-=y[0];Yi[b][a]-=y[1]}}
  const Rr=[],Ri=[];for(let i=0;i<E;i++){Rr.push([]);Ri.push([]);for(let j=0;j<E;j++){Rr[i].push(Yr[ext[i]][ext[j]]);Ri[i].push(Yi[ext[i]][ext[j]])}}
  if(I){const Ar=new Float64Array(I*I),Ai=new Float64Array(I*I),Br=new Float64Array(I*E),Bi=new Float64Array(I*E);
   for(let r=0;r<I;r++){for(let c=0;c<I;c++){Ar[r*I+c]=Yr[int[r]][int[c]];Ai[r*I+c]=Yi[int[r]][int[c]]}for(let c=0;c<E;c++){Br[r*E+c]=Yr[int[r]][ext[c]];Bi[r*E+c]=Yi[int[r]][ext[c]]}}
   solveC(Ar,Ai,Br,Bi,I,E);
   for(let i=0;i<E;i++)for(let j=0;j<E;j++){let sr=0,si=0;for(let r=0;r<I;r++){const t=cmul([Yr[ext[i]][int[r]],Yi[ext[i]][int[r]]],[Br[r*E+j],Bi[r*E+j]]);sr+=t[0];si+=t[1]}Rr[i][j]-=sr;Ri[i][j]-=si}}
  // S = (I - A)(I + A)^-1, A = 50*Y (E = 1 or 2)
  const A=Rr.map((r,i)=>r.map((v,j)=>[50*v,50*Ri[i][j]]));
  if(E===1){const n=[1-A[0][0][0],-A[0][0][1]],d=[1+A[0][0][0],A[0][0][1]];out.push([[cmul(n,inv(d))]])}
  else{const a=[1+A[0][0][0],A[0][0][1]],b=A[0][1],c=A[1][0],d=[1+A[1][1][0],A[1][1][1]];
   const det=[cmul(a,d)[0]-cmul(b,c)[0],cmul(a,d)[1]-cmul(b,c)[1]],id=inv(det);
   const Pi=[[cmul(d,id),cmul([-b[0],-b[1]],id)],[cmul([-c[0],-c[1]],id),cmul(a,id)]];
   const M=[[[1-A[0][0][0],-A[0][0][1]],[-A[0][1][0],-A[0][1][1]]],[[-A[1][0][0],-A[1][0][1]],[1-A[1][1][0],-A[1][1][1]]]];
   const S=[[0,0],[0,0]].map((r,i)=>r.map((_,j)=>{const x=cmul(M[i][0],Pi[0][j]),y=cmul(M[i][1],Pi[1][j]);return[x[0]+y[0],x[1]+y[1]]}));out.push(S)}}
 return out}
const db=z=>20*Math.log10(Math.hypot(z[0],z[1])+1e-15);
function fmt(p,v){// 3 significant digits without trailing zeros after the point (10 stays 10)
 const n=x=>String(parseFloat(x.toPrecision(3)));if(p.kind==='C')return n(v*1e12)+' pF';if(p.kind==='L')return n(v*1e9)+' nH';return p.label}
const box=document.getElementById('parts');
const MODES=[['fit','fitted'],['open','not fitted'],['short','0 Ω']];
// a C / L place (fitted, not fitted or 0 ohm in the design) can be fitted as a C or an L ("alt" kinds)
const kind0={},prop0={},lastV={};D.parts.forEach(p=>{kind0[p.ref]=p.kind;prop0[p.ref]=[p.q,p.esl,p.esr];lastV[p.ref]={}});
// loss model of a part as kind k: the design's own for its own kind, the defaults for the other kind
function kprops(p,k){return k===kind0[p.ref]?prop0[p.ref]:[D.defaults.Q[k],D.defaults.ESL[k]||0,0]}
function seriesK(p,k){const k0=p.kind;p.kind=k;const l=vlist(p);p.kind=k0;return l?l.map(x=>x.v):D.series[k]}
function setKind(p,k){if(!p.alt||!p.alt.length||p.kind===k)return;lastV[p.ref][p.kind]=cur[p.ref];
 p.kind=k;p.series=D.series[k];[p.q,p.esl,p.esr]=kprops(p,k);p.fq=p.fq||868e6;
 const own=k===kind0[p.ref]&&mode0[p.ref]==='fit';   // back to the design's kind: its value again
 const want=lastV[p.ref][k]||(own?init[p.ref]:D.defaults.fit[k]);const sr=seriesOf(p);
 cur[p.ref]=(own&&want===init[p.ref]&&VM!=='vendor')?want:sr.reduce((b,x)=>Math.abs(Math.log(x/want))<Math.abs(Math.log(b/want))?x:b,sr[0])}
function modeKey(p){const m=mode[p.ref];return m==='fit'&&p.alt&&p.alt.length?'fit:'+p.kind:m}
function modeKey0(p){const m=mode0[p.ref];return m==='fit'&&p.alt&&p.alt.length?'fit:'+kind0[p.ref]:m}
D.parts.forEach(p=>{const row=document.createElement('div');row.className='part';
 const canFit=p.kind==='C'||p.kind==='L'||p.kind==='R';
 const M=p.alt&&p.alt.length?[...p.alt.map(k=>['fit:'+k,'fitted as '+k]),['open','not fitted'],['short','0 Ω']]:MODES.filter(([m])=>m!=='fit'||canFit);
 const opts=M.map(([m,t])=>`<option value="${m}"${m===modeKey0(p)?' selected':''}>${t}</option>`).join('');
 const sel=`<select title="fitted as capacitor / inductor, removed or bridged">${opts}</select>`;
 const nearIdx=(s,v)=>s.reduce((bi,x,i)=>Math.abs(Math.log(x/v))<Math.abs(Math.log(s[bi]/v))?i:bi,0);
 const tip=(v)=>{if(VM!=='vendor'||!(p.kind==='C'||p.kind==='L'))return'';const x=vpart(p,v);
  return x?`${x.pn} · Q ${x.q} at 868 MHz · SRF ${x.srf?x.srf+' MHz':'above the data'}`:'ideal model: value not in the selected vendor series'};
 if(p.tunable&&p.series.length){const i0=nearIdx(p.series,p.value);
  row.innerHTML=`<input type="checkbox" class="lk" title="lock: autotune keeps this part"><b>${p.ref}</b><input type="range" min="0" max="${p.series.length-1}" value="${i0}"><span class="val"></span>${sel}`;
  const r=row.querySelector('input[type=range]'),s=row.querySelector('.val');
  p._set=()=>{const m=mode[p.ref];r.disabled=m!=='fit';row.classList.toggle('off',m!=='fit');
   s.textContent=m==='open'?'removed':m==='short'?'0 Ω':fmt(p,cur[p.ref]);s.title=m==='fit'?tip(cur[p.ref]):'';
   s.style.fontStyle=(m==='fit'&&VM==='vendor'&&!vpart(p,cur[p.ref]))?'italic':'';
   s.classList.toggle('chg',cur[p.ref]!==init[p.ref]||m!==mode0[p.ref]||(m==='fit'&&p.kind!==kind0[p.ref]))};
  // other part model / series: same slider, other value list; snap to the nearest available value
  p._rebuild=()=>{const sr=seriesOf(p);r.max=sr.length-1;const i=nearIdx(sr,cur[p.ref]);cur[p.ref]=sr[i];r.value=i;p._set()};
  r.oninput=()=>{cur[p.ref]=seriesOf(p)[+r.value];p._set();update()};
  p._reset=()=>{if(p.alt&&p.alt.length&&p.kind!==kind0[p.ref]){setKind(p,kind0[p.ref]);p._rebuild()}
   lastV[p.ref]={};const sr=seriesOf(p),i=nearIdx(sr,init[p.ref]);r.value=i;cur[p.ref]=VM==='vendor'?sr[i]:init[p.ref];mode[p.ref]=mode0[p.ref];row.querySelector('select').value=modeKey0(p);p._set()}}
 else{row.innerHTML=`<span></span><b>${p.ref}</b><span class="sub">fixed</span><span class="val">${p.label}</span>${sel}`;const s=row.querySelector('.val');
  p._set=()=>{const m=mode[p.ref];row.classList.toggle('off',m==='open');s.textContent=m==='open'?'removed':m==='short'?'0 Ω':p.label;s.title=m==='fit'?tip(p.value):'';s.classList.toggle('chg',m!==mode0[p.ref])};
  p._reset=()=>{mode[p.ref]=mode0[p.ref];row.querySelector('select').value=mode0[p.ref];p._set()}}
 row.querySelector('select').onchange=e=>{const v=e.target.value;
  if(v.startsWith('fit:')){const k=v.slice(4);mode[p.ref]='fit';if(p.kind!==k){setKind(p,k);if(p._rebuild)p._rebuild()}}
  else mode[p.ref]=v;p._set();update()};p._set();
 const lk=row.querySelector('.lk');if(lk)lk.onchange=()=>{p.locked=lk.checked;row.title=lk.checked?'locked for autotune':''};
 box.appendChild(row)});
let ref0=compute(init,mode0);const css=getComputedStyle(document.documentElement);
// vendor part selection
(function(){const kinds={C:new Set(),L:new Set()};
 D.parts.forEach(p=>{(p.alt&&p.alt.length?p.alt:[p.kind]).forEach(k=>{const g=(k==='C'||k==='L')&&p.size&&D.vendor[k]&&D.vendor[k][p.size];if(g)g.forEach(x=>kinds[k].add(x.series+'|'+x.label))})});
 if(!kinds.C.size&&!kinds.L.size)return;document.getElementById('vbox').style.display='block';
 ['C','L'].forEach(k=>{const el=document.getElementById('vs'+k);if(!kinds[k].size){document.getElementById('vs'+k+'row').style.display='none';return}
  [...kinds[k]].forEach(t=>{const [s,l]=t.split('|');el.add(new Option(l,s))});
  const pref=k==='C'?['GJM15','GJM03','GJM18']:['LQW15AN_80','LQW15AN_00','LQW18AN_00'];const hit=pref.find(x=>[...el.options].some(o=>o.value===x));if(hit)el.value=hit;VSEL[k]=el.value;el.onchange=setVM});
 document.getElementById('pmodel').onchange=setVM})();
function vinfo(){const el=document.getElementById('vinfo');if(VM!=='vendor'){el.textContent='Values snap to E24; losses from a constant Q, capacitors with 0.3 nH ESL.';return}
 const t=[];['C','L'].forEach(k=>{const p=D.parts.find(x=>x.kind===k&&vgroup(x));if(!p)return;const g=vgroup(p),ps=g.parts;
  t.push(`${k}: ${ps.length} values ${fmt(p,ps[0].v)} – ${fmt(p,ps[ps.length-1].v)}`)});
 el.textContent='Measured impedance of each part (incl. its ESL / SRF and losses). '+t.join(' · ')+'. Hover a value for the part number.'}
function setVM(){VM=document.getElementById('pmodel').value;['C','L'].forEach(k=>{const el=document.getElementById('vs'+k);if(el&&el.value)VSEL[k]=el.value});
 D.parts.forEach(p=>{if(p._rebuild)p._rebuild();else p._set()});ref0=compute(init,mode0);vinfo();update()}
vinfo();
function layout(t,y){return{title:{text:t,font:{size:13}},margin:{l:50,r:10,t:36,b:40},paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
 font:{color:css.getPropertyValue('--fg')},xaxis:{title:'f / GHz',gridcolor:css.getPropertyValue('--line')},yaxis:{title:y,gridcolor:css.getPropertyValue('--line')},
 legend:{orientation:'h',y:-0.25},shapes:D.marks.map(m=>({type:'line',x0:m/1e9,x1:m/1e9,yref:'paper',y0:0,y1:1,line:{width:1,dash:'dot',color:'#999'}}))}}
const fG=D.f.map(x=>x/1e9);
function useSim(){return !!D.load&&document.getElementById('ldsim').checked}
function gL(k){let R,X;if(useSim()){R=D.load.zr[k];X=D.load.zi[k]}else{R=+document.getElementById('lr').value||0;X=+document.getElementById('lx').value||0}
 return cmul([R-50,X],inv([R+50,X]))}
function toLoad(s,k){// transducer gain into the load: available source power (target impedance at port 1) -> load
 if(s.length<2)return null;const gl=gL(k),gs=gS();
 const a=[1-cmul(s[0][0],gs)[0],-cmul(s[0][0],gs)[1]],b=[1-cmul(s[1][1],gl)[0],-cmul(s[1][1],gl)[1]];
 const c=cmul(cmul(s[1][0],s[0][1]),cmul(gs,gl)),ab=cmul(a,b),d=[ab[0]-c[0],ab[1]-c[1]];
 const s21=Math.hypot(...s[1][0])**2,m=1-(gl[0]**2+gl[1]**2),ms=1-(gs[0]**2+gs[1]**2);return s21*m*ms/(d[0]**2+d[1]**2)}
function gin(s,k){// input reflection at port 1 with port 2 loaded
 if(s.length<2)return s[0][0];
 const gl=gL(k);const num=cmul(cmul(s[0][1],s[1][0]),gl);const den=[1-cmul(s[1][1],gl)[0],-cmul(s[1][1],gl)[1]];
 const t=cmul(num,inv(den));return[s[0][0][0]+t[0],s[0][0][1]+t[1]]}
// target impedance at port 1: reflection against it (power waves, source = conj(target))
function zT(){if(!document.getElementById('src').checked)return null;const R=+document.getElementById('sr').value||50,X=+document.getElementById('sx').value||0;return R===50&&X===0?null:[R,X]}
function tgt(g){const zt=zT();if(!zt)return g;const z=zOf(g);return cmul([z[0]-zt[0],z[1]-zt[1]],inv([z[0]+zt[0],z[1]-zt[1]]))}
function gS(){const zt=zT();if(!zt)return[0,0];const zs=[zt[0],-zt[1]];return cmul([zs[0]-50,zs[1]],inv([zs[0]+50,zs[1]]))}
function gT(s,k){return tgt(gin(s,k))}
// ---- measurement (Touchstone) overlay
let MEAS=null;
function parseTS(txt,name){let unit=1e9,fmt='MA',R=50;const nums=[];
 for(let l of txt.split(/\r?\n/)){l=l.split('!')[0].trim();if(!l)continue;
  if(l.startsWith('#')){const t=l.slice(1).trim().toUpperCase().split(/\s+/);t.forEach((w,i)=>{if(w==='HZ')unit=1;else if(w==='KHZ')unit=1e3;else if(w==='MHZ')unit=1e6;else if(w==='GHZ')unit=1e9;
   else if(w==='DB'||w==='MA'||w==='RI')fmt=w;else if(w==='R'&&t[i+1])R=+t[i+1]});continue}
  if(/^\[/.test(l))continue;l.split(/\s+/).forEach(x=>{const v=+x;if(!isNaN(v))nums.push(v)})}
 const np=/s2p$/i.test(name)?2:1,per=1+2*np*np;const out={f:[],s11:[],s21:[],s22:[],np,name};
 const c=(a,b)=>fmt==='RI'?[a,b]:fmt==='MA'?[a*Math.cos(b*Math.PI/180),a*Math.sin(b*Math.PI/180)]:[10**(a/20)*Math.cos(b*Math.PI/180),10**(a/20)*Math.sin(b*Math.PI/180)];
 for(let i=0;i+per<=nums.length;i+=per){out.f.push(nums[i]*unit);let g=c(nums[i+1],nums[i+2]);
  if(R!==50){const z=cmul([1+g[0],g[1]],inv([1-g[0],-g[1]]));const zz=[R*z[0],R*z[1]];g=cmul([zz[0]-50,zz[1]],inv([zz[0]+50,zz[1]]))}
  out.s11.push(g);if(np===2){out.s21.push(c(nums[i+3],nums[i+4]));out.s22.push(c(nums[i+7],nums[i+8]))}}
 return out.f.length?out:null}
document.getElementById('meas').onchange=e=>{const f=e.target.files[0];if(!f)return;const rd=new FileReader();
 rd.onload=()=>{MEAS=parseTS(rd.result,f.name);document.getElementById('measinfo').textContent=MEAS?`${f.name}: ${MEAS.f.length} points ${(MEAS.f[0]/1e6).toFixed(0)}–${(MEAS.f[MEAS.f.length-1]/1e6).toFixed(0)} MHz`:'not a Touchstone file';update()};rd.readAsText(f)};
let marks=D.marks.slice();document.getElementById('mk').value=marks.map(m=>(m/1e6).toFixed(0)).join(', ');
const G=g=>Math.hypot(g[0],g[1]);
const QTY={db:{t:'|S| / dB',f:g=>db(g),ref:true},lin:{t:'|S|',f:g=>G(g)},vswr:{t:'VSWR',f:g=>(1+G(g))/Math.max(1e-9,1-G(g)),refl:true},
 rl:{t:'return loss / dB',f:g=>-db(g),refl:true},ml:{t:'mismatch loss / dB',f:g=>-10*Math.log10(Math.max(1e-12,1-G(g)**2)),refl:true}};
const COLS=[['s11','S11 dB',true],['g','|Γ|',false],['vswr','VSWR',true],['rl','RL dB',false],['ml','mismatch dB',false],
 ['s21','S21 dB',true],['zin','Zin Ω',true],['load','to load',true],['rad','radiated',true]];
const colOn={};const cbox=document.getElementById('cols');
COLS.forEach(([k,t,on])=>{if((k==='s21'||k==='load')&&D.external.length<2)return;if(k==='rad'&&!D.load)return;colOn[k]=on;
 const l=document.createElement('label');l.innerHTML=`<input type="checkbox" ${on?'checked':''}> ${t}`;l.querySelector('input').onchange=e=>{colOn[k]=e.target.checked;update()};cbox.appendChild(l)});
function span(){const v=document.getElementById('span').value;if(v==='full')return[D.f[0],D.f[nF-1]];
 const bd=bandOf(document.getElementById('band'));
 if(v==='band'&&bd){const [lo,hi]=bandEdges(bd),m=Math.max(0.15*(hi-lo),0.01*lo);return[lo-m,hi+m]}
 if(v==='custom'){const lo=+document.getElementById('flo').value*1e6,hi=+document.getElementById('fhi').value*1e6;return[Math.min(lo,hi)||D.f[0],Math.max(lo,hi)||D.f[nF-1]]}
 const m=marks[0]||D.f[Math.floor(nF/2)],r=+v/100;return[m*(1-r),m*(1+r)]}
function zOf(g){const r=cmul([1+g[0],g[1]],inv([1-g[0],-g[1]]));return[50*r[0],50*r[1]]}
let lastRows=[];
function update(){const S0=compute(cur),showRef=document.getElementById('showref').checked;const E=D.external.length;
 const S=S0.map((s,k)=>{const g=gT(s,k);return E>1?[[g,s[0][1]],[s[1][0],s[1][1]]]:[[g]]});
 const Z50=S0.map((s,k)=>gin(s,k));const zt=zT();
 const [lo,hi]=span();const ks=ALLK.filter(k=>D.f[k]>=lo&&D.f[k]<=hi);const KS=ks.length>1?ks:ALLK;
 const q=QTY[document.getElementById('qty').value];const fx=KS.map(k=>D.f[k]/1e9);
 const tr=[{x:fx,y:KS.map(k=>q.f(S[k][0][0])),name:zt?`S11 vs ${zt[0]}${zt[1]>=0?'+':'−'}j${Math.abs(zt[1])} Ω`:'S11 (port 2 loaded)',line:{color:'#2a6fdb'}}];
 if(E>1){if(!q.refl)tr.push({x:fx,y:KS.map(k=>q.f(S[k][1][0])),name:'S21',line:{color:'#d0661c'}});tr.push({x:fx,y:KS.map(k=>q.f(S[k][1][1])),name:'S22',line:{color:'#3a9a5b',dash:'dash'}})}
 if(showRef){tr.push({x:fx,y:KS.map(k=>q.f(gT(ref0[k],k))),name:'S11 initial',line:{color:'#999',width:1,dash:'dot'}});if(E>1&&!q.refl)tr.push({x:fx,y:KS.map(k=>q.f(ref0[k][1][0])),name:'S21 initial',line:{color:'#bbb',width:1,dash:'dot'}})}
 if(MEAS){const mk=MEAS.f.map((f,i)=>i).filter(i=>MEAS.f[i]>=fx[0]*1e9&&MEAS.f[i]<=fx[fx.length-1]*1e9);
  tr.push({x:mk.map(i=>MEAS.f[i]/1e9),y:mk.map(i=>q.f(MEAS.s11[i])),name:'S11 measured',line:{color:'#7b3fb0',width:2}});
  if(MEAS.np===2&&!q.refl)tr.push({x:mk.map(i=>MEAS.f[i]/1e9),y:mk.map(i=>q.f(MEAS.s21[i])),name:'S21 measured',line:{color:'#b07b3f',width:2}})}
 const L=layout('S-parameters (layout-aware)',q.t);L.xaxis.range=[fx[0],fx[fx.length-1]];
 const yr=document.getElementById('yr').value;if(q===QTY.db&&yr!=='auto')L.yaxis.range=[-(+yr),2];
 const BD=bandOf(document.getElementById('band'));
 L.shapes=bandShapes(BD,1e9).concat(marks.map(m=>({type:'line',x0:m/1e9,x1:m/1e9,yref:'paper',y0:0,y1:1,line:{width:1,dash:'dot',color:'#999'}})));
 Plotly.react('p1',tr,L,{responsive:true,displaylogo:false});
 // Smith chart (normalised to 50 ohm)
 const sm=(g)=>{const z=zOf(g);return[z[0]/50,z[1]/50]};const st=[];
 const addS=(name,gs,color,dash,width)=>{const zz=gs.map(sm);st.push({type:'scattersmith',real:zz.map(z=>z[0]),imag:zz.map(z=>z[1]),mode:'lines',name,line:{color,dash,width:width||2},
  text:KS.map(k=>(D.f[k]/1e6).toFixed(0)+' MHz'),hovertemplate:'%{text}<br>z = %{real:.2f} %{imag:+.2f}j<extra>'+name+'</extra>'})};
 addS('S11',KS.map(k=>Z50[k]),'#2a6fdb');if(E>1)addS('S22',KS.map(k=>S[k][1][1]),'#3a9a5b','dash');
 if(MEAS){const mi=MEAS.f.map((f,i)=>i).filter(i=>MEAS.f[i]>=fx[0]*1e9&&MEAS.f[i]<=fx[fx.length-1]*1e9);const zz=mi.map(i=>sm(MEAS.s11[i]));
  st.push({type:'scattersmith',real:zz.map(z=>z[0]),imag:zz.map(z=>z[1]),mode:'lines',name:'S11 measured',line:{color:'#7b3fb0',width:2},
   text:mi.map(i=>(MEAS.f[i]/1e6).toFixed(0)+' MHz'),hovertemplate:'%{text}<br>z = %{real:.2f} %{imag:+.2f}j<extra>measured</extra>'})}
 if(zt)st.push({type:'scattersmith',real:[zt[0]/50],imag:[zt[1]/50],mode:'markers+text',text:['target'],textposition:'bottom right',marker:{size:11,symbol:'star',color:'#c4521b'},name:'target',hoverinfo:'skip'});
 if(BD){const kb=KS.filter(k=>inBand(D.f[k],BD));if(kb.length){const zz=kb.map(k=>sm(Z50[k]));
  st.push({type:'scattersmith',real:zz.map(z=>z[0]),imag:zz.map(z=>z[1]),mode:'markers',marker:{size:4,color:'#2ea05a'},name:'S11 in band',hoverinfo:'skip'})}}
 if(showRef)addS('S11 initial',KS.map(k=>gin(ref0[k],k)),'#999','dot',1);
 const mk=marks.map(m=>nearestK(m));const zm=mk.map(k=>sm(Z50[k]));
 st.push({type:'scattersmith',real:zm.map(z=>z[0]),imag:zm.map(z=>z[1]),mode:'markers+text',text:marks.map(m=>(m/1e6).toFixed(0)),textposition:'top right',
  marker:{size:8,color:'#d0661c'},name:'markers',hoverinfo:'skip'});
 Plotly.react('p3',st,{title:{text:'Smith chart (Z₀ = 50 Ω)',font:{size:13}},margin:{l:30,r:30,t:40,b:30},paper_bgcolor:'rgba(0,0,0,0)',
  font:{color:css.getPropertyValue('--fg')},smith:{bgcolor:'rgba(0,0,0,0)',realaxis:{gridcolor:css.getPropertyValue('--line')},imaginaryaxis:{gridcolor:css.getPropertyValue('--line')}},
  legend:{orientation:'h',y:-0.12}},{responsive:true,displaylogo:false});
 // impedance plot (R and X over frequency)
 const Z=KS.map(k=>zOf(Z50[k]));
 const L2=layout('Input impedance at '+D.external[0],'Ω');L2.xaxis.range=[fx[0],fx[fx.length-1]];
 L2.shapes=bandShapes(BD,1e9).concat(marks.map(m=>({type:'line',x0:m/1e9,x1:m/1e9,yref:'paper',y0:0,y1:1,line:{width:1,dash:'dot',color:'#999'}})));
 Plotly.react('p2',[{x:fx,y:Z.map(z=>z[0]),name:'R',line:{color:'#2a6fdb'}},{x:fx,y:Z.map(z=>z[1]),name:'X',line:{color:'#d0661c'}},
  {x:[fx[0],fx[fx.length-1]],y:[zt?zt[0]:50,zt?zt[0]:50],name:zt?'target R':'50 Ω',line:{color:'#999',dash:'dot',width:1}}].concat(zt?[{x:[fx[0],fx[fx.length-1]],y:[zt[1],zt[1]],name:'target X',line:{color:'#d0661c',dash:'dot',width:1}}]:[]),L2,{responsive:true,displaylogo:false});
 // table
 const on=k=>colOn[k];const hdr=[['f','f']].concat(COLS.filter(([k])=>on(k)).map(([k,t])=>[k,t]));
 lastRows=[];let h='<tr>'+hdr.map(([,t])=>`<th>${t}</th>`).join('')+'</tr>';
 for(const m of marks){const i=nearestK(m),g=S[i][0][0],z=zOf(Z50[i]);const row={f:(D.f[i]/1e6).toFixed(1)+' MHz',s11:db(g).toFixed(1),g:G(g).toFixed(3),
  vswr:QTY.vswr.f(g).toFixed(2),rl:(-db(g)).toFixed(1),ml:QTY.ml.f(g).toFixed(2),s21:E>1?db(S[i][1][0]).toFixed(1):'',
  zin:`${z[0].toFixed(1)}${z[1]>=0?'+':'−'}j${Math.abs(z[1]).toFixed(1)}`,load:E>1?(100*toLoad(S0[i],i)).toFixed(1)+' %':'',rad:D.load&&useSim()?radiated(S0[i],i):''};
  lastRows.push(hdr.map(([k])=>row[k]));const cls=k=>k==='s11'||k==='vswr'?(G(g)<0.316?' class="good"':G(g)>0.5?' class="bad"':''):'';
  h+='<tr>'+hdr.map(([k])=>`<td${cls(k)}>${row[k]}</td>`).join('')+'</tr>'}
 document.getElementById('tab').innerHTML=h;window._hdr=hdr;
 // worst case inside the chosen band
 const bs=document.getElementById('bandsum');
 if(BD){const kb=ALLK.filter(k=>inBand(D.f[k],BD));
  if(!kb.length){bs.textContent=`${BD.n}: outside the simulated sweep or between two frequency points`}
  else{let ws=-1e9,wf=0,wl=1e9,wr=1e9;for(const k of kb){const g=S[k][0][0],d=db(g);if(d>ws){ws=d;wf=D.f[k]}
    if(E>1){const t=toLoad(S0[k],k);if(t<wl)wl=t}if(D.load&&useSim()){const r=parseFloat(radiated(S0[k],k));if(!isNaN(r)&&r<wr)wr=r}}
   bs.innerHTML=`<b>${BD.n}</b>: worst S11 ${ws.toFixed(1)} dB (at ${(wf/1e6).toFixed(1)} MHz)`+(E>1?`, at least ${(100*wl).toFixed(0)} % to the load`:'')
    +(wr<1e9?`, at least ${wr.toFixed(0)} % radiated`:'')+` · ${kb.length} frequency points in the band`}}
 else bs.textContent=''}
document.getElementById('copy').onclick=()=>{const t=[window._hdr.map(x=>x[1]).join('\t')].concat(lastRows.map(r=>r.join('\t'))).join('\n');
 (navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(()=>document.getElementById('cpmsg').textContent=' copied',()=>document.getElementById('cpmsg').textContent=' copy not allowed here')};
document.getElementById('csv').onclick=()=>{const S0=compute(cur);const E=D.external.length;const rows=['f_Hz,S11_re,S11_im,S11_dB,VSWR,Zin_re,Zin_im'+(E>1?',S21_dB,S22_dB':'')];
 S0.forEach((s,k)=>{const g=gT(s,k),z=zOf(gin(s,k));rows.push([D.f[k],g[0].toFixed(6),g[1].toFixed(6),db(g).toFixed(3),QTY.vswr.f(g).toFixed(4),z[0].toFixed(3),z[1].toFixed(3)].concat(E>1?[db(s[1][0]).toFixed(3),db(s[1][1]).toFixed(3)]:[]).join(','))});
 const b=new Blob([rows.join('\n')],{type:'text/csv'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=(D.title||'rf').replace(/[^\w]+/g,'_')+'_sweep.csv';a.click()};
// ---- Touchstone export (RI, Hz, 50 ohm) with the current values
function saveText(name,text){const host=window.rfsim&&window.rfsim.postMessage?window.rfsim:null;
 if(host){host.postMessage(JSON.stringify({type:'save',name,text}));return}
 const b=new Blob([text],{type:'text/plain'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click()}
function tsHead(what){const vals=D.parts.map(p=>{const m=mode[p.ref];return p.ref+'='+(m==='open'?'DNP':m==='short'?'0R':(p.series.length?fmt(p,cur[p.ref]).replace(' ',''):p.label))}).join(' ');
 return `! RF Sim - ${D.title}\n! ${what}\n! board ${D.board||''}, ports ${D.external.join(' -> ')}\n! part values: ${vals}\n! part models: ${VM}\n# Hz S RI R 50\n`}
const tsBase=()=>(D.title||'rf').replace(/[^\w]+/g,'_');
document.getElementById('ts').onclick=()=>{const S0=compute(cur),E=D.external.length;let t=tsHead('matching network, layout from the EM run, parts as set in the viewer');
 S0.forEach((s,k)=>{const r=[D.f[k]];if(E===1)r.push(s[0][0][0],s[0][0][1]);else for(const [i,j] of [[0,0],[1,0],[0,1],[1,1]])r.push(s[i][j][0],s[i][j][1]);
  t+=r.map((x,q)=>q?x.toExponential(9):x.toFixed(0)).join(' ')+'\n'});saveText(tsBase()+(E===1?'.s1p':'.s2p'),t)};
document.getElementById('tsin').onclick=()=>{const S0=compute(cur);let t=tsHead('input reflection at port 1 with the port-2 load '+(useSim()?'(simulated / file antenna)':`(${document.getElementById('lr').value} + j${document.getElementById('lx').value} ohm)`));
 S0.forEach((s,k)=>{const g=gin(s,k);t+=`${D.f[k].toFixed(0)} ${g[0].toExponential(9)} ${g[1].toExponential(9)}\n`});saveText(tsBase()+"_input.s1p",t)};
if(D.external.length<2)document.getElementById('tsin').style.display='none';
['span','qty','yr'].forEach(id=>document.getElementById(id).onchange=()=>{document.getElementById('custrow').style.display=document.getElementById('span').value==='custom'?'flex':'none';update()});
fillBands(document.getElementById('band'),D.f[0],D.f[nF-1]);const DBAND=addDesignBand(document.getElementById('band'),D.band);
function bandMarks(b){const m=[];b.r.forEach(([lo,hi])=>{m.push(lo,hi)});const [lo,hi]=bandEdges(b);if(b.r.length===1)m.splice(1,0,(lo+hi)/2);
 return [...new Set(m.map(x=>Math.round(x/1e5)*1e5))].sort((a,b)=>a-b).slice(0,8)}
function setBand(save){const sel=document.getElementById('band'),b=bandOf(sel);
 if(b){document.getElementById('span').value='band';marks=bandMarks(b);document.getElementById('mk').value=marks.map(m=>(m/1e6).toFixed(1)).join(', ');
  const [lo,hi]=bandEdges(b);document.getElementById('atlo').value=(lo/1e6).toFixed(2);document.getElementById('athi').value=(hi/1e6).toFixed(2)}
 else if(document.getElementById('span').value==='band')document.getElementById('span').value='20';
 if(save){try{localStorage.setItem('rfsim_band',sel.value)}catch(e){}}update()}
document.getElementById('band').onchange=()=>setBand(true);
['flo','fhi'].forEach(id=>document.getElementById(id).oninput=update);
document.getElementById('flo').value=(D.f[0]/1e6).toFixed(0);document.getElementById('fhi').value=(D.f[nF-1]/1e6).toFixed(0);
document.getElementById('mk').onchange=e=>{const v=e.target.value.split(/[,; ]+/).map(Number).filter(x=>x>0).map(x=>x*1e6);if(v.length){marks=v;update()}};
document.getElementById('showref').onchange=update;
document.getElementById('lr').oninput=()=>{document.getElementById('ldc').checked=true;update()};
document.getElementById('lx').oninput=()=>{document.getElementById('ldc').checked=true;update()};
document.getElementById('ldc').onchange=update;
['sr','sx'].forEach(id=>document.getElementById(id).oninput=()=>{document.getElementById('src').checked=true;update()});
['sr50','src'].forEach(id=>document.getElementById(id).onchange=update);
if(D.source){document.getElementById('sr').value=D.source[0];document.getElementById('sx').value=D.source[1];document.getElementById('src').checked=true}
// the target typed in the page is kept for the next visit (per setup)
try{const t0=JSON.parse(localStorage.getItem('rfsim_target_'+D.title)||'null');if(t0&&!D.source){document.getElementById('sr').value=t0[0];document.getElementById('sx').value=t0[1];document.getElementById(t0[2]?'src':'sr50').checked=true}}catch(e){}
function saveTarget(){try{localStorage.setItem('rfsim_target_'+D.title,JSON.stringify([+document.getElementById('sr').value,+document.getElementById('sx').value,document.getElementById('src').checked]))}catch(e){}}
['sr','sx','sr50','src'].forEach(id=>document.getElementById(id).addEventListener('change',saveTarget));
if(D.load){document.getElementById('simrow').style.display='flex';document.getElementById('simname').textContent=(D.load.file?'from the file ':'(')+D.load.name+(D.load.file?' (vendor / measured data)':')');
 if(D.load.file)document.getElementById('simrow').firstChild.nextSibling.textContent=' antenna ';document.getElementById('ldsim').onchange=update}
else document.getElementById('ldc').checked=true;
function radiated(s,k){const f=D.f[k];let best=null;for(const [fs,e] of Object.entries(D.load.eff)){if(Math.abs(+fs-f)/f<0.015&&(!best||Math.abs(+fs-f)<Math.abs(best[0]-f)))best=[+fs,e]}
 return best?(100*toLoad(s,k)*best[1]).toFixed(1)+' %':'–'}
if(D.external.length<2)document.getElementById('loadbox').style.display='none';
document.getElementById('reset').onclick=()=>{D.parts.forEach(p=>p._reset());update()};
function rkm(p,v){// KiCad-style value text: 4p7, 39p, 9n1, 100n
 const u=p.kind==='C'?[['p',1e-12],['n',1e-9],['u',1e-6]]:[['n',1e-9],['u',1e-6]];let [s,m]=u[0];for(const [ss,mm] of u){if(v>=mm*0.9999){s=ss;m=mm}}
 const x=+(v/m).toPrecision(3);const [a,b]=String(x).split('.');return b?a+s+b:a+s}
// a kind that differs from the footprint's (an inductor on a capacitor place) is written with its unit:
// "5.6nH" / "4.7pF" - the unit decides the kind when the board is read again
function vtext(p,v){if(!p.hint||p.hint===p.kind||!(p.kind==='C'||p.kind==='L'))return rkm(p,v);
 const n=x=>String(parseFloat(x.toPrecision(3)));return p.kind==='C'?n(v*1e12)+'pF':n(v*1e9)+'nH'}
// inside the RF Sim window the values go straight to the board (script message handler "rfsim")
const host=window.rfsim&&window.rfsim.postMessage?window.rfsim:null;
if(host)document.getElementById('exp').textContent='Apply to board';
document.getElementById('exp').onclick=()=>{const vals={};D.parts.forEach(p=>{const m=mode[p.ref],mc=m!==mode0[p.ref];const vc=m==='fit'&&p.series.length&&cur[p.ref]!==init[p.ref];if(!(mc||vc||(p.tunable&&p.series.length)))return;
 const vx=m==='fit'&&VM==='vendor'?vpart(p,cur[p.ref]):null;
 const kc=p.alt&&p.alt.length&&m==='fit',kx=kc&&p.kind!==kind0[p.ref];
 vals[p.ref]={value:cur[p.ref],text:m==='short'?'0R':(p.series.length?vtext(p,cur[p.ref]):p.label),mode:m,mode_was:mode0[p.ref],changed:!!(mc||vc||vx||kx),mpn:vx?vx.pn:undefined,kind:kc?p.kind:undefined}});
 const txt=JSON.stringify({board:D.board,values:vals},null,2);
 if(host){host.postMessage(txt);return}
 const blob=new Blob([txt],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='rfsim_values.json';a.click()};
// ---------------- autotune ----------------
(function(){const m0=D.marks[0]||D.f[Math.floor(nF/2)];
 document.getElementById('atlo').value=(m0/1e6*0.994).toFixed(1);document.getElementById('athi').value=(m0/1e6*1.006).toFixed(1)})();
if(D.external.length<2){const g=document.getElementById('atgoal');g.querySelector('[value=power]').disabled=true;g.querySelector('[value=robust]').disabled=true}
function bandIdx(lo,hi){let ks=ALLK.filter(k=>D.f[k]>=lo&&D.f[k]<=hi);
 if(!ks.length){const c=(lo+hi)/2;ks=[ALLK.reduce((b,k)=>Math.abs(D.f[k]-c)<Math.abs(D.f[b]-c)?k:b,0)]}return ks}
function nearestK(f){return ALLK.reduce((b,k)=>Math.abs(D.f[k]-f)<Math.abs(D.f[b]-f)?k:b,0)}
function cost(vals,modes,goal,ks,shift){const S=compute(vals,modes,ks);let worst=0;
 for(let i=0;i<ks.length;i++){const k=ks[i],s=S[i];
  if(goal==='power'&&s.length>1){const g=toLoad(s,k);worst=Math.max(worst,1-g)}
  else if(goal==='robust'&&s.length>1&&useSim()){for(const d of shift){const kk=nearestK(D.f[k]*(1+d));
    const gi=tgt(gin2(s,kk));worst=Math.max(worst,Math.hypot(gi[0],gi[1]))}}
  else{const g=gT(s,k);worst=Math.max(worst,Math.hypot(g[0],g[1]))}}
 return worst}
function gin2(s,kLoad){// input reflection with the load taken at another frequency index (detuned antenna)
 const gl=gL(kLoad);const num=cmul(cmul(s[0][1],s[1][0]),gl);const den=[1-cmul(s[1][1],gl)[0],-cmul(s[1][1],gl)[1]];
 const t=cmul(num,inv(den));return[s[0][0][0]+t[0],s[0][0][1]+t[1]]}
function options(p,topo,free){// [mode, value, kind]; with "free" a place may become a C or an L
 const k0=p.kind,ks=free&&p.alt&&p.alt.length?[k0].concat(p.alt.filter(k=>k!==k0)):[k0];const o=[];
 for(const k of ks)seriesK(p,k).forEach(v=>o.push(['fit',v,k]));
 if(topo){o.push(['open',o[0][1],k0]);o.push(['short',o[0][1],k0])}return o}
function autotune(){const lo=+document.getElementById('atlo').value*1e6,hi=+document.getElementById('athi').value*1e6;
 const goal=document.getElementById('atgoal').value,topo=document.getElementById('attopo').checked,msg=document.getElementById('atmsg');
 const free=document.getElementById('atkind').value==='free';
 let ks=bandIdx(Math.min(lo,hi),Math.max(lo,hi));const shift=[-0.03,0,0.03];
 {const b=bandOf(document.getElementById('band'));if(b){const [blo,bhi]=bandEdges(b);  // only the band's own ranges (UL / DL)
  if(Math.abs(blo-Math.min(lo,hi))<2e4&&Math.abs(bhi-Math.max(lo,hi))<2e4){const kb=ks.filter(k=>inBand(D.f[k],b));if(kb.length)ks=kb}}}
 const tp=D.parts.filter(p=>p.tunable&&p.series.length&&!p.locked&&(topo||mode[p.ref]==='fit'));
 if(!tp.length){msg.textContent='no unlocked tunable part';return}
 const opts=tp.map(p=>options(p,topo,free));
 const base={...cur},bm={...mode};
 const bk={};tp.forEach(p=>bk[p.ref]=[p.kind,p.q,p.esl,p.esr]);
 const evalIdx=ix=>{const v={...base},m={...bm},kk={};tp.forEach((p,i)=>{const [mm,vv,k]=opts[i][ix[i]];m[p.ref]=mm;v[p.ref]=vv;kk[p.ref]=k;
   if(k!==p.kind){p.kind=k;[p.q,p.esl,p.esr]=kprops(p,k)}});
  const c=cost(v,m,goal,ks,shift);tp.forEach(p=>{[p.kind,p.q,p.esl,p.esr]=bk[p.ref]});return[c,v,m,kk]};
 const startIx=tp.map((p,i)=>{const o=opts[i];let b=0;o.forEach(([mm,vv,k],j)=>{if(mm===mode[p.ref]&&k===p.kind&&(o[b][2]!==p.kind||Math.abs(Math.log(vv/cur[p.ref]))<Math.abs(Math.log(o[b][1]/cur[p.ref]))))b=j});return b});
 let best=evalIdx(startIx),bestIx=startIx.slice(),c0=best[0];
 const starts=[startIx].concat([...Array(24)].map(()=>tp.map((_,i)=>Math.floor(Math.random()*opts[i].length))));
 let si=0,evals=0;document.getElementById('atrun').disabled=true;
 function runStart(){if(si>=starts.length){finish();return}
  let ix=starts[si].slice(),cb=evalIdx(ix)[0];evals++;
  for(let sweep=0;sweep<12;sweep++){let improved=false;
   for(let i=0;i<tp.length;i++){let bj=ix[i];for(let j=0;j<opts[i].length;j++){if(j===ix[i])continue;const t=ix.slice();t[i]=j;const r=evalIdx(t);evals++;if(r[0]<cb-1e-12){cb=r[0];bj=j}}
    if(bj!==ix[i]){ix[i]=bj;improved=true}}
   if(!improved)break}
  if(cb<best[0]){best=evalIdx(ix);bestIx=ix.slice()}
  si++;msg.textContent=`searching ... ${Math.round(100*si/starts.length)} %`;setTimeout(runStart,0)}
 function finish(){document.getElementById('atrun').disabled=false;
  const [c,v,m,kk]=best;
  if(c>=c0-1e-9){msg.textContent='no better combination found';return}
  tp.forEach(p=>{if(kk[p.ref]&&kk[p.ref]!==p.kind){setKind(p,kk[p.ref]);if(p._rebuild)p._rebuild()}cur[p.ref]=v[p.ref];mode[p.ref]=m[p.ref]});
  D.parts.forEach(p=>{const row=[...document.querySelectorAll('#parts .part')].find(x=>x.querySelector('b').textContent===p.ref);if(!row||p.locked)return;
   const r=row.querySelector('input[type=range]');if(r&&p.series.length){const i=seriesOf(p).indexOf(cur[p.ref]);if(i>=0)r.value=i}
   row.querySelector('select').value=modeKey(p);p._set()});
  update();const lab={match:'worst |S11|',power:'worst loss to load',robust:'worst |S11| detuned'}[goal];
  const fm=x=>goal==='power'?(100*x).toFixed(1)+' %':(20*Math.log10(x+1e-12)).toFixed(1)+' dB';
  msg.textContent=`${lab}: ${fm(c0)} → ${fm(c)} (${evals} combinations)`;window._autotune={cost0:c0,cost:c,values:v,modes:m,kinds:kk}}
 runStart()}
document.getElementById('atrun').onclick=autotune;
if(DBAND!==null){document.getElementById('band').value=DBAND;setBand(false)}else try{const b0=localStorage.getItem('rfsim_band');if(b0!==null&&b0!==''&&document.querySelector(`#band option[value="${b0}"]`)){document.getElementById('band').value=b0;setBand(false)}}catch(e){}
update();
</script></body></html>
"""
