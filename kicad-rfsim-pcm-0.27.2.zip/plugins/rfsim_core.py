"""RF Sim program logic without GUI: setup from the selection, applying tuned
values, config and solver-settings handling, app settings.

Used by the RF Sim window (rfsim_app.py). Everything here works on a kipy
board object and the project folder; nothing opens windows.
"""
from __future__ import annotations

import copy
import dataclasses
import json

import numpy as np
import os
import time
from pathlib import Path

from rfsim_common import APP_DIR, board_snapshot, rfsim_dir, selected_nets, selected_refs

# config groups that hold solver settings, per config type
GROUPS = {"circuit": ("model", "mesh", "solver"), "antenna": ("settings", "solver")}
# keys shown in MHz in the GUI (stored in Hz)
FREQ_KEYS = {"f_min", "f_max", "f_loss", "f_farfield"}
# choices for text settings
CHOICES = {"boundary": ["MUR", "PML_8", "PEC"], "excitation": ["dc_free", "gauss"],
           "engine": ["auto", "multithreaded", "sse-compressed", "sse", "basic"], "edge_rule": ["thirds", "edge"],
           "copper_thickness": ["auto", "on", "off"]}


# ---------------------------------------------------------------------------
# app settings (per user, not per project)
# ---------------------------------------------------------------------------
def _settings_path() -> Path:
    return APP_DIR / "settings.json"


def load_app_settings() -> dict:
    try:
        return json.loads(_settings_path().read_text())
    except Exception:
        return {}


def apply_vendor_dir(path: str | None = None) -> str | None:
    """Tell the simulation code where the vendor part libraries are (app setting "vendor_dir");
    the index cache lives in the app folder."""
    if path is None:
        path = load_app_settings().get("vendor_dir")
    if path and Path(path).is_dir():
        os.environ["RFSIM_VENDOR_DIR"] = str(path)
        os.environ["RFSIM_CACHE_DIR"] = str(APP_DIR)
        return str(path)
    os.environ.pop("RFSIM_VENDOR_DIR", None)
    return None


def vendor_summary(path: str) -> str:
    """Index the library (cached) and describe what the tuning viewer can use."""
    from collections import Counter

    from kicad_rfsim.vendor import load_index
    parts = load_index(path, APP_DIR)
    if not parts:
        return "No usable parts found (S-parameter files of capacitors and inductors)."
    c = Counter((p.kind, p.size, p.series) for p in parts)
    by = {}
    for (k, sz, se), n in sorted(c.items()):
        by.setdefault(f"{'Capacitors' if k == 'C' else 'Inductors'} {sz}", []).append(f"{se} ({n})")
    return f"{len(parts)} parts: " + "; ".join(f"{k}: {', '.join(v)}" for k, v in by.items())


def save_app_settings(d: dict):
    APP_DIR.mkdir(parents=True, exist_ok=True)
    _settings_path().write_text(json.dumps(d, indent=2))


def find_openems() -> str | None:
    from rfsim_common import find_openems as _f
    return _f()


def openems_version(exe: str) -> str:
    """'v0.37.0' from the openEMS banner (empty if it cannot be run)."""
    import re
    import subprocess
    try:
        kw = {"creationflags": 0x08000000} if os.name == "nt" else {}
        r = subprocess.run([exe, "--help"], capture_output=True, text=True, timeout=15, **kw)
        m = re.search(r"version\s+(\S+)", r.stdout + r.stderr)
        return m.group(1) if m else ""
    except Exception:
        return ""


OPENEMS_TESTED = (0, 0, 36)  # oldest openEMS release the plugin was tested with (v0.0.36 ... v0.37.0)


def _ver_tuple(v: str) -> tuple:
    import re
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3]) or (0,)


def openems_check(exe: str | None) -> tuple[str, list[str]]:
    """(version, problems) of an openEMS installation: version too old, nf2ff missing next to it."""
    if not exe:
        return "", ["openEMS was not found."]
    ver = openems_version(exe)
    probs = []
    if not ver:
        probs.append("openEMS does not start (missing DLLs? Unzip the complete Windows build, not only openEMS.exe).")
    elif _ver_tuple(ver) < OPENEMS_TESTED:
        probs.append(f"openEMS {ver} is older than the tested v0.0.36 - update it (Solver Settings, Download).")
    folder = Path(exe).parent
    if not any((folder / n).exists() for n in ("nf2ff.exe", "nf2ff")):
        probs.append("nf2ff is not next to openEMS: antenna patterns and efficiency cannot be computed.")
    return ver, probs


# ---------------------------------------------------------------------------
# configs
# ---------------------------------------------------------------------------
@dataclasses.dataclass
class ConfigInfo:
    path: Path
    name: str
    kind: str  # "antenna" | "circuit"
    summary: str
    out: Path  # result folder
    has_result: bool
    updated: float | None

    @property
    def label(self) -> str:
        if self.kind == "fullboard":
            return "Whole board (RF path + antenna)"
        return ("Antenna: " if self.kind == "antenna" else "RF chain: ") + self.name


def inspect_mesh(proj: Path, info: "ConfigInfo", board=None, progress=print) -> Path:
    """Mesh inspector page of a setup (mesh.html in its result folder) from the open board, with the
    mesh settings editable on the page."""
    from kicad_rfsim.pipeline import inspect_mesh as _im
    snap = None
    if board is not None:
        snap, _ = board_snapshot(board, proj)
    est = ""
    try:
        est = estimate_runtime(proj, info)
    except Exception:  # noqa: BLE001
        pass
    tune = None
    try:
        tune = mesh_tune_info(info.path)
    except Exception:  # noqa: BLE001
        pass
    return _im(info.path, board_path=snap, progress=progress, estimate=est, tune=tune)


def sparam_file(info: "ConfigInfo") -> Path:
    """Touchstone file of a result: <setup>_feed.s1p (antenna; written from the result if missing) or
    the RF chain's EM N-port <setup>.sNp."""
    out = info.out
    if info.kind == "antenna":
        f = out / f"{info.name}_feed.s1p"
        if not f.exists():
            npz = out / "antenna_result.npz"
            if not npz.exists():
                raise FileNotFoundError("No antenna result yet - run the simulation first.")
            from kicad_rfsim.antenna import load_result
            from kicad_rfsim.openems_export import to_touchstone
            r = load_result(npz)
            to_touchstone(np.asarray(r.s11).reshape(-1, 1, 1), np.asarray(r.f), f)
        return f
    hits = sorted(out.glob(f"{info.name}.s*p"))
    if not hits:
        raise FileNotFoundError("No S-parameter file yet - run the simulation first.")
    return hits[0]


def broken_configs(proj: Path) -> list[str]:
    """One line per setup / casing file in the rfsim folder that cannot be used."""
    from kicad_rfsim.pipeline import broken_configs as _bc
    try:
        return [f"{p.name}: {why}. Fix the file or create the setup again on the Setup page."
                for p, why in _bc(rfsim_dir(proj))]
    except OSError:
        return []


def list_configs(proj: Path) -> list[ConfigInfo]:
    from kicad_rfsim.pipeline import list_configs as _lc
    out = []
    for p in _lc(rfsim_dir(proj)):
        try:
            cfg = json.loads(p.read_text())
        except Exception:  # noqa: BLE001 - changed since listing; reported by broken_configs
            continue
        kind = "antenna" if cfg.get("type") == "antenna" else "circuit"
        res = p.parent / cfg.get("output", "rfsim") / cfg["name"]
        main = res / ("antenna_report.html" if kind == "antenna" else "tune.html")
        if kind == "antenna":
            summ = (f"feed on the trace after {cfg['feed']['trace'].get('after') or cfg['feed']['ref'] + '.' + cfg['feed']['pad']}"
                    if cfg["feed"].get("trace")
                    else f"feed {cfg['feed']['ref']}.{cfg['feed']['pad']}") + f", nets {', '.join(cfg.get('antenna_nets', []))}"
        else:
            summ = f"{len(cfg.get('ports', []))} ports, external {' → '.join(cfg.get('external', []))}"
        out.append(ConfigInfo(p, cfg["name"], kind, summ, res, main.exists(),
                              main.stat().st_mtime if main.exists() else None))
    return out


# recordings of a run: only needed to rebuild wave views / the whole-board overlay or to
# recompute the far field; the reports and wave pages keep what they show
FIELD_PATTERNS = ("fld_*.h5", "fld_*.npz", "nf2ff_E_*.h5", "nf2ff_H_*.h5", "et", "ht")
RAW_PATTERNS = ("fld_*.h5", "nf2ff_E_*.h5", "nf2ff_H_*.h5", "et", "ht")  # what shrink_field_data replaces / drops


def field_files(out: Path) -> list[Path]:
    """Raw field recordings below a result folder (all run folders)."""
    out = Path(out)
    if not out.is_dir():
        return []
    found = []
    for pat in FIELD_PATTERNS:
        found += [p for p in out.rglob(pat) if p.is_file()]
    return sorted(set(found))


def field_data_size(out: Path) -> int:
    return sum(p.stat().st_size for p in field_files(out))


def raw_field_size(out: Path) -> int:
    """Bytes of raw HDF5 recordings (results of runs before v0.24.0) that shrink_field_data compacts."""
    out = Path(out)
    if not out.is_dir():
        return 0
    return sum(p.stat().st_size for pat in RAW_PATTERNS for p in out.rglob(pat) if p.is_file())


def shrink_field_data(out: Path, progress=print) -> int:
    """Compact the raw recordings of a result (normal field component, 8 bit, thinned to what the
    pages show) and drop the near-field surfaces of a finished far field. Wave views and the
    whole-board overlay keep working. Returns the bytes freed."""
    from kicad_rfsim.pipeline import _compact_runs
    before = field_data_size(out)
    _compact_runs(Path(out), progress)
    return before - field_data_size(out)


def delete_field_data(out: Path) -> tuple[int, int]:
    """Delete the raw field recordings of a result. Returns (files, bytes) removed. Reports, tuning
    viewers, wave pages, port data and S-parameters stay; the whole-board overlay needs a new run."""
    n = b = 0
    for p in field_files(out):
        try:
            sz = p.stat().st_size
            p.unlink()
            n, b = n + 1, b + sz
        except OSError:
            pass
    return n, b


def fmt_bytes(b: int) -> str:
    for unit, k in (("GB", 1 << 30), ("MB", 1 << 20), ("kB", 1 << 10)):
        if b >= k:
            return f"{b / k:.1f} {unit}"
    return f"{b} B"


def full_board_info(proj: Path) -> "ConfigInfo | None":
    """The whole-board wave view (RF path + antenna, joined) as a results entry, if it exists."""
    try:
        a = json.loads((rfsim_dir(proj) / "antenna.json").read_text())
    except Exception:
        return None
    out = rfsim_dir(proj) / a.get("output", "rfsim") / "full_board"
    w = out / "wave.html"
    if not w.exists():
        return None
    return ConfigInfo(out / "full_board.json", "whole board", "fullboard", "RF path + antenna wave view", out, True,
                      w.stat().st_mtime)


def settings_classes(kind: str) -> dict:
    from kicad_rfsim.antenna import AntennaSettings
    from kicad_rfsim.openems_export import MeshSettings, ModelSettings
    from kicad_rfsim.solver import SolverOptions
    if kind == "antenna":
        return {"settings": AntennaSettings, "solver": SolverOptions}
    return {"model": ModelSettings, "mesh": MeshSettings, "solver": SolverOptions}


def settings_rows(cfg: dict) -> list[dict]:
    """Every solver setting of a config: group, key, value, default, auto value, meaning, type."""
    from kicad_rfsim.solver import SETTING_DOCS
    kind = "antenna" if cfg.get("type") == "antenna" else "circuit"
    auto = cfg.get("_auto", {})
    rows = []
    for grp, cls in settings_classes(kind).items():
        vals = cfg.get(grp, {})
        for f in dataclasses.fields(cls):
            if f.name == "mesh" or f.name == "mode":
                continue
            default = f.default if f.default is not dataclasses.MISSING else (
                f.default_factory() if f.default_factory is not dataclasses.MISSING else None)
            v = vals.get(f.name, default)
            rows.append({"group": grp, "key": f.name, "value": v, "default": default,
                         "auto": auto.get(grp, {}).get(f.name, default), "doc": SETTING_DOCS.get(f.name, ""),
                         "type": _type_of(f, default), "choices": CHOICES.get(f.name)})
    return rows


def _type_of(f, default) -> str:
    t = str(f.type)
    if "bool" in t:
        return "bool"
    if "int" in t and "None" in t and "float" not in t:
        return "optint"
    if "list" in t:
        return "list"
    if "int" in t and "float" not in t:
        return "int"
    if "float" in t:
        return "float"
    return "str"


def solver_mode(cfg: dict) -> str:
    return cfg.get("solver", {}).get("mode", "auto")


# mesh presets: factors on the setup's values (cell sizes) and the stop criterion.
# Energy decay at the stop: antenna 30 / 40 / 50 dB (Fast / Automatic / Accurate; 60 dB moved the
# bench antennas by < 0.2 %), RF chain 50 / 60 / 70 dB (its circuit math needs the tail, see
# ModelSettings.end_criteria)
PRESETS = {
    "fast": {"cell": 1.8, "end_criteria": 1e-3, "end_criteria_circuit": 1e-5, "time": 0.8,
             "text": "coarse mesh, stops early (antenna 30 dB, RF chain 50 dB energy decay) - a first look, "
                     "roughly 3-6x faster"},
    "accurate": {"cell": 0.65, "end_criteria": 1e-5, "end_criteria_circuit": 1e-7, "time": 1.4,
                 "text": "fine mesh, stops late (antenna 50 dB, RF chain 70 dB) - for final values, roughly 3-5x slower"},
}
_CELL_KEYS = {"mesh": ("max_fine", "min_cell", "max_coarse"),
              "settings": ("max_antenna", "max_board", "min_cell", "max_air")}
MODES = ["auto", "fast", "accurate", "custom"]


def preset_values(cfg: dict, mode: str) -> dict:
    """Settings groups for a preset, derived from the setup's automatic values."""
    kind = "antenna" if cfg.get("type") == "antenna" else "circuit"
    auto = cfg.get("_auto") or {g: copy.deepcopy(cfg.get(g, {})) for g in GROUPS[kind]}
    out = {g: copy.deepcopy(auto.get(g, {})) for g in GROUPS[kind]}
    pr = PRESETS.get(mode)
    if not pr:
        return out
    classes = settings_classes(kind)
    for g, keys in _CELL_KEYS.items():
        if g not in classes:
            continue
        defaults = {f.name: f.default for f in dataclasses.fields(classes[g])}
        for k in keys:
            v = out[g].get(k, defaults.get(k))
            if isinstance(v, (int, float)) and v:
                out[g][k] = round(float(v) * pr["cell"], 4)
    grp = "model" if kind == "circuit" else "settings"
    out[grp]["end_criteria"] = pr["end_criteria_circuit"] if kind == "circuit" else pr["end_criteria"]
    # simulated-time limit: 30 dB needs ~0.75x, 50 dB ~1.25x the time of 40 dB
    cls = classes["model" if kind == "circuit" else "settings"]
    base_t = out[grp].get("max_time_ns", next(f.default for f in dataclasses.fields(cls) if f.name == "max_time_ns"))
    out[grp]["max_time_ns"] = round(float(base_t) * pr["time"], 1)
    return out


CONVERGENCE_LEVELS = {"quick": ("fast", "auto"), "full": ("fast", "auto", "accurate")}


def convergence_variants(cfg: dict, levels=("fast", "auto", "accurate")) -> list[tuple[str, dict, float]]:
    """The setup at each mesh level (presets derived from its automatic values), coarse -> fine:
    [(level, setup dict, cell factor)]."""
    out = []
    for lv in levels:
        c = copy.deepcopy(cfg)
        for g, v in preset_values(cfg, lv).items():
            c[g] = v
        c.setdefault("solver", {})["mode"] = lv
        out.append((lv, c, PRESETS[lv]["cell"] if lv in PRESETS else 1.0))
    return out


def run_convergence(proj: Path, info: "ConfigInfo", levels=("fast", "auto", "accurate"), board_path=None,
                    threads: int = 0, progress=print, openems_bin=None, force: bool = False) -> dict:
    """Mesh convergence check of one setup (see kicad_rfsim.convergence). The Automatic level is
    the setup's own result when the setup uses the Automatic settings."""
    from kicad_rfsim.convergence import run_convergence as _run
    cfg = json.loads(info.path.read_text())
    return _run(info.path, convergence_variants(cfg, levels), board_path=board_path, threads=threads,
                progress=progress, openems_bin=openems_bin, force=force, main_out=info.out,
                auto_in_main=solver_mode(cfg) == "auto")


def convergence_page(info: "ConfigInfo") -> Path:
    return info.out / "convergence" / "convergence.html"


def save_settings(path: Path, rows: list[dict], mode: str):
    """Write the settings of a config. 'auto' restores the values the setup chose, 'fast' /
    'accurate' derive them from those, 'custom' takes ``rows``."""
    cfg = json.loads(Path(path).read_text())
    kind = "antenna" if cfg.get("type") == "antenna" else "circuit"
    auto = cfg.get("_auto") or {g: copy.deepcopy(cfg.get(g, {})) for g in GROUPS[kind]}
    cfg["_auto"] = auto
    for r in rows:  # frequencies belong to the board, not to a mesh preset: editable in every mode
        if r["key"] in FREQ_KEYS and r["value"] is not None:
            auto.setdefault(r["group"], {})[r["key"]] = r["value"]
            cfg.setdefault(r["group"], {})[r["key"]] = r["value"]
    if mode in ("auto", "fast", "accurate"):
        keep = {k: v for k, v in cfg.get("solver", {}).items() if k in ("engine", "threads", "parallel")}
        for g, vals in preset_values(cfg, mode).items():
            cfg[g] = vals
        cfg.setdefault("solver", {}).update(keep)
    else:
        for r in rows:
            grp = cfg.setdefault(r["group"], {})
            if r["value"] == r["default"] and r["key"] not in auto.get(r["group"], {}):
                grp.pop(r["key"], None)  # keep the file short: defaults are implicit
            else:
                grp[r["key"]] = r["value"]
    cfg.setdefault("solver", {})["mode"] = mode
    # validate before writing
    from kicad_rfsim.solver import check_keys, solver_options
    for g, cls in settings_classes(kind).items():
        check_keys(cls, {k: v for k, v in cfg.get(g, {}).items() if not (g == "model" and k == "mesh")}, g)
    solver_options(cfg)  # engine name
    Path(path).write_text(json.dumps(cfg, indent=2))
    return cfg


# settings the mesh inspector page offers (group, key, label)
MESH_TUNE = {
    "antenna": [("settings", "max_antenna", "cell on the antenna (mm)"),
                ("settings", "rf_cell", "cell on the RF chain copper (mm, empty = auto)"),
                ("settings", "max_board", "cell on the rest of the board (mm)"),
                ("settings", "max_air", "cell in the air (mm, empty = λ/20)"),
                ("settings", "min_cell", "smallest cell (mm)"),
                ("settings", "rf_path_mesh", "fine mesh over the RF chain"),
                ("settings", "plane_gap", "close copper gaps up to (mm)"),
                ("settings", "plane_hole", "fill enclosed holes up to (mm²)"),
                ("settings", "end_criteria", "stop at energy decay")],
    "circuit": [("mesh", "max_fine", "cell in the region (mm)"),
                ("mesh", "max_coarse", "cell in the air margin (mm)"),
                ("mesh", "min_cell", "smallest cell (mm)"),
                ("mesh", "z_cells_per_dielectric", "cells per dielectric layer"),
                ("model", "end_criteria", "stop at energy decay")],
}


def mesh_tune_info(path: Path) -> dict:
    """What the mesh inspector page needs to edit the mesh: the setup's mesh settings, their
    automatic values and the preset values (Fast / Automatic / Accurate)."""
    path = Path(path)
    cfg = json.loads(path.read_text())
    kind = "antenna" if cfg.get("type") == "antenna" else "circuit"
    rows = {(r["group"], r["key"]): r for r in settings_rows(cfg)}
    presets = {m: preset_values(cfg, m) for m in ("fast", "auto", "accurate")}
    fields = []
    for g, k, label in MESH_TUNE[kind]:
        r = rows.get((g, k))
        if r is None:
            continue
        pv = {}
        for m, vals in presets.items():
            pv[m] = vals.get(g, {}).get(k, r["default"])
        fields.append({"group": g, "key": k, "label": label, "value": r["value"], "default": r["default"],
                       "type": r["type"], "optional": r["default"] is None, "doc": r["doc"], "presets": pv})
    return {"config": str(path), "kind": kind, "mode": solver_mode(cfg), "fields": fields,
            "f_max": float(cfg.get("settings" if kind == "antenna" else "model", {}).get("f_max", 0) or 0)}


def apply_mesh_settings(path: Path, mode: str, values: dict | None = None) -> dict:
    """Mesh settings from the mesh inspector page: a preset, or custom values {group: {key: value}}
    on top of the setup's current settings."""
    path = Path(path)
    cfg = json.loads(path.read_text())
    if mode in ("auto", "fast", "accurate"):
        return save_settings(path, [], mode)
    kind = "antenna" if cfg.get("type") == "antenna" else "circuit"
    editable = {(g, k) for g, k, _l in MESH_TUNE[kind]}
    rows = settings_rows(cfg)
    for r in rows:
        if (r["group"], r["key"]) not in editable or r["key"] not in (values or {}).get(r["group"], {}):
            continue
        v = values[r["group"]][r["key"]]
        if v == "":
            v = None
        if r["type"] in ("float", "int") and v is not None:
            v = int(v) if r["type"] == "int" else float(v)
            if v < 0 or (v == 0 and r["key"] not in ("plane_gap", "plane_hole")):
                raise ValueError(f"{r['key']} must be > 0")
        elif r["type"] == "bool":
            v = bool(v)
        r["value"] = v
    return save_settings(path, rows, "custom")


def estimate_runtime(proj: Path, info: "ConfigInfo") -> str:
    """Rough runtime text for the Simulate page: from the last run of this setup if there is one,
    else from the cell count (cells x expected timesteps / typical speed)."""
    from kicad_rfsim.solver import load_record, physical_cores
    rec = load_record(info.out)
    cfg = json.loads(info.path.read_text())
    if info.kind == "antenna":
        try:
            return estimate_antenna(info.path.parent, cfg, rec)
        except Exception:  # noqa: BLE001
            pass
    if rec and rec.get("runs"):
        tot = sum(r.get("wall_s", 0) for r in rec["runs"])
        return f"last run {_fmt_dur(tot)}"
    cores = physical_cores()
    try:
        if info.kind == "antenna":
            return "antenna: ~5-30 min (first run)"
        from kicad_rfsim.board import Board
        from kicad_rfsim.pipeline import build_circuit_model
        b = Board((info.path.parent / cfg["board"]).resolve())
        m = build_circuit_model(b, cfg)
        n_exc = sum(1 for p in m.ports if not p.termination)
        # a run lasts about as long as its pulse (18 / (2 pi fc)) plus the decay of a damped network
        import math
        ts = 1.3 * 18 / (2 * math.pi * m.pulse()[1]) / m.timestep_estimate()
        speed = 30e6  # cells x timesteps per second and core, small models on a desktop CPU
        t = n_exc * m.n_cells * ts / (speed * cores)
        return f"~{_fmt_dur(t)} ({n_exc} runs, {m.n_cells/1e6:.2f} M cells)"
    except Exception:
        return ""


def estimate_antenna(base: Path, cfg: dict, rec: dict | None = None) -> str:
    """Runtime of an antenna run with the current settings: cells x timesteps / speed.

    The simulated time the antenna needs to ring down (its Q) does not depend on the mesh, so it is
    taken from the last converged run (else 20 ns, a typical small antenna); the timestep comes from
    the smallest cells of the current mesh, the speed from the last run (else ~8 MC/s per core)."""
    from kicad_rfsim.openems_export import courant_dt
    from kicad_rfsim.pipeline import build_antenna_model
    from kicad_rfsim.solver import physical_cores
    out = base / cfg.get("output", "rfsim") / cfg["name"]
    m = build_antenna_model(cfg, base, progress=lambda *_a: None, workdir=out)
    dt = courant_dt(m.lines)
    try:  # openEMS' own timestep (its criterion is up to ~2x stricter than Courant), cached per mesh
        from kicad_rfsim.openems_export import exact_dt, find_openems
        exe = find_openems()
        if exe:
            d0 = out / "dt_probe"
            d0.mkdir(parents=True, exist_ok=True)
            dt = exact_dt(exe, m.write_xml(d0 / "antenna.xml"), out) or dt
            import shutil
            shutil.rmtree(d0, ignore_errors=True)
    except Exception:  # noqa: BLE001
        pass
    runs = (rec or {}).get("runs") or []
    need_ns, speed, src = 20.0, 8e6 * physical_cores(), "typical"
    for r in runs:
        if r.get("stop_reason") == "energy decayed" and r.get("sim_time_ns"):
            need_ns, src = float(r["sim_time_ns"]), "last run"
        if r.get("speed_mcs"):
            speed = float(r["speed_mcs"]) * 1e6
    lim = m.max_timesteps * dt * 1e9
    t_ns = min(need_ns, lim)
    t = m.n_cells * (t_ns * 1e-9 / dt) / max(speed, 1e6)
    d = [min(np.diff(l)) for l in m.lines]
    txt = (f"~{_fmt_dur(t)} ({m.n_cells/1e6:.2f} M cells, smallest cell {min(d):.3f} mm, "
           f"dt {dt*1e15:.0f} fs, {t_ns:.0f} ns to ring down ({src}))")
    if t > 3 * 3600:
        txt += " - long: a larger min_cell (e.g. 0.15 mm) or the Fast preset is much quicker"
    return txt


def _fmt_dur(s: float) -> str:
    return f"{s:.0f} s" if s < 90 else f"{s/60:.0f} min" if s < 5400 else f"{s/3600:.1f} h"


def _remember_auto(cfg: dict) -> dict:
    kind = "antenna" if cfg.get("type") == "antenna" else "circuit"
    cfg["_auto"] = {g: copy.deepcopy(cfg.get(g, {})) for g in GROUPS[kind]}
    cfg.setdefault("solver", {}).setdefault("mode", "auto")
    return cfg


# ---------------------------------------------------------------------------
# setup from the PCB selection
# ---------------------------------------------------------------------------
@dataclasses.dataclass
class SetupSection:
    title: str
    text: str
    image: Path | None = None
    warn: list = dataclasses.field(default_factory=list)


def read_selection(board) -> tuple[list[str], list[str]]:
    return selected_refs(board), selected_nets(board)


def antenna_options(board, proj: Path) -> dict:
    """What the Setup page offers for the antenna: detected candidates (with reasons, also
    rejected ones), the nets and pads of the selection to define one yourself, and the
    previous choice (from antenna.json)."""
    from kicad_rfsim.antenna_detect import antenna_candidates
    from kicad_rfsim.board import Board
    from kicad_rfsim.rfpath import find_rf_cluster
    seeds = selected_nets(board)
    snap, _ = board_snapshot(board, proj)
    b = Board(snap)
    nets = find_rf_cluster(b, seeds).nets if seeds else []
    cands = antenna_candidates(b, nets, proj) if nets else []
    pads = {n: sorted(f"{f.ref}.{p.number}" for f in b.footprints for p in f.pads if p.net == n and p.number)
            for n in nets}
    prev = None
    try:
        a = json.loads((rfsim_dir(proj) / "antenna.json").read_text())
        if a.get("antenna_source") == "user":
            prev = {"net": a["antenna_nets"][0], "feed": f"{a['feed']['ref']}.{a['feed']['pad']}",
                    "ground_mode": a["feed"].get("ground", "auto")}
        elif a.get("antenna_source") == "board" and a.get("subboards"):
            sd = a["subboards"][0]
            bp = Path(sd["board"])
            prev = {"mode": "board", "footprint": sd["footprint"], "feed": f"{a['feed']['ref']}.{a['feed']['pad']}",
                    "board": str(bp if bp.is_absolute() else (rfsim_dir(proj) / bp).resolve()),
                    "input_pad": sd.get("input_pad") or ""}
    except Exception:
        pass
    feed_trace = None
    try:
        tr = json.loads((rfsim_dir(proj) / "antenna.json").read_text())["feed"].get("trace")
        feed_trace = {"offset": tr.get("offset", 0.0)} if tr else None
    except Exception:  # noqa: BLE001
        pass
    band, why = project_band(proj, b)
    return {"candidates": cands, "nets": nets, "pads": pads, "previous": prev, "feed_trace": feed_trace,
            "model_fps": model_footprints(b, nets, proj), "band": band, "band_reason": why}


# ---------------------------------------------------------------------------
# operating band: one definition for all setups of a board
# ---------------------------------------------------------------------------
def project_band(proj: Path, board=None) -> tuple[list | None, str]:
    """The board's operating band (MHz ranges) from its existing setups, or None: the user chooses it
    (there are too many RF chips to guess it from the parts)."""
    for name in ("antenna.json", "rf.json"):
        try:
            b = json.loads((rfsim_dir(proj) / name).read_text()).get("band")
        except Exception:  # noqa: BLE001
            b = None
        if b:
            return [tuple(map(float, r)) for r in b], f"from the existing setup ({name})"
    return None, "choose the operating band of the design"


def _sweep_group(cfg: dict) -> str:
    return "settings" if cfg.get("type") == "antenna" else "model"


def apply_band(proj: Path, ranges) -> list[str]:
    """Write the operating band into every setup of the board (antenna and RF chain get the same
    sweep). Mesh presets and custom mesh values stay. Returns the setup names changed."""
    from kicad_rfsim.pipeline import set_band
    done = []
    for info in list_configs(proj):
        try:
            cfg = json.loads(info.path.read_text())
        except Exception:  # noqa: BLE001
            continue
        set_band(cfg, ranges)
        info.path.write_text(json.dumps(cfg, indent=2))
        done.append(info.path.stem)
    return done


def band_summary(ranges) -> str:
    from kicad_rfsim.bands import derive
    d = derive(ranges)
    a, c = d["antenna"], d["circuit"]
    mhz = lambda xs: ", ".join(f"{x / 1e6:g}" for x in xs)  # noqa: E731
    return f"Sweep {a['f_min'] / 1e6:g}-{a['f_max'] / 1e6:g} MHz, far field at {mhz(a['f_farfield'])} MHz"


def sync_sweep(path: Path) -> list[str]:
    """After the sweep of one setup was edited: give the other setups of the board the same
    f_min / f_max (antenna and RF chain on the same frequencies). Returns the setups changed."""
    path = Path(path)
    cfg = json.loads(path.read_text())
    g = _sweep_group(cfg)
    lo, hi = cfg.get(g, {}).get("f_min"), cfg.get(g, {}).get("f_max")
    if lo is None or hi is None:
        return []
    from kicad_rfsim.pipeline import list_configs as _lc
    done = []
    for p in _lc(path.parent):
        if p.resolve() == path.resolve():
            continue
        try:
            o = json.loads(p.read_text())
        except Exception:  # noqa: BLE001
            continue
        og = _sweep_group(o)
        if o.get(og, {}).get("f_min") == lo and o.get(og, {}).get("f_max") == hi:
            continue
        for t in [o] + ([o["_auto"]] if isinstance(o.get("_auto"), dict) else []):
            t.setdefault(og, {}).update({"f_min": lo, "f_max": hi})
        p.write_text(json.dumps(o, indent=2))
        done.append(p.stem)
    return done


def model_footprints(b, nets, proj: Path) -> list[dict]:
    """Footprints on the RF nets that have a 3D model - candidates for a soldered-in antenna board:
    {ref, step, board (found .kicad_pcb or ""), pads ["REF.PAD" on the RF nets]}."""
    from kicad_rfsim.pipeline import _resolve_model_path, find_subboard_project
    out = []
    for f in b.footprints:
        if not f.models or not any(p.net in nets for p in f.pads):
            continue
        step = _resolve_model_path(f.models[0]["path"], proj)
        sub = None
        try:
            sub = find_subboard_project(step, proj, exclude=getattr(b, "path", None))
        except Exception:  # noqa: BLE001
            pass
        out.append({"ref": f.ref, "step": str(step), "board": str(sub) if sub else "",
                    "pads": [f"{f.ref}.{p.number}" for p in f.pads if p.number and p.net in nets]})
    out.sort(key=lambda d: (0 if d["board"] else 1, d["ref"]))
    return out


def board_pads(path: str) -> list[str]:
    """Pads of an antenna board that are on a net: ["J1.1 (ANT)", ...]."""
    from kicad_rfsim.board import Board
    b = Board(Path(path))
    return [f"{f.ref}.{p.number} ({p.net})" for f in b.footprints for p in f.pads if p.number and p.net]


def create_setup(board, proj: Path, log=print, antenna: dict | None = None, band=None) -> list[SetupSection]:
    """Write antenna.json / rf.json for the current selection (see the plugin docs).

    ``antenna``: None / {"mode": "auto"} = detected antenna, {"mode": "none"} = RF chain only,
    {"mode": "user", "net": ..., "feed": "REF.PAD", "ground_mode": "auto|below|side"}.

    * footprints selected -> small setup: only those parts get ports
    * only traces selected -> the whole RF chain (slow, many ports)
    Earlier custom solver settings of a config with the same name are kept.
    """
    from kicad_rfsim.board import Board
    from kicad_rfsim.pipeline import (build_antenna_model, init_antenna_config, init_config,
                                      init_config_selection, set_band)
    from kicad_rfsim.render import render_model
    from kicad_rfsim.rfpath import find_rf_cluster

    out = rfsim_dir(proj)
    seeds = selected_nets(board)
    refs = selected_refs(board)
    if not seeds:
        raise ValueError("Nothing RF-related is selected. Select the antenna (trace or footprint) and the "
                         "matching parts in the PCB editor, then press Create setup again.")
    log("reading the board (incl. unsaved edits) ...")
    snap, live = board_snapshot(board, proj)
    b = Board(snap)
    rel = os.path.relpath(proj / board.name, out).replace(os.sep, "/")
    cluster = find_rf_cluster(b, seeds)
    if not band:
        band, why = project_band(proj, b)
        if not band:
            from kicad_rfsim.bands import DEFAULT_RANGES
            band, why = list(DEFAULT_RANGES), "no band given - 868 MHz assumed"
        log(f"operating band {', '.join(f'{lo:g}-{hi:g}' for lo, hi in band)} MHz ({why})")
    from kicad_rfsim.antenna_detect import antenna_candidates, render_antenna, user_antenna
    mode = (antenna or {}).get("mode", "auto")
    cands = antenna_candidates(b, cluster.nets, proj)
    if mode == "none":
        ants = []
        if (out / "antenna.json").exists():  # RF chain only: the old antenna setup must not run again
            (out / "antenna.json").replace(out / "antenna.json.off")
    elif mode == "user":
        ants = [user_antenna(b, antenna["net"], antenna["feed"], proj, ground_mode=antenna.get("ground_mode", "auto"))]
    elif mode == "board":  # soldered-in antenna board chosen by the user
        fref, fpad = antenna["feed"].split(".", 1)
        net = b.footprint(fref).pad(fpad).net
        ants = [{"kind": "subboard", "nets": [net], "feed": antenna["feed"], "footprint": antenna["footprint"],
                 "subboard": antenna["board"], "input_pad": antenna.get("input_pad") or None, "source": "board",
                 "accepted": True, "step": antenna.get("step") or "",
                 "reason": f"antenna board {Path(antenna['board']).name} on {antenna['footprint']}, chosen by you"}]
    else:
        ants = [c for c in cands if c["accepted"]]
    detect_txt = "\n".join(f"  {'✓' if c['accepted'] else '✗'} {c['nets'][0]}: {c['reason']}" for c in cands)
    sections = []
    pre = [] if live else ["Could not read unsaved edits - the saved board file was used."]
    # --- antenna
    feed = None
    feed_rf = None
    if ants:
        a = ants[0]
        feed = a["feed"]
        feed_rf = feed
        subs, steps = [], []
        if a["kind"] == "subboard":
            try:
                brel = os.path.relpath(a["subboard"], out).replace(os.sep, "/")
            except ValueError:  # other drive (Windows)
                brel = str(a["subboard"])
            subs = [{"board": brel, "footprint": a["footprint"], "placement": "auto",
                     "input_pad": a.get("input_pad") or None}]
            try:  # keep a hand correction of the placement of the same antenna board
                old = json.loads((out / "antenna.json").read_text()).get("subboards", [])
                if old and old[0].get("board") == brel and old[0].get("footprint") == a["footprint"] and old[0].get("adjust"):
                    subs[0]["adjust"] = old[0]["adjust"]
            except Exception:  # noqa: BLE001
                pass
        elif a["kind"] == "step":
            steps = [{"footprint": a["footprint"], "file": a["step"], "mesh": 0.5}]
        acfg = init_antenna_config(b, a["nets"], feed, name="antenna", board_rel=rel, subboards=subs, step_parts=steps,
                                   ground_mode=a.get("ground_mode", "auto"), band=band)
        trace_note = None
        if (antenna or {}).get("feed_trace"):
            trace_note = _trace_feed(b, board, a, feed, acfg, float((antenna or {}).get("feed_offset", 0.0)), out)
        acfg["antenna_source"] = a.get("source", "detected")
        acfg["antenna_reason"] = a.get("reason", "")
        acfg = set_band(_keep_custom(out / "antenna.json", _remember_auto(acfg)), band)
        (out / "antenna.json").write_text(json.dumps(acfg, indent=2))
        pic = None
        if acfg["feed"].get("trace"):
            a = dict(a, feed_point=(acfg["feed"]["trace"]["x"], acfg["feed"]["trace"]["y"]),
                     feed_trace=acfg["feed"]["trace"], feed=acfg["feed"]["trace"].get("after") or a["feed"])
        try:
            pic = render_antenna(b, a, out / "antenna_setup_preview.png")
        except Exception as e:  # noqa: BLE001
            log(f"antenna picture failed: {e}")
        log("building the antenna model ...")
        msgs = []
        tr = acfg["feed"].get("trace")
        if tr and tr.get("after"):
            feed_rf = tr["after"]  # the RF chain ends at the last matching pad (the antenna load is there)
        head = (f"{'Set by you' if a.get('source') == 'user' else 'Detected'}: {a.get('reason', '')}\n"
                + (f"Feed on the {tr['net']} trace at ({tr['x']:.2f}, {tr['y']:.2f}) mm (after {tr.get('after') or feed}); "
                   f"the matching network behind it is ground in the antenna model" if tr else
                   f"Feed {feed}, net {', '.join(a['nets'])}")
                + (f", ground reference: {a.get('ground_mode')}" if a.get("ground_mode", "auto") != "auto" else "")
                + (f"\n\nCandidates on the RF nets:\n{detect_txt}" if detect_txt else ""))
        try:
            am = build_antenna_model(acfg, out, snap, progress=msgs.append)
            sections.append(SetupSection(f"Antenna ({a['kind']})", head + "\n\n" + "\n".join(msgs) + "\n"
                                         + am.describe(), pic, [m for m in msgs if "WARNING" in m]
                                         + ([trace_note] if trace_note else [])))
        except Exception as e:
            sections.append(SetupSection("Antenna", head, pic, [f"Antenna model could not be built: {e}"]))
    elif mode != "none":
        sections.append(SetupSection("Antenna", "No antenna detected on the RF nets."
                                     + (f"\n\nCandidates:\n{detect_txt}" if detect_txt else "")
                                     + "\n\nIf there is one, choose 'Define antenna' and pick its net and feed pad.",
                                     None, ["No antenna detected - RF chain only."]))
    # --- circuit
    tune_refs = [r for r in refs if not (ants and ants[0].get("footprint") == r)]
    if tune_refs:
        cfg, notes = init_config_selection(b, tune_refs, name="rf", antenna_feed=feed_rf, board_rel=rel, band=band)
        scope = f"selected parts: {', '.join(tune_refs)}"
    else:
        cfg = init_config(b, seeds, name="rf", board_rel=rel, band=band)
        notes = ["No footprints selected - the whole RF chain was taken. This can take hours. "
                 "Select only the parts you want to tune (e.g. Z1, Z2, Z3) and create the setup again."]
        if feed_rf and feed_rf in cfg["ports"]:
            cfg["external"] = (cfg["external"][:1] or [cfg["ports"][0]]) + [feed_rf]
            cfg["load_antenna"] = "antenna.json"
        scope = "whole RF chain"
    path = out / "rf.json"
    cfg = set_band(_keep_custom(path, _remember_auto(cfg)), band)
    cfg = _keep_user_ports(path, cfg, notes)
    cfg = _keep_part_models(path, cfg, b, notes)
    if path.exists():
        path.replace(out / "rf.json.bak")
    path.write_text(json.dumps(cfg, indent=2))
    log("building the RF chain model ...")
    from kicad_rfsim.pipeline import build_circuit_model
    model = build_circuit_model(b, cfg)
    prev = out / "rf_setup_preview.png"
    render_model(model, str(prev), external=cfg["external"])
    from kicad_rfsim.openems_export import _inner_nets, region_cuts
    for cut in region_cuts(b, model.region, _inner_nets(model, cfg["external"]), model.layers):
        notes.append(f"The region boundary cuts {cut['net']} on {cut['layer']} at ({cut['x']}, {cut['y']}) mm - "
                     "the trace ends there in the model. Select the next part too to enlarge the region.")
    from kicad_rfsim.pipeline import off_ground_notes
    notes.extend(off_ground_notes(b, model, cfg["external"]))
    n_exc = sum(1 for p in model.ports if not p.termination)
    sections.insert(0, SetupSection(f"RF chain ({scope})",
                                    f"External ports {' → '.join(cfg['external'])}\n{n_exc} excitations, "
                                    f"{model.n_cells/1e6:.2f} M cells\n\n{model.describe()}", prev, pre + notes))
    log("setup written")
    return sections


def _trace_feed(b, board, a: dict, feed: str, acfg: dict, offset: float, out: Path) -> str | None:
    """Put the feed on the selected antenna trace segment (the one nearest the feed pad).
    Returns a warning text when no segment of the antenna net is selected."""
    from shapely.geometry import Point
    from kicad_rfsim.pipeline import trace_feed
    from rfsim_common import selected_segments
    net = a["nets"][0]
    cands = []
    for seg in selected_segments(board):
        for t in b.tracks:
            if t.net != net or len(t.points) < 2:
                continue
            ends = {(round(t.points[0][0], 3), round(t.points[0][1], 3)), (round(t.points[-1][0], 3), round(t.points[-1][1], 3))}
            if {(round(seg[0][0], 3), round(seg[0][1], 3)), (round(seg[1][0], 3), round(seg[1][1], 3))} == ends:
                cands.append(seg)
    if not cands:
        try:  # the feed point of the last setup on the same net, if it is still on the trace
            old = json.loads((out / "antenna.json").read_text())["feed"].get("trace")
        except Exception:  # noqa: BLE001
            old = None
        if old and old.get("net") == net:
            from kicad_rfsim.pipeline import check_feed
            try:
                check_feed(b, {"ref": "", "pad": "", "trace": old})
                acfg["feed"]["trace"] = old
                return None
            except ValueError:
                pass
        return ("Feed on the selected antenna trace: no segment of the antenna net " + net + " is selected - the "
                "feed is at the pad " + feed + ". Select the antenna trace segment after the matching network too.")
    fr, fp = feed.split(".", 1)
    try:
        pp = b.footprint(fr).pad(fp)
        ref_pt = Point(pp.x, pp.y)
    except KeyError:
        ref_pt = None
    seg = min(cands, key=lambda s: min(Point(*q).distance(ref_pt) for q in s) if ref_pt else 0.0)
    match_pad = None if a["kind"] == "subboard" else feed  # an antenna board's footprint pad is the far end
    acfg["feed"]["trace"] = trace_feed(b, seg, net, feed_pad=match_pad, offset=offset,
                                       exclude=(a.get("footprint"),) if a["kind"] == "subboard" else ())
    return None


def _keep_user_ports(path: Path, new: dict, notes: list) -> dict:
    """External ports set by the user survive a new setup if they are still ports."""
    try:
        old = json.loads(Path(path).read_text())
    except Exception:
        return new
    if old.get("external_source") != "user":
        return new
    ext = [e for e in old.get("external", []) if e in new["ports"]]
    if ext and ext[0] in new["ports"]:
        new["external"], new["external_source"] = ext, "user"
        new["external_reason"] = [f"set by you: {' → '.join(ext)}"]
    else:
        notes.append(f"Your ports {' → '.join(old.get('external', []))} are not ports of the new setup - "
                     "the automatic choice is used.")
    return new


def rf_ports(proj: Path, name: str = "rf.json") -> dict | None:
    """Ports of an RF chain setup: all ports, the external ones and why they were chosen."""
    try:
        cfg = json.loads((rfsim_dir(proj) / name).read_text())
    except Exception:
        return None
    return {"ports": cfg.get("ports", []), "external": cfg.get("external", []),
            "reason": cfg.get("external_reason", []), "source": cfg.get("external_source", "auto")}


def set_external_ports(board, proj: Path, inp: str, outp: str | None, name: str = "rf.json") -> Path:
    """Set the input / output port of an RF chain setup and redraw its picture. The EM result
    stays valid (the ports are combined in the circuit step), so no new EM run is needed."""
    from kicad_rfsim.board import Board
    from kicad_rfsim.render import render_model
    path = rfsim_dir(proj) / name
    cfg = json.loads(path.read_text())
    if inp not in cfg["ports"] or (outp and outp not in cfg["ports"]) or inp == outp:
        raise ValueError("Choose two different ports of this setup.")
    cfg["external"] = [inp] + ([outp] if outp else [])
    cfg["external_source"] = "user"
    cfg["external_reason"] = [f"set by you: {' → '.join(cfg['external'])}"]
    path.write_text(json.dumps(cfg, indent=2))
    snap, _ = board_snapshot(board, proj)
    b = Board(snap)
    from kicad_rfsim.pipeline import build_circuit_model
    model = build_circuit_model(b, cfg)
    prev = rfsim_dir(proj) / "rf_setup_preview.png"
    render_model(model, str(prev), external=cfg["external"])
    return prev


def highlight_in_kicad(board, refs: list[str]) -> int:
    """Select these footprints in the PCB editor (cross-probing). Returns how many were found."""
    want = set(refs)
    items = [fp for fp in board.get_footprints() if fp.reference_field.text.value in want]
    board.clear_selection()
    if items:
        board.add_to_selection(items)
    return len(items)


def _keep_part_models(path: Path, new: dict, board, notes: list) -> dict:
    """Vendor S-parameter files of parts and the port-2 load file survive a new setup; the pads
    of a kept model become EM ports (the model connects there)."""
    try:
        old = json.loads(Path(path).read_text())
    except Exception:
        return new
    if old.get("load_file"):
        new["load_file"] = old["load_file"]
    for ref, m in (old.get("nport_models") or {}).items():
        try:
            fp = board.footprint(ref)
            if not all(any(p.number == q for p in fp.pads) for q in m["pads"]):
                raise KeyError(ref)
        except KeyError:
            notes.append(f"{ref}: vendor model {Path(m['file']).name} dropped - the part or its pads are gone")
            continue
        new.setdefault("nport_models", {})[ref] = m
        for q in m["pads"]:
            if f"{ref}.{q}" not in new["ports"]:
                new["ports"].append(f"{ref}.{q}")
    return new


# ---------------------------------------------------------------------------
# vendor S-parameter files for single parts (switch, balun, filter, chip antenna) and the load
# ---------------------------------------------------------------------------
def circuit_config(proj: Path, prefer: Path | None = None) -> Path | None:
    if prefer is not None and prefer.exists():
        try:
            if json.loads(prefer.read_text()).get("type") != "antenna":
                return prefer
        except Exception:  # noqa: BLE001
            pass
    for c in list_configs(proj):
        if c.kind == "circuit":
            return c.path
    return None


def touchstone_ports(path: str) -> int:
    import re
    m = re.search(r"\.s(\d+)p$", str(path), re.I)
    if m:
        return int(m.group(1))
    import skrf as rf
    return rf.Network(str(path)).nports


def part_pad_choices(cfg_path: Path, ref: str) -> list[str]:
    """Pads of a part ("1 (NET)"), signal pads first, ground pads last."""
    from kicad_rfsim.board import Board
    cfg = json.loads(Path(cfg_path).read_text())
    b = Board((Path(cfg_path).parent / cfg["board"]).resolve())
    fp = b.footprint(ref)
    gnd = set(Board._GND_NAMES) | ({b.ground_alias} if b.ground_alias else set())
    pads = [p for p in fp.pads if p.number]
    pads.sort(key=lambda p: (p.net in gnd or not p.net, _padkey(p.number)))
    return [f"{p.number} ({p.net or 'no net'})" for p in pads]


def _padkey(n: str):
    import re
    m = re.match(r"(\d+)", n)
    return (0, int(m.group(1)), n) if m else (1, 0, n)


def model_parts(cfg_path: Path) -> list[str]:
    """Parts a model can be given to: the parts of the setup (their pads are EM ports)."""
    cfg = json.loads(Path(cfg_path).read_text())
    refs = list(cfg.get("selection", []))
    for q in cfg.get("ports", []):
        r = q.split(".")[0]
        if r not in refs:
            refs.append(r)
    return refs


def assign_part_model(cfg_path: Path, ref: str, file: str, pads: list[str]) -> list[str]:
    """Give ``ref`` the vendor S-parameters ``file`` (port k of the file on pad pads[k]). Pads
    that are no EM port yet become ports (the next run repeats the EM simulation)."""
    cfg_path = Path(cfg_path)
    cfg = json.loads(cfg_path.read_text())
    n = touchstone_ports(file)
    if n != len(pads):
        raise ValueError(f"{Path(file).name} has {n} ports, {len(pads)} pads were given")
    if len(set(pads)) != len(pads):
        raise ValueError("each port needs its own pad")
    try:
        rel = os.path.relpath(file, cfg_path.parent).replace(os.sep, "/")
    except ValueError:
        rel = str(file)
    notes = []
    cfg.setdefault("nport_models", {})[ref] = {"file": rel, "pads": list(pads)}
    added = [f"{ref}.{q}" for q in pads if f"{ref}.{q}" not in cfg["ports"]]
    cfg["ports"] += added
    if added:
        notes.append(f"pads {', '.join(added)} added as EM ports - the next run repeats the EM simulation")
    cfg_path.write_text(json.dumps(cfg, indent=2))
    return notes


def remove_part_model(cfg_path: Path, ref: str):
    cfg = json.loads(Path(cfg_path).read_text())
    (cfg.get("nport_models") or {}).pop(ref, None)
    Path(cfg_path).write_text(json.dumps(cfg, indent=2))


def set_load_file(cfg_path: Path, file: str | None):
    cfg_path = Path(cfg_path)
    cfg = json.loads(cfg_path.read_text())
    if file:
        try:
            cfg["load_file"] = os.path.relpath(file, cfg_path.parent).replace(os.sep, "/")
        except ValueError:
            cfg["load_file"] = str(file)
    else:
        cfg.pop("load_file", None)
    cfg_path.write_text(json.dumps(cfg, indent=2))


def part_models(cfg_path: Path) -> dict:
    cfg = json.loads(Path(cfg_path).read_text())
    lf = cfg.get("load_file")
    if lf and not Path(lf).is_absolute():
        lf = str((Path(cfg_path).parent / lf).resolve())
    out = {}
    for ref, m in (cfg.get("nport_models") or {}).items():
        f = m["file"] if Path(m["file"]).is_absolute() else str((Path(cfg_path).parent / m["file"]).resolve())
        out[ref] = {"file": f, "pads": m["pads"]}
    return {"models": out, "load_file": lf}


def _keep_custom(path: Path, new: dict) -> dict:
    """If the old config had custom solver settings, carry them over to the new setup."""
    try:
        old = json.loads(Path(path).read_text())
    except Exception:
        return new
    if solver_mode(old) != "custom":
        return new
    kind = "antenna" if new.get("type") == "antenna" else "circuit"
    for g in GROUPS[kind]:
        if g in old:
            new[g] = copy.deepcopy(old[g])
    return new


# ---------------------------------------------------------------------------
# tuned values -> footprints
# ---------------------------------------------------------------------------
def describe_change(v: dict) -> str:
    m = v.get("mode", "fit")
    if m == "open":
        return "not fitted (DNP)"
    if m == "short":
        return "0R (bridged)"
    return v.get("text", "") + (f" ({v['mpn']})" if v.get("mpn") else "")


_WIN_CODES = {0xC0000005: "crash (access violation)", 0xC00000FD: "stack overflow", 0xC0000374: "heap corruption",
              0xC0000017: "out of memory", 0xC000013A: "stopped (Ctrl+C / closed)", 0xC0000409: "crash (stack buffer)"}


def explain_error(e: Exception) -> str:
    """A message for the user instead of a Python exception text."""
    import subprocess
    if isinstance(e, subprocess.CalledProcessError):
        code = e.returncode & 0xFFFFFFFF if e.returncode is not None else 0
        what = _WIN_CODES.get(code, f"exit code {e.returncode}")
        exe = Path(str(e.cmd[0])).name if e.cmd else "solver"
        tail = ""
        out = str(e.output or "")
        if out.startswith("see "):
            try:
                lines = Path(out[4:]).read_text(encoding="utf-8", errors="replace").splitlines()
                tail = "\n".join(l for l in lines[-12:] if l.strip())
            except OSError:
                pass
        hint = ("Too little memory: use the Fast preset or a smaller region." if "memory" in what else
                "Run it again; if it repeats, the openEMS log in the result folder shows where it stopped.")
        return f"{exe} stopped with an error: {what}.\n{hint}" + (f"\n\nLast lines of its log:\n{tail}" if tail else "")
    if isinstance(e, MemoryError):
        return "Not enough memory for this model. Use the Fast preset (Solver Settings) or a smaller region."
    if isinstance(e, KeyError) and str(e).strip("'\"").endswith(".Cu"):
        return (f"The setup refers to the copper layer {e} that this board does not have. "
                "Create the setup again on the Setup page.")
    if isinstance(e, FileNotFoundError) and "openEMS" in str(e):
        return "openEMS was not found. Select openEMS.exe on the Solver Settings page."
    return str(e)


MPN_FIELDS = ("mpn", "part number", "manufacturer part number", "manufacturer_part_number", "mfr part number", "pn")


def set_part_number(fp, pn: str) -> bool:
    """Write the vendor part number into an existing MPN-like field of the footprint."""
    for t in getattr(fp, "texts_and_fields", []) or []:
        name = str(getattr(t, "name", "") or "").strip().lower()
        if name in MPN_FIELDS and hasattr(t, "text"):
            try:
                t.text.value = pn
                return True
            except Exception:  # noqa: BLE001
                return False
    return False


def apply_values(board, data: dict) -> list[tuple[str, str, str, str]]:
    """Write changes from the tuning viewer to the footprints in one undo step.

    mode "fit": value text (and DNP off), "open": DNP on (value kept),
    "short": value "0R" (DNP off). Returns rows (ref, old, new, status)."""
    wanted = {ref: v for ref, v in data.get("values", {}).items() if v.get("changed")}
    fps = {fp.reference_field.text.value: fp for fp in board.get_footprints()}
    changed, rows = [], []
    for ref, v in wanted.items():
        fp = fps.get(ref)
        new = describe_change(v)
        if fp is None:
            rows.append((ref, "", new, "not on the board"))
            continue
        old_val = fp.value_field.text.value
        attrs = getattr(fp, "attributes", None)
        old_dnp = bool(getattr(attrs, "do_not_populate", False)) if attrs is not None else False
        old = old_val + (" (DNP)" if old_dnp else "")
        m = v.get("mode", "fit")
        want_dnp = m == "open"
        want_val = old_val if m == "open" else ("0R" if m == "short" else v.get("text", old_val))
        mpn = v.get("mpn") if m == "fit" else None
        mpn_note = ""
        if mpn:
            done = set_part_number(fp, mpn)
            mpn_note = f"; part number {mpn}" if done else f"; add the part number {mpn} by hand (no MPN field)"
            if done:
                changed.append(fp)
        if want_val == old_val and want_dnp == old_dnp:
            rows.append((ref, old, new, ("unchanged" + mpn_note) if mpn_note else "unchanged"))
            continue
        fp.value_field.text.value = want_val
        status = "changed" + mpn_note
        k = v.get("kind") if m == "fit" else None
        if k and not ref.upper().startswith(k):
            what = {"C": "capacitor", "L": "inductor"}.get(k, k)
            status += f"; now a {what} - check its symbol and footprint"
        if want_dnp != old_dnp:
            if attrs is not None and hasattr(attrs, "do_not_populate"):
                attrs.do_not_populate = want_dnp
            else:
                status = "changed (set DNP by hand: this KiCad API has no DNP attribute)"
        if fp not in changed:
            changed.append(fp)
        rows.append((ref, old, new, status))
    if changed:
        commit = board.begin_commit()
        board.update_items(changed)
        board.push_commit(commit, "RF Sim: apply tuned values")
    return rows


def newest_values_file(proj: Path) -> Path | None:
    cands = list((Path.home() / "Downloads").glob("rfsim_values*.json")) + list(rfsim_dir(proj).glob("rfsim_values*.json"))
    return max(cands, key=lambda p: p.stat().st_mtime) if cands else None


def fmt_time(t: float | None) -> str:
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(t)) if t else "-"


def fmt_when(t: float | None) -> str:
    """Short time for lists: 14:33 today, 30.10. 14:33 this year, else 2025-10-30."""
    if not t:
        return "-"
    lt, now = time.localtime(t), time.localtime()
    if lt[:3] == now[:3]:
        return time.strftime("%H:%M", lt)
    return time.strftime("%d.%m. %H:%M" if lt.tm_year == now.tm_year else "%Y-%m-%d", lt)


def result_status(rec: dict | None) -> tuple[str, str]:
    """(text, level) of a result for the Results list: level ok / warn / none."""
    if not rec:
        return "-", "none"
    if any(not c.get("ok", True) for c in rec.get("checks", [])):
        return "check failed", "warn"
    runs = rec.get("runs", [])
    if runs and not all(r.get("converged") for r in runs):
        return "not settled", "warn"
    if any("unstable" in str(r.get("stop_reason")) for r in runs):
        return "unstable", "warn"
    return ("ok" if runs else "-"), ("ok" if runs else "none")
